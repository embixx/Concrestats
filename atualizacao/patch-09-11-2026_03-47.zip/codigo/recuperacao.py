# -*- coding: utf-8 -*-
"""Copia local do que ainda nao foi salvo.

Pedido do Naor: "quando uma alteracao foi feita, salvar localmente e/ou caso eu
feche o app ele apareca a mensagem". A pergunta so' resolve quem fecha pelo X. Na
maquina dele quem fecha, as vezes, e' o antivirus: a edicao morava so' na memoria
e ia junto. Aqui ela vai para o disco alguns segundos depois de cada mudanca, e
fechar direito apaga a copia. Se o arquivo existe na abertura, o programa caiu.

Fica em %LOCALAPPDATA%, como a marca de sessao: arquivo regravado o tempo todo nao
mora em pasta sincronizada. Um por instalacao, pelo mesmo motivo.
"""
import gzip
import hashlib
import json
import os
import threading
import time

import laboratorio

ESPERA = 3.0
_trava = threading.Lock()
_estado = {"sess": None, "timer": None, "manter": False, "base": ""}


def configurar(base):
    _estado["base"] = base


def _arquivo():
    marca = hashlib.sha1(os.path.normcase(_estado["base"]).encode("utf-8")).hexdigest()[:10]
    return os.path.join(laboratorio.pasta(), "recuperacao-%s.json.gz" % marca)


def guardar(sess):
    """Marca que mudou. A gravacao espera: digitar 20 celulas grava uma vez so'."""
    with _trava:
        _estado["sess"] = sess
        if _estado["timer"] is None:
            t = threading.Timer(ESPERA, gravar_agora)
            t.daemon = True
            _estado["timer"] = t
            t.start()


def gravar_agora():
    with _trava:
        sess, _estado["timer"] = _estado["sess"], None
        if sess is None:
            return
        demo = set(sess.get("demo") or [])
        abas = {n: p for n, p in dict(sess.get("sheets") or {}).items() if n not in demo}
        if not abas:
            return
        corpo = {"quando": time.strftime("%Y-%m-%dT%H:%M:%S"), "path": sess.get("path") or "",
                 "copia": bool(sess.get("copia")), "ativa": sess.get("active"), "abas": abas,
                 "abas_origem": sess.get("abas_origem") or [], "topos": sess.get("topos") or {}}
        arq = _arquivo()
        tmp = arq + ".tmp"
        try:
            with gzip.open(tmp, "wt", encoding="utf-8") as f:
                json.dump(corpo, f, ensure_ascii=False)
            os.replace(tmp, arq)
        except OSError:
            pass                      # sem copia hoje; a edicao segue na memoria


def apagar():
    """Salvou, ou fechou de proposito: nao ha' o que recuperar."""
    with _trava:
        if _estado["timer"] is not None:
            _estado["timer"].cancel()
        _estado["timer"] = None
        _estado["sess"] = None
        if _estado["manter"]:
            return
        try:
            os.remove(_arquivo())
        except OSError:
            pass


def manter():
    """A tela nao respondeu ao X: fecha, mas ninguem decidiu jogar a edicao fora."""
    _estado["manter"] = True


def ler():
    try:
        with gzip.open(_arquivo(), "rt", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError, EOFError):
        return None
