# -*- coding: utf-8 -*-
"""Calcula as formulas de uma planilha do Excel sem o Excel.

O Concrestats mostrava o resultado que o Excel deixou guardado no arquivo e
nunca refazia a conta: mudar um preco em "Premissas" nao mexia na simulacao, e
o Salvar (openpyxl) gravava as formulas sem resultado nenhum - ao reabrir,
toda celula com formula aparecia vazia.

Aqui fica o motor: le formulas e valores do .xlsx, recalcula o que depende de
cada celula editada, na ordem certa, e devolve os resultados para a tela e para
o arquivo (gravar_resultados poe o valor ao lado da formula, como o Excel faz).

So' usa openpyxl e biblioteca padrao. O exe que esta' na mao dos clientes so'
tem o que foi importado quando ele foi compilado, e a atualizacao troca o nosso
codigo, nao as bibliotecas.

Formula com funcao que o motor nao conhece nao e' inventada: fica com o ultimo
valor que o Excel calculou, e a funcao aparece em `Pasta.faltando`.
"""
import bisect
import datetime
import math
import os
import re
import zipfile
from decimal import Decimal, ROUND_DOWN, ROUND_HALF_UP, ROUND_UP, InvalidOperation
from xml.sax.saxutils import escape

from openpyxl.formula.tokenizer import Token, Tokenizer
from openpyxl.utils import column_index_from_string


# ---------------------------------------------------------------- valores
class Erro(object):
    __slots__ = ("codigo",)

    def __init__(self, codigo):
        self.codigo = codigo

    def __eq__(self, outro):
        return isinstance(outro, Erro) and outro.codigo == self.codigo

    def __hash__(self):
        return hash(self.codigo)

    def __repr__(self):
        return self.codigo


DIV0, VALOR, NA, REF, NOME, NUM = (Erro(c) for c in (
    "#DIV/0!", "#VALUE!", "#N/A", "#REF!", "#NAME?", "#NUM!"))
ERROS = {e.codigo: e for e in (DIV0, VALOR, NA, REF, NOME, NUM, Erro("#NULL!"))}


class NaoSei(Exception):
    """O motor nao sabe calcular isto: a celula fica com o valor do Excel."""


class _ErroSobe(Exception):
    def __init__(self, erro):
        Exception.__init__(self, erro.codigo)
        self.erro = erro


class Matriz(object):
    __slots__ = ("linhas",)

    def __init__(self, linhas):
        self.linhas = linhas

    @property
    def altura(self):
        return len(self.linhas)

    @property
    def largura(self):
        return len(self.linhas[0]) if self.linhas else 0

    def todos(self):
        for linha in self.linhas:
            for v in linha:
                yield v


class Faixa(object):
    __slots__ = ("aba", "r1", "c1", "r2", "c2")

    def __init__(self, aba, r1, c1, r2, c2):
        self.aba, self.r1, self.c1, self.r2, self.c2 = aba, r1, c1, r2, c2

    @property
    def altura(self):
        return self.r2 - self.r1 + 1

    @property
    def largura(self):
        return self.c2 - self.c1 + 1

    def contem(self, r, c):
        return self.r1 <= r <= self.r2 and self.c1 <= c <= self.c2


DIA_ZERO = datetime.datetime(1899, 12, 30)


def serial(v):
    """data/hora do Python -> numero de serie do Excel."""
    if isinstance(v, datetime.datetime):
        d = v - DIA_ZERO
        return d.days + d.seconds / 86400.0 + d.microseconds / 86400e6
    if isinstance(v, datetime.date):
        return float((v - DIA_ZERO.date()).days)
    if isinstance(v, datetime.time):
        return (v.hour * 3600 + v.minute * 60 + v.second) / 86400.0
    if isinstance(v, datetime.timedelta):
        return v.total_seconds() / 86400.0
    return v


def data_de(n):
    n = float(n)
    if n < 0 or n > 2958465:
        raise _ErroSobe(NUM)
    return DIA_ZERO + datetime.timedelta(days=n)


def normal(v):
    """O que o Excel guardaria: 15 algarismos, sem -0, sem infinito."""
    if isinstance(v, bool) or v is None or isinstance(v, (str, Erro)):
        return v
    if isinstance(v, (int, float)):
        f = float(v)
        if math.isnan(f) or math.isinf(f):
            return NUM
        if f == 0:
            return 0.0
        return float("%.15g" % f)
    return v


# ------------------------------------------------------------- coercao
_RE_NUM_BR = re.compile(r"^[-+]?(\d{1,3}(\.\d{3})+|\d+)(,\d+)?$")


def _texto_para_numero(s):
    t = s.strip()
    if not t:
        raise _ErroSobe(VALOR)
    pct = t.endswith("%")
    if pct:
        t = t[:-1].strip()
    try:
        n = float(t)
    except ValueError:
        if _RE_NUM_BR.match(t):
            n = float(t.replace(".", "").replace(",", "."))
        else:
            raise _ErroSobe(VALOR)
    if math.isnan(n) or math.isinf(n):
        raise _ErroSobe(VALOR)
    return n / 100 if pct else n


def num(v):
    if isinstance(v, bool):
        return 1.0 if v else 0.0
    if isinstance(v, (int, float)):
        return float(v)
    if v is None or v is VAZIO:
        return 0.0
    if isinstance(v, Erro):
        raise _ErroSobe(v)
    if isinstance(v, str):
        return _texto_para_numero(v)
    raise _ErroSobe(VALOR)


def texto_num(n):
    """Numero -> texto, como o Excel em portugues faz ao concatenar."""
    n = normal(n)
    if isinstance(n, Erro):
        raise _ErroSobe(n)
    if n == int(n) and abs(n) < 1e15:
        return "%d" % n
    t = "%.15g" % n
    if "e" in t:
        m, e = t.split("e")
        t = "%sE%s%02d" % (m, e[0], abs(int(e)))
    return t.replace(".", ",")


def txt(v):
    if isinstance(v, str):
        return v
    if v is None:
        return ""
    if isinstance(v, bool):
        return "VERDADEIRO" if v else "FALSO"
    if isinstance(v, Erro):
        raise _ErroSobe(v)
    return texto_num(v)


def logico(v):
    if isinstance(v, bool):
        return v
    if v is None:
        return False
    if isinstance(v, (int, float)):
        return v != 0
    if isinstance(v, Erro):
        raise _ErroSobe(v)
    s = v.strip().upper()
    if s in ("TRUE", "VERDADEIRO"):
        return True
    if s in ("FALSE", "FALSO"):
        return False
    raise _ErroSobe(VALOR)


def _ordem_tipo(v):
    if isinstance(v, bool):
        return 2
    if isinstance(v, str):
        return 1
    return 0


def comparar(a, b):
    """-1, 0, 1 com as regras do Excel (numero < texto < logico)."""
    if isinstance(a, Erro):
        raise _ErroSobe(a)
    if isinstance(b, Erro):
        raise _ErroSobe(b)
    if a is None:
        a = "" if isinstance(b, str) else (False if isinstance(b, bool) else 0.0)
    if b is None:
        b = "" if isinstance(a, str) else (False if isinstance(a, bool) else 0.0)
    ta, tb = _ordem_tipo(a), _ordem_tipo(b)
    if ta != tb:
        return -1 if ta < tb else 1
    if ta == 1:
        a, b = a.casefold(), b.casefold()
    elif ta == 0:
        a, b = normal(a), normal(b)
    return (a > b) - (a < b)


# ---------------------------------------------------------------- parser
_RE_REF = re.compile(
    r"^(?:(?:'((?:[^']|'')+)'|([^'!:\[\]]+))!)?"
    r"(\$?[A-Za-z]{1,3}\$?\d+|\$?[A-Za-z]{1,3}|\$?\d+)"
    r"(?::(\$?[A-Za-z]{1,3}\$?\d+|\$?[A-Za-z]{1,3}|\$?\d+))?$")
_RE_CEL = re.compile(r"^\$?([A-Za-z]{1,3})?\$?(\d+)?$")
MAX_LIN, MAX_COL = 1048576, 16384


def _ponta(t):
    m = _RE_CEL.match(t)
    col = column_index_from_string(m.group(1).upper()) if m.group(1) else None
    lin = int(m.group(2)) if m.group(2) else None
    return lin, col


def ler_ref(texto, aba_atual):
    """'Aba'!A1:B2 -> (aba, r1, c1, r2, c2) ou None se nao for referencia."""
    m = _RE_REF.match(texto)
    if not m:
        return None
    aba = m.group(1).replace("''", "'") if m.group(1) else (m.group(2) or aba_atual)
    a, b = m.group(3), m.group(4)
    r1, c1 = _ponta(a)
    if b is None:
        if r1 is None or c1 is None:
            return None
        return (aba, r1, c1, r1, c1)
    r2, c2 = _ponta(b)
    if (r1 is None) != (r2 is None) or (c1 is None) != (c2 is None):
        return None
    if c1 is None:                       # 3:5 linhas inteiras
        c1, c2 = 1, MAX_COL
    if r1 is None:                       # A:C colunas inteiras
        r1, r2 = 1, MAX_LIN
    return (aba, min(r1, r2), min(c1, c2), max(r1, r2), max(c1, c2))


class _Leitor(object):
    def __init__(self, tokens, aba):
        self.t, self.i, self.aba = tokens, 0, aba

    def olha(self):
        return self.t[self.i] if self.i < len(self.t) else None

    def anda(self):
        tk = self.t[self.i]
        self.i += 1
        return tk

    def eh(self, tipo, sub=None, valor=None):
        tk = self.olha()
        return (tk is not None and tk.type == tipo and (sub is None or tk.subtype == sub)
                and (valor is None or tk.value == valor))

    def expr(self):
        a = self.concat()
        while self.eh(Token.OP_IN) and self.olha().value in ("=", "<>", "<", ">", "<=", ">="):
            op = self.anda().value
            a = ("op", op, a, self.concat())
        return a

    def concat(self):
        a = self.soma()
        while self.eh(Token.OP_IN, valor="&"):
            self.anda()
            a = ("op", "&", a, self.soma())
        return a

    def soma(self):
        a = self.produto()
        while self.eh(Token.OP_IN) and self.olha().value in ("+", "-"):
            op = self.anda().value
            a = ("op", op, a, self.produto())
        return a

    def produto(self):
        a = self.potencia()
        while self.eh(Token.OP_IN) and self.olha().value in ("*", "/"):
            op = self.anda().value
            a = ("op", op, a, self.potencia())
        return a

    def potencia(self):
        a = self.unario()
        while self.eh(Token.OP_IN, valor="^"):
            self.anda()
            a = ("op", "^", a, self.unario())
        return a

    def unario(self):
        if self.eh(Token.OP_PRE):
            op = self.anda().value
            a = self.unario()
            return ("neg", a) if op == "-" else ("pos", a)
        a = self.primario()
        while self.eh(Token.OP_POST, valor="%"):
            self.anda()
            a = ("pct", a)
        return a

    def argumentos(self):
        args = []
        if self.eh(Token.FUNC, Token.CLOSE):
            self.anda()
            return args
        while True:
            if self.eh(Token.SEP, Token.ARG) or self.eh(Token.FUNC, Token.CLOSE):
                args.append(("vazio",))
            else:
                args.append(self.expr())
            if self.eh(Token.SEP, Token.ARG):
                self.anda()
                continue
            if self.eh(Token.FUNC, Token.CLOSE):
                self.anda()
                return args
            raise NaoSei("argumento")

    def primario(self):
        tk = self.olha()
        if tk is None:
            raise NaoSei("formula incompleta")
        if tk.type == Token.FUNC and tk.subtype == Token.OPEN:
            self.anda()
            nome = tk.value[:-1].upper()
            for p in ("_XLFN._XLWS.", "_XLFN.", "_XLWS."):
                if nome.startswith(p):
                    nome = nome[len(p):]
            return ("f", nome, self.argumentos())
        if tk.type == Token.PAREN and tk.subtype == Token.OPEN:
            self.anda()
            a = self.expr()
            if not self.eh(Token.PAREN, Token.CLOSE):
                raise NaoSei("parenteses")
            self.anda()
            return a
        if tk.type == Token.ARRAY and tk.subtype == Token.OPEN:
            self.anda()
            linhas, linha = [], []
            while True:
                linha.append(self.expr())
                if self.eh(Token.SEP, Token.ARG):
                    self.anda()
                elif self.eh(Token.SEP, Token.ROW):
                    self.anda()
                    linhas.append(linha)
                    linha = []
                elif self.eh(Token.ARRAY, Token.CLOSE):
                    self.anda()
                    linhas.append(linha)
                    return ("arr", linhas)
                else:
                    raise NaoSei("matriz")
        if tk.type == Token.OPERAND:
            self.anda()
            v = tk.value
            if tk.subtype == Token.NUMBER:
                return ("v", float(v))
            if tk.subtype == Token.TEXT:
                return ("v", v[1:-1].replace('""', '"'))
            if tk.subtype == Token.LOGICAL:
                return ("v", v.upper() == "TRUE")
            if tk.subtype == Token.ERROR:
                return ("v", ERROS.get(v.upper(), VALOR))
            ref = ler_ref(v, self.aba)
            if ref:
                return ("ref",) + ref
            if "[" in v:
                raise NaoSei("referencia externa ou tabela")
            if "!" in v:
                aba, _, nome = v.rpartition("!")
                return ("nome", nome.upper(), aba.strip("'").replace("''", "'"))
            return ("nome", v.upper(), None)
        raise NaoSei("token %s" % tk.value)


def compilar(texto, aba):
    tokens = [t for t in Tokenizer(texto).items if t.type != Token.WSPACE]
    leitor = _Leitor(tokens, aba)
    arvore = leitor.expr()
    if leitor.olha() is not None:
        raise NaoSei("sobrou %s" % leitor.olha().value)
    return arvore


VOLATEIS = {"TODAY", "NOW", "RAND", "RANDBETWEEN", "OFFSET", "INDIRECT", "CELL", "INFO"}


def _percorrer(no, refs, nomes, flags):
    tipo = no[0]
    if tipo == "ref":
        refs.append(no[1:])
    elif tipo == "nome":
        nomes.append(no)
    elif tipo == "f":
        if no[1] in VOLATEIS:
            flags.add("volatil")
        flags.add("f:" + no[1])
        for a in no[2]:
            _percorrer(a, refs, nomes, flags)
    elif tipo == "op":
        _percorrer(no[2], refs, nomes, flags)
        _percorrer(no[3], refs, nomes, flags)
    elif tipo in ("neg", "pos", "pct"):
        _percorrer(no[1], refs, nomes, flags)
    elif tipo == "arr":
        for linha in no[1]:
            for a in linha:
                _percorrer(a, refs, nomes, flags)


# ------------------------------------------------------------- avaliacao
class _Vazio(object):
    """Argumento em branco: ROUND(x;) ou SE(a;;b)."""


VAZIO = _Vazio()


class _Ctx(object):
    __slots__ = ("pasta", "aba", "lin", "col")

    def __init__(self, pasta, aba, lin, col):
        self.pasta, self.aba, self.lin, self.col = pasta, aba, lin, col


def matriz(x, ctx):
    """Qualquer coisa -> Matriz (referencia vira os valores dela)."""
    if isinstance(x, Faixa):
        return ctx.pasta.ler_faixa(x)
    if isinstance(x, Matriz):
        return x
    return Matriz([[None if x is VAZIO else x]])


def valor(x, ctx):
    """Referencia de uma celula vira o valor; faixa maior vira Matriz."""
    if isinstance(x, Faixa):
        if x.r1 == x.r2 and x.c1 == x.c2:
            return ctx.pasta.ler(x.aba, x.r1, x.c1)
        return ctx.pasta.ler_faixa(x)
    if isinstance(x, Matriz) and x.altura == 1 and x.largura == 1:
        return x.linhas[0][0]
    if x is VAZIO:
        return None
    return x


def _pega(v, i, j):
    if not isinstance(v, Matriz):
        return v
    if v.altura == 1:
        i = 0
    if v.largura == 1:
        j = 0
    if i >= v.altura or j >= v.largura:
        return NA
    return v.linhas[i][j]


def _espalhar(fn, vals):
    """Aplica fn celula a celula quando algum argumento e' matriz."""
    ms = [v for v in vals if isinstance(v, Matriz)]
    if not ms:
        return fn(*vals)
    h = max(m.altura for m in ms)
    w = max(m.largura for m in ms)
    return Matriz([[fn(*[_pega(v, i, j) for v in vals]) for j in range(w)] for i in range(h)])


def _seguro(fn):
    def f(*a):
        try:
            return fn(*a)
        except _ErroSobe as e:
            return e.erro
        except ZeroDivisionError:
            return DIV0
        except (OverflowError, ValueError):
            return NUM
    return f


def _aritm(op, a, b):
    if isinstance(a, Erro):
        return a
    if isinstance(b, Erro):
        return b
    if op == "&":
        return txt(a) + txt(b)
    if op in ("=", "<>", "<", ">", "<=", ">="):
        c = comparar(a, b)
        return {"=": c == 0, "<>": c != 0, "<": c < 0, ">": c > 0,
                "<=": c <= 0, ">=": c >= 0}[op]
    x, y = num(a), num(b)
    if op == "+":
        return x + y
    if op == "-":
        return x - y
    if op == "*":
        return x * y
    if op == "/":
        if y == 0:
            return DIV0
        return x / y
    if op == "^":
        if x == 0 and y < 0:
            return DIV0
        if x < 0 and y != int(y):
            return NUM
        return x ** y
    raise NaoSei(op)


_ARIT = _seguro(_aritm)


def avaliar(no, ctx):
    tipo = no[0]
    if tipo == "v":
        return no[1]
    if tipo == "ref":
        return Faixa(*no[1:])
    if tipo == "op":
        a = valor(avaliar(no[2], ctx), ctx)
        b = valor(avaliar(no[3], ctx), ctx)
        op = no[1]
        return _espalhar(lambda x, y: _ARIT(op, x, y), [a, b])
    if tipo == "neg":
        return _espalhar(_seguro(lambda x: x if isinstance(x, Erro) else -num(x)),
                         [valor(avaliar(no[1], ctx), ctx)])
    if tipo == "pos":
        return valor(avaliar(no[1], ctx), ctx)
    if tipo == "pct":
        return _espalhar(_seguro(lambda x: x if isinstance(x, Erro) else num(x) / 100),
                         [valor(avaliar(no[1], ctx), ctx)])
    if tipo == "f":
        item = FUNCOES.get(no[1])
        if item is None:
            raise NaoSei(no[1])
        fn, modo = item
        if modo == "lazy":
            return fn(no[2], ctx)
        args = [VAZIO if a[0] == "vazio" else avaliar(a, ctx) for a in no[2]]
        return fn(args, ctx)
    if tipo == "arr":
        return Matriz([[valor(avaliar(a, ctx), ctx) for a in linha] for linha in no[1]])
    if tipo == "nome":
        return ctx.pasta.avaliar_nome(no[1], no[2] or ctx.aba, ctx)
    if tipo == "vazio":
        return None
    raise NaoSei(tipo)


# ------------------------------------------------------------- funcoes
FUNCOES = {}


def cru(*nomes):
    def dec(fn):
        for n in nomes:
            FUNCOES[n] = (fn, "cru")
        return fn
    return dec


def preguica(*nomes):
    def dec(fn):
        for n in nomes:
            FUNCOES[n] = (fn, "lazy")
        return fn
    return dec


def escalar(*nomes, **kw):
    """Funcao de uma celula: vale para matriz celula a celula; erro sobe."""
    aceita_erro = kw.get("aceita_erro", False)
    minimo = kw.get("minimo", 0)

    def dec(fn):
        def chama(*vals):
            if not aceita_erro:
                for v in vals:
                    if isinstance(v, Erro):
                        return v
            try:
                return fn(*vals)
            except _ErroSobe as e:
                return e.erro
            except ZeroDivisionError:
                return DIV0
            except (OverflowError, ValueError):
                return NUM

        def rodar(args, ctx):
            if len(args) < minimo:
                return VALOR
            vals = [VAZIO if a is VAZIO else valor(a, ctx) for a in args]
            return _espalhar(chama, vals)
        for n in nomes:
            FUNCOES[n] = (rodar, "cru")
        return fn
    return dec


def _opc(vals, i, padrao):
    if i >= len(vals) or vals[i] is VAZIO:
        return padrao
    return vals[i]


def _numeros(args, ctx):
    """Os numeros dos argumentos, como SOMA e MEDIA enxergam: em referencia e
    matriz so' conta numero; valor digitado direto e' convertido."""
    for a in args:
        if a is VAZIO:
            continue
        if isinstance(a, (Faixa, Matriz)):
            for v in matriz(a, ctx).todos():
                if isinstance(v, Erro):
                    raise _ErroSobe(v)
                if isinstance(v, (int, float)) and not isinstance(v, bool):
                    yield float(v)
        else:
            if isinstance(a, Erro):
                raise _ErroSobe(a)
            yield num(a)


def _agregar(fn):
    def rodar(args, ctx):
        try:
            return fn(list(_numeros(args, ctx)))
        except _ErroSobe as e:
            return e.erro
        except ZeroDivisionError:
            return DIV0
        except (OverflowError, ValueError):
            return NUM
    return rodar


def _media(xs):
    if not xs:
        raise _ErroSobe(DIV0)
    return sum(xs) / len(xs)


def _var(xs, amostra):
    n = len(xs)
    if n - (1 if amostra else 0) <= 0:
        raise _ErroSobe(DIV0)
    m = sum(xs) / n
    return sum((x - m) ** 2 for x in xs) / (n - 1 if amostra else n)


def _mediana(xs):
    if not xs:
        raise _ErroSobe(NUM)
    s = sorted(xs)
    n = len(s)
    return s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2


def _percentil(xs, k):
    if not xs or k < 0 or k > 1:
        raise _ErroSobe(NUM)
    s = sorted(xs)
    pos = k * (len(s) - 1)
    i = int(math.floor(pos))
    if i + 1 >= len(s):
        return s[-1]
    return s[i] + (pos - i) * (s[i + 1] - s[i])


def _moda(xs):
    melhor, vezes = None, 1
    for x in xs:
        c = xs.count(x)
        if c > vezes:
            melhor, vezes = x, c
    if melhor is None:
        raise _ErroSobe(NA)
    return melhor


def _produto(xs):
    p = 1.0
    for x in xs:
        p *= x
    return p if xs else 0.0


for _n, _f in (("SUM", sum), ("AVERAGE", _media),
               ("MIN", lambda xs: min(xs) if xs else 0.0),
               ("MAX", lambda xs: max(xs) if xs else 0.0),
               ("MEDIAN", _mediana),
               ("STDEV", lambda xs: math.sqrt(_var(xs, True))),
               ("STDEV.S", lambda xs: math.sqrt(_var(xs, True))),
               ("STDEVP", lambda xs: math.sqrt(_var(xs, False))),
               ("STDEV.P", lambda xs: math.sqrt(_var(xs, False))),
               ("VAR", lambda xs: _var(xs, True)), ("VAR.S", lambda xs: _var(xs, True)),
               ("VARP", lambda xs: _var(xs, False)), ("VAR.P", lambda xs: _var(xs, False)),
               ("SUMSQ", lambda xs: sum(x * x for x in xs)),
               ("MODE", _moda), ("MODE.SNGL", _moda), ("PRODUCT", _produto),
               ("AVEDEV", lambda xs: sum(abs(x - _media(xs)) for x in xs) / len(xs)),
               ("DEVSQ", lambda xs: sum((x - _media(xs)) ** 2 for x in xs))):
    FUNCOES[_n] = (_agregar(_f), "cru")


@cru("COUNT")
def f_count(args, ctx):
    n = 0
    for a in args:
        if isinstance(a, (Faixa, Matriz)):
            n += sum(1 for v in matriz(a, ctx).todos()
                     if isinstance(v, (int, float)) and not isinstance(v, bool))
        elif a is not VAZIO:
            try:
                num(a)
                n += 1
            except _ErroSobe:
                pass
    return float(n)


@cru("COUNTA")
def f_counta(args, ctx):
    n = 0
    for a in args:
        if isinstance(a, (Faixa, Matriz)):
            n += sum(1 for v in matriz(a, ctx).todos() if v is not None)
        elif a is not VAZIO:
            n += 1
    return float(n)


@cru("COUNTBLANK")
def f_countblank(args, ctx):
    return float(sum(1 for v in matriz(args[0], ctx).todos() if v is None or v == ""))


def _k_esimo(args, ctx, maior):
    try:
        xs = sorted(_numeros(args[:1], ctx), reverse=maior)
        k = int(num(valor(args[1], ctx)))
    except _ErroSobe as e:
        return e.erro
    if k < 1 or k > len(xs):
        return NUM
    return xs[k - 1]


cru("LARGE")(lambda a, c: _k_esimo(a, c, True))
cru("SMALL")(lambda a, c: _k_esimo(a, c, False))


@cru("PERCENTILE", "PERCENTILE.INC")
def f_percentil(args, ctx):
    try:
        return _percentil(list(_numeros(args[:1], ctx)), num(valor(args[1], ctx)))
    except _ErroSobe as e:
        return e.erro


@cru("QUARTILE", "QUARTILE.INC")
def f_quartil(args, ctx):
    try:
        q = int(num(valor(args[1], ctx)))
        if q < 0 or q > 4:
            return NUM
        return _percentil(list(_numeros(args[:1], ctx)), q / 4.0)
    except _ErroSobe as e:
        return e.erro


@cru("RANK", "RANK.EQ")
def f_rank(args, ctx):
    try:
        x = num(valor(args[0], ctx))
        xs = list(_numeros(args[1:2], ctx))
        cresc = logico(valor(_opc(args, 2, False), ctx))
    except _ErroSobe as e:
        return e.erro
    if x not in xs:
        return NA
    return float(1 + sum(1 for v in xs if (v < x if cresc else v > x)))


def _pares(args, ctx):
    ys = list(matriz(args[0], ctx).todos())
    xs = list(matriz(args[1], ctx).todos())
    if len(xs) != len(ys):
        raise _ErroSobe(NA)
    par = [(float(x), float(y)) for x, y in zip(xs, ys)
           if isinstance(x, (int, float)) and isinstance(y, (int, float))
           and not isinstance(x, bool) and not isinstance(y, bool)]
    if len(par) < 2:
        raise _ErroSobe(DIV0)
    return par


def _regressao(par):
    n = len(par)
    mx = sum(p[0] for p in par) / n
    my = sum(p[1] for p in par) / n
    sxx = sum((p[0] - mx) ** 2 for p in par)
    syy = sum((p[1] - my) ** 2 for p in par)
    sxy = sum((p[0] - mx) * (p[1] - my) for p in par)
    if sxx == 0:
        raise _ErroSobe(DIV0)
    return mx, my, sxx, syy, sxy


def _estat_par(fn):
    def rodar(args, ctx):
        try:
            return fn(*_regressao(_pares(args, ctx)))
        except _ErroSobe as e:
            return e.erro
        except ZeroDivisionError:
            return DIV0
    return rodar


FUNCOES["SLOPE"] = (_estat_par(lambda mx, my, sxx, syy, sxy: sxy / sxx), "cru")
FUNCOES["INTERCEPT"] = (_estat_par(lambda mx, my, sxx, syy, sxy: my - sxy / sxx * mx), "cru")
FUNCOES["RSQ"] = (_estat_par(lambda mx, my, sxx, syy, sxy: sxy * sxy / (sxx * syy)), "cru")
FUNCOES["CORREL"] = FUNCOES["PEARSON"] = (
    _estat_par(lambda mx, my, sxx, syy, sxy: sxy / math.sqrt(sxx * syy)), "cru")


@cru("FORECAST", "FORECAST.LINEAR")
def f_forecast(args, ctx):
    try:
        x = num(valor(args[0], ctx))
        mx, my, sxx, syy, sxy = _regressao(_pares(args[1:], ctx))
        return my + sxy / sxx * (x - mx)
    except _ErroSobe as e:
        return e.erro


@cru("SUMPRODUCT")
def f_sumproduct(args, ctx):
    ms = [matriz(a, ctx) for a in args if a is not VAZIO]
    if not ms:
        return VALOR
    h, w = ms[0].altura, ms[0].largura
    if any(m.altura != h or m.largura != w for m in ms):
        return VALOR
    total = 0.0
    for i in range(h):
        for j in range(w):
            p = 1.0
            for m in ms:
                v = m.linhas[i][j]
                if isinstance(v, Erro):
                    return v
                p *= float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else 0.0
            total += p
    return total


# ---- logica
def _escolher(cond, sim, nao):
    if isinstance(cond, Erro):
        return cond
    try:
        return sim() if logico(cond) else nao()
    except _ErroSobe as e:
        return e.erro


@preguica("IF")
def f_if(nos, ctx):
    if not nos or len(nos) > 3:
        return VALOR
    cond = valor(avaliar(nos[0], ctx), ctx)

    def ramo(i, padrao):
        if i >= len(nos):
            return padrao
        if nos[i][0] == "vazio":
            return 0.0
        return avaliar(nos[i], ctx)
    if not isinstance(cond, Matriz):
        return _escolher(cond, lambda: ramo(1, True), lambda: ramo(2, False))
    sim = valor(ramo(1, True), ctx)
    nao = valor(ramo(2, False), ctx)
    return _espalhar(lambda c, s, n: _escolher(c, lambda: s, lambda: n), [cond, sim, nao])


@preguica("IFERROR", "IFNA")
def f_iferror(nos, ctx):
    if len(nos) != 2:
        return VALOR
    so_na = False
    v = valor(avaliar(nos[0], ctx), ctx)

    def troca(x, alt):
        return alt if isinstance(x, Erro) and (not so_na or x == NA) else x
    if isinstance(v, Matriz):
        return _espalhar(troca, [v, valor(avaliar(nos[1], ctx), ctx)])
    if isinstance(v, Erro):
        return avaliar(nos[1], ctx) if nos[1][0] != "vazio" else 0.0
    return v


@preguica("IFNA")
def f_ifna(nos, ctx):
    v = valor(avaliar(nos[0], ctx), ctx)
    if v == NA:
        return avaliar(nos[1], ctx)
    return v


@preguica("IFS")
def f_ifs(nos, ctx):
    for i in range(0, len(nos) - 1, 2):
        c = valor(avaliar(nos[i], ctx), ctx)
        if isinstance(c, Erro):
            return c
        try:
            if logico(c):
                return avaliar(nos[i + 1], ctx)
        except _ErroSobe as e:
            return e.erro
    return NA


@preguica("SWITCH")
def f_switch(nos, ctx):
    alvo = valor(avaliar(nos[0], ctx), ctx)
    if isinstance(alvo, Erro):
        return alvo
    resto = nos[1:]
    for i in range(0, len(resto) - 1, 2):
        try:
            if comparar(alvo, valor(avaliar(resto[i], ctx), ctx)) == 0:
                return avaliar(resto[i + 1], ctx)
        except _ErroSobe as e:
            return e.erro
    return avaliar(resto[-1], ctx) if len(resto) % 2 else NA


@preguica("CHOOSE")
def f_choose(nos, ctx):
    try:
        i = int(num(valor(avaliar(nos[0], ctx), ctx)))
    except _ErroSobe as e:
        return e.erro
    if i < 1 or i >= len(nos):
        return VALOR
    return avaliar(nos[i], ctx)


def _logicos(args, ctx):
    for a in args:
        if a is VAZIO:
            continue
        if isinstance(a, (Faixa, Matriz)):
            for v in matriz(a, ctx).todos():
                if isinstance(v, Erro):
                    raise _ErroSobe(v)
                if isinstance(v, bool) or (isinstance(v, (int, float))):
                    yield bool(v)
        else:
            yield logico(a)


def _juntar_logico(fn):
    def rodar(args, ctx):
        try:
            vs = list(_logicos(args, ctx))
        except _ErroSobe as e:
            return e.erro
        if not vs:
            return VALOR
        return fn(vs)
    return rodar


FUNCOES["AND"] = (_juntar_logico(all), "cru")
FUNCOES["OR"] = (_juntar_logico(any), "cru")
FUNCOES["XOR"] = (_juntar_logico(lambda vs: sum(vs) % 2 == 1), "cru")
escalar("NOT", minimo=1)(lambda v: not logico(v))
cru("TRUE")(lambda a, c: True)
cru("FALSE")(lambda a, c: False)
cru("NA")(lambda a, c: NA)
cru("PI")(lambda a, c: math.pi)


# ---- informacao
escalar("ISNUMBER", aceita_erro=True)(
    lambda v: isinstance(v, (int, float)) and not isinstance(v, bool))
escalar("ISTEXT", aceita_erro=True)(lambda v: isinstance(v, str))
escalar("ISNONTEXT", aceita_erro=True)(lambda v: not isinstance(v, str))
escalar("ISLOGICAL", aceita_erro=True)(lambda v: isinstance(v, bool))
escalar("ISBLANK", aceita_erro=True)(lambda v: v is None or v is VAZIO)
escalar("ISERROR", aceita_erro=True)(lambda v: isinstance(v, Erro))
escalar("ISERR", aceita_erro=True)(lambda v: isinstance(v, Erro) and v != NA)
escalar("ISNA", aceita_erro=True)(lambda v: v == NA)
escalar("ISEVEN")(lambda v: int(num(v)) % 2 == 0)
escalar("ISODD")(lambda v: int(num(v)) % 2 == 1)


@escalar("N")
def f_n(v):
    if isinstance(v, bool):
        return 1.0 if v else 0.0
    if isinstance(v, (int, float)):
        return float(v)
    return 0.0


escalar("T")(lambda v: v if isinstance(v, str) else "")


# ---- conta com criterio (CONT.SE, SOMASE...)
def _curinga(t):
    saida, i = [], 0
    while i < len(t):
        ch = t[i]
        if ch == "~" and i + 1 < len(t) and t[i + 1] in "*?~":
            saida.append(re.escape(t[i + 1]))
            i += 2
            continue
        saida.append(".*" if ch == "*" else "." if ch == "?" else re.escape(ch))
        i += 1
    return re.compile("".join(saida), re.I | re.S)


def criterio(c):
    """Criterio do CONT.SE -> funcao que diz se a celula entra."""
    if isinstance(c, Erro):
        raise _ErroSobe(c)
    if c is None or c is VAZIO:
        c = ""
    if isinstance(c, bool) or isinstance(c, (int, float)):
        op, alvo = "=", c
    else:
        op = ""
        for p in (">=", "<=", "<>", ">", "<", "="):
            if c.startswith(p):
                op = p
                break
        resto = c[len(op):]
        op = op or "="
        alvo = resto
        if resto.upper() in ("TRUE", "VERDADEIRO"):
            alvo = True
        elif resto.upper() in ("FALSE", "FALSO"):
            alvo = False
        elif resto.strip():
            try:
                alvo = _texto_para_numero(resto)
            except _ErroSobe:
                alvo = resto
    if isinstance(alvo, bool):
        igual = lambda v: isinstance(v, bool) and v == alvo
    elif isinstance(alvo, (int, float)):
        def igual(v):
            if isinstance(v, str):
                try:
                    v = _texto_para_numero(v)
                except _ErroSobe:
                    return False
            return (isinstance(v, (int, float)) and not isinstance(v, bool)
                    and normal(v) == normal(alvo))
    elif alvo == "":
        igual = lambda v: v is None or v == ""
    else:
        padrao = _curinga(alvo)
        igual = lambda v: isinstance(v, str) and padrao.fullmatch(v) is not None
    if op == "=":
        return igual
    if op == "<>":
        return lambda v: not igual(v)

    def compara(v):
        if isinstance(v, Erro) or v is None:
            return False
        if isinstance(alvo, (int, float)) and not isinstance(alvo, bool):
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                return False
        elif isinstance(alvo, str) and not isinstance(v, str):
            return False
        r = comparar(v, alvo)
        return {"<": r < 0, ">": r > 0, "<=": r <= 0, ">=": r >= 0}[op]
    return compara


def _filtro_posicoes(pares, ctx):
    """[(faixa, criterio)...] -> (forma, lista de posicoes que passam em todos)."""
    forma, ok = None, None
    for faixa, crit in pares:
        m = matriz(faixa, ctx)
        if forma is None:
            forma = (m.altura, m.largura)
        elif (m.altura, m.largura) != forma:
            raise _ErroSobe(VALOR)
        teste = criterio(valor(crit, ctx))
        passa = {(i, j) for i, linha in enumerate(m.linhas) for j, v in enumerate(linha) if teste(v)}
        ok = passa if ok is None else ok & passa
    return forma, ok or set()


def _valores_em(faixa, posicoes, ctx):
    m = matriz(faixa, ctx)
    for i, j in posicoes:
        if i < m.altura and j < m.largura:
            yield m.linhas[i][j]


def _so_numeros(vs):
    for v in vs:
        if isinstance(v, Erro):
            raise _ErroSobe(v)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            yield float(v)


def _com_criterio(alvo_primeiro, fn):
    def rodar(args, ctx):
        try:
            if alvo_primeiro:          # SOMASES(alvo; faixa1; crit1; ...)
                alvo, pares = args[0], [(args[k], args[k + 1]) for k in range(1, len(args) - 1, 2)]
            else:                      # SOMASE(faixa; crit; [alvo])
                pares = [(args[0], args[1])]
                alvo = _opc(args, 2, args[0])
            _, pos = _filtro_posicoes(pares, ctx)
            return fn(list(_so_numeros(_valores_em(alvo, sorted(pos), ctx))))
        except _ErroSobe as e:
            return e.erro
    return rodar


FUNCOES["SUMIF"] = (_com_criterio(False, sum), "cru")
FUNCOES["SUMIFS"] = (_com_criterio(True, sum), "cru")
FUNCOES["AVERAGEIF"] = (_com_criterio(False, _media), "cru")
FUNCOES["AVERAGEIFS"] = (_com_criterio(True, _media), "cru")
FUNCOES["MAXIFS"] = (_com_criterio(True, lambda xs: max(xs) if xs else 0.0), "cru")
FUNCOES["MINIFS"] = (_com_criterio(True, lambda xs: min(xs) if xs else 0.0), "cru")


@cru("COUNTIF", "COUNTIFS")
def f_countifs(args, ctx):
    try:
        _, pos = _filtro_posicoes([(args[k], args[k + 1]) for k in range(0, len(args) - 1, 2)], ctx)
        return float(len(pos))
    except _ErroSobe as e:
        return e.erro


# ---- matematica de uma celula
def _decimal(x):
    try:
        return Decimal(repr(normal(x)))
    except InvalidOperation:
        raise _ErroSobe(NUM)


def _arredondar(x, casas, modo):
    casas = int(casas)
    d = _decimal(num(x))
    q = Decimal(1).scaleb(-casas)
    return float(d.quantize(q, rounding=modo)) if casas >= 0 else \
        float((d / q).quantize(Decimal(1), rounding=modo) * q)


escalar("ROUND", minimo=2)(lambda x, n: _arredondar(x, num(n), ROUND_HALF_UP))
escalar("ROUNDUP", minimo=2)(lambda x, n: _arredondar(x, num(n), ROUND_UP))
escalar("ROUNDDOWN", minimo=2)(lambda x, n: _arredondar(x, num(n), ROUND_DOWN))
escalar("TRUNC", minimo=1)(lambda x, n=0.0: _arredondar(x, num(n), ROUND_DOWN))
escalar("INT", minimo=1)(lambda x: float(math.floor(num(x))))
escalar("ABS", minimo=1)(lambda x: abs(num(x)))
escalar("SIGN", minimo=1)(lambda x: float((num(x) > 0) - (num(x) < 0)))
escalar("EXP", minimo=1)(lambda x: math.exp(num(x)))
escalar("LN", minimo=1)(lambda x: math.log(num(x)))
escalar("LOG10", minimo=1)(lambda x: math.log10(num(x)))
escalar("LOG", minimo=1)(lambda x, b=10.0: math.log(num(x), num(b) if b is not VAZIO else 10.0))
escalar("SIN", minimo=1)(lambda x: math.sin(num(x)))
escalar("COS", minimo=1)(lambda x: math.cos(num(x)))
escalar("TAN", minimo=1)(lambda x: math.tan(num(x)))
escalar("RADIANS", minimo=1)(lambda x: math.radians(num(x)))
escalar("DEGREES", minimo=1)(lambda x: math.degrees(num(x)))


@escalar("SQRT", minimo=1)
def f_sqrt(x):
    x = num(x)
    if x < 0:
        return NUM
    return math.sqrt(x)


@escalar("POWER", minimo=2)
def f_power(x, y):
    return _aritm("^", x, y)


@escalar("MOD", minimo=2)
def f_mod(a, b):
    a, b = num(a), num(b)
    if b == 0:
        return DIV0
    return a - b * math.floor(a / b)


def _multiplo(x, m, pra_cima):
    x, m = num(x), num(m)
    if m == 0:
        return 0.0
    if x > 0 and m < 0:
        return NUM
    q = x / m
    q = math.ceil(round(q, 12)) if pra_cima else math.floor(round(q, 12))
    return float(_decimal(q * m))


escalar("CEILING", minimo=1)(lambda x, m=1.0: _multiplo(x, 1.0 if m is VAZIO else m, True))
escalar("FLOOR", minimo=1)(lambda x, m=1.0: _multiplo(x, 1.0 if m is VAZIO else m, False))
escalar("CEILING.MATH", minimo=1)(
    lambda x, m=1.0, *r: _multiplo(x, abs(num(1.0 if m is VAZIO else m)), True))
escalar("FLOOR.MATH", minimo=1)(
    lambda x, m=1.0, *r: _multiplo(x, abs(num(1.0 if m is VAZIO else m)), False))


@escalar("MROUND", minimo=2)
def f_mround(x, m):
    x, m = num(x), num(m)
    if m == 0:
        return 0.0
    if (x > 0) != (m > 0) and x != 0:
        return NUM
    return float((_decimal(x) / _decimal(m)).quantize(Decimal(1), rounding=ROUND_HALF_UP)
                 * _decimal(m))


# ---- distribuicao normal (fck = fcm - 1,65 sd vem daqui)
def _norm_s_inv(p):
    if p <= 0 or p >= 1:
        raise _ErroSobe(NUM)
    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
         1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
         6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00]
    if p < 0.02425:
        q = math.sqrt(-2 * math.log(p))
        x = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / \
            ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    elif p > 1 - 0.02425:
        q = math.sqrt(-2 * math.log(1 - p))
        x = -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / \
            ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    else:
        q = p - 0.5
        r = q * q
        x = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / \
            (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1)
    # um passo de Newton leva a' precisao do Excel
    e = 0.5 * math.erfc(-x / math.sqrt(2)) - p
    u = e * math.sqrt(2 * math.pi) * math.exp(x * x / 2)
    return x - u / (1 + x * u / 2)


def _norm_dist(x, m, s, acumulada):
    if s <= 0:
        raise _ErroSobe(NUM)
    z = (x - m) / s
    if acumulada:
        return 0.5 * math.erfc(-z / math.sqrt(2))
    return math.exp(-z * z / 2) / (s * math.sqrt(2 * math.pi))


escalar("NORM.S.INV", "NORMSINV", minimo=1)(lambda p: _norm_s_inv(num(p)))
escalar("NORM.INV", "NORMINV", minimo=3)(
    lambda p, m, s: NUM if num(s) <= 0 else num(m) + num(s) * _norm_s_inv(num(p)))
escalar("NORMSDIST", minimo=1)(lambda z: _norm_dist(num(z), 0.0, 1.0, True))
escalar("NORM.S.DIST", minimo=2)(lambda z, a: _norm_dist(num(z), 0.0, 1.0, logico(a)))
escalar("NORM.DIST", "NORMDIST", minimo=4)(
    lambda x, m, s, a: _norm_dist(num(x), num(m), num(s), logico(a)))


# ---- texto
def _inteiro(v, padrao):
    return padrao if v is VAZIO else int(num(v))


escalar("LEFT", minimo=1)(lambda t, n=1: txt(t)[:max(0, _inteiro(n, 1))] if _inteiro(n, 1) >= 0 else VALOR)
escalar("RIGHT", minimo=1)(
    lambda t, n=1: (txt(t)[-_inteiro(n, 1):] if _inteiro(n, 1) > 0 else "") if _inteiro(n, 1) >= 0 else VALOR)
escalar("MID", minimo=3)(
    lambda t, i, n: VALOR if int(num(i)) < 1 or int(num(n)) < 0
    else txt(t)[int(num(i)) - 1:int(num(i)) - 1 + int(num(n))])
escalar("LEN", minimo=1)(lambda t: float(len(txt(t))))
escalar("UPPER", minimo=1)(lambda t: txt(t).upper())
escalar("LOWER", minimo=1)(lambda t: txt(t).lower())
escalar("PROPER", minimo=1)(lambda t: re.sub(r"[^\W\d_]+", lambda m: m.group(0).capitalize(),
                                             txt(t).lower()))
escalar("TRIM", minimo=1)(lambda t: re.sub(" +", " ", txt(t).strip(" ")))
escalar("CLEAN", minimo=1)(lambda t: "".join(ch for ch in txt(t) if ord(ch) >= 32))
escalar("REPT", minimo=2)(lambda t, n: txt(t) * int(num(n)))
escalar("EXACT", minimo=2)(lambda a, b: txt(a) == txt(b))
escalar("CHAR", minimo=1)(lambda n: chr(int(num(n))))
escalar("CODE", minimo=1)(lambda t: float(ord(txt(t)[0])) if txt(t) else VALOR)
escalar("CONCATENATE")(lambda *vs: "".join(txt(v) for v in vs))


@escalar("SUBSTITUTE", minimo=3)
def f_substitute(t, velho, novo, qual=VAZIO):
    t, velho, novo = txt(t), txt(velho), txt(novo)
    if not velho:
        return t
    if qual is VAZIO:
        return t.replace(velho, novo)
    n, pos = int(num(qual)), -1
    for _ in range(n):
        pos = t.find(velho, pos + 1)
        if pos < 0:
            return t
    return t[:pos] + novo + t[pos + len(velho):]


@escalar("REPLACE", minimo=4)
def f_replace(t, i, n, novo):
    t, i, n = txt(t), int(num(i)), int(num(n))
    return t[:i - 1] + txt(novo) + t[i - 1 + n:]


def _achar(agulha, palheiro, inicio, sem_caixa):
    a, p = txt(agulha), txt(palheiro)
    i = 1 if inicio is VAZIO else int(num(inicio))
    if i < 1 or i > len(p) + 1:
        return VALOR
    if sem_caixa:
        m = _curinga(a).pattern if any(ch in a for ch in "*?") else re.escape(a)
        achou = re.compile(m, re.I | re.S).search(p, i - 1)
        return float(achou.start() + 1) if achou else VALOR
    k = p.find(a, i - 1)
    return float(k + 1) if k >= 0 else VALOR


escalar("FIND", minimo=2)(lambda a, p, i=VAZIO: _achar(a, p, i, False))
escalar("SEARCH", minimo=2)(lambda a, p, i=VAZIO: _achar(a, p, i, True))


@escalar("VALUE", minimo=1)
def f_value(t):
    if isinstance(t, (int, float)) and not isinstance(t, bool):
        return float(t)
    return _texto_para_numero(txt(t))


def _milhar_br(inteiro):
    s = "%d" % inteiro
    partes = []
    while len(s) > 3:
        partes.insert(0, s[-3:])
        s = s[:-3]
    partes.insert(0, s)
    return ".".join(partes)


def _fixo(x, casas, milhar=True):
    """Numero -> texto com casas fixas, em portugues: 1.234,50."""
    casas = int(casas)
    r = _arredondar(x, casas, ROUND_HALF_UP)
    neg = r < 0
    d = _decimal(abs(r)).quantize(Decimal(1).scaleb(-max(casas, 0)), rounding=ROUND_HALF_UP)
    inteiro, _, frac = ("%f" % d if casas > 0 else "%d" % d).partition(".")
    if casas > 0:
        t = "{:.{}f}".format(d, casas)
        inteiro, _, frac = t.partition(".")
    corpo = _milhar_br(int(inteiro)) if milhar else inteiro
    if casas > 0:
        corpo += "," + frac
    return ("-" if neg and float(d) != 0 else "") + corpo


escalar("FIXED", minimo=1)(
    lambda x, n=2.0, sem=False: _fixo(num(x), 2 if n is VAZIO else num(n),
                                      not (sem is not VAZIO and logico(sem))))
escalar("DOLLAR", minimo=1)(lambda x, n=2.0: "R$ " + _fixo(num(x), 2 if n is VAZIO else num(n)))

_MESES = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto",
          "setembro", "outubro", "novembro", "dezembro"]
_DIAS = ["segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira",
         "sábado", "domingo"]


def _texto_data(n, fmt):
    d = data_de(n)
    saida, i, f = [], 0, fmt
    tem_hora = re.search(r"[hHsS]", f) is not None
    while i < len(f):
        ch = f[i]
        if ch == '"':
            fim = f.find('"', i + 1)
            fim = len(f) if fim < 0 else fim
            saida.append(f[i + 1:fim])
            i = fim + 1
            continue
        if ch == "\\" and i + 1 < len(f):
            saida.append(f[i + 1])
            i += 2
            continue
        k = i
        while k < len(f) and f[k].lower() == ch.lower():
            k += 1
        n_ = k - i
        c = ch.lower()
        if c == "d":
            saida.append("%02d" % d.day if n_ == 2 else str(d.day) if n_ == 1 else
                         _DIAS[d.weekday()][:3] if n_ == 3 else _DIAS[d.weekday()])
        elif c == "m" and tem_hora and (re.search(r"[hH][^dDyYaA]*$", "".join(f[:i])) or
                                        re.match(r"^[^dDyYaA]*[sS]", f[k:])):
            saida.append("%02d" % d.minute if n_ >= 2 else str(d.minute))
        elif c == "m":
            saida.append("%02d" % d.month if n_ == 2 else str(d.month) if n_ == 1 else
                         _MESES[d.month - 1][:3] if n_ == 3 else _MESES[d.month - 1])
        elif c in "ya":
            saida.append("%04d" % d.year if n_ > 2 else "%02d" % (d.year % 100))
        elif c == "h":
            saida.append("%02d" % d.hour if n_ >= 2 else str(d.hour))
        elif c == "s":
            saida.append("%02d" % d.second if n_ >= 2 else str(d.second))
        else:
            saida.append(f[i:k])
        i = k
    return "".join(saida)


_RE_MASCARA = re.compile(r"[#0?][#0?,.]*")


def _texto_numero(x, fmt):
    secoes = fmt.split(";")
    if x < 0 and len(secoes) > 1:
        fmt, x = secoes[1], -x
    elif x == 0 and len(secoes) > 2:
        fmt = secoes[2]
    else:
        fmt = secoes[0]
    literais = []

    def guarda(m):
        literais.append(m.group(1))
        return "\x00%d\x00" % (len(literais) - 1)
    f = re.sub(r'"([^"]*)"', guarda, fmt)
    f = re.sub(r"\\(.)", guarda, f)
    if "%" in f:
        x *= 100
    m = _RE_MASCARA.search(f)
    if not m:
        raise NaoSei("TEXT " + fmt)
    mascara = m.group(0).rstrip(",.")
    if "," in mascara and "." in mascara:
        dec_sep = "," if mascara.rfind(",") > mascara.rfind(".") else "."
    elif "," in mascara:
        dec_sep = "." if re.search(r"[#0],[#0]{3}$", mascara) and mascara.startswith("#") else ","
    elif "." in mascara:
        dec_sep = "," if re.search(r"[#0]\.[#0]{3}$", mascara) and mascara.startswith("#") else "."
    else:
        dec_sep = "."
    mil_sep = "," if dec_sep == "." else "."
    inteira, _, frac = mascara.partition(dec_sep)
    casas = len(re.sub(r"[^0#?]", "", frac))
    obrig = len(re.sub(r"[^0]", "", frac))
    milhar = mil_sep in inteira
    corpo = _fixo(x, casas, milhar)
    if casas > obrig:                    # "#" nas decimais some se for zero
        inte, _, dec = corpo.partition(",")
        dec = dec.rstrip("0")
        dec = dec + "0" * max(0, obrig - len(dec))
        corpo = inte + ("," + dec if dec else "")
    zeros = len(re.sub(r"[^0]", "", inteira))
    if zeros > 1:
        sinal = corpo.startswith("-")
        inte, virg, dec = corpo.lstrip("-").partition(",")
        inte = inte.replace(".", "").zfill(zeros)
        inte = _milhar_br(int(inte)).zfill(zeros) if milhar else inte
        corpo = ("-" if sinal else "") + inte + virg + dec
    elif zeros == 0 and corpo.lstrip("-").startswith("0,"):
        corpo = corpo.replace("0,", ",", 1)    # "#,00" mostra ",50"
    saida = f[:m.start()] + corpo + f[m.start() + len(m.group(0)):]
    return re.sub("\x00(\\d+)\x00", lambda k: literais[int(k.group(1))], saida)


@escalar("TEXT", minimo=2)
def f_text(v, fmt):
    fmt = txt(fmt)
    if fmt.strip().lower() in ("", "general", "geral", "@"):
        return txt(v)
    if isinstance(v, str):
        try:
            v = _texto_para_numero(v)
        except _ErroSobe:
            return v
    x = num(v)
    sem_literal = re.sub(r'"[^"]*"|\\.', "", fmt)
    if re.search(r"[dDyYaAhHsS]", sem_literal) or (
            re.search(r"[mM]", sem_literal) and not re.search(r"[#0?]", sem_literal)):
        return _texto_data(x, fmt)
    return _texto_numero(x, fmt)


def _juntar(args, ctx, sep, pula_vazio):
    partes = []
    for a in args:
        if a is VAZIO:
            continue
        for v in (matriz(a, ctx).todos() if isinstance(a, (Faixa, Matriz)) else [a]):
            t = txt(v)
            if t == "" and pula_vazio:
                continue
            partes.append(t)
    return sep.join(partes)


@cru("CONCAT")
def f_concat2(args, ctx):
    try:
        return _juntar(args, ctx, "", False)
    except _ErroSobe as e:
        return e.erro


@cru("TEXTJOIN")
def f_textjoin(args, ctx):
    try:
        return _juntar(args[2:], ctx, txt(valor(args[0], ctx)), logico(valor(args[1], ctx)))
    except _ErroSobe as e:
        return e.erro


# ---- procura e referencia
def _vetor(a, ctx):
    m = matriz(a, ctx)
    if m.altura == 1:
        return list(m.linhas[0])
    if m.largura == 1:
        return [linha[0] for linha in m.linhas]
    raise _ErroSobe(NA)


def _posicao(alvo, itens, tipo):
    """CORRESP: indice a partir de 0, ou None."""
    if isinstance(alvo, Erro):
        raise _ErroSobe(alvo)
    if tipo == 0:
        if isinstance(alvo, str) and any(ch in alvo for ch in "*?~"):
            p = _curinga(alvo)
            for i, v in enumerate(itens):
                if isinstance(v, str) and p.fullmatch(v):
                    return i
            return None
        for i, v in enumerate(itens):
            if v is None or isinstance(v, Erro):
                continue
            if _ordem_tipo(v) == _ordem_tipo(alvo) and comparar(v, alvo) == 0:
                return i
        return None
    achou = None
    for i, v in enumerate(itens):
        if v is None or isinstance(v, Erro) or _ordem_tipo(v) != _ordem_tipo(alvo):
            continue
        c = comparar(v, alvo)
        if c == 0:
            achou = i
            if tipo > 0:
                continue
            return i
        if (c < 0) if tipo > 0 else (c > 0):
            achou = i
        else:
            break
    return achou


@cru("MATCH")
def f_match(args, ctx):
    try:
        alvo = valor(args[0], ctx)
        tipo = int(num(valor(_opc(args, 2, 1.0), ctx)))
        alvo_m = alvo if isinstance(alvo, Matriz) else None
        itens = _vetor(args[1], ctx)

        def um(a):
            i = _posicao(a, itens, 0 if tipo == 0 else (1 if tipo > 0 else -1))
            return NA if i is None else float(i + 1)
        if alvo_m is not None:
            return _espalhar(_seguro(um), [alvo_m])
        return um(alvo)
    except _ErroSobe as e:
        return e.erro


def _procv(args, ctx, vertical):
    try:
        alvo = valor(args[0], ctx)
        tabela = matriz(args[1], ctx)
        n = int(num(valor(args[2], ctx)))
        aprox = logico(valor(_opc(args, 3, True), ctx))
    except _ErroSobe as e:
        return e.erro
    linhas = tabela.linhas if vertical else [list(x) for x in zip(*tabela.linhas)]
    if n < 1:
        return VALOR
    if not linhas or n > len(linhas[0]):
        return REF
    try:
        i = _posicao(alvo, [x[0] for x in linhas], 1 if aprox else 0)
    except _ErroSobe as e:
        return e.erro
    return NA if i is None else linhas[i][n - 1]


cru("VLOOKUP")(lambda a, c: _procv(a, c, True))
cru("HLOOKUP")(lambda a, c: _procv(a, c, False))


@cru("LOOKUP")
def f_lookup(args, ctx):
    try:
        alvo = valor(args[0], ctx)
        busca = _vetor(args[1], ctx)
        result = _vetor(args[2], ctx) if len(args) > 2 else busca
        i = _posicao(alvo, busca, 1)
    except _ErroSobe as e:
        return e.erro
    return NA if i is None or i >= len(result) else result[i]


@cru("XLOOKUP")
def f_xlookup(args, ctx):
    try:
        alvo = valor(args[0], ctx)
        busca = _vetor(args[1], ctx)
        result = matriz(args[2], ctx)
        modo = int(num(valor(_opc(args, 4, 0.0), ctx)))
        if modo == 2:
            i = _posicao(alvo, busca, 0)
        elif modo == 0:
            i = _posicao(alvo, [v for v in busca], 0) if not isinstance(alvo, str) else \
                next((k for k, v in enumerate(busca) if isinstance(v, str)
                      and v.casefold() == alvo.casefold()), None)
        else:
            raise NaoSei("XLOOKUP modo %d" % modo)
    except _ErroSobe as e:
        return e.erro
    if i is None:
        return valor(args[3], ctx) if len(args) > 3 and args[3] is not VAZIO else NA
    if result.largura == 1:
        return result.linhas[i][0]
    if result.altura == 1:
        return result.linhas[0][i]
    return Matriz([result.linhas[i]])


@cru("INDEX")
def f_index(args, ctx):
    try:
        lin = 0 if _opc(args, 1, VAZIO) is VAZIO else int(num(valor(args[1], ctx)))
        col = None if _opc(args, 2, VAZIO) is VAZIO else int(num(valor(args[2], ctx)))
    except _ErroSobe as e:
        return e.erro
    base = args[0]
    alt, larg = (base.altura, base.largura) if isinstance(base, (Faixa, Matriz)) else (1, 1)
    if col is None:
        if alt == 1 and larg > 1:
            lin, col = 1, lin
        else:
            col = 0 if larg > 1 else 1
    if lin < 0 or col < 0 or lin > alt or col > larg:
        return REF
    if isinstance(base, Faixa):
        r1, r2 = (base.r1, base.r2) if lin == 0 else (base.r1 + lin - 1,) * 2
        c1, c2 = (base.c1, base.c2) if col == 0 else (base.c1 + col - 1,) * 2
        return Faixa(base.aba, r1, c1, r2, c2)
    m = matriz(base, ctx)
    linhas = m.linhas if lin == 0 else [m.linhas[lin - 1]]
    if col == 0:
        return Matriz([list(x) for x in linhas])
    return Matriz([[x[col - 1]] for x in linhas]) if len(linhas) > 1 else linhas[0][col - 1]


@cru("ROW")
def f_row(args, ctx):
    if not args or args[0] is VAZIO:
        return float(ctx.lin)
    f = args[0]
    if not isinstance(f, Faixa):
        return VALOR
    if f.altura == 1:
        return float(f.r1)
    return Matriz([[float(r)] for r in range(f.r1, min(f.r2, ctx.pasta.limite(f.aba)[0]) + 1)])


@cru("COLUMN")
def f_column(args, ctx):
    if not args or args[0] is VAZIO:
        return float(ctx.col)
    f = args[0]
    if not isinstance(f, Faixa):
        return VALOR
    if f.largura == 1:
        return float(f.c1)
    return Matriz([[float(c) for c in range(f.c1, min(f.c2, ctx.pasta.limite(f.aba)[1]) + 1)]])


cru("ROWS")(lambda a, c: float(a[0].altura) if isinstance(a[0], (Faixa, Matriz)) else 1.0)
cru("COLUMNS")(lambda a, c: float(a[0].largura) if isinstance(a[0], (Faixa, Matriz)) else 1.0)


@cru("OFFSET")
def f_offset(args, ctx):
    base = args[0]
    if not isinstance(base, Faixa):
        return VALOR
    try:
        dl, dc = int(num(valor(args[1], ctx))), int(num(valor(args[2], ctx)))
        h = base.altura if _opc(args, 3, VAZIO) is VAZIO else int(num(valor(args[3], ctx)))
        w = base.largura if _opc(args, 4, VAZIO) is VAZIO else int(num(valor(args[4], ctx)))
    except _ErroSobe as e:
        return e.erro
    r1, c1 = base.r1 + dl, base.c1 + dc
    if r1 < 1 or c1 < 1 or h < 1 or w < 1:
        return REF
    return Faixa(base.aba, r1, c1, r1 + h - 1, c1 + w - 1)


@cru("INDIRECT")
def f_indirect(args, ctx):
    try:
        t = txt(valor(args[0], ctx))
        if not logico(valor(_opc(args, 1, True), ctx)):
            raise NaoSei("INDIRECT L1C1")
    except _ErroSobe as e:
        return e.erro
    ref = ler_ref(t.strip(), ctx.aba)
    if ref:
        return Faixa(*ref)
    try:
        return ctx.pasta.avaliar_nome(t.strip().upper(), ctx.aba, ctx)
    except NaoSei:
        return REF


# ---- datas (numero de serie do Excel)
def _ymd(n):
    d = data_de(math.floor(num(n)))
    return d.year, d.month, d.day


@escalar("DATE", minimo=3)
def f_date(a, m, d):
    a, m, d = int(num(a)), int(num(m)), int(num(d))
    if 0 <= a < 1900:
        a += 1900
    a += (m - 1) // 12
    m = (m - 1) % 12 + 1
    return serial(datetime.date(a, m, 1)) + d - 1


escalar("TIME", minimo=3)(lambda h, m, s: ((num(h) * 3600 + num(m) * 60 + num(s)) % 86400) / 86400.0)
escalar("YEAR", minimo=1)(lambda n: float(_ymd(n)[0]))
escalar("MONTH", minimo=1)(lambda n: float(_ymd(n)[1]))
escalar("DAY", minimo=1)(lambda n: float(_ymd(n)[2]))
escalar("HOUR", minimo=1)(lambda n: float(int(round((num(n) % 1) * 86400)) // 3600))
escalar("MINUTE", minimo=1)(lambda n: float(int(round((num(n) % 1) * 86400)) % 3600 // 60))
escalar("SECOND", minimo=1)(lambda n: float(int(round((num(n) % 1) * 86400)) % 60))
escalar("DAYS", minimo=2)(lambda f, i: math.floor(num(f)) - math.floor(num(i)))


@escalar("WEEKDAY", minimo=1)
def f_weekday(n, tipo=1.0):
    t = 1 if tipo is VAZIO else int(num(tipo))
    py = data_de(math.floor(num(n))).weekday()          # segunda = 0
    if t == 1:
        return float((py + 1) % 7 + 1)
    if t == 2:
        return float(py + 1)
    if t == 3:
        return float(py)
    raise NaoSei("WEEKDAY tipo %d" % t)


def _somar_meses(n, meses, fim_do_mes):
    a, m, d = _ymd(n)
    total = a * 12 + (m - 1) + int(num(meses))
    a, m = total // 12, total % 12 + 1
    ultimo = (datetime.date(a + (m == 12), m % 12 + 1, 1) - datetime.timedelta(days=1)).day
    return serial(datetime.date(a, m, ultimo if fim_do_mes else min(d, ultimo)))


escalar("EDATE", minimo=2)(lambda n, k: _somar_meses(n, k, False))
escalar("EOMONTH", minimo=2)(lambda n, k: _somar_meses(n, k, True))


@escalar("DATEDIF", minimo=3)
def f_datedif(i, f, u):
    i, f, u = math.floor(num(i)), math.floor(num(f)), txt(u).upper()
    if f < i:
        return NUM
    a1, m1, d1 = _ymd(i)
    a2, m2, d2 = _ymd(f)
    meses = (a2 - a1) * 12 + (m2 - m1) - (1 if d2 < d1 else 0)
    if u == "D":
        return float(f - i)
    if u == "M":
        return float(meses)
    if u == "Y":
        return float(meses // 12)
    if u == "YM":
        return float(meses % 12)
    if u == "MD":
        return float(d2 - d1 if d2 >= d1 else
                     (data_de(f) - (data_de(f).replace(day=1) - datetime.timedelta(days=1))
                      .replace(day=min(d1, 28))).days)
    if u == "YD":
        ini = data_de(i).replace(year=a2)
        if ini > data_de(f):
            ini = ini.replace(year=a2 - 1)
        return float((data_de(f) - ini).days)
    return NUM


cru("TODAY")(lambda a, c: serial(datetime.date.today()))
cru("NOW")(lambda a, c: serial(datetime.datetime.now()))


# ---------------------------------------------------------------- a pasta
class Formula(object):
    __slots__ = ("texto", "arvore", "refs", "flags", "alvo", "motivo")

    def __init__(self, texto, alvo=None):
        self.texto, self.alvo = texto, alvo
        self.arvore, self.refs, self.flags, self.motivo = None, [], set(), None


_RE_TEM_FORMULA = re.compile(rb"<f[ >/]")


def tem_formula(path):
    """Olha o .xlsx por dentro sem abrir no openpyxl: planilha sem formula
    (a maioria dos laudos) nao paga o custo de montar o motor."""
    try:
        with zipfile.ZipFile(path) as z:
            for n in z.namelist():
                if not (n.startswith("xl/worksheets/") and n.endswith(".xml")):
                    continue
                with z.open(n) as fh:
                    resto = b""
                    while True:
                        bloco = fh.read(1 << 20)
                        if not bloco:
                            break
                        if _RE_TEM_FORMULA.search(resto + bloco):
                            return True
                        resto = bloco[-4:]
    except (OSError, zipfile.BadZipFile, KeyError):
        return False
    return False


def abrir(path):
    """Pasta com formulas e valores do arquivo, ou None se nao tiver formula."""
    if not str(path or "").lower().endswith((".xlsx", ".xlsm")) or not tem_formula(path):
        return None
    from openpyxl import load_workbook
    from openpyxl.styles.numbers import is_date_format
    from openpyxl.worksheet.formula import ArrayFormula

    wf = load_workbook(path)
    wv = load_workbook(path, data_only=True)
    p = Pasta()
    for ws in wf.worksheets:
        aba = ws.title
        vals = p.valores[aba] = {}
        if aba in wv.sheetnames:
            for (r, c), cel in wv[aba]._cells.items():
                v = cel.value
                if v is None:
                    continue
                if cel.data_type == "e":
                    v = ERROS.get(str(v).upper(), VALOR)
                elif isinstance(v, (datetime.datetime, datetime.date, datetime.time,
                                    datetime.timedelta)):
                    v = serial(v)
                    p.datas.add((aba, r, c))
                elif isinstance(v, int) and not isinstance(v, bool):
                    v = float(v)
                vals[(r, c)] = v
        for (r, c), cel in ws._cells.items():
            if cel.data_type != "f":
                continue
            v, alvo = cel.value, None
            if isinstance(v, ArrayFormula):
                texto = v.text
                ref = ler_ref(v.ref or "", aba) if v.ref else None
                if ref and (ref[1], ref[2]) != (ref[3], ref[4]):
                    alvo = Faixa(*ref)
            elif isinstance(v, str):
                texto = v
            else:
                texto = None              # tabela de dados (o Excel resolve)
            chave = (aba, r, c)
            p.formulas[chave] = Formula(texto, alvo)
            if is_date_format(cel.number_format or ""):
                p.datas.add(chave)
            if alvo is not None:
                for rr in range(alvo.r1, alvo.r2 + 1):
                    for cc in range(alvo.c1, alvo.c2 + 1):
                        if (rr, cc) != (r, c):
                            p.donos[(aba, rr, cc)] = chave
    dn = wf.defined_names
    itens = list(dn.items()) if hasattr(dn, "items") else \
        [(d.name, d) for d in getattr(dn, "definedName", [])]
    for nome, d in itens:
        escopo = None
        if getattr(d, "localSheetId", None) is not None and d.localSheetId < len(wf.sheetnames):
            escopo = wf.sheetnames[d.localSheetId]
        if d.attr_text:
            p.nomes[(escopo, nome.upper())] = d.attr_text
    for ws in wf.worksheets:
        for nome, d in getattr(ws, "defined_names", {}).items():
            if d.attr_text:
                p.nomes[(ws.title, nome.upper())] = d.attr_text
    p.primeira = wf.sheetnames[0] if wf.sheetnames else None
    wf.close()
    wv.close()
    p.preparar()
    return p


class Pasta(object):
    def __init__(self):
        self.valores = {}        # aba -> {(lin, col): valor}
        self.formulas = {}       # (aba, lin, col) -> Formula
        self.donos = {}          # celula preenchida por formula-matriz -> a formula
        self.nomes = {}          # (aba ou None, NOME) -> texto do nome definido
        self._arv_nomes = {}
        self.datas = set()       # celulas com formato de data
        self.pos = {}            # chave -> lugar na ordem de calculo
        self.dependentes = {}
        self.leitores = {}       # celula -> formulas que leem so' ela
        self.leitores_faixa = {}  # aba -> [(r1, c1, r2, c2, formula)]
        self.volateis = set()
        self.ciclicas = set()
        self.telas = {}          # aba -> o que a tela mostra (ver ligar)
        self.mostrados = {}      # formula -> textos que a tela ja' mostrou dela
        self.mostrar = str
        self.primeira = None
        self._lim = {}

    # -- leitura
    def limite(self, aba):
        lim = self._lim.get(aba)
        if lim is None:
            ks = self.valores.get(aba) or {}
            lim = self._lim[aba] = (max((k[0] for k in ks), default=1),
                                    max((k[1] for k in ks), default=1))
        return lim

    def ler(self, aba, r, c):
        vs = self.valores.get(aba)
        if vs is None:
            raise _ErroSobe(REF)
        return vs.get((r, c))

    def ler_faixa(self, f):
        vs = self.valores.get(f.aba)
        if vs is None:
            raise _ErroSobe(REF)
        r2, c2 = f.r2, f.c2
        if r2 == MAX_LIN or c2 == MAX_COL:      # coluna/linha inteira: ate' onde tem dado
            mr, mc = self.limite(f.aba)
            r2 = max(f.r1, mr) if r2 == MAX_LIN else r2
            c2 = max(f.c1, mc) if c2 == MAX_COL else c2
        return Matriz([[vs.get((r, c)) for c in range(f.c1, c2 + 1)]
                       for r in range(f.r1, r2 + 1)])

    def _por(self, aba, r, c, v):
        vs = self.valores.setdefault(aba, {})
        if v is None:
            vs.pop((r, c), None)
        else:
            vs[(r, c)] = v
        lim = self._lim.get(aba)
        if lim is not None and (r > lim[0] or c > lim[1]):
            self._lim.pop(aba, None)

    def _texto_nome(self, nome, aba):
        return self.nomes.get((aba, nome), self.nomes.get((None, nome)))

    def _arvore_nome(self, nome, aba):
        texto = self._texto_nome(nome, aba)
        if texto is None:
            raise NaoSei("nome " + nome)
        chave = (aba, nome)
        if chave not in self._arv_nomes:
            self._arv_nomes[chave] = compilar("=" + texto, aba or self.primeira)
        return self._arv_nomes[chave]

    def avaliar_nome(self, nome, aba, ctx):
        return avaliar(self._arvore_nome(nome, aba), ctx)

    # -- ordem de calculo
    def _formulas_em(self, aba, r1, c1, r2, c2):
        cols = self._idx.get(aba)
        if not cols:
            return ()
        if c2 - c1 > 64:
            cs = [c for c in cols if c1 <= c <= c2]
        else:
            cs = [c for c in range(c1, c2 + 1) if c in cols]
        achadas = set()
        for c in cs:
            linhas = cols[c]
            for r in linhas[bisect.bisect_left(linhas, r1):bisect.bisect_right(linhas, r2)]:
                k = (aba, r, c)
                achadas.add(self.donos.get(k, k))
        return achadas

    def _compilar(self, chave, f):
        aba = chave[0]
        if f.texto is None:
            f.motivo = "tabela de dados"
            return
        try:
            f.arvore = compilar(f.texto, aba)
        except NaoSei as e:
            f.motivo = str(e)
            return
        except Exception:  # noqa: BLE001 -- formula que o leitor nao entende fica com o valor do Excel
            f.motivo = "formula nao lida"
            return
        refs, nomes, flags = [], [], set()
        _percorrer(f.arvore, refs, nomes, flags)
        vistos = set()
        while nomes:                      # nome definido -> as referencias dele
            no = nomes.pop()
            chave_n = (no[2] or aba, no[1])
            if chave_n in vistos:
                continue
            vistos.add(chave_n)
            try:
                _percorrer(self._arvore_nome(no[1], no[2] or aba), refs, nomes, flags)
            except NaoSei:
                flags.add("f:#NOME " + no[1])
            except Exception:  # noqa: BLE001
                flags.add("f:#NOME " + no[1])
        f.refs, f.flags = refs, flags
        for fl in flags:
            if fl.startswith("f:") and fl[2:] not in FUNCOES:
                f.motivo = fl[2:]
                break

    def preparar(self):
        self._idx = {}
        for (aba, r, c) in list(self.formulas) + list(self.donos):
            self._idx.setdefault(aba, {}).setdefault(c, []).append(r)
        for cols in self._idx.values():
            for linhas in cols.values():
                linhas.sort()
        precede = {}
        for chave, f in self.formulas.items():
            self._compilar(chave, f)
            ps = set()
            for aba, r1, c1, r2, c2 in f.refs:
                ps.update(self._formulas_em(aba, r1, c1, r2, c2))
                if r1 == r2 and c1 == c2:
                    self.leitores.setdefault((aba, r1, c1), set()).add(chave)
                else:
                    self.leitores_faixa.setdefault(aba, []).append((r1, c1, r2, c2, chave))
            precede[chave] = ps
            for p in ps:
                self.dependentes.setdefault(p, set()).add(chave)
            if "volatil" in f.flags:
                self.volateis.add(chave)
        grau = {k: len(ps) for k, ps in precede.items()}
        fila = sorted((k for k, g in grau.items() if g == 0), reverse=True)
        ordem = []
        while fila:
            k = fila.pop()
            ordem.append(k)
            for d in self.dependentes.get(k, ()):
                grau[d] -= 1
                if grau[d] == 0:
                    fila.append(d)
        self.pos = {k: i for i, k in enumerate(ordem)}
        self.ciclicas = set(self.formulas) - set(self.pos)

    @property
    def faltando(self):
        """O que o motor nao calcula (funcao, nome, referencia externa...)."""
        return sorted({f.motivo for f in self.formulas.values() if f.motivo})

    # -- calculo
    def _leitores_de(self, cel):
        aba, r, c = cel
        achados = set(self.leitores.get(cel, ()))
        for r1, c1, r2, c2, k in self.leitores_faixa.get(aba, ()):
            if r1 <= r <= r2 and c1 <= c <= c2:
                achados.add(k)
        return achados

    def _calcular(self, chave):
        f = self.formulas.get(chave)
        if f is None or f.arvore is None or f.motivo:
            return
        aba, r, c = chave
        ctx = _Ctx(self, aba, r, c)
        try:
            v = avaliar(f.arvore, ctx)
            if isinstance(v, Faixa):
                v = valor(v, ctx)
        except NaoSei as e:
            f.motivo = str(e)
            return
        except _ErroSobe as e:
            v = e.erro
        except RecursionError:
            f.motivo = "formula longa demais"
            return
        except Exception as e:  # noqa: BLE001 -- defeito do motor nao pode derrubar a edicao
            f.motivo = "nao calculada (%s)" % e.__class__.__name__
            return
        if f.alvo is not None:
            a = f.alvo
            for i, rr in enumerate(range(a.r1, a.r2 + 1)):
                for j, cc in enumerate(range(a.c1, a.c2 + 1)):
                    self._por(aba, rr, cc, _final(_pega(v, i, j)))
            return
        if isinstance(v, Matriz):
            v = v.linhas[0][0] if v.linhas and v.linhas[0] else VALOR
        self._por(aba, r, c, _final(v))

    def recalcular(self, mudadas=(), tudo=False, formulas=()):
        """Refaz as formulas que dependem das celulas mudadas (e as `formulas`
        pedidas, com quem depende delas), na ordem certa."""
        if tudo:
            sujas = set(self.formulas)
        else:
            sujas = set(self.volateis) | set(formulas)
            for cel in mudadas:
                sujas |= self._leitores_de(cel)
            pilha = list(sujas)
            while pilha:
                for d in self.dependentes.get(pilha.pop(), ()):
                    if d not in sujas:
                        sujas.add(d)
                        pilha.append(d)
        ordem = sorted((k for k in sujas if k in self.pos and k in self.formulas),
                       key=self.pos.__getitem__)
        for k in ordem:
            self._calcular(k)
        if sujas & self.volateis:         # INDIRETO/DESLOC leem o que a ordem nao previu
            for k in ordem:
                self._calcular(k)
        return ordem

    def _tirar_formula(self, chave):
        f = self.formulas.pop(chave, None)
        self.pos.pop(chave, None)
        self.mostrados.pop(chave, None)
        self.volateis.discard(chave)
        if f is not None and f.alvo is not None:
            for k in [k for k, d in self.donos.items() if d == chave]:
                del self.donos[k]

    # -- a tela
    def texto(self, aba, r, c):
        """O que a grade mostra para a celula (o mesmo que a leitura do arquivo)."""
        v = (self.valores.get(aba) or {}).get((r, c))
        if isinstance(v, Erro):
            return ""
        if (aba, r, c) in self.datas and isinstance(v, float):
            try:
                d = data_de(v)
                v = d.time() if v < 1 else d
            except _ErroSobe:
                pass
        return self.mostrar(v)

    def ligar(self, aba, base, headers, data, mostrar):
        """Liga a grade da tela ao arquivo: o cabecalho esta' na linha `base`.

        So' liga se o que a tela mostra bate com o arquivo nessa posicao. Se a
        conta das linhas sair errada, editar uma celula mexeria na vizinha.
        """
        self.mostrar = mostrar
        if aba not in self.valores:
            return False
        erradas = total = 0
        for i, linha in enumerate(data):
            for j, t in enumerate(linha):
                esperado = self.texto(aba, base + 1 + i, j + 1)
                if esperado == "" and (t or "") == "":
                    continue
                total += 1
                if esperado != (t or ""):
                    erradas += 1
        if erradas > max(2, total // 50):
            return False
        self.telas[aba] = {"base": base, "largura": len(headers),
                           "texto": [list(x) for x in data]}
        for (a, r, c) in self.formulas:
            i = r - base - 1
            if a == aba and 0 <= i < len(data) and c - 1 < len(data[i]):
                self.mostrados.setdefault((a, r, c), set()).add(data[i][c - 1] or "")
        return True

    def estender(self, aba, headers, data):
        """Linha ou coluna que so' tinha formula sem resultado guardado chega
        vazia da leitura do arquivo, e o pandas corta o vazio do fim: uma aba
        so' de formulas abria em branco. Depois de calcular, a grade cresce
        ate' onde ha' valor (headers e data sao alterados no lugar)."""
        tela = self.telas.get(aba)
        if tela is None:
            return False
        base = tela["base"]
        # formula conta mesmo sem valor: coluna cortada da grade e' apagada no Salvar
        cels = list((self.valores.get(aba) or {})) + [k[1:] for k in self.formulas if k[0] == aba]
        ult_l = max((r for (r, c) in cels if r > base), default=base)
        ult_c = max((c for (r, c) in cels if r >= base), default=0)
        mudou = False
        if ult_c > len(headers):
            usados = set(headers)
            for j in range(len(headers) + 1, ult_c + 1):
                nome = self.texto(aba, base, j) or "Unnamed: %d" % (j - 1)
                final, k = nome, 1
                while final in usados:
                    final, k = "%s.%d" % (nome, k), k + 1
                usados.add(final)
                headers.append(final)
            mudou = True
        for linha in data:
            linha.extend([""] * (len(headers) - len(linha)))
        while base + len(data) < ult_l:
            data.append([""] * len(headers))
            mudou = True
        tela["largura"] = len(headers)
        tela["texto"] = [list(x) for x in data]
        return mudou

    def aplicar(self, aba, headers, data, tipar):
        """A tela mandou a aba inteira: acha o que mudou, recalcula e devolve
        {aba: [(linha, coluna, texto)]} do que a tela precisa trocar."""
        tela = self.telas.get(aba)
        if tela is None:
            return {}
        base, velho = tela["base"], tela["texto"]
        largura = len(headers)
        mudadas = set()
        for i in range(max(len(velho), len(data))):
            lv = velho[i] if i < len(velho) else ()
            ln = data[i] if i < len(data) else ()
            for j in range(max(tela["largura"], largura, len(lv), len(ln))):
                tv = (lv[j] if j < len(lv) else "") or ""
                tn = (ln[j] if j < len(ln) and j < largura else "") or ""
                if tv == tn:
                    continue
                chave = (aba, base + 1 + i, j + 1)
                if chave in self.formulas and tn in self.mostrados.get(chave, ()):
                    continue                     # a tela so' estava atrasada
                self._tirar_formula(chave)
                v = tipar(tn)
                if isinstance(v, (datetime.date, datetime.datetime, datetime.time)):
                    self.datas.add(chave)
                    v = serial(v)
                else:
                    self.datas.discard(chave)
                    if isinstance(v, int) and not isinstance(v, bool):
                        v = float(v)
                self._por(aba, chave[1], chave[2], v)
                mudadas.add(chave)
        tela["texto"] = [list(x) for x in data]
        tela["largura"] = largura
        if not mudadas:
            return {}
        return self._remendos(self.recalcular(mudadas))

    def _remendos(self, recalculadas):
        saida = {}
        celulas = []
        for k in recalculadas:
            f = self.formulas.get(k)
            if f is not None and f.alvo is not None:
                a = f.alvo
                celulas.extend((k[0], r, c) for r in range(a.r1, a.r2 + 1)
                               for c in range(a.c1, a.c2 + 1))
            else:
                celulas.append(k)
        for aba, r, c in celulas:
            tela = self.telas.get(aba)
            if tela is None:
                continue
            i, j = r - tela["base"] - 1, c - 1
            if i < 0 or i >= len(tela["texto"]) or j >= tela["largura"]:
                continue
            novo = self.texto(aba, r, c)
            linha = tela["texto"][i]
            while len(linha) <= j:
                linha.append("")
            if (linha[j] or "") == novo:
                continue
            linha[j] = novo
            dono = self.donos.get((aba, r, c), (aba, r, c))
            self.mostrados.setdefault(dono, set()).add(novo)
            saida.setdefault(aba, []).append((i, j, novo))
        return saida

    def viva(self, aba, r, c):
        """A celula ainda e' formula (ninguem digitou valor por cima)?"""
        k = (aba, r, c)
        return k in self.formulas or k in self.donos

    # -- o arquivo
    def gravar_resultados(self, path):
        """Poe o resultado de cada formula ao lado dela no .xlsx (o openpyxl
        grava a formula sem resultado). Devolve quantas celulas recebeu."""
        with zipfile.ZipFile(path) as z:
            wbxml = z.read("xl/workbook.xml").decode("utf-8")
            rels = z.read("xl/_rels/workbook.xml.rels").decode("utf-8")
        alvos = {}
        for m in re.finditer(r"<Relationship\b[^>]*>", rels):
            i = re.search(r'\bId="([^"]+)"', m.group(0))
            t = re.search(r'\bTarget="([^"]+)"', m.group(0))
            if i and t:
                alvo = t.group(1)
                alvo = alvo.lstrip("/") if alvo.startswith("/") else "xl/" + alvo
                alvos[i.group(1)] = alvo
        arquivos = {}
        for m in re.finditer(r"<(?:\w+:)?sheet\b[^>]*>", wbxml):
            n = re.search(r'\bname="([^"]*)"', m.group(0))
            i = re.search(r'\br:id="([^"]+)"', m.group(0))
            if n and i and i.group(1) in alvos:
                nome = (n.group(1).replace("&quot;", '"').replace("&apos;", "'")
                        .replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&"))
                arquivos[alvos[i.group(1)]] = nome
        conta = [0]

        def troca(aba):
            vals = self.valores.get(aba) or {}

            def f(m):
                r, c = int(m.group(2)), column_index_from_string(m.group(1))
                v = vals.get((r, c))
                if v is None:
                    return m.group(0)
                attrs = re.sub(r'\st="[^"]*"', "", m.group(3))
                if isinstance(v, bool):
                    t, corpo = ' t="b"', "1" if v else "0"
                elif isinstance(v, Erro):
                    t, corpo = ' t="e"', v.codigo
                elif isinstance(v, str):
                    t, corpo = ' t="str"', escape(v)
                else:
                    t, corpo = "", repr(float(v))
                conta[0] += 1
                return '<c r="%s%s"%s%s>%s<v>%s</v></c>' % (
                    m.group(1), m.group(2), attrs, t, m.group(4), corpo)
            return f

        padrao = re.compile(r'<c r="([A-Z]+)(\d+)"([^>]*)>(<f\b[^>]*>[^<]*</f>|<f\b[^>]*/>)'
                            r'(?:<v\s*/>|<v>[^<]*</v>)?</c>')
        tmp = path + ".calc.tmp"
        with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                dados = zin.read(item.filename)
                aba = arquivos.get(item.filename)
                if aba is not None:
                    dados = padrao.sub(troca(aba), dados.decode("utf-8")).encode("utf-8")
                zout.writestr(item, dados)
        os.replace(tmp, path)
        return conta[0]


def _final(v):
    if v is None or v is VAZIO:
        return 0.0
    if isinstance(v, Matriz):
        return v.linhas[0][0] if v.linhas and v.linhas[0] else VALOR
    return normal(v)
