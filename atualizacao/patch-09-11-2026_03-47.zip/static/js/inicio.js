/* inicio.js - a tela de Início: o resumo do dia.
 *
 * Item 22 da lista que o Naor aprovou em 12/10/2026: "ao abrir, mostra os
 * rompimentos de hoje, as reprovações recentes e os últimos arquivos, em vez
 * de uma tela vazia".
 *
 * Para haver o que resumir ao abrir, o programa reabre sozinho a última
 * planilha usada (pode desligar em Aparência e configurações). Os números vêm
 * das mesmas contas das outras telas - os rompimentos são os da Agenda, o fck
 * é o do Dashboard - para o Início nunca discordar delas.
 */
(function () {
  'use strict';

  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const DIA_MS = 86400000;
  const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho',
    'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];

  let abrindo = '';          // nome do arquivo sendo reaberto na partida
  let previa = false;

  function hoje() {
    const d = new Date();
    return Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / DIA_MS;
  }
  const diaDe = v => (window.AgendaModule && window.AgendaModule._diaDe ? window.AgendaModule._diaDe(v) : null);
  const fmtDia = n => (window.AgendaModule ? window.AgendaModule._fmtDia(n) : '');
  const num = v => {
    if (typeof v === 'number') return v;
    const t = String(v == null ? '' : v).trim().replace(/\s/g, '');
    if (!t) return NaN;
    const x = t.includes(',') && t.includes('.')
      ? (t.lastIndexOf(',') > t.lastIndexOf('.') ? t.replace(/\./g, '').replace(',', '.') : t.replace(/,/g, ''))
      : t.replace(',', '.');
    const n = Number(x);
    return isFinite(n) ? n : NaN;
  };
  const f1 = n => n.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
  const soNome = p => { const t = String(p || ''); const i = Math.max(t.lastIndexOf('\\'), t.lastIndexOf('/')); return i >= 0 ? t.slice(i + 1) : t; };

  function dados() {
    const d = window.getConcrestatsData ? window.getConcrestatsData({ filtered: true }) : null;
    if (!d || !Array.isArray(d.headers) || !d.headers.length) return null;
    return { headers: d.headers, rows: d.data || [], sheet: d.activeSheet };
  }

  /* -- reprovações: exemplar de 28 dias abaixo do fck pedido ------------
   * Exemplar = o maior dos dois CPs (NBR 12655), como no relatório. A janela
   * é de 30 dias de rompimento até hoje; planilha antiga, sem nada nesse
   * período, usa os 30 dias que terminam no último rompimento dela - e diz. */
  function reprovacoes(f) {
    const c = window.ConcreColunas, lab = window.ConcreLab;
    if (!c || !lab || !lab.fckFrom) return null;
    const H = f.headers;
    const i28 = c.indice(H, 'mpa28'), i28b = c.indice(H, 'mpa28b'), iD = c.indice(H, 'data');
    if (i28 < 0 || iD < 0) return null;
    const iCp = c.indice(H, 'cp'), iCli = c.indice(H, 'cliente');
    const iRec = c.indice(H, 'receita') >= 0 ? c.indice(H, 'receita') : c.indice(H, 'produto');
    const lista = [];
    let ultimo = -Infinity, comFck = 0;
    f.rows.forEach(r => {
      const molde = diaDe(r[iD]);
      if (molde === null) return;
      const a = num(r[i28]), b = i28b >= 0 ? num(r[i28b]) : NaN;
      const va = isFinite(a) && a > 0 && a < 150, vb = isFinite(b) && b > 0 && b < 150;
      if (!va && !vb) return;
      const ex = va && vb ? Math.max(a, b) : va ? a : b;
      const rompe = molde + 28;
      // data no futuro é digitação; não pode puxar a janela para o mês errado
      if (rompe > hoje()) return;
      if (rompe > ultimo) ultimo = rompe;
      const fck = lab.fckFrom(r, H);
      if (!(fck > 0)) return;
      comFck++;
      if (ex < fck) {
        lista.push({ rompe, ex, fck, cp: iCp >= 0 ? String(r[iCp] || '').trim() : '',
          cliente: iCli >= 0 ? String(r[iCli] || '').trim() : '', receita: iRec >= 0 ? String(r[iRec] || '').trim() : '' });
      }
    });
    if (!isFinite(ultimo)) return { lista: [], semDado: true };
    const hj = hoje();
    const recente = ultimo >= hj - 30;
    const fim = recente ? hj : ultimo;
    const janela = lista.filter(x => x.rompe > fim - 30 && x.rompe <= fim).sort((x, y) => y.rompe - x.rompe);
    return { lista: janela, fim, recente, comFck };
  }

  /* -- cartões --------------------------------------------------------- */
  function cartao(classe, titulo, corpo, acao) {
    return '<section class="ini-cartao ' + classe + '"><h3>' + titulo + '</h3>' + corpo +
      (acao ? '<div class="ini-acao">' + acao + '</div>' : '') + '</section>';
  }

  function cartaoRompimentos(f) {
    if (!f) return cartao('ini-romp', 'Rompimentos de hoje', '<p class="ini-vazio">' +
      (abrindo ? 'Abrindo ' + esc(abrindo) + '…' : 'Abra uma planilha para ver a agenda do dia.') + '</p>');
    const r = window.AgendaModule ? window.AgendaModule.resumo() : null;
    if (!r) return cartao('ini-romp', 'Rompimentos de hoje', '<p class="ini-vazio">Agenda indisponível.</p>');
    if (r.semColuna) {
      return cartao('ini-romp', 'Rompimentos de hoje', '<p class="ini-vazio">Não achei a coluna da data de moldagem nesta planilha.</p>',
        '<button type="button" class="ini-link" data-ir="agenda">Escolher na Agenda</button>');
    }
    const partes = r.porIdade.map(x => '<li><span class="ini-idade">' + x.idade + ' dias</span><b>' + x.total + '</b>' +
      (x.total ? '<small>' + (x.feitos === x.total ? 'todos rompidos' : x.feitos + ' rompido(s)') + '</small>' : '') + '</li>').join('');
    return cartao('ini-romp', 'Rompimentos de hoje',
      '<div class="ini-numero">' + r.total + '<small>corpo(s) de prova</small></div><ul class="ini-idades">' + partes + '</ul>',
      '<button type="button" class="ini-link" data-ir="agenda">Abrir a agenda</button>');
  }

  function cartaoAtrasados(f) {
    if (!f) return '';
    const r = window.AgendaModule ? window.AgendaModule.resumo() : null;
    if (!r || r.semColuna) return '';
    return cartao('ini-atras' + (r.atrasados ? ' alerta' : ''), 'Atrasados',
      '<div class="ini-numero">' + r.atrasados + '<small>' + (r.atrasados ? 'passaram do dia sem resultado (últimos 30 dias)' : 'nada passou do dia nos últimos 30 dias') + '</small></div>',
      r.atrasados ? '<button type="button" class="ini-link" data-ir="atrasados">Ver quais são</button>' : '');
  }

  function cartaoReprovacoes(f) {
    if (!f) return cartao('ini-repr', 'Reprovações recentes', '<p class="ini-vazio">Abra uma planilha para ver.</p>');
    const r = reprovacoes(f);
    if (!r) return cartao('ini-repr', 'Reprovações recentes', '<p class="ini-vazio">Sem a coluna do rompimento de 28 dias ou da data de moldagem.</p>');
    if (r.semDado) return cartao('ini-repr', 'Reprovações recentes', '<p class="ini-vazio">Nenhum resultado de 28 dias nesta planilha ainda.</p>');
    if (!r.comFck) return cartao('ini-repr', 'Reprovações recentes', '<p class="ini-vazio">Não achei o fck pedido (coluna própria ou no nome do produto) para comparar.</p>');
    const quando = r.recente ? 'rompidos nos últimos 30 dias'
      : 'nos últimos 30 dias da planilha, até ' + fmtDia(r.fim);
    const linhas = r.lista.slice(0, 6).map(x =>
      '<tr><td class="cp">' + esc(x.cp || '—') + '</td><td class="txt" title="' + esc(x.receita) + '">' + esc(x.receita) +
      '</td><td class="txt" title="' + esc(x.cliente) + '">' + esc(x.cliente) + '</td><td class="n"><b>' + f1(x.ex) +
      '</b> <small>de ' + f1(x.fck) + '</small></td></tr>').join('');
    return cartao('ini-repr' + (r.lista.length ? ' alerta' : ''), 'Reprovações recentes',
      '<div class="ini-numero">' + r.lista.length + '<small>abaixo do fck · ' + esc(quando) + '</small></div>' +
      (linhas ? '<table class="ini-tab"><tbody>' + linhas + '</tbody></table>' +
        (r.lista.length > 6 ? '<p class="ini-mais">e mais ' + (r.lista.length - 6) + '</p>' : '') : ''),
      '<button type="button" class="ini-link" data-ir="previsao">Ver na Previsão</button>');
  }

  /* -- fechamento do mes -------------------------------------------------
   * Item 11 da primeira lista: quantos ensaios, quantos abaixo do fck, a pior
   * versao e o pior cliente, pelo mes em que romperam. Pior e' o maior percentual
   * de falhas, como o Naor definiu, e grupo com menos de 3 ensaios nao entra.
   */
  let fechMes = '';
  function fechamento(f) {
    const c = window.ConcreColunas, lab = window.ConcreLab;
    if (!c || !lab || !lab.fckFrom) return null;
    const H = f.headers;
    const i28 = c.indice(H, 'mpa28'), i28b = c.indice(H, 'mpa28b'), iD = c.indice(H, 'data');
    if (i28 < 0 || iD < 0) return null;
    const iCli = c.indice(H, 'cliente'), iRec = c.indice(H, 'receita') >= 0 ? c.indice(H, 'receita') : c.indice(H, 'produto');
    const meses = new Map(), agora = new Date();
    f.rows.forEach(r => {
      const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(r[iD] == null ? '' : r[iD]));
      if (!m) return;
      const a = num(r[i28]), b = i28b >= 0 ? num(r[i28b]) : NaN;
      const va = isFinite(a) && a > 0 && a < 150, vb = isFinite(b) && b > 0 && b < 150;
      if (!va && !vb) return;
      const rompe = new Date(+m[1], +m[2] - 1, +m[3] + 28);
      if (rompe > agora) return;
      const k = rompe.getFullYear() + '-' + String(rompe.getMonth() + 1).padStart(2, '0');
      if (!meses.has(k)) meses.set(k, []);
      const fck = lab.fckFrom(r, H), ex = va && vb ? Math.max(a, b) : va ? a : b;
      meses.get(k).push({ ex, fck: fck > 0 ? fck : NaN, cli: iCli >= 0 ? String(r[iCli] || '').trim() : '', rec: iRec >= 0 ? String(r[iRec] || '').trim() : '' });
    });
    const P = window.PainelModule, linhas = [];
    meses.forEach((v, k) => v.forEach(() => linhas.push([k + '-15'])));
    const soltos = P && P._mesesIsolados ? P._mesesIsolados(linhas, 0) : [];
    const chaves = [...meses.keys()].filter(k => !soltos.includes(k)).sort();
    if (!chaves.length) return null;
    const mes = chaves.includes(fechMes) ? fechMes : chaves[chaves.length - 1];
    const lista = meses.get(mes), julgados = lista.filter(x => isFinite(x.fck));
    const abaixo = julgados.filter(x => x.ex < x.fck);
    const pior = campo => {
      const g = new Map();
      julgados.forEach(x => {
        const k = x[campo];
        if (!k) return;
        const t = g.get(k) || { n: 0, f: 0 };
        t.n++; if (x.ex < x.fck) t.f++;
        g.set(k, t);
      });
      return [...g.entries()].filter(([, t]) => t.n >= 3 && t.f > 0).map(([k, t]) => ({ k, n: t.n, f: t.f, p: t.f / t.n }))
        .sort((x, y) => y.p - x.p || y.f - x.f)[0] || null;
    };
    return { mes, chaves, ensaios: lista.length, julgados: julgados.length, abaixo: abaixo.length, versao: pior('rec'), cliente: pior('cli') };
  }

  const rotuloDoMes = k => MESES[+k.slice(5, 7) - 1] + ' de ' + k.slice(0, 4);
  const piorHtml = (nome, x) => '<p class="ini-mais"><b>' + nome + ':</b> ' + (x ? esc(x.k) + ' (' + x.f + ' de ' + x.n + ', ' +
    Math.round(x.p * 100) + '%)' : 'nenhum com 3 ensaios ou mais abaixo do fck') + '</p>';

  function cartaoFechamento(f) {
    const r = f ? fechamento(f) : null;
    if (!r) return '';
    const opcoes = r.chaves.slice().reverse().map(k => '<option value="' + k + '"' + (k === r.mes ? ' selected' : '') + '>' + esc(rotuloDoMes(k)) + '</option>').join('');
    return cartao('ini-fech', 'Fechamento do mês',
      '<select id="ini-fech-mes" aria-label="Mês do fechamento">' + opcoes + '</select>' +
      '<div class="ini-numero">' + r.ensaios.toLocaleString('pt-BR') + '<small>ensaios rompidos · ' + r.abaixo.toLocaleString('pt-BR') + ' abaixo do fck (' +
        (r.julgados ? f1(100 * r.abaixo / r.julgados) : '0,0') + '%)</small></div>' +
      piorHtml('Pior versão', r.versao) + piorHtml('Pior cliente', r.cliente),
      '<button type="button" class="ini-link" id="ini-fech-excel">Exportar para Excel</button>');
  }

  function ligarFechamento(f) {
    const s = $('ini-fech-mes');
    if (s) s.addEventListener('change', () => { fechMes = s.value; render(); });
    const b = $('ini-fech-excel');
    if (b) b.addEventListener('click', () => {
      const r = fechamento(f), L = window.ConcreLaboratorio;
      if (!r || !L) return;
      L.exportar([['Fechamento de ' + rotuloDoMes(r.mes)], ['Ensaios rompidos', r.ensaios], ['Com fck conhecido', r.julgados], ['Abaixo do fck', r.abaixo],
        ['Pior versão', r.versao ? r.versao.k : '', r.versao ? r.versao.f + ' de ' + r.versao.n : ''],
        ['Pior cliente', r.cliente ? r.cliente.k : '', r.cliente ? r.cliente.f + ' de ' + r.cliente.n : '']], 'fechamento_' + r.mes, 'Fechamento');
    });
  }

  function cartaoCalibracao() {
    const cal = window.ConcreCalibracao ? window.ConcreCalibracao() : null;
    let corpo, classe = 'ini-cal';
    if (!cal) {
      corpo = '<p class="ini-vazio">Validade do certificado não informada.</p>';
    } else if (cal.dias < 0) {
      classe += ' alerta';
      corpo = '<div class="ini-numero">Vencida<small>desde ' + cal.data + '</small></div>';
    } else if (cal.dias <= 30) {
      classe += ' atencao';
      corpo = '<div class="ini-numero">' + cal.dias + ' dia' + (cal.dias === 1 ? '' : 's') + '<small>para vencer · ' + cal.data + '</small></div>';
    } else {
      corpo = '<div class="ini-numero ok">Em dia<small>válida até ' + cal.data + '</small></div>';
    }
    return cartao(classe, 'Calibração da prensa', corpo, '<button type="button" class="ini-link" data-ir="fixos">Campos fixos</button>');
  }

  function cartaoArquivos(f) {
    const R = window.ConcrestatsRecentes;
    const lista = R ? R.lista() : [];
    const itens = lista.slice(0, 6).map((r, i) => '<li><button type="button" class="ini-arq" data-i="' + i + '" title="' + esc(r.path) + '">' +
      '<b>' + esc(soNome(r.path)) + '</b><small>' + esc(r.path) + '</small></button></li>').join('');
    const aberta = f ? '<p class="ini-aberta">Aberta agora: <b>' + esc(soNome(window.__concreSourcePath || '') || f.sheet || '') +
      '</b> · ' + f.rows.length.toLocaleString('pt-BR') + ' linhas</p>' : '';
    return cartao('ini-arqs', 'Últimos arquivos', aberta + (itens ? '<ul class="ini-arquivos">' + itens + '</ul>'
      : '<p class="ini-vazio">Nenhum arquivo aberto ainda.</p>') + (R ? R.pastasHtml() : ''),
      '<button type="button" class="ini-link" data-ir="abrir">Abrir outro arquivo</button>');
  }

  /* -- a tela ---------------------------------------------------------- */
  function cumprimento() {
    const h = new Date().getHours();
    return h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite';
  }
  function empresa() {
    try { return String((JSON.parse(localStorage.getItem('concrestats_ensaio_fixos') || '{}') || {}).empresa || '').trim(); }
    catch (e) { return ''; }
  }

  function render() {
    const host = $('ini-corpo');
    if (!host) return;
    const f = dados();
    const d = new Date();
    const data = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'][d.getDay()] +
      ', ' + d.getDate() + ' de ' + MESES[d.getMonth()] + ' de ' + d.getFullYear();
    host.innerHTML =
      '<div class="ini-folha">' +
        '<header class="ini-cab"><div><p class="ini-data">' + esc(data) + '</p><h1>' + cumprimento() +
          (empresa() ? '<span>' + esc(empresa()) + '</span>' : '') + '</h1></div>' +
          (!f && !abrindo ? '<div class="ini-cab-acoes"><button type="button" class="primary-btn" data-ir="abrir">Abrir planilha</button></div>' : '') +
        '</header>' +
        '<div class="ini-grade">' +
          cartaoRompimentos(f) + cartaoAtrasados(f) + cartaoReprovacoes(f) + cartaoFechamento(f) + cartaoCalibracao() + cartaoArquivos(f) +
        '</div>' +
      '</div>';
    host.querySelectorAll('[data-ir]').forEach(b => b.addEventListener('click', () => ir(b.dataset.ir)));
    if (f) ligarFechamento(f);
    if (window.ConcrestatsRecentes) window.ConcrestatsRecentes.ligarPastas(host);
    host.querySelectorAll('.ini-arq[data-i]').forEach(b => b.addEventListener('click', async () => {
      const R = window.ConcrestatsRecentes;
      const rec = R && R.lista()[Number(b.dataset.i)];
      if (!rec) return;
      abrindo = soNome(rec.path); render();
      await R.abrir(rec);
      abrindo = ''; render();
    }));
  }

  function ir(onde) {
    const abrir = window.ConcrestatsOpenModule;
    if (!abrir) return;
    if (onde === 'agenda') {
      if (window.AgendaModule) window.AgendaModule.irPara(hoje());
      abrir('agenda');
    } else if (onde === 'atrasados') {
      if (window.AgendaModule) window.AgendaModule.verAtrasados();
      abrir('agenda');
    } else if (onde === 'previsao') {
      abrir('previsao');
    } else if (onde === 'fixos') {
      abrir('relatorio');
      setTimeout(() => $('rep-fixos')?.click(), 120);
    } else if (onde === 'abrir') {
      abrir('spreadsheet');
      setTimeout(() => $('btn-upload')?.click(), 60);
    }
  }

  /* -- a partida ------------------------------------------------------- */
  async function partida() {
    previa = await (window.ConcrePrevia || Promise.resolve(false));
    if (!previa || !window.ConcrestatsOpenModule) return;
    window.ConcrestatsOpenModule('inicio');
    if (dados()) return;
    if (window.ConcrestatsRecuperar && await window.ConcrestatsRecuperar()) return;
    let reabrir = '';
    try { reabrir = sessionStorage.getItem('concre_reabrir') || ''; sessionStorage.removeItem('concre_reabrir'); } catch (e) { /* ok */ }
    const R = window.ConcrestatsRecentes;
    if (!R) return;
    const lista = await R.carregado();
    const alvo = reabrir ? (lista.find(r => r.path === reabrir) || { path: reabrir, nome: soNome(reabrir) })
      : (window.ConcreAparencia && window.ConcreAparencia.abrirUltima() ? lista[0] : null);
    if (alvo) {
      abrindo = soNome(alvo.path);
      render();
      await R.abrir(alvo, true);
      abrindo = '';
    }
    if (window.AgendaModule && window.AgendaModule.carregar) await window.AgendaModule.carregar();
    render();
  }

  window.addEventListener('concrestats:pastas', () => {
    const m = $('module-inicio');
    if (m && m.style.display !== 'none') render();
  });
  window.addEventListener('concrestats:datachanged', () => {
    const m = $('module-inicio');
    if (m && m.style.display !== 'none') render();
  });
  document.addEventListener('DOMContentLoaded', () => { setTimeout(partida, 0); });

  window.InicioModule = {
    onModuleEnter: () => {
      const a = window.AgendaModule && window.AgendaModule.carregar ? window.AgendaModule.carregar() : Promise.resolve();
      a.then(render);
    },
    // para o Modo Teste
    _reprovacoes: () => { const f = dados(); return f ? reprovacoes(f) : null; },
  };
})();
