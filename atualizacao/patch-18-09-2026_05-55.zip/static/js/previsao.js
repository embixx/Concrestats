/**
 * previsao.js — Previsão do rompimento de 28 dias e alerta de receita fora da faixa
 *
 * Pedido do Naor: "fazer previsão de resultados de receita, e identificar na
 * tabela que receitas estão saindo da faixa de resistência desejada".
 *
 * Por que isto NÃO é um modelo de linguagem
 * -----------------------------------------
 * Num laboratório o número precisa ser defensável na frente do cliente: de onde
 * saiu, com quantos ensaios, com que erro. Um palpite que ninguém consegue
 * rastrear não serve para nada aqui — e ainda exigiria embutir chave de API num
 * programa que é distribuído, que é justamente o que estamos evitando.
 *
 * Então é estatística, com a conta à mostra. E com uma regra: quando o histórico
 * não sustenta a previsão, esta tela DIZ isso em vez de inventar um número.
 *
 * O que foi medido antes de escrever (4.809 ensaios reais da Usinop, treinando
 * na metade antiga de cada receita e testando na metade nova):
 *
 *     palpite burro ("essa receita costuma dar X")   6,33 MPa de erro
 *     razão 28/7 da própria receita                  5,30 MPa
 *     reta ajustada na própria receita               4,73 MPa   <- é o que usamos
 *
 * Ganha do palpite burro por cerca de 25%. É real, e é pouco: por isso a margem
 * aparece SEMPRE junto do número.
 */
(function () {
  'use strict';

  // Mínimo para a reta valer alguma coisa. Abaixo disso a reta acompanha o
  // ruído e erra com confiança, que é pior do que não responder.
  const MINIMO_DE_ENSAIOS = 12;
  // Acima deste erro a própria receita é irregular demais para ser prevista.
  const ERRO_INACEITAVEL = 8;
  // Para o alerta de faixa basta menos histórico: a conta é média e desvio.
  const MINIMO_PARA_FAIXA = 6;

  const est = { receita: null, cadastro: [] };

  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function br(v, casas) {
    const n = Number(v);
    if (!isFinite(n)) return '—';
    return n.toFixed(casas === undefined ? 1 : casas).replace('.', ',');
  }
  function numBR(v) {
    if (v === null || v === undefined) return NaN;
    if (typeof v === 'number') return isFinite(v) ? v : NaN;
    let s = String(v).trim().replace(/\s| /g, '');
    if (!s) return NaN;
    s = s.replace(/[^0-9,.\-]/g, '');
    if (!s || s === '-' || s === ',' || s === '.') return NaN;
    if (s.includes(',') && s.includes('.')) {
      s = s.lastIndexOf(',') > s.lastIndexOf('.')
        ? s.replace(/\./g, '').replace(',', '.')
        : s.replace(/,/g, '');
    } else if (s.includes(',')) s = s.replace(',', '.');
    const n = Number(s);
    return isFinite(n) ? n : NaN;
  }

  /* ── o que o concreto não faz ─────────────────────────────────────────
   * Na planilha da Usinop, 12% das linhas com 7 e 28 dias eram fisicamente
   * impossíveis — e mandavam no resultado. Antes de limpar, a correlação
   * entre 7 e 28 dias dava 0,23 e uma receita aparecia com média 214 MPa e
   * desvio 723. Depois de limpar, vira um problema tratável.
   */
  function possivel(p) {
    if (!isFinite(p.d7) || !isFinite(p.d28)) return false;
    if (p.d7 <= 0 || p.d28 <= 0) return false;
    if (p.d7 > 120 || p.d28 > 120) return false;       // não existe nessa usina
    if (p.d28 < p.d7 * 0.7) return false;              // cair assim é digitação
    if (p.d28 > p.d7 * 4) return false;                // subir assim também
    return true;
  }

  function coluna(headers, nomes) {
    for (const n of nomes) {
      const i = headers.findIndex(h => String(h).trim().toUpperCase() === n);
      if (i >= 0) return i;
    }
    return -1;
  }

  /* ── fck pedido: o cadastro manda, o nome é o segundo melhor ───────── */
  function chaveNome(s) {
    return String(s || '').trim().toUpperCase().replace(/\s+/g, ' ');
  }
  function fckDoCadastro(nome) {
    const k = chaveNome(nome);
    const rec = (est.cadastro || []).find(r => chaveNome(r.nome) === k);
    if (!rec || !Array.isArray(rec.versoes) || !rec.versoes.length) return NaN;
    const v = rec.versoes.find(x => x.id === rec.versaoAtiva) || rec.versoes[0];
    const direto = numBR(v && v.fck);
    if (!isNaN(direto) && direto > 0) return direto;
    const p = ((v && v.propriedades) || []).find(x => /fck|resist/i.test(x.nome || ''));
    const pv = p ? numBR(p.consumo) : NaN;
    return (!isNaN(pv) && pv > 0) ? pv : NaN;
  }
  function fckDoNome(nome) {
    const m = String(nome || '').toUpperCase().match(/FCK\s*[-:_]*\s*(\d+(?:[.,]\d+)?)/);
    return m ? numBR(m[1]) : NaN;
  }
  function fckPedido(nome) {
    const c = fckDoCadastro(nome);
    if (!isNaN(c)) return { valor: c, origem: 'cadastro' };
    const n = fckDoNome(nome);
    return { valor: n, origem: isNaN(n) ? null : 'nome' };
  }

  /* ── junta os ensaios por receita ─────────────────────────────────── */
  function porReceita() {
    const sd = window.getConcrestatsData ? window.getConcrestatsData({ filtered: true }) : null;
    if (!sd || !sd.headers || !sd.headers.length) return null;
    const h = sd.headers;
    const iR = coluna(h, ['PRODUTO', 'RECEITA', 'TRAÇO', 'TRACO', 'NOME']);
    const i7 = coluna(h, ['MPA 7', 'MPA7', 'MPA 7D']);
    const i28 = coluna(h, ['MPA 28', 'MPA28', 'MPA 28D']);
    if (iR < 0 || i28 < 0) return { erro: 'faltaColuna', temR: iR >= 0, tem28: i28 >= 0 };

    const mapa = new Map();
    let descartados = 0, comParDeEnsaios = 0;
    sd.data.forEach(linha => {
      const nome = String(linha[iR] || '').trim();
      if (!nome) return;
      const d28 = numBR(linha[i28]);
      if (!isFinite(d28) || d28 <= 0 || d28 > 120) { if (isFinite(d28)) descartados++; return; }
      const d7 = i7 >= 0 ? numBR(linha[i7]) : NaN;
      if (!mapa.has(nome)) mapa.set(nome, { nome, todos: [], pares: [] });
      const r = mapa.get(nome);
      r.todos.push(d28);
      if (isFinite(d7)) {
        comParDeEnsaios++;
        const p = { d7, d28 };
        if (possivel(p)) r.pares.push(p);
        else descartados++;
      }
    });
    return { receitas: [...mapa.values()], descartados, comParDeEnsaios, semColuna7: i7 < 0 };
  }

  function media(a) { return a.reduce((s, v) => s + v, 0) / a.length; }
  function desvio(a) {
    if (a.length < 2) return 0;
    const m = media(a);
    return Math.sqrt(a.reduce((s, v) => s + (v - m) * (v - m), 0) / (a.length - 1));
  }

  /* ── a reta desta receita, e o erro que ela comete nos próprios dados ─ */
  function reta(pares) {
    const n = pares.length;
    if (n < 2) return null;
    const mx = media(pares.map(p => p.d7));
    const my = media(pares.map(p => p.d28));
    let num = 0, den = 0;
    pares.forEach(p => { num += (p.d7 - mx) * (p.d28 - my); den += (p.d7 - mx) * (p.d7 - mx); });
    if (!den) return null;
    const a = num / den;
    const b = my - a * mx;
    const erros = pares.map(p => Math.abs(a * p.d7 + b - p.d28));
    return { a, b, erro: media(erros), n };
  }

  function analisar(r) {
    const alvo = fckPedido(r.nome);
    const vals = r.todos;
    const m = vals.length ? media(vals) : NaN;
    const sd = desvio(vals);
    // NBR 12655: a resistência característica estimada é média − 1,65 · desvio.
    // É por ela que a receita passa ou não, e não pela média — que é onde quase
    // toda receita desta usina parece bem e mesmo assim reprova.
    const fckEst = vals.length >= MINIMO_PARA_FAIXA ? m - 1.65 * sd : NaN;
    const folga = (isFinite(fckEst) && isFinite(alvo.valor)) ? fckEst - alvo.valor : NaN;
    return { ...r, alvo, n: vals.length, media: m, desvio: sd, fckEst, folga,
             reta: reta(r.pares) };
  }

  /* ── PREVISÃO ──────────────────────────────────────────────────────── */
  function prever(a, mpa7) {
    if (!a || !a.reta) {
      return { ok: false, msg: 'Esta receita não tem ensaios de 7 dias suficientes para prever.' };
    }
    if (a.reta.n < MINIMO_DE_ENSAIOS) {
      return { ok: false, msg: 'Só ' + a.reta.n + ' ensaios com 7 e 28 dias. Abaixo de ' +
                              MINIMO_DE_ENSAIOS + ' a conta segue o acaso, não a receita.' };
    }
    if (a.reta.erro > ERRO_INACEITAVEL) {
      return { ok: false, msg: 'O histórico desta receita varia demais (erro típico de ' +
                              br(a.reta.erro) + ' MPa). Prever aqui seria inventar um número.' };
    }
    const v = a.reta.a * mpa7 + a.reta.b;
    if (!isFinite(v)) return { ok: false, msg: 'Não consegui calcular.' };
    return { ok: true, valor: v, erro: a.reta.erro, n: a.reta.n,
             minimo: v - a.reta.erro, maximo: v + a.reta.erro };
  }

  /* ── TELA ──────────────────────────────────────────────────────────── */
  function render() {
    const corpo = $('prev-corpo');
    if (!corpo) return;
    const dados = porReceita();

    if (!dados) {
      corpo.innerHTML = vazio('Abra uma planilha de rompimentos',
        'Preciso de uma coluna de produto/receita e de uma coluna MPA 28.');
      return;
    }
    if (dados.erro === 'faltaColuna') {
      corpo.innerHTML = vazio('Não achei as colunas certas',
        'Esta tela precisa de uma coluna com o nome da receita (PRODUTO ou RECEITA) e de ' +
        'uma coluna MPA 28. A de MPA 7 é opcional: sem ela dá para alertar, mas não prever.');
      return;
    }

    const analisadas = dados.receitas.map(analisar);
    const comFaixa = analisadas.filter(a => isFinite(a.folga))
      .sort((x, y) => x.folga - y.folga);
    const fora = comFaixa.filter(a => a.folga < 0);

    corpo.innerHTML =
      blocoResumo(analisadas, comFaixa, fora, dados) +
      blocoFaixa(comFaixa) +
      blocoPrevisao(analisadas);

    ligarPrevisao(analisadas);
  }

  function vazio(titulo, sub) {
    return '<div class="graf-empty-state"><div class="empty-icon">◈</div>' +
           '<p>' + esc(titulo) + '</p><p class="empty-sub">' + esc(sub) + '</p></div>';
  }

  function blocoResumo(todas, comFaixa, fora, dados) {
    const aviso = dados.descartados
      ? '<p class="prev-nota">Deixei de fora ' + dados.descartados + ' ensaio(s) fisicamente ' +
        'impossível(is) — resistência negativa, acima de 120 MPa, ou 28 dias muito abaixo do ' +
        'próprio 7 dias. São erros de digitação, e incluí-los distorce tudo.</p>'
      : '';
    return '<div class="prev-resumo">' +
      cartao(todas.length, 'receitas na planilha') +
      cartao(comFaixa.length, 'com histórico para julgar') +
      cartao(fora.length, 'abaixo do fck pedido', fora.length ? 'ruim' : 'bom') +
      '</div>' + aviso;
  }
  function cartao(valor, rotulo, tom) {
    return '<div class="prev-cartao ' + (tom || '') + '">' +
           '<div class="prev-cartao-num">' + valor + '</div>' +
           '<div class="prev-cartao-rot">' + esc(rotulo) + '</div></div>';
  }

  function blocoFaixa(lista) {
    if (!lista.length) {
      return secao('Receitas fora da faixa',
        '<p class="prev-nota">Nenhuma receita tem ensaios suficientes (mínimo ' +
        MINIMO_PARA_FAIXA + ') para o cálculo.</p>');
    }
    const linhas = lista.map(a => {
      const ruim = a.folga < 0;
      return '<tr class="' + (ruim ? 'prev-fora' : '') + '">' +
        '<td class="prev-nome" title="' + esc(a.nome) + '">' + esc(a.nome) + '</td>' +
        '<td>' + a.n + '</td>' +
        '<td>' + br(a.alvo.valor, 0) + (a.alvo.origem === 'nome' ? '<span class="prev-marca" title="lido do nome do produto; cadastre a receita para usar o valor oficial">?</span>' : '') + '</td>' +
        '<td>' + br(a.media) + '</td>' +
        '<td>' + br(a.desvio, 2) + '</td>' +
        '<td><b>' + br(a.fckEst) + '</b></td>' +
        '<td class="' + (ruim ? 'prev-neg' : 'prev-pos') + '">' +
          (a.folga >= 0 ? '+' : '') + br(a.folga) + '</td>' +
      '</tr>';
    }).join('');

    const explica =
      '<p class="prev-nota"><b>Como se lê:</b> pela NBR 12655 quem aprova a receita não é a ' +
      'média, é a resistência característica estimada — média menos 1,65 vezes o desvio. ' +
      'Repare que quase toda receita desta lista tem média ACIMA do fck pedido e mesmo assim ' +
      'fica abaixo: o que reprova é a irregularidade, não a fraqueza. Concreto irregular ' +
      'gasta cimento a mais e continua não passando.</p>';

    return secao('Receitas fora da faixa',
      '<div class="prev-tabela-wrap"><table class="prev-tabela">' +
      '<thead><tr><th>Receita</th><th>Ensaios</th><th>fck pedido</th><th>Média</th>' +
      '<th>Desvio</th><th>fck estimado</th><th>Folga</th></tr></thead>' +
      '<tbody>' + linhas + '</tbody></table></div>' + explica);
  }

  function blocoPrevisao(todas) {
    const podem = todas.filter(a => a.reta && a.reta.n >= MINIMO_DE_ENSAIOS)
      .sort((x, y) => y.reta.n - x.reta.n);
    if (!podem.length) {
      return secao('Prever o rompimento de 28 dias',
        '<p class="prev-nota">Nenhuma receita tem ' + MINIMO_DE_ENSAIOS + ' ou mais ensaios ' +
        'com os dois rompimentos (7 e 28 dias) preenchidos. Sem esse par não há o que aprender.</p>');
    }
    const opcoes = podem.map(a =>
      '<option value="' + esc(a.nome) + '">' + esc(a.nome) + '  (' + a.reta.n + ' ensaios)</option>'
    ).join('');
    return secao('Prever o rompimento de 28 dias',
      '<div class="prev-form">' +
        '<label>Receita</label><select id="prev-receita">' + opcoes + '</select>' +
        '<label>Resistência aos 7 dias (MPa)</label>' +
        // type="text" de proposito: um campo numerico RECUSA a virgula, e aqui
        // todo mundo digita "18,5". O numBR ja' entende os dois jeitos.
        '<input id="prev-mpa7" type="text" inputmode="decimal" placeholder="ex: 18,5">' +
        '<button class="primary-btn" id="prev-calcular">Prever</button>' +
      '</div><div id="prev-saida"></div>');
  }

  function secao(titulo, dentro) {
    return '<div class="prev-secao"><h3>' + esc(titulo) + '</h3>' + dentro + '</div>';
  }

  function ligarPrevisao(todas) {
    const bt = $('prev-calcular');
    if (!bt) return;
    const calcular = () => {
      const nome = $('prev-receita').value;
      const mpa7 = numBR($('prev-mpa7').value);
      const saida = $('prev-saida');
      if (!isFinite(mpa7) || mpa7 <= 0) {
        saida.innerHTML = '<p class="prev-nota">Digite a resistência dos 7 dias.</p>';
        return;
      }
      const a = todas.find(x => x.nome === nome);
      const r = prever(a, mpa7);
      if (!r.ok) {
        saida.innerHTML = '<div class="prev-recusa"><b>Não vou prever.</b> ' + esc(r.msg) + '</div>';
        return;
      }
      const alvo = a.alvo.valor;
      const passa = isFinite(alvo) ? (r.minimo >= alvo) : null;
      const risco = isFinite(alvo) && !passa
        ? '<div class="prev-risco">Com a margem, este corpo de prova pode ficar abaixo do fck de ' +
          br(alvo, 0) + ' MPa. Vale acompanhar.</div>'
        : '';
      saida.innerHTML =
        '<div class="prev-resultado">' +
          '<div class="prev-numero">' + br(r.valor) + ' <small>MPa aos 28 dias</small></div>' +
          '<div class="prev-margem">entre ' + br(r.minimo) + ' e ' + br(r.maximo) +
            ' — erro típico de ' + br(r.erro) + ' MPa nesta receita</div>' +
          '<div class="prev-base">calculado sobre ' + r.n + ' ensaios desta mesma receita</div>' +
        '</div>' + risco;
    };
    bt.addEventListener('click', calcular);
    $('prev-mpa7').addEventListener('keydown', e => { if (e.key === 'Enter') calcular(); });
  }

  /* ── cadastro de receitas: o fck oficial vem de lá ─────────────────── */
  function carregarCadastro() {
    try {
      const raw = localStorage.getItem('concrelab_receitas');
      if (raw) est.cadastro = JSON.parse(raw) || [];
    } catch (e) { /* segue com o nome */ }
    // Como no módulo de Gráficos, quem vai à rede aqui é a tela, e é local.
    try {
      fetch('/api/receitas')
        .then(r => (r.ok ? r.json() : null))
        .then(lista => { if (Array.isArray(lista)) est.cadastro = lista; })
        .catch(() => {});
    } catch (e) { /* idem */ }
  }

  document.addEventListener('DOMContentLoaded', function () {
    carregarCadastro();
    const b = $('prev-atualizar');
    if (b) b.addEventListener('click', render);
    window.addEventListener('concrestats:datachanged', () => {
      const el = $('module-previsao');
      if (el && el.style.display !== 'none') setTimeout(render, 50);
    });
  });

  window.PrevisaoModule = {
    onModuleEnter() { carregarCadastro(); render(); },
    // exposto para o Modo Teste conferir a conta sem depender da tela
    _analisar: () => (porReceita() || { receitas: [] }).receitas.map(analisar),
    _prever: prever,
  };
})();
