/**
 * receitas.js - Módulo de Cadastro de Receitas de Concreto
 * ConcreLab v1.2
 *
 * Modelo: receita = produto, cada produto tem versoes[]
 * Persistência: /api/receitas (JSON no disco) + fallback localStorage
 */

(function () {
  'use strict';

  // Escapa texto do usuário antes de injetar em innerHTML/atributos
  // (nomes de receita/versão com " < > & não quebram mais a lista).
  const esc = s => String(s ?? '').replace(/[&<>"']/g,
    c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));

  /* -------------------------------------------------
     ESTADO
  ------------------------------------------------- */
  let receitas     = [];
  let receitaAtiva = null;
  let versaoAtiva  = null;
  let unsaved      = false;

  /* -------------------------------------------------
     NAVEGAÇÃO
  ------------------------------------------------- */
  function mudarModulo(mod) {
    // Mostra/oculta módulos de forma defensiva.
    // Antes alguns botões de Relatório ficavam sem ação quando a página era aberta em janela/app.
    const appEl      = document.getElementById('app');
    const receitasEl = document.getElementById('module-receitas');
    const graficosEl = document.getElementById('module-graficos');
    const dashEl     = document.getElementById('module-dashboard');
    const relEl      = document.getElementById('module-relatorio');
    const anaEl      = document.getElementById('module-analise');
    const panEl      = document.getElementById('module-painel');
    const prevEl     = document.getElementById('module-previsao');
    const iniEl      = document.getElementById('module-inicio');
    const ageEl      = document.getElementById('module-agenda');

    // Painel de filtros aberto em outra tela volta para Planilhas antes de ela sumir.
    if (window.ConcrestatsRecolherFiltros) window.ConcrestatsRecolherFiltros();

    if (appEl)      appEl.style.display      = mod === 'spreadsheet' ? '' : 'none';
    if (iniEl)      iniEl.style.display      = mod === 'inicio' ? 'flex' : 'none';
    if (ageEl)      ageEl.style.display      = mod === 'agenda' ? 'flex' : 'none';
    if (receitasEl) receitasEl.classList.toggle('active', mod === 'receitas');
    if (graficosEl) graficosEl.style.display = mod === 'charts' ? 'flex' : 'none';
    if (dashEl)     dashEl.style.display     = mod === 'dashboard' ? 'flex' : 'none';
    if (relEl)      relEl.style.display      = mod === 'relatorio' ? 'flex' : 'none';
    if (anaEl)      anaEl.style.display      = mod === 'analise' ? 'flex' : 'none';
    if (panEl)      panEl.style.display      = mod === 'painel' ? 'flex' : 'none';
    if (prevEl)     prevEl.style.display     = mod === 'previsao' ? 'flex' : 'none';

    // Atualiza nav. O Relatório técnico não tem aba própria - abre a partir da
    // planilha (Exportar > Relatório) - e a barra ficava sem nada marcado, como
    // se a pessoa estivesse em lugar nenhum. Acende Planilhas, de onde ela veio.
    const destaque = mod === 'relatorio' ? 'spreadsheet' : mod;
    document.querySelectorAll('.nav-btn[data-module]').forEach(b => {
      b.classList.toggle('active', b.dataset.module === destaque);
    });

    if (mod === 'receitas') carregarReceitas().then(renderLista);
    if (mod === 'charts' && window.GraficosModule) window.GraficosModule.onModuleEnter();
    if (mod === 'dashboard' && window.DashboardModule) window.DashboardModule.onModuleEnter();
    if (mod === 'relatorio' && window.RelatorioModule) {
      setTimeout(() => window.RelatorioModule.onModuleEnter(), 0);
    }
    if (mod === 'analise' && window.AnaliseModule) {
      setTimeout(() => window.AnaliseModule.onModuleEnter(), 0);
    }
    if (mod === 'painel' && window.PainelModule) {
      setTimeout(() => window.PainelModule.onModuleEnter(), 0);
    }
    if (mod === 'previsao' && window.PrevisaoModule) {
      setTimeout(() => window.PrevisaoModule.onModuleEnter(), 0);
    }
    if (mod === 'inicio' && window.InicioModule) {
      setTimeout(() => window.InicioModule.onModuleEnter(), 0);
    }
    if (mod === 'agenda' && window.AgendaModule) {
      setTimeout(() => window.AgendaModule.onModuleEnter(), 0);
    }
  }

  // Expõe navegação para outros módulos/botões, inclusive Exportar > Relatório.
  window.ConcrestatsOpenModule = mudarModulo;

  // Listener delegado: funciona mesmo com botões adicionados depois ou em topbars duplicadas.
  document.addEventListener('click', (ev) => {
    const btn = ev.target.closest('.nav-btn[data-module], [data-open-module]');
    if (!btn) return;
    if (btn.classList.contains('disabled')) return;
    const mod = btn.dataset.module || btn.dataset.openModule;
    if (!mod) return;
    ev.preventDefault();
    mudarModulo(mod);
  });

  /* -------------------------------------------------
     PERSISTÊNCIA
  ------------------------------------------------- */
  async function carregarReceitas() {
    try {
      const r = await fetch('/api/receitas');
      if (r.ok) { receitas = migrarStatus(await r.json()); return; }
    } catch (_) {}
    const raw = localStorage.getItem('concrelab_receitas');
    receitas = migrarStatus(raw ? JSON.parse(raw) : []);
  }

  // Ativa, teste e descontinuada sao da VERSAO: um produto pode ter a versao
  // antiga descontinuada e a nova em teste. Quem ja' estava salvo so' com o
  // status do produto passa ele para as versoes. r.status continua existindo,
  // igual ao da versao ativa, para quem ainda le o campo antigo.
  function migrarStatus(lista) {
    (lista || []).forEach(r => (r.versoes || []).forEach(v => {
      if (!v.status) v.status = r.status || 'ativa';
    }));
    return lista;
  }
  const ROTULO_STATUS = { ativa: 'Ativa', teste: 'Teste', descontinuada: 'Descont.' };
  const statusDe = (r, v) => (v && v.status) || r.status || 'ativa';

  // Devolve se o servidor gravou: a cópia no localStorage só é lida quando ele
  // não responde, então fechar o programa em cima dela perderia a edição.
  async function salvarReceitas() {
    let gravou = false;
    try {
      const r = await fetch('/api/receitas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(receitas)
      });
      gravou = r.ok;
    } catch (_) {}
    localStorage.setItem('concrelab_receitas', JSON.stringify(receitas));
    return gravou;
  }

  let _idSeq = 0;
  function gerarId(p = 'ID') {
    _idSeq++;
    return p + '-' + Date.now().toString(36).toUpperCase() + _idSeq.toString(36).toUpperCase();
  }
  function hoje() { return new Date().toLocaleDateString('pt-BR'); }

  /* -------------------------------------------------
     LISTA LATERAL
  ------------------------------------------------- */
  // Na prévia o filtro da planilha vale aqui também: receita é a coluna PRODUTO,
  // então a lista fica só com as que aparecem nas linhas filtradas. Sem filtro,
  // ou sem essa coluna, devolve null e a lista não muda.
  function nomesDoFiltro() {
    if (document.documentElement.dataset.previa !== '1') return null;
    const d = window.getConcrestatsData ? window.getConcrestatsData({ filtered: true }) : null;
    if (!d || !(d.filters || []).length || !window.ConcreColunas) return null;
    const i = window.ConcreColunas.indice(d.headers, 'produto');
    if (i < 0) return null;
    return new Set(d.data.map(l => String(l[i] ?? '').trim().toLowerCase()).filter(Boolean));
  }

  function renderLista(filtro) {
    const lista = document.getElementById('rec-list');
    const count = document.getElementById('rec-count');
    const termo = (filtro !== undefined ? filtro : document.getElementById('rec-search').value || '').toLowerCase();
    const doFiltro = nomesDoFiltro();
    const filtradas = receitas.filter(r => (r.nome || '').toLowerCase().includes(termo) &&
      (!doFiltro || doFiltro.has(String(r.nome || '').trim().toLowerCase())));
    count.textContent = receitas.length;

    if (filtradas.length === 0) {
      lista.innerHTML = `<div class="rec-empty-list">${termo ? 'Nenhum resultado'
        : doFiltro ? 'Nenhuma receita nas linhas filtradas' : 'Nenhuma receita cadastrada'}</div>`;
      return;
    }

    lista.innerHTML = filtradas.map(r => {
      const vAt = (r.versoes || []).find(v => v.id === r.versaoAtiva) || r.versoes?.[0];
      const nv  = (r.versoes || []).length;
      return `
        <div class="rec-list-item ${r.id === receitaAtiva ? 'active' : ''}" data-id="${r.id}">
          <div class="rec-list-item-name">${r.nome ? esc(r.nome) : '(sem nome)'}</div>
          <div class="rec-list-item-meta">
            <span>${vAt?.fck ? vAt.fck + ' MPa' : '—'}</span>
            <span class="rec-versoes-badge">${nv} versão${nv !== 1 ? 'ões' : ''}</span>
          </div>
          <span class="rec-list-item-status rec-status-${statusDe(r, vAt)}">${ROTULO_STATUS[statusDe(r, vAt)] || 'Ativa'}</span>
        </div>`;
    }).join('');
  }

  // Delegação de evento única na lista - não recria listeners a cada render
  document.getElementById('rec-list').addEventListener('click', async e => {
    const item = e.target.closest('.rec-list-item');
    if (!item) return;
    const id = item.dataset.id;
    if (!id || id === receitaAtiva) return;
    if (unsaved && !(await perguntar('Alterações não salvas', 'Há alterações não salvas nesta receita. Descartar?', 'Descartar'))) return;
    selecionarReceita(id);
  });

  /* -------------------------------------------------
     SELECIONAR RECEITA
  ------------------------------------------------- */
  function selecionarReceita(id, idVersao) {
    receitaAtiva = id; unsaved = false; limparUnsaved();
    const r = receitas.find(x => x.id === id);
    if (!r) return;
    if (!r.versoes) r.versoes = [];
    const vid = idVersao || r.versaoAtiva || r.versoes[0]?.id || null;
    versaoAtiva = vid; r.versaoAtiva = vid;

    document.getElementById('rec-placeholder').style.display = 'none';
    document.getElementById('rec-form').style.display = 'block';
    document.getElementById('rec-nome').value   = r.nome || '';
    document.getElementById('rec-id-display').textContent = r.id;

    renderVersoesTabs(r);
    carregarVersao(r, vid);

    document.getElementById('rec-btn-salvar').disabled  = false;
    document.getElementById('rec-btn-excluir').disabled = false;
    document.getElementById('rec-btn-duplicar-versao').disabled = !vid;
    document.getElementById('rec-btn-excluir-versao').disabled  = !vid || r.versoes.length <= 1;
    renderLista();
  }

  /* -------------------------------------------------
     TABS DE VERSÕES
  ------------------------------------------------- */
  function renderVersoesTabs(r) {
    const ct = document.getElementById('rec-versoes-tabs');
    ct.innerHTML = (r.versoes || []).map(v =>
      `<button class="rec-versao-tab ${v.id === versaoAtiva ? 'active' : ''}" data-vid="${esc(v.id)}" title="${esc(v.nome || v.id)} - ${ROTULO_STATUS[statusDe(r, v)] || 'Ativa'}"><i class="rec-versao-marca rec-status-${statusDe(r, v)}"></i>${v.nome ? esc(v.nome) : 'Versão'}</button>`
    ).join('');

    // Clique normal - troca versão ativa
    ct.onclick = async e => {
      const btn = e.target.closest('.rec-versao-tab');
      if (!btn) return;
      const novaVid = btn.dataset.vid;
      if (novaVid === versaoAtiva) return;
      if (unsaved && !(await perguntar('Alterações não salvas', 'Há alterações não salvas nesta versão. Descartar?', 'Descartar'))) return;
      const r2 = receitas.find(x => x.id === receitaAtiva);
      versaoAtiva = novaVid;
      r2.versaoAtiva = versaoAtiva;
      unsaved = false; limparUnsaved();
      renderVersoesTabs(r2);
      carregarVersao(r2, versaoAtiva);
      document.getElementById('rec-btn-excluir-versao').disabled  = r2.versoes.length <= 1;
      document.getElementById('rec-btn-duplicar-versao').disabled = false;
    };

    // Botão direito - renomear versão
    ct.oncontextmenu = e => {
      const btn = e.target.closest('.rec-versao-tab');
      if (!btn) return;
      e.preventDefault();
      const vid = btn.dataset.vid;
      const r2  = receitas.find(x => x.id === receitaAtiva);
      const v   = r2?.versoes.find(x => x.id === vid);
      if (!v) return;

      // Remove menu anterior se existir
      document.getElementById('versao-ctx-menu')?.remove();

      const menu = document.createElement('div');
      menu.id = 'versao-ctx-menu';
      menu.style.cssText = `
        position:fixed; z-index:2000;
        background:var(--bg-white); border:1px solid var(--border-dark);
        border-radius:5px; box-shadow:0 4px 16px rgba(0,0,0,0.15);
        padding:4px 0; min-width:140px;
        left:${e.clientX}px; top:${e.clientY}px;
      `;
      menu.innerHTML = `
        <div id="versao-ctx-renomear" style="
          padding:7px 16px; cursor:pointer; font-size:12px;
          color:var(--text); font-family:var(--sans);
          transition:background 0.1s;
        ">Renomear versão</div>
      `;
      document.body.appendChild(menu);

      // Hover no item
      const item = menu.querySelector('#versao-ctx-renomear');
      item.onmouseenter = () => item.style.background = 'var(--accent-bg)';
      item.onmouseleave = () => item.style.background = '';
      // Fecha ao clicar fora
      const fechar = ev => { if (!menu.contains(ev.target)) { menu.remove(); document.removeEventListener('mousedown', fechar); } };
      setTimeout(() => document.addEventListener('mousedown', fechar), 0);

      document.getElementById('versao-ctx-renomear').onclick = () => {
        menu.remove();
        document.removeEventListener('mousedown', fechar);

        // Era prompt(). No navegador funciona; na janela do app, que é
        // WebView2, prompt() não abre caixa nenhuma e devolve null - o
        // "Renomear" não fazia nada, sem erro e sem aviso. O modal do próprio
        // app funciona nos dois.
        const atual = String(v.nome || '').replace(/"/g, '&quot;');
        window.openModal('Renomear versão',
          '<label style="display:block;font-size:11px;text-transform:uppercase;' +
          'letter-spacing:.05em;color:var(--text-3);margin-bottom:5px">Novo nome</label>' +
          '<input id="versao-novo-nome" type="text" style="width:100%" value="' + atual + '">',
          () => {
            const campo = document.getElementById('versao-novo-nome');
            if (!campo) return;
            const nome = campo.value.trim();
            if (!nome) { toast('Nome não pode ser vazio', 'error'); return; }
            if (nome === v.nome) return;          // não mudou

            v.nome = nome;
            salvarReceitas().then(() => {
              renderVersoesTabs(r2);
              toast('Versão renomeada', 'success');
            });
          });
      };
    };
  }

  /* -------------------------------------------------
     CARREGAR VERSÃO
  ------------------------------------------------- */
  function carregarVersao(r, vid) {
    const v = (r.versoes || []).find(x => x.id === vid) || {};
    document.getElementById('rec-status').value = statusDe(r, v);
    document.getElementById('rec-obs').value = v.obs || '';
    renderPropriedades(migrarPropriedades(v));
    document.getElementById('rec-data-display').textContent    = v.criadaEm  || '—';
    document.getElementById('rec-editada-display').textContent = v.editadaEm || '—';
  }

  /* -------------------------------------------------
     COLETAR FORMULÁRIO
  ------------------------------------------------- */
  function coletarFormulario() {
    const r = receitas.find(x => x.id === receitaAtiva);
    if (!r) return null;
    r.nome   = document.getElementById('rec-nome').value.trim();
    const v = (r.versoes || []).find(x => x.id === versaoAtiva);
    if (!v) return r;
    v.status = document.getElementById('rec-status').value;
    r.status = v.status;
    v.obs          = document.getElementById('rec-obs').value.trim();
    v.editadaEm    = hoje();
    v.propriedades = coletarIngredientes('rec-props-list');
    // FCK derivado da 1ª propriedade de resistência - usado na lista lateral.
    // O tipo "Resistencia" virou a classe "Propriedade"; quem diz que a linha
    // e' o fck agora e' o NOME, que e' o sinal confiavel de qualquer forma.
    const fckProp = v.propriedades.find(p => /fck|resist/i.test(p.nome));
    v.fck = fckProp ? fckProp.consumo : null;
    return r;
  }

  function coletarIngredientes(listId) {
    return Array.from(document.querySelectorAll(`#${listId} .rec-ingrediente-row`)).map(row => ({
      nome:    row.querySelector('.ing-nome')?.value    || '',
      tipo:    row.querySelector('.ing-tipo')?.value    || '',
      consumo: parseFloat(row.querySelector('.ing-consumo')?.value) || null,
      unidade: row.querySelector('.ing-unidade')?.value || 'kg/m³',
    }));
  }

  /* -------------------------------------------------
     INGREDIENTES
  ------------------------------------------------- */
  const TIPOS_AGREGADO = ['Areia fina','Areia média','Areia grossa','Brita 0','Brita 1','Brita 2','Pedrisco','Pó de pedra','Outro'];
  const TIPOS_ADITIVO  = ['Plastificante','Superplastificante','Polifuncional','Retardador','Acelerador','Incorporador de ar','Sílica ativa','Cinza volante','Escória','Outro'];
  const UNIDADES       = ['kg/m³','L/m³','%','MPa','mm','% cim','g/m³','un'];
  // Lista única de propriedades (Naor): tipos genéricos + alguns pré-preenchidos.
  // O TIPO e' a classe do material; o NOME e' o material. Antes o tipo repetia
  // o nome ("Areia" era tipo E nome), misturando as duas coisas - o Naor
  // apontou: areia nao e' tipo, e' agregado miudo.
  //
  // A divisao segue a norma: o que passa na peneira de 4,75 mm e' agregado
  // MIUDO (areia, po de pedra), o que fica retido e' GRAUDO (brita, pedrisco,
  // seixo). Cimento e cal sao aglomerantes. Aditivo muda o comportamento em
  // pequena dose; adicao entra em quantidade e vira parte do material.
  const PROP_TIPOS = ['Aglomerante', 'Agregado miúdo', 'Agregado graúdo',
                      'Água', 'Aditivo', 'Adição', 'Propriedade', 'Outro'];

  // O que sugerir no nome, depois de escolhido o tipo.
  const SUGESTOES_POR_TIPO = {
    'Aglomerante':     ['CP II-E-32', 'CP II-F-32', 'CP II-Z-32', 'CP III-40 RS',
                        'CP IV-32', 'CP V-ARI', 'CP V-ARI RS', 'Cal hidratada'],
    'Agregado miúdo':  ['Areia fina', 'Areia média', 'Areia grossa',
                        'Areia natural', 'Areia de britagem', 'Pó de pedra'],
    'Agregado graúdo': ['Brita 0', 'Brita 1', 'Brita 2', 'Pedrisco',
                        'Seixo rolado'],
    'Água':            ['Água', 'Água de amassamento', 'Água reciclada'],
    'Aditivo':         ['Plastificante', 'Superplastificante', 'Polifuncional',
                        'Retardador de pega', 'Acelerador de pega',
                        'Incorporador de ar', 'Impermeabilizante'],
    'Adição':          ['Sílica ativa', 'Metacaulim', 'Cinza volante',
                        'Escória de alto-forno', 'Fíler calcário'],
    'Propriedade':     ['fck', 'Slump', 'Relação a/c', '% argamassa',
                        'Teor de ar', 'Massa específica'],
  };

  // De onde os tipos antigos vieram, para o que ja' esta' salvo nao virar "-".
  const TIPO_ANTIGO = {
    'Cimento': 'Aglomerante',
    'Areia': 'Agregado miúdo', 'Areia fina': 'Agregado miúdo',
    'Areia média': 'Agregado miúdo', 'Areia grossa': 'Agregado miúdo',
    'Pó de pedra': 'Agregado miúdo',
    'Brita': 'Agregado graúdo', 'Brita 0': 'Agregado graúdo',
    'Brita 1': 'Agregado graúdo', 'Brita 2': 'Agregado graúdo',
    'Pedrisco': 'Agregado graúdo',
    'Resistência': 'Propriedade',
    'Sílica ativa': 'Adição', 'Cinza volante': 'Adição', 'Escória': 'Adição',
    'Plastificante': 'Aditivo', 'Superplastificante': 'Aditivo',
    'Polifuncional': 'Aditivo', 'Retardador': 'Aditivo',
    'Acelerador': 'Aditivo', 'Incorporador de ar': 'Aditivo',
  };
  const tipoAtualizado = t => TIPO_ANTIGO[t] || t || '';

  function propsPadrao() {
    return [
      { nome:'Cimento',  tipo:'Aglomerante',     consumo:null, unidade:'kg/m³' },
      { nome:'Areia',    tipo:'Agregado miúdo',  consumo:null, unidade:'kg/m³' },
      { nome:'Brita',    tipo:'Agregado graúdo', consumo:null, unidade:'kg/m³' },
      { nome:'Água',     tipo:'Água',            consumo:null, unidade:'L/m³' },
    ];
  }
  // Migra versões antigas (campos estruturados) -> lista de propriedades, sem
  // perder dados. Usado ao carregar versões salvas antes da simplificação.
  function migrarPropriedades(v) {
    if (Array.isArray(v.propriedades)) return v.propriedades;
    const p = [];
    if (v.fck)          p.push({ nome:'FCK',          tipo:'Resistência', consumo:v.fck,          unidade:'MPa' });
    if (v.slump)        p.push({ nome:'Slump',        tipo:'Outro',       consumo:v.slump,        unidade:'mm' });
    if (v.cimentoKg || v.cimentoTipo) p.push({ nome:v.cimentoTipo||'Cimento', tipo:'Cimento', consumo:v.cimentoKg||null, unidade:'kg/m³' });
    if (v.agua)         p.push({ nome:'Água',         tipo:'Água',        consumo:v.agua,         unidade:'L/m³' });
    if (v.pctArgamassa) p.push({ nome:'% Argamassa',  tipo:'Outro',       consumo:v.pctArgamassa, unidade:'%' });
    (v.agregados || []).forEach(a => p.push({ nome:a.nome||'Agregado', tipo:a.tipo||'Areia',   consumo:a.consumo??null, unidade:a.unidade||'kg/m³' }));
    (v.aditivos  || []).forEach(a => p.push({ nome:a.nome||'Aditivo',  tipo:a.tipo||'Aditivo', consumo:a.consumo??null, unidade:a.unidade||'kg/m³' }));
    return p;
  }
  function renderPropriedades(lista) {
    const el = document.getElementById('rec-props-list');
    el.innerHTML = (lista.length ? cabecalhoIngredientes() : '') + lista.map(p => htmlIngrediente(p, PROP_TIPOS)).join('');
    bindRemoveIngrediente(el); bindIngredienteChange(el);
  }

  function cabecalhoIngredientes() {
    // Tipo antes do nome: primeiro se escolhe a classe, e ai' o nome ja' vem
    // com as sugestoes daquela classe. Pedido do Naor.
    return `<div class="rec-ingrediente-header"><span>Tipo</span><span>Nome</span><span>Valor</span><span>Unidade</span><span></span></div>`;
  }
  let seqSugestao = 0;
  const listaPropria = () => document.documentElement.dataset.previa === '1';

  /* -- nomes ja usados ---------------------------------------------------
   * Quem cadastra escreve o mesmo material em dezenas de receitas. Escreveu uma
   * vez, ele passa a aparecer aqui: os mais usados primeiro, depois os padroes
   * do tipo. O nome continua livre, a lista so' poupa digitar de novo.
   */
  const semAcento = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();

  function sugerirNomes(lista, tipo, termo) {
    const usados = new Map();
    (lista || []).forEach(rc => (rc.versoes || []).forEach(v => (v.propriedades || []).forEach(p => {
      const chave = semAcento(p.nome);
      if (!chave) return;
      const u = usados.get(chave) || { nome: String(p.nome).trim(), vezes: 0 };
      u.vezes++;
      usados.set(chave, u);
    })));
    const ordem = [...usados.values()].sort((a, b) => b.vezes - a.vezes || a.nome.localeCompare(b.nome, 'pt-BR'));
    (SUGESTOES_POR_TIPO[tipo] || []).forEach(n => {
      if (!usados.has(semAcento(n))) ordem.push({ nome: n, vezes: 0 });
    });
    const busca = semAcento(termo);
    return busca ? ordem.filter(o => semAcento(o.nome).includes(busca)) : ordem;
  }

  let caixaNomes = null, campoNomes = null, marcado = -1;

  function fecharNomes() {
    if (caixaNomes) caixaNomes.remove();
    caixaNomes = null; campoNomes = null; marcado = -1;
  }

  function escolherNome(nome) {
    const campo = campoNomes;
    fecharNomes();
    if (!campo) return;
    campo.value = nome;
    campo.dispatchEvent(new Event('input', { bubbles: true }));
  }

  function abrirNomes(campo) {
    const linha = campo.closest('.rec-ingrediente-row');
    const tipo = linha ? (linha.querySelector('.ing-tipo') || {}).value : '';
    const itens = sugerirNomes(receitas, tipo, campo.value);
    if (caixaNomes) caixaNomes.remove();
    caixaNomes = null; campoNomes = campo; marcado = -1;
    if (!itens.length) return;
    const c = document.createElement('div');
    c.className = 'rec-nomes';
    c.innerHTML = itens.map(o => `<div class="rec-nome-op" data-nome="${esc(o.nome)}"><span>${esc(o.nome)}</span>` +
      (o.vezes ? `<small>${o.vezes}x</small>` : '') + '</div>').join('');
    const b = campo.getBoundingClientRect();
    c.style.left = b.left + 'px';
    c.style.top = (b.bottom + 2) + 'px';
    c.style.width = Math.max(b.width, 220) + 'px';
    // mousedown e nao click: o clique tiraria o foco do campo e fecharia a lista
    c.addEventListener('mousedown', ev => {
      ev.preventDefault();
      const op = ev.target.closest('.rec-nome-op');
      if (op) escolherNome(op.dataset.nome);
    });
    document.body.appendChild(c);
    caixaNomes = c;
    const sobra = innerHeight - b.bottom - 12;
    if (sobra < 120) { c.style.top = ''; c.style.bottom = (innerHeight - b.top + 2) + 'px'; }
    else c.style.maxHeight = Math.min(240, sobra) + 'px';
  }

  function marcarNome(passo) {
    if (!caixaNomes) return;
    const ops = [...caixaNomes.querySelectorAll('.rec-nome-op')];
    if (!ops.length) return;
    marcado = (marcado + passo + ops.length) % ops.length;
    ops.forEach((o, i) => o.classList.toggle('ativa', i === marcado));
    ops[marcado].scrollIntoView({ block: 'nearest' });
  }

  function ligarNomes() {
    const area = document.getElementById('rec-props-list');
    if (!area) return;
    const eCampo = e => e.target.classList && e.target.classList.contains('ing-nome') && listaPropria();
    area.addEventListener('focusin', e => { if (eCampo(e)) abrirNomes(e.target); });
    area.addEventListener('click', e => { if (eCampo(e) && !caixaNomes) abrirNomes(e.target); });
    area.addEventListener('input', e => { if (eCampo(e) && campoNomes === e.target) abrirNomes(e.target); });
    area.addEventListener('focusout', e => { if (eCampo(e)) fecharNomes(); });
    area.addEventListener('keydown', e => {
      if (!eCampo(e) || !caixaNomes) return;
      if (e.key === 'ArrowDown') { e.preventDefault(); marcarNome(1); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); marcarNome(-1); }
      else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); fecharNomes(); }
      else if (e.key === 'Enter' && marcado >= 0) {
        e.preventDefault();
        escolherNome(caixaNomes.querySelectorAll('.rec-nome-op')[marcado].dataset.nome);
      }
    });
    const formulario = document.getElementById('rec-form-area');
    if (formulario) formulario.addEventListener('scroll', fecharNomes);
  }

  function htmlIngrediente(ing, tipos) {
    const tipo = tipoAtualizado(ing.tipo);
    const listaTipos = (tipo && !tipos.includes(tipo)) ? [tipo, ...tipos] : tipos;
    const tOpts = listaTipos.map(t => `<option ${tipo===t?'selected':''}>${t}</option>`).join('');
    const uOpts = UNIDADES.map(u => `<option ${(ing.unidade||'kg/m³')===u?'selected':''}>${u}</option>`).join('');
    // Lista de sugestoes ao digitar o nome (pedido do Naor). datalist e' do
    // proprio navegador: sugere sem impedir de escrever outra coisa.
    const idLista = 'sug-' + (++seqSugestao);
    const sugestoes = (SUGESTOES_POR_TIPO[tipo] || [])
      .map(x => `<option value="${x}"></option>`).join('');
    // Com a previa quem sugere e' a lista propria (nomesJaUsados): o datalist
    // nao abre ao clicar e nao conhece o que ja' foi escrito em outra receita.
    const lista = listaPropria() ? '' : ` list="${idLista}"`;
    return `<div class="rec-ingrediente-row">
      <select class="ing-tipo"><option value="">—</option>${tOpts}</select>
      <input class="ing-nome" type="text" value="${esc(ing.nome||'')}" placeholder="Nome do material" autocomplete="off"${lista}>
      <datalist id="${idLista}">${sugestoes}</datalist>
      <input class="ing-consumo" type="number" step="0.01" min="0" value="${ing.consumo??''}" placeholder="ex: 800">
      <select class="ing-unidade">${uOpts}</select>
      <button class="rec-btn-remove" title="Remover">×</button>
    </div>`;
  }
  function renderAgregados(lista) {
    const el = document.getElementById('rec-agregados-list');
    el.innerHTML = (lista.length ? cabecalhoIngredientes() : '') + lista.map(a => htmlIngrediente(a, TIPOS_AGREGADO)).join('');
    bindRemoveIngrediente(el); bindIngredienteChange(el);
  }
  function renderAditivos(lista) {
    const el = document.getElementById('rec-aditivos-list');
    el.innerHTML = (lista.length ? cabecalhoIngredientes() : '') + lista.map(a => htmlIngrediente(a, TIPOS_ADITIVO)).join('');
    bindRemoveIngrediente(el); bindIngredienteChange(el);
  }
  function bindRemoveIngrediente(container) {
    container.querySelectorAll('.rec-btn-remove').forEach(btn => {
      btn.addEventListener('click', () => {
        btn.closest('.rec-ingrediente-row').remove();
        if (!container.querySelector('.rec-ingrediente-row')) container.innerHTML = '';
        marcarUnsaved();
      });
    });
  }
  function bindIngredienteChange(container) {
    container.querySelectorAll('input, select').forEach(el => {
      el.addEventListener('input', marcarUnsaved); el.addEventListener('change', marcarUnsaved);
    });
    // Trocou o tipo? As sugestoes do nome acompanham. Sem isto, escolher
    // "Agregado graudo" continuaria sugerindo areia.
    container.querySelectorAll('.ing-tipo').forEach(sel => {
      sel.addEventListener('change', () => {
        const linha = sel.closest('.rec-ingrediente-row');
        const lista = linha && linha.querySelector('datalist');
        if (!lista) return;
        lista.innerHTML = (SUGESTOES_POR_TIPO[sel.value] || [])
          .map(x => `<option value="${x}"></option>`).join('');
        // Nome ainda vazio: ja' oferece o primeiro da classe, que e' o caso
        // comum (uma areia media, uma brita 1).
        const nome = linha.querySelector('.ing-nome');
        if (nome && !nome.value.trim()) nome.placeholder =
          'ex.: ' + ((SUGESTOES_POR_TIPO[sel.value] || ['Nome do material'])[0]);
      });
    });
  }
  function adicionarIngrediente(listId, tipos) {
    const el = document.getElementById(listId);
    if (!el.querySelector('.rec-ingrediente-header')) el.insertAdjacentHTML('beforeend', cabecalhoIngredientes());
    const row = document.createElement('div');
    row.innerHTML = htmlIngrediente({}, tipos);
    el.appendChild(row.firstElementChild);
    bindRemoveIngrediente(el); bindIngredienteChange(el); marcarUnsaved();
  }

  /* -------------------------------------------------
     CÁLCULO a/c
  ------------------------------------------------- */
  function calcAc() {
    const a = parseFloat(document.getElementById('rec-agua').value);
    const c = parseFloat(document.getElementById('rec-cimento-kg').value);
    document.getElementById('rec-ac').value = (a > 0 && c > 0) ? (a/c).toFixed(3) : '';
  }

  /* -------------------------------------------------
     UNSAVED / TOAST
  ------------------------------------------------- */
  function marcarUnsaved() {
    unsaved = true;
    const btn = document.getElementById('rec-btn-salvar');
    if (!btn.querySelector('.rec-unsaved-dot')) btn.insertAdjacentHTML('beforeend', '<span class="rec-unsaved-dot"></span>');
  }
  function limparUnsaved() {
    unsaved = false;
    document.querySelectorAll('.rec-unsaved-dot').forEach(d => d.remove());
  }
  function toast(msg, tipo = '') {
    if (typeof window.showToast === 'function') { window.showToast(msg, tipo); return; }
    let c = document.getElementById('toast-container');
    if (!c) { c = document.createElement('div'); c.id = 'toast-container'; document.body.appendChild(c); }
    const t = document.createElement('div');
    t.className = `toast ${tipo}`; t.textContent = msg;
    c.appendChild(t); setTimeout(() => t.remove(), 3000);
  }

  /* -------------------------------------------------
     IMPORTAR DA PLANILHA
  ------------------------------------------------- */
  document.getElementById('rec-btn-importar').addEventListener('click', () => {
    const colunas = window.currentSheetData?.headers || [];
    const opts = colunas.length
      ? colunas.map(c => `<option value="${c}">${c}</option>`).join('')
      : '<option value="">— carregue uma planilha primeiro —</option>';

    document.getElementById('modal-content').innerHTML = `
      <div class="modal-header">IMPORTAR RECEITAS
        <button id="mi-close" style="background:none;border:none;color:#fff;cursor:pointer;font-size:18px">×</button>
      </div>
      <div class="modal-body">
        <p style="font-size:12px;color:var(--text-2);margin-bottom:14px">
          Cada valor único da coluna <strong>Produto</strong> vira uma receita.<br>
          Cada valor único da coluna <strong>Versão/Receita</strong> vira uma versão dentro do produto.
        </p>
        <label>Coluna de Produto</label>
        <select id="mi-prod">${opts}</select>
        <label style="margin-top:12px">Coluna de Versão/Receita</label>
        <select id="mi-vers">${opts}</select>
        ${!colunas.length ? '<p style="color:var(--danger);font-size:11px;margin-top:10px">Abra uma planilha primeiro na aba Planilhas.</p>' : ''}
      </div>
      <div class="modal-footer">
        <button class="secondary-btn" id="mi-cancel">Cancelar</button>
        <button class="primary-btn" id="mi-ok" ${!colunas.length?'disabled':''}>Importar</button>
      </div>`;

    document.getElementById('modal-overlay').style.display = 'flex';
    ['PRODUTO','RECEITA'].forEach((alvo, i) => {
      const sel = document.getElementById(i === 0 ? 'mi-prod' : 'mi-vers');
      if (sel && [...sel.options].some(o => o.value === alvo)) sel.value = alvo;
    });
    document.getElementById('mi-close').onclick  =
    document.getElementById('mi-cancel').onclick = () => { document.getElementById('modal-overlay').style.display = 'none'; };
    document.getElementById('mi-ok').onclick = () => {
      const cp = document.getElementById('mi-prod').value;
      const cv = document.getElementById('mi-vers').value;
      document.getElementById('modal-overlay').style.display = 'none';
      if (!cp) { toast('Selecione a coluna de produto', 'error'); return; }
      importar(cp, cv);
    };
  });

  function importar(colP, colV) {
    const sd = window.currentSheetData;
    if (!sd?.data?.length) { toast('Nenhuma planilha carregada', 'error'); return; }
    const { headers, data } = sd;
    const iP = headers.indexOf(colP), iV = colV ? headers.indexOf(colV) : -1;
    if (iP === -1) { toast('Coluna não encontrada', 'error'); return; }

    const mapa = new Map();
    data.forEach(row => {
      const prod = String(row[iP] || '').trim();
      const vers = iV >= 0 ? String(row[iV] || '').trim() : prod;
      if (!prod) return;
      if (!mapa.has(prod)) mapa.set(prod, new Set());
      if (vers) mapa.get(prod).add(vers);
    });

    let criadas = 0, atualizadas = 0, versAdic = 0;
    mapa.forEach((versoes, nomeProd) => {
      let rec = receitas.find(r => r.nome === nomeProd);
      if (!rec) {
        rec = { id: gerarId('REC'), nome: nomeProd, status: 'ativa', criadaEm: hoje(), versoes: [], versaoAtiva: null };
        receitas.push(rec); criadas++;
      } else { atualizadas++; }
      versoes.forEach(nv => {
        if (!rec.versoes.find(v => v.nome === nv)) {
          const v = { id: gerarId('VRS'), nome: nv, criadaEm: hoje(), editadaEm: hoje() };
          rec.versoes.push(v);
          if (!rec.versaoAtiva) rec.versaoAtiva = v.id;
          versAdic++;
        }
      });
    });
    salvarReceitas().then(() => {
      renderLista();
      toast(`${criadas} criadas · ${atualizadas} atualizadas · ${versAdic} versões`, 'success');
    });
  }

  /* -------------------------------------------------
     EVENTOS - RECEITA
  ------------------------------------------------- */
  document.getElementById('rec-btn-nova').addEventListener('click', async () => {
    if (unsaved && !(await perguntar('Alterações não salvas', 'Há alterações não salvas nesta receita. Descartar?', 'Descartar'))) return;
    const v1 = { id: gerarId('VRS'), nome: 'Versão 1', criadaEm: hoje(), editadaEm: hoje(), propriedades: propsPadrao() };
    const nova = { id: gerarId('REC'), nome: 'Nova Receita', status: 'ativa', criadaEm: hoje(), versoes: [v1], versaoAtiva: v1.id };
    receitas.push(nova);
    await salvarReceitas();
    selecionarReceita(nova.id);
    document.getElementById('rec-nome').focus();
    document.getElementById('rec-nome').select();
  });

  document.getElementById('rec-btn-salvar').addEventListener('click', async () => {
    if (!receitaAtiva) return;
    coletarFormulario();
    await salvarReceitas();
    limparUnsaved(); renderLista();
    const salva = receitas.find(x => x.id === receitaAtiva);
    if (salva) renderVersoesTabs(salva);
    toast('Salvo', 'success');
  });

  document.getElementById('rec-btn-excluir').addEventListener('click', async () => {
    if (!receitaAtiva) return;
    const r = receitas.find(x => x.id === receitaAtiva);
    if (!(await perguntar('Excluir receita', `Excluir "${r?.nome}"? Todas as versões serão removidas.`, 'Excluir'))) return;
    receitas = receitas.filter(x => x.id !== receitaAtiva);
    await salvarReceitas();
    receitaAtiva = null; versaoAtiva = null; unsaved = false;
    document.getElementById('rec-form').style.display = 'none';
    document.getElementById('rec-placeholder').style.display = 'flex';
    document.getElementById('rec-btn-salvar').disabled  = true;
    document.getElementById('rec-btn-excluir').disabled = true;
    renderLista(); toast('Receita excluída');
  });

  /* -------------------------------------------------
     EVENTOS - VERSÃO
  ------------------------------------------------- */
  document.getElementById('rec-btn-nova-versao').addEventListener('click', async () => {
    if (!receitaAtiva) return;
    if (unsaved && !(await perguntar('Alterações não salvas', 'Há alterações não salvas nesta versão. Descartar?', 'Descartar'))) return;
    const r = receitas.find(x => x.id === receitaAtiva);
    const n = (r.versoes?.length || 0) + 1;
    const v = { id: gerarId('VRS'), nome: `Versão ${n}`, status: 'ativa', criadaEm: hoje(), editadaEm: hoje() };
    r.versoes.push(v); r.versaoAtiva = v.id; versaoAtiva = v.id;
    await salvarReceitas();
    selecionarReceita(receitaAtiva, v.id);
    toast('Nova versão criada', 'success');
  });

  document.getElementById('rec-btn-duplicar-versao').addEventListener('click', async () => {
    if (!receitaAtiva || !versaoAtiva) return;
    const r = receitas.find(x => x.id === receitaAtiva);
    const orig = r.versoes.find(v => v.id === versaoAtiva);
    if (!orig) return;
    const copia = JSON.parse(JSON.stringify(orig));
    copia.id = gerarId('VRS'); copia.nome = orig.nome + ' (cópia)';
    copia.criadaEm = hoje(); copia.editadaEm = hoje();
    r.versoes.push(copia); r.versaoAtiva = copia.id; versaoAtiva = copia.id;
    await salvarReceitas();
    selecionarReceita(receitaAtiva, copia.id);
    toast('Versão duplicada', 'success');
  });

  document.getElementById('rec-btn-excluir-versao').addEventListener('click', async () => {
    if (!receitaAtiva || !versaoAtiva) return;
    const r = receitas.find(x => x.id === receitaAtiva);
    if (r.versoes.length <= 1) { toast('A receita precisa ter ao menos uma versão', 'error'); return; }
    const v = r.versoes.find(x => x.id === versaoAtiva);
    if (!(await perguntar('Excluir versão', `Excluir a versão "${v?.nome}"?`, 'Excluir'))) return;
    r.versoes = r.versoes.filter(x => x.id !== versaoAtiva);
    r.versaoAtiva = r.versoes[0].id; versaoAtiva = r.versaoAtiva;
    await salvarReceitas();
    selecionarReceita(receitaAtiva, versaoAtiva);
    toast('Versão excluída');
  });

  /* -------------------------------------------------
     EVENTOS - INGREDIENTES & CAMPOS
  ------------------------------------------------- */
  document.getElementById('rec-add-prop').addEventListener('click', () => adicionarIngrediente('rec-props-list', PROP_TIPOS));
  document.getElementById('rec-search').addEventListener('input', e => renderLista(e.target.value));
  ['rec-nome','rec-status','rec-obs'].forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.addEventListener('input', marcarUnsaved); el.addEventListener('change', marcarUnsaved); }
  });
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey||e.metaKey) && e.key==='s' && document.querySelector('.nav-btn.active')?.dataset.module==='receitas') {
      e.preventDefault(); document.getElementById('rec-btn-salvar').click();
    }
  });
  window.addEventListener('concrestats:datachanged', () => {
    if (document.getElementById('module-receitas').classList.contains('active')) renderLista();
  });

  // Quem pergunta ao fechar o programa é o app.js (ver "Fechar o programa").
  window.ConcrestatsReceitas = {
    sujo: () => unsaved,
    nome: () => document.getElementById('rec-nome').value.trim() || 'sem nome',
    salvar: async () => {
      if (!receitaAtiva) return false;
      coletarFormulario();
      const gravou = await salvarReceitas();
      if (gravou) { limparUnsaved(); renderLista(); }
      return gravou;
    },
    // para o Modo Teste
    _migrarStatus: migrarStatus,
    _sugerir: sugerirNomes,
  };

  /* INIT */
  ligarNomes();
  carregarReceitas();

})();
