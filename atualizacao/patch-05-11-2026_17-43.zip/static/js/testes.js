/**
 * testes.js - Modo Teste
 *
 * Existe para economizar o tempo de quem testa. Em vez de abrir o Trello,
 * montar uma planilha com os casos certos e conferir item por item, ele:
 *   1. carrega uma planilha de DEMONSTRAÇÃO com todos os casos já plantados;
 *   2. roda sozinho as verificações que a máquina consegue fazer;
 *   3. leva até a tela certa, já com o cenário montado, no que precisa de olho.
 *
 * As verificações chamam as MESMAS funções do app (sortData, recomputeFilters,
 * evaluateFormula...). Se um teste passa aqui, passou no código de verdade -
 * não numa cópia paralela que pode divergir.
 */
(function () {
  'use strict';

  const $ = id => document.getElementById(id);
  const esc = s => String(s ?? '').replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const espera = ms => new Promise(r => setTimeout(r, ms));
  // Espera a condição acontecer (até `limite` ms). Sem isto, um PC mais lento
  // faria a verificação falhar por atraso e o testador reportaria um bug que
  // não existe - pior do que não testar.
  async function ate(cond, limite = 4000, passo = 100) {
    const fim = Date.now() + limite;
    while (Date.now() < fim) {
      try { if (cond()) return true; } catch (_) {}
      await espera(passo);
    }
    try { return !!cond(); } catch (_) { return false; }
  }

  /* -- planilha de demonstração ---------------------
     Cada linha existe por um motivo: datas do mesmo mês (ordenação), MPA
     abaixo e acima do FCK (regra de cor), estorno negativo, célula sem
     número e coluna de código que já enganou a detecção automática. */
  const DEMO_HEADERS = ['CP', 'DATA', 'CLIENTE', 'RECEITA', 'FCK', 'MPA 28', 'M³', 'NF'];
  function dadosDemo() {
    const clientes = ['Alfa Engenharia', 'Beta Construtora', 'Gama Incorporadora', 'Delta Obras'];
    const linhas = [];
    let n = 1;
    // Janeiro: datas embaralhadas de propósito, dentro do MESMO mês
    [30, 5, 21, 13, 8, 27, 2, 17].forEach(dia => {
      const fck = [25, 30][n % 2];
      const mpa = n % 3 === 0 ? fck - 2.4 : fck + 3.1;    // 1 a cada 3 reprova
      linhas.push([`CP-${100 + n}`, `${String(dia).padStart(2, '0')}/01/2026`,
        clientes[n % 4], `${200 + n}-FCK ${fck} S100 B0`, String(fck),
        mpa.toFixed(1).replace('.', ','), String(6 + (n % 5)) + ',5', `NF-${5000 + n}`]);
      n++;
    });
    // Fevereiro a junho: volume para a Análise e o Painel terem o que mostrar
    for (let mes = 2; mes <= 6; mes++) {
      for (let i = 0; i < 9; i++) {
        const fck = [25, 30, 40][i % 3];
        const mpa = i === 4 ? fck - 1.8 : fck + 2 + (i % 6);
        linhas.push([`CP-${100 + n}`, `${String(1 + i * 3).padStart(2, '0')}/${String(mes).padStart(2, '0')}/2026`,
          clientes[i % 4], `${200 + (i % 5)}-FCK ${fck} S100 B0`, String(fck),
          mpa.toFixed(1).replace('.', ','), String(4 + (i % 7)) + ',5', `NF-${5000 + n}`]);
        n++;
      }
    }
    // Casos de borda, no fim para ficarem fáceis de achar
    linhas.push(['CP-999', '15/06/2026', 'Beta Construtora', '204-FCK 25 S100 B0', '25', '31,0', '-12,5', 'NF-9001']);
    linhas.push(['CP-998', '16/06/2026', 'Alfa Engenharia', '201-FCK 30 S100 B0', '30', 'n/d', '8,0', 'NF-9002']);
    return linhas;
  }
  const CADASTRO_HEADERS = ['CLIENTE', 'REGIAO', 'VENDEDOR'];
  const CADASTRO_DADOS = [
    ['Alfa Engenharia', 'Sul', 'Ana'],
    ['Beta Construtora', 'Sudeste', 'Bruno'],
    ['Gama Incorporadora', 'Norte', 'Carla'],
  ];

  let abaDoUsuario = null;      // para devolver o app como estava
  let nomeDemo = 'DEMONSTRAÇÃO';
  let nomeCadastro = 'Cadastro';
  const criadasAqui = new Set();   // abas que ESTE teste criou nesta sessao

  async function limparDemo(preparando) {
    // SO' apaga o que o servidor marcou como demonstracao. Apagar pelo NOME
    // era perigoso: uma planilha de verdade pode ter uma aba "Cadastro", e ela
    // sumia da sessao - e sumiria do arquivo no Salvar seguinte.
    //
    // Com a lista do servidor em maos, ela e' a palavra final. Antes somava a
    // lista com o que este teste lembrava de ter criado - e pedia de novo para
    // apagar o que ja' tinha saido, levando um 400 por aba a cada rodada.
    // Barulho vermelho no console ensina a ignorar vermelho.
    let alvos = new Set();
    [nomeDemo, nomeCadastro].forEach(n => { if (criadasAqui.has(n)) alvos.add(n); });
    try {
      const info = await apiFetch('/api/sheets_info', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: SESSION_ID })
      });
      if (info && Array.isArray(info.demo)) alvos = new Set(info.demo);
    } catch (e) { /* sem a lista, fica so' com o que este teste criou */ }
    for (const nome of alvos) {
      try {
        await apiFetch('/api/delete_sheet', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ session_id: SESSION_ID, sheet_name: nome,
                               somente_demo: true })
        });
      } catch (_) {}
    }
    if (preparando) return;

    if (abaDoUsuario) {
      const r = await apiFetch('/api/get_sheet', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: SESSION_ID, sheet_name: abaDoUsuario })
      });
      if (r && r.success) { loadSheetData(r); return; }
    }

    // Ninguem tinha planilha aberta: o servidor nao deixa apagar a ultima aba,
    // entao criamos uma vazia e apagamos as de demonstracao - a promessa e'
    // que a demonstracao some no fim, e ela tem que valer sempre.
    const nova = await apiFetch('/api/new_sheet', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: SESSION_ID, sheet_name: 'Planilha1' })
    });
    // So' o que AINDA e' demonstracao: a primeira passada ja' apagou o que
    // pode, e pedir de novo levava um 400 por aba.
    let restantes = alvos;
    try {
      const info2 = await apiFetch('/api/sheets_info', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: SESSION_ID })
      });
      if (info2 && Array.isArray(info2.demo)) restantes = new Set(info2.demo);
    } catch (e) { /* sem a lista, tenta todas como antes */ }
    for (const nome of restantes) {
      try {
        await apiFetch('/api/delete_sheet', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ session_id: SESSION_ID, sheet_name: nome,
                               somente_demo: true })
        });
      } catch (e) {}
    }
    if (nova && nova.success) {
      const r2 = await apiFetch('/api/get_sheet', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: SESSION_ID, sheet_name: nova.active_sheet || 'Planilha1' })
      });
      if (r2 && r2.success) loadSheetData(r2);
    }
  }

  // Grava no servidor imediatamente. O saveToServer() do app é adiado por
  // debounce - e o cruzamento é feito NO SERVIDOR, então ele encontrava a
  // demonstração ainda vazia e falhava sozinho.
  async function gravarAgora(nome, headers, data) {
    return apiFetch('/api/save_data', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: SESSION_ID, sheet_name: nome, headers, data })
    });
  }

  async function carregarDemo(comCadastro) {
    if (state.activeSheet && !criadasAqui.has(state.activeSheet)) {
      abaDoUsuario = state.activeSheet;   // a aba dele, para voltar no fim
    }
    // Apaga sobras de uma rodada anterior. Sem isto a segunda execução criava
    // "Cadastro (2)" e o teste de cruzamento falhava sozinho - um bug que não
    // existe é pior do que nenhum teste.
    await limparDemo(true);
    const res = await apiFetch('/api/new_sheet', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session_id: SESSION_ID, sheet_name: 'DEMONSTRAÇÃO', demo: true })
    });
    if (!res || !res.success) throw new Error('não consegui criar a planilha de demonstração');
    nomeDemo = res.active_sheet || 'DEMONSTRAÇÃO';
    criadasAqui.add(nomeDemo);
    loadSheetData(res);
    state.headers = DEMO_HEADERS.slice();
    state.data = dadosDemo();
    state.filters = []; state.regrasCor = []; state.colunasFixas = [];
    recomputeFilters();
    renderGrid();
    await gravarAgora(nomeDemo, state.headers, state.data);
    if (comCadastro) {
      const r2 = await apiFetch('/api/new_sheet', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: SESSION_ID, sheet_name: 'Cadastro', demo: true })
      });
      if (r2 && r2.success) {
        nomeCadastro = r2.active_sheet || 'Cadastro';
        criadasAqui.add(nomeCadastro);
        await gravarAgora(nomeCadastro, CADASTRO_HEADERS, CADASTRO_DADOS);
        // volta o foco para a demonstração (o new_sheet ativou o Cadastro)
        const volta = await apiFetch('/api/get_sheet', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ session_id: SESSION_ID, sheet_name: nomeDemo })
        });
        if (volta && volta.success) loadSheetData(volta);
        state.headers = DEMO_HEADERS.slice();
        state.data = dadosDemo();
        recomputeFilters(); renderGrid();
        await gravarAgora(nomeDemo, state.headers, state.data);
      }
    }
    notifyDataChanged('demo');
  }

  /* -- itens de teste -------------------------------
     auto:   verifica sozinho e devolve {ok, msg} (ou {ok, msg, subs:[...]})
     ir:     leva até a tela com o cenário montado, para o olho humano
     grupo:  organiza a lista em blocos                                   */
  const G_ARQ = 'O seu arquivo';
  const G_PLAN = 'Planilha';
  const G_JUNTAR = 'Trazer colunas e importar';
  const G_VIS = 'Análise, gráficos e painel';
  const G_OLHO = 'Precisa do seu olho';

  // Uma edicao pode nao mostrar certas abas (ver edicao.js). Testar o que nao
  // esta' na tela nao e' falha - e' verificacao que nao se aplica a esta copia.
  function semAba(mod) {
    return !document.querySelector('.nav-btn[data-module="' + mod + '"]');
  }
  const pular = mod => ({ ok: true, pulou: true,
                          msg: 'esta edição não mostra a aba ' + mod.toUpperCase() });
  // Recursos em prévia só existem na cópia de quem testa (app.previa()).
  const G_PREVIA = 'Novidades em teste';
  const emPrevia = () => document.documentElement.dataset.previa === '1';
  const pularPrevia = () => ({ ok: true, pulou: true, msg: 'só na cópia em prévia (edição Completa)' });

  const ITENS = [
    /* -- grupo: o arquivo de quem usa ----------------- */
    {
      id: 'arquivo',
      grupo: G_ARQ,
      titulo: 'Salvar não estraga a planilha de trabalho',
      olhar: 'Abra uma planilha sua com fórmula e formatação, mude uma célula, salve e confira no Excel.',
      auto: async () => {
        const r = await apiFetch('/api/autoteste_arquivo', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({})
        });
        if (!r || !r.success) return { ok: false, msg: (r && r.error) || 'não consegui rodar' };
        const subs = (r.checks || []).map(c => ({ ok: c.ok, texto: c.nome, detalhe: c.detalhe }));
        const bons = subs.filter(s => s.ok).length;
        return { ok: !!r.ok, msg: bons + ' de ' + subs.length + ' conferências no arquivo', subs };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'ultima-edicao',
      grupo: G_ARQ,
      titulo: 'A última alteração não se perde ao salvar',
      olhar: 'Digite numa célula e clique em Salvar na sequência: o valor novo tem que ir para o arquivo.',
      auto: async () => {
        const marca = 'X' + Date.now();
        const linha = state.data.length - 1;
        const antes = state.data[linha][2];
        state.data[linha][2] = marca;
        saveToServer();                    // fica pendente (o envio é adiado)
        await enviarPendencias();          // é o que o botão Salvar faz agora
        const r = await apiFetch('/api/get_sheet', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ session_id: SESSION_ID, sheet_name: state.activeSheet })
        });
        const chegou = !!r && JSON.stringify(r.data.data).includes(marca);
        state.data[linha][2] = antes;
        await gravarAgora(state.activeSheet, state.headers, state.data);
        renderGrid();
        return { ok: chegou, msg: chegou ? 'o servidor já estava com o valor novo' : 'o valor novo ficou para trás' };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'exportar-csv',
      grupo: G_ARQ,
      titulo: 'Exportar CSV sai com os dados certos',
      olhar: 'Exportar em CSV e abrir no Excel: colunas e acentos têm que estar certos.',
      auto: async () => {
        const r = await fetch(API + '/api/export', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ session_id: SESSION_ID, sheet_name: state.activeSheet, format: 'csv' })
        });
        if (!r.ok) return { ok: false, msg: 'a exportação falhou (' + r.status + ')' };
        const txt = await r.text();
        const temCabecalho = txt.indexOf('CLIENTE') >= 0 && txt.indexOf('MPA 28') >= 0;
        const temAcento = /Incorporadora|Engenharia/.test(txt);
        const linhas = txt.trim().split(/\r?\n/).length;
        const ok = temCabecalho && temAcento && linhas > 40;
        return { ok, msg: ok ? linhas + ' linhas, cabeçalho e acentos ok' : 'o conteúdo não bateu' };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },

    /* -- grupo: planilha ------------------------------- */
    {
      id: 'ordenar',
      grupo: G_PLAN,
      titulo: 'Ordenar por data dentro do mesmo mês',
      olhar: 'Clique no cabeçalho DATA. As datas de janeiro devem ficar em ordem.',
      auto: async () => {
        state.sortState = { col: 1, dir: 'asc' };
        sortData();
        const jan = getDisplayRows().filter(r => String(r[1]).indexOf('/01/2026') >= 0).map(r => r[1]);
        const ordenado = jan.slice().sort((a, b) => Number(a.slice(0, 2)) - Number(b.slice(0, 2)));
        const ok = JSON.stringify(jan) === JSON.stringify(ordenado) && jan.length > 3;
        return { ok, msg: ok ? jan.length + ' datas de janeiro em ordem' : 'a ordem não bateu' };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'filtro-vive',
      grupo: G_PLAN,
      titulo: 'Filtro sobrevive a ordenar, colar e desfazer',
      olhar: 'Filtre um cliente, ordene, adicione linha e desfaça: o filtro continua valendo.',
      auto: async () => {
        state.filters = [{ col: 'CLIENTE', op: '==', val: 'Alfa Engenharia' }];
        recomputeFilters();
        const antes = getDisplayRows().length;
        state.sortState = { col: 1, dir: 'desc' }; sortData();
        const posSort = getDisplayRows().length;
        const nAntesAdd = state.data.length;
        addRow();
        const posAdd = getDisplayRows().length;
        pushUndo(); state.data.push(state.headers.map(() => 'x')); undo();
        const posUndo = getDisplayRows().length;
        // devolve a planilha como estava: um teste que deixa lixo faz o
        // teste seguinte falhar sozinho, e isso confunde quem esta' testando
        state.data.length = nAntesAdd;
        state.filters = []; recomputeFilters(); renderGrid();
        const ok = antes > 0 && posSort === antes && posAdd === antes && posUndo === antes;
        return { ok, msg: ok ? antes + ' linhas mantidas nas 3 operações'
                             : 'variou: ' + antes + '/' + posSort + '/' + posAdd + '/' + posUndo };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'cores',
      grupo: G_PLAN,
      titulo: 'Regra de cor: MPA abaixo do FCK fica vermelho',
      olhar: 'A coluna MPA 28 deve ter os reprovados em vermelho e os aprovados em verde.',
      auto: async () => {
        state.regrasCor = [
          { col: 'MPA 28', op: '<', val: '[FCK]', cor: 'vermelho' },
          { col: 'MPA 28', op: '>=', val: '[FCK]', cor: 'verde' },
        ];
        renderGrid();
        const ci = state.headers.indexOf('MPA 28');
        await ate(() => document.querySelectorAll('#table-body td[data-col="' + ci + '"]').length > 0);
        const cels = [].slice.call(document.querySelectorAll('#table-body td[data-col="' + ci + '"]'));
        const ehNum = c => !isNaN(parseFloat(String(c.textContent).replace(',', '.')));
        const pintadas = cels.filter(c => c.getAttribute('style'));
        const numericas = cels.filter(ehNum);
        const semNumeroPintada = pintadas.filter(c => !ehNum(c)).length;
        const ok = numericas.length > 0 && pintadas.length === numericas.length && semNumeroPintada === 0;
        return {
          ok,
          msg: ok ? pintadas.length + ' células pintadas, nenhuma sem resultado'
                  : pintadas.length + ' pintadas para ' + numericas.length + ' numéricas' +
                    (semNumeroPintada ? ' (' + semNumeroPintada + ' sem número foi pintada)' : '')
        };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'negativos',
      grupo: G_PLAN,
      titulo: 'Número negativo aparece em vermelho',
      olhar: 'Procure o CP-999: o M³ dele é -12,5 e deve estar vermelho.',
      auto: async () => {
        const ci = state.headers.indexOf('M³');
        const linha = state.data.findIndex(r => String(r[0]) === 'CP-999');
        if (linha < 0 || ci < 0) return { ok: false, msg: 'não achei o caso na demonstração' };
        selectCell(linha, ci);
        await espera(120);
        const td = document.querySelector('#table-body td[data-row="' + linha + '"][data-col="' + ci + '"]');
        const ok = !!td && td.classList.contains('cel-neg');
        return { ok, msg: ok ? 'o -12,5 está marcado' : 'não ficou vermelho' };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'busca',
      grupo: G_PLAN,
      titulo: 'Busca (Ctrl+F) conta e destaca',
      olhar: 'Ctrl+F, digite "Alfa": deve destacar em amarelo e mostrar quantos achou.',
      auto: async () => {
        abrirBusca();
        const inp = $('find-input');
        inp.value = 'alfa'; inp.dispatchEvent(new Event('input'));
        await ate(() => /de\s+\d+/.test($('find-count').textContent));
        const conta = $('find-count').textContent;
        const marcadas = document.querySelectorAll('#table-body td.cel-busca').length;
        fecharBusca();
        const ok = /de\s+\d+/.test(conta) && marcadas > 0;
        return { ok, msg: ok ? conta + ', ' + marcadas + ' destacadas' : 'não destacou' };
      },
      ir: () => { ConcrestatsOpenModule('spreadsheet'); abrirBusca(); },
    },
    {
      id: 'refazer',
      grupo: G_PLAN,
      titulo: 'Desfazer e Refazer (Ctrl+Z / Ctrl+Y)',
      olhar: 'Adicione uma linha, Ctrl+Z para desfazer e Ctrl+Y para trazer de volta.',
      auto: async () => {
        const n0 = state.data.length;
        pushUndo(); state.data.push(state.headers.map(() => 'teste')); renderGrid();
        const n1 = state.data.length;
        undo(); const n2 = state.data.length;
        redo(); const n3 = state.data.length;
        undo();
        const ok = n1 === n0 + 1 && n2 === n0 && n3 === n0 + 1;
        return { ok, msg: ok ? 'desfez e refez certo' : n0 + '/' + n1 + '/' + n2 + '/' + n3 };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'desfazer-fundo',
      grupo: G_PLAN,
      titulo: 'Desfazer volta várias vezes seguidas',
      olhar: 'Faça 3 alterações e aperte Ctrl+Z três vezes: tem que voltar tudo.',
      auto: async () => {
        const original = state.data[0][2];
        ['um', 'dois', 'tres'].forEach(v => { pushUndo(); state.data[0][2] = v; });
        renderGrid();
        undo(); undo(); undo();
        const ok = state.data[0][2] === original;
        renderGrid();
        return { ok, msg: ok ? 'voltou os 3 passos' : 'parou em "' + state.data[0][2] + '"' };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'excluir-linha',
      grupo: G_PLAN,
      titulo: 'Excluir linha e desfazer devolve a linha igual',
      olhar: 'Exclua uma linha e aperte Ctrl+Z: ela volta com o mesmo conteúdo.',
      auto: async () => {
        const n0 = state.data.length;
        const copia = state.data[2].slice();
        pushUndo();
        state.data.splice(2, 1);
        recomputeFilters(); renderGrid();
        const n1 = state.data.length;
        undo();
        const voltou = JSON.stringify(state.data[2]) === JSON.stringify(copia);
        const ok = n1 === n0 - 1 && state.data.length === n0 && voltou;
        renderGrid();
        return { ok, msg: ok ? 'linha excluída e devolvida idêntica'
                             : n0 + ' → ' + n1 + ' → ' + state.data.length };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'congelar',
      grupo: G_PLAN,
      titulo: 'Congelar prende a coluna ESCOLHIDA',
      olhar: 'Clique numa célula de CLIENTE e depois em Congelar: quem fica ' +
        'parada ao rolar é CLIENTE, não o CP. Botão direito no Congelar lista ' +
        'o que está preso, para soltar uma sem perder as outras.',
      auto: async () => {
        // Congelar pegava sempre "as N primeiras", entao prendia o CP mesmo
        // quando o usuario tinha escolhido outra coluna. E' o que o Naor
        // reportou em 05/09.
        const alvo = Math.min(3, state.headers.length - 1);
        const nome = state.headers[alvo];
        state.colunasFixas = []; state.activeCell = { row: 0, col: alvo };
        document.getElementById('btn-congelar').click();
        await ate(() => document.querySelector('#data-table thead th.col-fixa'), 4000);
        const th = document.querySelector('#data-table thead th.col-fixa');
        const presa = th ? parseInt(th.dataset.col) : -1;
        const fixou = presa === alvo && getComputedStyle(th).position === 'sticky';
        // e soltar uma so' mantem as outras
        state.activeCell = { row: 0, col: 0 };
        document.getElementById('btn-congelar').click();   // congela a primeira tambem
        await espera(120);
        const duas = state.colunasFixas.length === 2;
        state.colunasFixas = state.colunasFixas.filter(c => c !== 0);
        renderGrid(); await espera(120);
        const sobrou = state.colunasFixas.length === 1 && state.colunasFixas[0] === alvo;
        state.colunasFixas = []; state.activeCell = { row: -1, col: -1 }; renderGrid();
        const ok = fixou && duas && sobrou;
        return { ok, msg: ok ? `prendeu ${nome}, e soltar uma manteve a outra`
                             : `presa=${presa} esperada=${alvo} duas=${duas} sobrou=${sobrou}` };
      },
      ir: () => { ConcrestatsOpenModule('spreadsheet'); state.colunasFixas = [3]; renderGrid(); },
    },
    {
      id: 'formula',
      grupo: G_PLAN,
      titulo: 'Fórmula com erro mostra #DIV/0!',
      olhar: 'Numa célula, escreva =MPA 28/0 - deve aparecer #DIV/0!, não "Infinity".',
      auto: async () => {
        const r = String(evaluateFormula('=[FCK]/0', state.data[0], state.headers));
        const r2 = String(evaluateFormula('=[FCK]*2', state.data[0], state.headers));
        // Somar dois campos: `[25]+[31]` em JavaScript devolve o TEXTO "2531"
        // em vez de 56, e o resultado sai na célula com cara de número.
        const a = parseFloat(state.data[0][state.headers.indexOf('FCK')]);
        const b = parseFloat(state.data[0][state.headers.indexOf('MPA 28')]);
        const soma = evaluateFormula('=[FCK]+[MPA 28]', state.data[0], state.headers);
        const somaOk = Math.abs(parseFloat(soma) - (a + b)) < 1e-9;
        const ok = r.indexOf('DIV/0') >= 0 && !isNaN(parseFloat(r2)) && somaOk;
        return { ok, msg: ok ? 'divisão por zero vira ' + r + ', e a soma de dois campos dá ' + soma
                             : (somaOk ? 'retornou ' + r : 'soma de dois campos deu ' + soma + ', esperado ' + (a + b)) };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'formula-so-conta',
      grupo: G_PLAN,
      titulo: 'Fórmula de planilha de fora não executa comando',
      olhar: 'Numa célula, escreva =document.title - deve aparecer #ERRO!, e não o ' +
        'título da janela. Planilha vem de cliente e de e-mail: fórmula é conta, ' +
        'não comando.',
      auto: async () => {
        // O cálculo joga o que sobrou da fórmula num Function(). Sem filtrar,
        // uma célula de planilha recebida de fora rodava sozinha ao ABRIR o
        // arquivo - a grade calcula as fórmulas para poder mostrá-las, ninguém
        // precisa clicar em nada.
        window.__provaDeFormula = 0;
        const tentativas = [
          '=window.__provaDeFormula = 1',
          '=document.title',
          '=(()=>{window.__provaDeFormula=3;return 1})()',
          '=fetch("/api/receitas")',
        ];
        const saidas = tentativas.map(f =>
          String(evaluateFormula(f, state.data[0], state.headers)));
        const rodou = window.__provaDeFormula !== 0;
        const barrou = saidas.every(s => s.indexOf('ERRO') >= 0 || s.indexOf('VALOR') >= 0);
        // e a conta de verdade continua funcionando
        const conta = String(evaluateFormula('=[FCK]+1', state.data[0], state.headers));
        const contaOk = !isNaN(parseFloat(conta));
        delete window.__provaDeFormula;
        const ok = !rodou && barrou && contaOk;
        return {
          ok,
          msg: ok ? 'as tentativas viraram #ERRO! e a conta normal continua certa'
            : (rodou ? 'EXECUTOU o comando escrito na célula'
                     : 'saídas: ' + saidas.join(' | ') + ' | conta: ' + conta)
        };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'formula-fica',
      grupo: G_PLAN,
      titulo: 'O resultado da fórmula continua depois de sair da célula',
      olhar: 'Escreva =MPA 28/0 numa célula e clique em outra: tem que continuar #DIV/0!, não voltar a fórmula.',
      auto: async () => {
        const ci = state.headers.length;
        state.headers.push('TESTE_FORMULA');
        state.data.forEach(l => l.push(''));
        state.data[0][ci] = '=[FCK]*2';
        state.data[1][ci] = '=[FCK]/0';
        renderGrid();
        await ate(() => document.querySelector('#table-body td[data-col="' + ci + '"]'));
        const ler = r => (document.querySelector(
          '#table-body td[data-row="' + r + '"][data-col="' + ci + '"]') || {}).textContent;
        const calc1 = ler(0), erro1 = ler(1);
        selectCell(3, 0);                 // sai da celula: redesenha a grade
        renderGrid();
        await espera(200);
        const calc2 = ler(0), erro2 = ler(1);
        // devolve a planilha como estava
        state.headers.pop();
        state.data.forEach(l => l.pop());
        renderGrid();
        const ok = calc1 === calc2 && erro1 === erro2 &&
                   String(erro1).indexOf('DIV/0') >= 0 && !isNaN(parseFloat(calc1));
        return { ok, msg: ok ? 'valor ' + calc1 + ' e ' + erro1 + ' continuam apos sair'
                             : calc1 + '/' + calc2 + ' e ' + erro1 + '/' + erro2 };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'cruzar',
      grupo: G_JUNTAR,
      titulo: 'Trazer colunas de outra planilha (REGIAO do Cadastro)',
      olhar: 'Trazer colunas: recebe DEMONSTRAÇÃO, fornece Cadastro, coluna em comum CLIENTE, trazendo REGIAO.',
      auto: async () => {
        const r = await apiFetch('/api/join_sheets', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            session_id: SESSION_ID, left_sheet: nomeDemo, right_sheet: nomeCadastro,
            left_key: 'CLIENTE', right_key: 'CLIENTE', columns: ['REGIAO'], destino: 'nova'
          })
        });
        if (!r || !r.success) return { ok: false, msg: (r && r.error) || 'falhou' };
        const ok = r.data.headers.indexOf('REGIAO') >= 0 && r.matched > 0;
        return { ok, msg: ok ? r.matched + ' de ' + r.total + ' linhas casaram' : 'nada casou' };
      },
      ir: () => { ConcrestatsOpenModule('spreadsheet'); $('btn-join') && $('btn-join').click(); },
    },
    {
      id: 'cruzar-sem-par',
      grupo: G_JUNTAR,
      titulo: 'Cliente sem cadastro fica em branco, não some',
      olhar: 'A Delta Obras não está no Cadastro: a linha continua, só sem REGIAO.',
      auto: async () => {
        const r = await apiFetch('/api/join_sheets', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            session_id: SESSION_ID, left_sheet: nomeDemo, right_sheet: nomeCadastro,
            left_key: 'CLIENTE', right_key: 'CLIENTE', columns: ['REGIAO'], destino: 'nova'
          })
        });
        if (!r || !r.success) return { ok: false, msg: (r && r.error) || 'falhou' };
        const iCli = r.data.headers.indexOf('CLIENTE');
        const iReg = r.data.headers.indexOf('REGIAO');
        const delta = r.data.data.filter(l => String(l[iCli]).indexOf('Delta') >= 0);
        const semRegiao = delta.filter(l => !String(l[iReg] || '').trim()).length;
        const ok = r.total === r.data.data.length && delta.length > 0 && semRegiao === delta.length;
        return { ok, msg: ok ? delta.length + ' linhas da Delta preservadas, sem REGIAO'
                             : 'linhas foram perdidas no cruzamento' };
      },
      ir: () => { ConcrestatsOpenModule('spreadsheet'); $('btn-join') && $('btn-join').click(); },
    },
    {
      id: 'importar',
      grupo: G_JUNTAR,
      titulo: 'Importar avisa quando os cabeçalhos não batem',
      olhar: 'Importar uma planilha sem colunas em comum deve avisar, não inserir linhas vazias.',
      auto: async () => {
        const blob = await (await fetch('/api/export_aoa', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ aoa: [['NADA_A_VER', 'OUTRA'], ['x', 'y']], base_name: 'teste' })
        })).blob();
        const fd = new FormData();
        fd.append('file', new File([blob], 'teste.xlsx'));
        fd.append('session_id', SESSION_ID);
        fd.append('target_sheet', nomeDemo);
        const r = await fetch('/api/import_merge', { method: 'POST', body: fd });
        const j = await r.json();
        const ok = r.status === 400 && /coluna/i.test(j.error || '');
        return { ok, msg: ok ? 'recusou e explicou o motivo' : 'aceitou sem avisar' };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'importar-bate',
      grupo: G_JUNTAR,
      titulo: 'Importar com as mesmas colunas acrescenta as linhas',
      olhar: 'Importar uma planilha com as MESMAS colunas deve somar as linhas no fim.',
      auto: async () => {
        // a conta e' feita no servidor: garantir que ele tem a mesma versao
        await gravarAgora(nomeDemo, state.headers, state.data);
        const antes = state.data.length;
        const linha = DEMO_HEADERS.map(h => h === 'CP' ? 'CP-IMPORTADO' : 'x');
        const blob = await (await fetch('/api/export_aoa', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ aoa: [DEMO_HEADERS, linha], base_name: 'teste' })
        })).blob();
        const fd = new FormData();
        fd.append('file', new File([blob], 'teste.xlsx'));
        fd.append('session_id', SESSION_ID);
        fd.append('target_sheet', nomeDemo);
        const r = await fetch('/api/import_merge', { method: 'POST', body: fd });
        const j = await r.json();
        const ok = r.ok && j.success && j.data && j.data.data.length === antes + 1 &&
                   j.data.data.some(l => String(l[0]) === 'CP-IMPORTADO');
        // devolve a demonstração ao estado original
        state.headers = DEMO_HEADERS.slice();
        state.data = dadosDemo();
        await gravarAgora(nomeDemo, state.headers, state.data);
        recomputeFilters(); renderGrid();
        return { ok, msg: ok ? antes + ' → ' + (antes + 1) + ' linhas' : 'a linha importada não apareceu' };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },

    /* -- grupo: análise, gráficos e painel ------------- */
    {
      id: 'painel-monta',
      grupo: G_VIS,
      titulo: 'Painel monta sozinho a partir dos dados',
      olhar: 'Abra o Painel e clique em Montar: devem aparecer blocos com números e gráficos.',
      auto: async () => {
        if (semAba('painel')) return pular('painel');
        ConcrestatsOpenModule('painel');
        await ate(() => $('pan-canvas') || document.querySelector('.pan-widget'), 6000);
        if (!document.querySelectorAll('.pan-widget').length) {
          $('pan-auto') && $('pan-auto').click();
          await ate(() => document.querySelectorAll('.pan-widget').length > 0, 8000);
        }
        const widgets = document.querySelectorAll('.pan-widget').length;
        const comGrafico = [].slice.call(document.querySelectorAll('.pan-widget'))
          .filter(w => w.querySelector('canvas')).length;
        const ok = widgets > 0 && comGrafico > 0;
        return { ok, msg: ok ? widgets + ' blocos, ' + comGrafico + ' com gráfico' : 'o painel ficou vazio' };
      },
      ir: () => ConcrestatsOpenModule('painel'),
    },
    {
      id: 'painel-impossivel',
      grupo: G_VIS,
      titulo: 'Ruptura impossível não entra na conta do desvio padrão',
      olhar: 'Na distribuição, se a planilha tiver um valor absurdo (ex.: 3000 MPa), ' +
        'a legenda tem que dizer quantos ficaram de fora - e o desvio padrão não pode explodir.',
      auto: async () => {
        const sep = window.ConcreLab && window.ConcreLab.separarImpossiveis;
        if (!sep) return { ok: false, msg: 'ConcreLab.separarImpossiveis não existe' };
        // 30 rupturas normais de usina + um 3553 digitado errado (foi o que
        // apareceu na planilha real: levava o desvio de ~8 para 55 MPa).
        const bons = [];
        for (let i = 0; i < 30; i++) bons.push(28 + (i % 9));
        const r = sep(bons.concat([3553.6]));
        const okFora = r.fora.length === 1 && Math.round(r.fora[0]) === 3554;
        const okBons = r.bons.length === 30;
        // e uma planilha que NAO e' de MPa (valores altos legitimos) tem que
        // passar inteira: o corte so' vale para o caso raro.
        const outra = sep([100, 200, 300, 400, 500, 600, 700, 800, 900, 1000]);
        const okOutra = outra.fora.length === 0;
        const ok = okFora && okBons && okOutra;
        return {
          ok,
          msg: ok ? '1 valor de 3554 MPa fora, 30 mantidos, escala grande intacta'
            : 'fora=' + r.fora.length + ' bons=' + r.bons.length + ' outra=' + outra.fora.length
        };
      },
      ir: () => ConcrestatsOpenModule('painel'),
    },
    {
      id: 'painel-distribuicao',
      grupo: G_VIS,
      titulo: 'Distribuição no Painel bate com a do Dashboard',
      olhar: 'Compare os números da distribuição no Painel com os da aba Dashboard: ' +
        'corpos de prova, média e desvio padrão têm que ser iguais.',
      auto: async () => {
        if (semAba('painel')) return pular('painel');
        const leia = raiz => [].slice.call(raiz.querySelectorAll('.dist-num'))
          .map(n => n.querySelector('b').textContent).join(' | ');
        ConcrestatsOpenModule('painel');
        await ate(() => document.querySelectorAll('.pan-widget').length > 0, 6000);
        let alvo = [].slice.call(document.querySelectorAll('.pan-widget'))
          .filter(w => w.querySelector('.dist-num'))[0];
        if (!alvo) {
          $('pan-auto') && $('pan-auto').click();
          await ate(() => [].slice.call(document.querySelectorAll('.pan-widget'))
            .some(w => w.querySelector('.dist-num')), 8000);
          alvo = [].slice.call(document.querySelectorAll('.pan-widget'))
            .filter(w => w.querySelector('.dist-num'))[0];
        }
        if (!alvo) return { ok: false, msg: 'o Painel não montou a distribuição' };
        const noPainel = leia(alvo);

        if (!document.querySelector('.nav-btn[data-module="dashboard"]')) {
          return { ok: !!noPainel, msg: 'sem aba Dashboard nesta edição; Painel: ' + noPainel };
        }
        ConcrestatsOpenModule('dashboard');
        await ate(() => document.querySelectorAll('#dist-numeros .dist-num').length > 0, 6000);
        const noDash = leia($('dist-numeros'));
        const ok = !!noPainel && noPainel === noDash;
        return { ok, msg: ok ? noPainel : 'Painel: ' + noPainel + '  ≠  Dashboard: ' + noDash };
      },
      ir: () => ConcrestatsOpenModule('painel'),
    },
    {
      id: 'previsao-diagnostico',
      grupo: G_VIS,
      titulo: 'A Previsão diz o que fazer, não só que há problema',
      olhar: 'Passe o mouse no nome de uma receita reprovada: a frase tem que dizer se o problema é o traço ou a irregularidade.',
      auto: async () => {
        if (semAba('previsao')) return pular('previsao');
        if (!window.PrevisaoModule) return { ok: false, msg: 'o módulo não carregou' };
        ConcrestatsOpenModule('previsao');
        await ate(() => document.getElementById('prev-corpo')
                        && document.getElementById('prev-corpo').children.length, 8000);
        const todas = window.PrevisaoModule._analisar();
        if (!todas.length) return { ok: true, pulou: true, msg: 'sem planilha de rompimentos' };

        const reprovadas = todas.filter(a => isFinite(a.folga) && a.folga < 0);
        // 1. condicao de preparo tem de sair para quem tem desvio.
        const comCondicao = todas.filter(a => a.n >= 6 && a.condicao).length;
        const deveriamTer = todas.filter(a => a.n >= 6).length;

        // 2. a conta do desvio necessario tem de FECHAR: com ele, o fck,est
        //    bate no alvo. Se errar aqui, a tela manda a usina perseguir um
        //    numero que nao resolve.
        let contaFecha = true;
        reprovadas.forEach(a => {
          if (!isFinite(a.sdNecessario) || a.sdNecessario <= 0) return;
          const estimado = a.media - 1.65 * a.sdNecessario;
          if (Math.abs(estimado - a.alvo.valor) > 0.05) contaFecha = false;
        });

        // 3. a margem desperdicada nunca pode ser negativa nem absurda.
        const desperdicioSao = todas.every(a => !a.desperdicio
          || (a.desperdicio.ganho > 0 && a.desperdicio.ganho < 60));

        const ok = comCondicao === deveriamTer && contaFecha && desperdicioSao;
        return {
          ok,
          msg: ok
            ? comCondicao + ' receitas com condição de preparo, e a conta do desvio necessário fecha'
            : 'condição ' + comCondicao + '/' + deveriamTer + ' conta=' + contaFecha +
              ' desperdício=' + desperdicioSao,
          subs: [
            { ok: comCondicao === deveriamTer, texto: 'toda receita com histórico recebe condição A/B/C' },
            { ok: contaFecha, texto: 'o desvio sugerido realmente faz o fck estimado bater no alvo' },
            { ok: desperdicioSao, texto: 'a margem desperdiçada é sempre positiva e plausível' },
          ],
        };
      },
      ir: () => ConcrestatsOpenModule('previsao'),
    },
    {
      id: 'perguntas-dentro-do-app',
      grupo: G_VIS,
      titulo: 'Os "tem certeza?" abrem dentro do programa, e nunca ficam esperando para sempre',
      olhar: 'Apague uma planilha ou uma receita: a pergunta tem de aparecer na caixa do próprio programa, '
           + 'e não numa janela do Windows (que podia abrir atrás e parecer que travou).',
      auto: async () => {
        if (typeof window.perguntar !== 'function') return { ok: false, msg: 'perguntar() não existe' };
        const clicar = sel => { const b = document.querySelector(sel); if (b) b.click(); return !!b; };
        const cancelar = () => {
          const b = [...document.querySelectorAll('#modal-content .modal-footer button')]
            .find(x => /Cancelar/.test(x.textContent));
          if (b) b.click();
        };
        // O painel do Modo Teste mora na MESMA caixa de dialogo que a pergunta
        // usa. Sem guardar e devolver, a primeira pergunta apagava o painel no
        // meio da rodada, e o placar final sumia. Guarda os proprios elementos
        // (nao uma copia): assim os botoes do painel continuam funcionando.
        const conteudo = document.getElementById('modal-content');
        const caixa = document.getElementById('modal-box');
        const fundo = document.getElementById('modal-overlay');
        const guardados = conteudo ? Array.from(conteudo.childNodes) : [];
        const classeCaixa = caixa ? caixa.className : '';
        const displayFundo = fundo ? fundo.style.display : '';
        let escapou, sim, naoCancelar, naoEsc, atropelada, segunda;
        try {
          let p = window.perguntar('Teste', 'Confirmar <b>isto</b>?', 'Sim');
          await espera(80);
          escapou = !document.querySelector('#modal-content .pergunta-texto b');
          clicar('#modal-confirm');
          sim = (await p) === true;

          p = window.perguntar('Teste', 'x'); await espera(60); cancelar();
          naoCancelar = (await p) === false;

          p = window.perguntar('Teste', 'x'); await espera(60);
          document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' }));
          naoEsc = (await p) === false;

          const p1 = window.perguntar('A', 'x'); await espera(40);
          const p2 = window.perguntar('B', 'y'); await espera(60);
          atropelada = (await p1) === false;
          clicar('#modal-confirm');
          segunda = (await p2) === true;
        } finally {
          if (conteudo) conteudo.replaceChildren(...guardados);
          if (caixa) caixa.className = classeCaixa;
          if (fundo) fundo.style.display = displayFundo;
        }

        // e nenhum confirm() do navegador sobrou nas telas
        const fontes = ['app.js', 'graficos.js', 'painel.js', 'receitas.js', 'analise.js', 'dashboard.js'];
        let nativos = 0;
        for (const f of fontes) {
          try {
            const src = await (await fetch('/static/js/' + f)).text();
            // comentario no fim da linha nao conta: tira antes de procurar
            nativos += src.split(/\r?\n/)
              .map(l => l.replace(/\/\/.*$/, ''))
              .filter(l => /[^.\w]confirm\(/.test(l)).length;
          } catch (e) { /* arquivo que nao existe nesta edicao */ }
        }

        const ok = escapou && sim && naoCancelar && naoEsc && atropelada && segunda && nativos === 0;
        return {
          ok,
          msg: ok ? 'sim, não, Esc, atropelo e texto escapado - e nenhum confirm() nativo'
                  : 'confirm() nativos restantes: ' + nativos,
          itens: [
            { ok: sim, texto: 'confirmar responde sim' },
            { ok: naoCancelar && naoEsc, texto: 'Cancelar e Esc respondem não' },
            { ok: atropelada && segunda, texto: 'uma pergunta por cima da outra não deixa a primeira esperando' },
            { ok: escapou, texto: 'nome com HTML aparece como texto' },
            { ok: nativos === 0, texto: 'nenhum confirm() do navegador nas telas' },
          ],
        };
      },
    },
    {
      id: 'reportar-problema',
      grupo: G_VIS,
      titulo: 'O botão "Reportar problema" existe em todas as telas e sabe o que aconteceu',
      olhar: 'Em qualquer tela, clique em "Reportar problema" no canto de cima: o texto tem de trazer a tela, '
           + 'a planilha, a versão e os últimos passos, e "Copiar para mandar" tem de copiar.',
      auto: async () => {
        const R = window.ReportarProblema;
        if (!R) return { ok: false, msg: 'o reportar.js não carregou' };
        const barras = document.querySelectorAll('.topbar-right').length;
        const botoes = document.querySelectorAll('.topbar-right .btn-reportar').length;
        const umPorBarra = barras > 0 && botoes === barras;

        // um passo de verdade: trocar de aba tem de entrar no registro
        const antes = R._passos().length;
        const b = [...document.querySelectorAll('[data-module="charts"]')].find(e => e.offsetParent !== null);
        if (b) b.click();
        await espera(300);
        const registrou = R._passos().length > antes &&
                          /abriu a aba/.test(R._passos().slice(-1)[0] || '');
        ConcrestatsOpenModule('spreadsheet');

        const texto = await R._texto('teste automático');
        const temVersao = /Versão: \S/.test(texto);
        const temPassos = /Últimos passos:/.test(texto) && /abriu a aba/.test(texto);
        const semDados = !/\d{2},\d{2}\s*MPa/.test(texto);   // números da planilha não vão junto

        const ok = umPorBarra && registrou && temVersao && temPassos && semDados;
        return {
          ok,
          msg: ok ? botoes + ' botões, registro de passos e texto completos'
                  : 'barras ' + barras + ', botões ' + botoes,
          itens: [
            { ok: umPorBarra, texto: 'um botão em cada uma das ' + barras + ' barras' },
            { ok: registrou, texto: 'trocar de aba entra nos últimos passos' },
            { ok: temVersao, texto: 'o texto traz a versão (falou com o programa)' },
            { ok: temPassos, texto: 'o texto traz os últimos passos' },
            { ok: semDados, texto: 'nenhum valor da planilha vai junto' },
          ],
        };
      },
    },
    {
      id: 'previsao-relatorio',
      grupo: G_VIS,
      titulo: 'O relatório de conformidade abre DENTRO do programa',
      olhar: 'Na Previsão, clique em "Relatório de conformidade": tem de abrir a impressão '
           + 'do Windows, e não a mensagem "We can’t open this about link".',
      auto: async () => {
        if (semAba('previsao')) return pular('previsao');
        const M = window.PrevisaoModule;
        if (!M || typeof M._relatorio !== 'function') {
          return { ok: false, msg: 'o módulo não expôs o relatório' };
        }
        ConcrestatsOpenModule('previsao');
        await ate(() => document.getElementById('prev-corpo')
                        && document.getElementById('prev-corpo').children.length, 8000);

        // 1. o documento tem de existir e ter conteúdo de verdade
        let html = '';
        try { html = M._relatorio() || ''; } catch (e) { html = ''; }
        if (!html) return { ok: true, pulou: true, msg: 'sem planilha de rompimentos' };
        const temTabela = /<table/i.test(html) && /12655/.test(html);

        // 2. NADA de window.open. Dentro do WebView2 'about:blank' nao e'
        //    pagina: o Windows tenta entregar o endereco a um aplicativo e
        //    responde "We can't open this 'about' link". Num navegador passa,
        //    e foi assim que o defeito chegou ao cliente.
        let abriuJanela = false;
        const openOriginal = window.open;
        window.open = function () { abriuJanela = true; return null; };

        // 3. a impressão tem de sair de um quadro interno
        let imprimiu = false;
        const bt = document.getElementById('prev-relatorio');
        // A troca da impressao e' REAPLICADA a cada volta: quando o documento
        // do quadro termina de carregar, o navegador cria uma janela nova la'
        // dentro e a impressao original volta. Trocar uma vez so', antes do
        // carregamento, fazia o teste passar ou falhar conforme o relogio.
        const falsa = () => { imprimiu = true; };
        const vigia = setInterval(() => {
          const q = document.getElementById('prev-quadro-impressao');
          if (q && q.contentWindow && q.contentWindow.print !== falsa) {
            try { q.contentWindow.print = falsa; } catch (e) { /* ainda carregando */ }
          }
        }, 15);

        if (bt) bt.click();
        await ate(() => imprimiu || abriuJanela, 6000);
        clearInterval(vigia);
        window.open = openOriginal;
        const q = document.getElementById('prev-quadro-impressao');
        if (q) { try { q.remove(); } catch (e) { /* ja' foi */ } }

        const ok = temTabela && !abriuJanela && imprimiu;
        return {
          ok,
          msg: ok ? 'documento montado e impresso por quadro interno'
                  : (abriuJanela ? 'ainda usa window.open - quebra dentro do programa'
                                 : (!imprimiu ? 'a impressão não foi chamada'
                                              : 'o documento saiu sem tabela ou sem a NBR')),
          itens: [
            { ok: temTabela, texto: 'o documento tem a tabela e cita a NBR 12655' },
            { ok: !abriuJanela, texto: 'não tenta abrir janela nova (about:blank)' },
            { ok: imprimiu, texto: 'a impressão sai de um quadro dentro da página' },
          ],
        };
      },
      ir: () => ConcrestatsOpenModule('previsao'),
    },
    {
      id: 'previsao-dois-cps',
      grupo: G_VIS,
      titulo: 'O maior dos dois corpos de prova entra na conta (NBR 12655)',
      olhar: 'Previsão > Dados: com duas colunas de 28 dias, o bloco "Segundo corpo de prova" mostra o efeito '
           + 'com e sem, e a opção começa LIGADA - o laboratório confirmou em 24/09/2026 que a segunda coluna '
           + 'é o segundo corpo de prova rompido do exemplar.',
      auto: async () => {
        if (semAba('previsao')) return pular('previsao');
        const M = window.PrevisaoModule;
        if (!M || typeof M._comDoisCPs !== 'function') return { ok: false, msg: 'o módulo não expôs a conta' };
        // Dados montados aqui: a planilha de demonstracao tem uma coluna de
        // 28 dias so'. Uma receita que reprova pelo primeiro corpo de prova e
        // passa pelo maior dos dois. A tela real nao e' tocada: a leitura dos
        // dados e' trocada so' durante a conta, e devolvida em seguida.
        const p1 = [25, 26, 24, 31, 33, 22, 27, 29, 30, 23, 28, 26];
        const p2 = [34, 35, 33, 36, 37, 34, 35, 36, 34, 35, 36, 34];
        const falso = {
          headers: ['PRODUTO', 'MPA 28', 'MPA 28.1'],
          data: p1.map((v, i) => ['TESTE FCK 30', String(v), String(p2[i])]),
        };
        const leituraReal = window.getConcrestatsData;
        let so1, maior, detectou;
        try {
          window.getConcrestatsData = () => Object.assign({ filteredData: falso.data, fullData: falso.data }, falso);
          so1 = M._comDoisCPs(false);
          maior = M._comDoisCPs(true);
          detectou = !!(so1 && maior);
        } finally {
          window.getConcrestatsData = leituraReal;
        }
        const ligada = M._doisCPsLigado() === true;
        const mudou = detectou && so1.abaixo === 1 && maior.abaixo === 0;
        const ok = ligada && mudou;
        return {
          ok,
          msg: ok ? 'ligada por padrão; com o maior dos dois, a receita de teste sai da reprovação'
                  : (!ligada ? 'a opção nasceu desligada'
                                : 'a conta com o maior dos dois não deu o esperado: ' +
                                  JSON.stringify({ so1, maior })),
          itens: [
            { ok: ligada, texto: 'a opção começa ligada' },
            { ok: detectou, texto: 'acha a segunda coluna de 28 dias (MPA 28.1)' },
            { ok: mudou, texto: 'com o maior dos dois, a receita de teste passa; sem, reprova' },
          ],
        };
      },
      ir: () => ConcrestatsOpenModule('previsao'),
    },
    {
      id: 'previsao-colunas',
      grupo: G_VIS,
      titulo: 'A Previsão acha a coluna certa, e pergunta quando não acha',
      olhar: 'Abra a Previsão e vá na aba Dados: o bloco "De onde vieram os números" tem de '
           + 'dizer de qual coluna sai cada coisa, e o botão Trocar as colunas tem de abrir a escolha.',
      auto: async () => {
        if (semAba('previsao')) return pular('previsao');
        const M = window.PrevisaoModule;
        if (!M || typeof M._coluna !== 'function') {
          return { ok: false, msg: 'o módulo não expôs o casamento de cabeçalho' };
        }
        const c = M._coluna;
        const casos = [
          // [cabecalhos, apelidos, indice esperado, por que importa]
          [['CP', 'PRODUTO', 'MPA 28'], ['PRODUTO', 'RECEITA'], 1,
           'nome exato continua valendo'],
          [['cp', 'produto', 'mpa 28'], ['PRODUTO'], 1,
           'minúsculas'],
          [['CP', 'Produto ', ' MPA  28 '], ['MPA 28'], 2,
           'espaço sobrando e dobrado'],
          [['CP', 'PRODUTO', 'MPA28'], ['MPA 28', 'MPA28'], 2,
           'sem o espaço no meio'],
          [['CP', 'TRAÇO', 'MPA 28'], ['TRACO'], 1,
           'acento no cabeçalho'],
          [['CP', 'M³', 'MPA 28'], ['M3'], 1,
           'M³ com o três em cima'],
          [['CP', 'OBRA', 'MPA 28'], ['PRODUTO', 'RECEITA'], -1,
           'não inventa coluna que não existe'],
        ];
        const falhas = casos
          .map(([h, nomes, esperado, porque]) => [c(h, nomes), esperado, porque])
          .filter(([deu, esperado]) => deu !== esperado)
          .map(([deu, esperado, porque]) => porque + ' (deu ' + deu + ', esperado ' + esperado + ')');

        // O fck PEDIDO nunca pode sair da coluna do rompimento: seria comparar
        // o ensaio com ele mesmo e aprovar qualquer coisa.
        ConcrestatsOpenModule('previsao');
        await ate(() => document.getElementById('prev-corpo')
                        && document.getElementById('prev-corpo').children.length, 8000);
        const uso = typeof M._colunasEmUso === 'function' ? M._colunasEmUso() : null;
        const fckSeparado = !uso || uso.fck < 0 || (uso.fck !== uso.d28 && uso.fck !== uso.d7);
        if (!fckSeparado) falhas.push('o fck pedido saiu da mesma coluna do rompimento');

        return {
          ok: !falhas.length,
          msg: falhas.length ? falhas.join(' · ')
                             : casos.length + ' formatos de cabeçalho reconhecidos',
          itens: [
            { ok: !falhas.length, texto: 'acento, maiúscula, espaço e M³ não atrapalham' },
            { ok: fckSeparado, texto: 'o fck pedido nunca vem da coluna do rompimento' },
          ],
        };
      },
      ir: () => ConcrestatsOpenModule('previsao'),
    },
    {
      id: 'colunas-comuns',
      grupo: G_VIS,
      titulo: 'Planilha com outros nomes de coluna funciona em todas as telas',
      olhar: 'Planilhas > botão Colunas: a caixa mostra de qual coluna cada tela lê o quê, com o que foi '
           + 'achado pelo nome já marcado. Escolher ali muda o Dashboard, o Painel, o Relatório e a '
           + 'Previsão de uma vez (pedido do Naor em 24/09/2026).',
      auto: async () => {
        const C = window.ConcreColunas, L = window.ConcreLab, P = window.PainelModule,
              M = window.PrevisaoModule;
        if (!C) return { ok: false, msg: 'a escolha de colunas não carregou' };
        // Os cabeçalhos de outro laboratório, com os mesmos papéis da Usinop.
        const h = ['Nº do CP', 'Data de moldagem', 'Contratante', 'Descrição', 'Volume (m³)',
                   'Resistência 7d (MPa)', 'Resistência 28d CP1 (MPa)', 'Resistência 28d CP2 (MPa)',
                   'fck (MPa)'];
        const esperado = { cp: 0, data: 1, cliente: 2, produto: 3, volume: 4, mpa7: 5,
                           mpa28: 6, mpa28b: 7, fck: 8 };
        const errados = Object.keys(esperado).filter(p => C.indice(h, p) !== esperado[p])
          .map(p => p + ' (deu ' + C.indice(h, p) + ')');
        const linhas = [['1', '2026-09-01', 'Obra A', 'CONCRETO C30', '8', '21', '31', '33', '30'],
                        ['2', '2026-09-02', 'Obra B', 'CONCRETO C30', '6', '22', '29', '34', '30'],
                        ['3', '2026-09-03', 'Obra A', 'CONCRETO C30', '7', '20', '32', '30', '30']];
        let rompe = [], fck = NaN, plano = null, previsao = null;
        const leituraReal = window.getConcrestatsData;
        try {
          window.getConcrestatsData = () => ({ headers: h, data: linhas, activeSheet: 'teste' });
          if (L && L.colunasDeRompimento) rompe = L.colunasDeRompimento(h, 'mpa28', 'mpa28b', 'MPA 28');
          if (L && L.fckFrom) fck = L.fckFrom(linhas[0], h);
          if (P && P._planoLaboratorio) plano = P._planoLaboratorio();
          if (M && M._comDoisCPs) previsao = M._comDoisCPs(true);
        } finally {
          window.getConcrestatsData = leituraReal;
        }
        const dash = rompe.join(',') === '6,7' && fck === 30;
        const painel = !!plano && plano.vol === h[4] && plano.cli === h[2] && plano.mpa === h[6];
        const prev = !!previsao;

        // Nome que nada reconhece: escolher à mão vale, e o 2º CP vem junto
        // pela coluna irmã. Depois, desfaz - a escolha é guardada.
        const h2 = ['CP', 'PRODUTO', 'Resultado final', 'Resultado final B', 'teste-' + Date.now()];
        const naoAchou = C.indice(h2, 'mpa28') === -1;
        C._escolher(h2, { mpa28: 2 });
        const escolheu = C.indice(h2, 'mpa28') === 2 && C.indice(h2, 'mpa28b') === 3;
        C._esquecer(h2);
        const desfez = C.indice(h2, 'mpa28') === -1;
        const manual = naoAchou && escolheu && desfez;

        const ok = !errados.length && dash && painel && prev && manual;
        return {
          ok,
          msg: ok ? '9 papéis achados pelo nome; Dashboard, Painel e Previsão leem das mesmas colunas'
                  : [errados.length ? 'papéis errados: ' + errados.join(', ') : '',
                     !dash ? 'Dashboard: ' + JSON.stringify({ rompe, fck }) : '',
                     !painel ? 'Painel: ' + JSON.stringify(plano) : '',
                     !prev ? 'a Previsão não achou as colunas' : '',
                     !manual ? 'escolha manual: ' + JSON.stringify({ naoAchou, escolheu, desfez }) : '']
                    .filter(Boolean).join(' · '),
          itens: [
            { ok: !errados.length, texto: '"Resistência 28d", "Contratante", "Volume (m³)", "Nº do CP"… reconhecidos' },
            { ok: dash, texto: 'Dashboard: os dois corpos de prova e o fck da coluna própria' },
            { ok: painel, texto: 'Painel automático monta com volume, cliente e resistência' },
            { ok: prev, texto: 'Previsão acha as colunas sem perguntar' },
            { ok: manual, texto: 'nome desconhecido: a escolha à mão vale, traz o 2º CP e pode ser desfeita' },
          ],
        };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'previsao-honesta',
      grupo: G_VIS,
      titulo: 'A Previsão mostra a margem e recusa quando não sabe',
      olhar: 'Na aba Previsão: toda previsão tem que vir com “entre X e Y”. Receita bagunçada tem que dizer que não vai prever.',
      auto: async () => {
        if (semAba('previsao')) return pular('previsao');
        if (!window.PrevisaoModule) return { ok: false, msg: 'o módulo não carregou' };
        ConcrestatsOpenModule('previsao');
        await ate(() => document.getElementById('prev-corpo')
                        && document.getElementById('prev-corpo').children.length, 8000);
        const todas = window.PrevisaoModule._analisar();
        if (!todas.length) return { ok: true, pulou: true, msg: 'sem planilha de rompimentos aberta' };

        // 1. um numero sozinho e' mentira: tem de vir com a margem e a base.
        const boa = todas.filter(a => a.reta && a.reta.n >= 12 && a.reta.erro <= 8)
                         .sort((x, y) => y.reta.n - x.reta.n)[0];
        let temMargem = true, numeroDentro = true;
        if (boa) {
          const r = window.PrevisaoModule._prever(boa, boa.media / 1.4);
          temMargem = !!(r.ok && isFinite(r.minimo) && isFinite(r.maximo)
                         && r.maximo > r.minimo && r.n >= 12);
          numeroDentro = !!(r.ok && r.valor > 0 && r.valor < 150);
        }

        // 2. e quando o historico nao sustenta, tem de RECUSAR.
        const ruim = todas.find(a => a.reta && a.reta.erro > 8)
                  || todas.find(a => a.reta && a.reta.n < 12);
        const recusou = ruim ? (window.PrevisaoModule._prever(ruim, 20).ok === false) : true;

        const ok = temMargem && numeroDentro && recusou;
        return {
          ok,
          msg: ok
            ? (boa ? 'previsão com margem em ' + boa.reta.n + ' ensaios; ' : '') +
              (ruim ? 'e recusa a receita irregular' : 'nenhuma receita irregular para recusar')
            : 'margem=' + temMargem + ' numero=' + numeroDentro + ' recusa=' + recusou,
          subs: [
            { ok: temMargem,    texto: 'toda previsão vem com "entre X e Y"' },
            { ok: numeroDentro, texto: 'o número previsto é fisicamente possível' },
            { ok: recusou,      texto: 'receita irregular demais recebe recusa, não palpite' },
          ],
        };
      },
      ir: () => ConcrestatsOpenModule('previsao'),
    },
    {
      id: 'painel-cabe-no-canvas',
      grupo: G_VIS,
      titulo: 'Bloco largo do Painel continua podendo ser arrastado',
      olhar: 'No Painel, alargue um bloco até passar da tela e tente arrastá-lo para o lado: tem que andar.',
      auto: async () => {
        if (semAba('painel')) return pular('painel');
        ConcrestatsOpenModule('painel');
        await ate(() => document.querySelectorAll('.pan-widget').length > 0, 8000);
        const c = document.getElementById('pan-canvas');
        const blocos = [].slice.call(document.querySelectorAll('.pan-widget'));
        if (!c || !blocos.length) return { ok: true, pulou: true, msg: 'painel vazio' };
        // A causa do defeito: o limite do arrasto era
        // (largura do canvas - largura do bloco). Com um bloco mais largo que o
        // canvas isso da' negativo, e o bloco ficava preso no canto esquerdo
        // sem andar um pixel. Basta o canvas acompanhar o conteudo para o
        // limite nunca mais ser negativo.
        let borda = 0, maisLargo = 0;
        blocos.forEach(w => {
          const x = parseInt(w.style.left) || 0;
          borda = Math.max(borda, x + w.offsetWidth);
          maisLargo = Math.max(maisLargo, w.offsetWidth);
        });
        const sobra = c.offsetWidth - borda;
        const ok = sobra >= 0;
        return {
          ok,
          msg: ok
            ? 'canvas de ' + c.offsetWidth + 'px acompanha o bloco mais largo ('
              + maisLargo + 'px)'
            : 'o conteúdo chega a ' + borda + 'px e o canvas tem só '
              + c.offsetWidth + 'px - blocos largos ficam presos no canto'
        };
      },
      ir: () => ConcrestatsOpenModule('painel'),
    },
    {
      id: 'painel-foco',
      grupo: G_VIS,
      titulo: 'Clicar num gráfico filtra o painel inteiro',
      olhar: 'No Painel, clique numa barra: aparece a faixa "Filtrando por..." no topo ' +
        'e TODOS os blocos passam a mostrar só aquele pedaço. O botão limpar desfaz.',
      auto: async () => {
        if (semAba('painel')) return pular('painel');
        ConcrestatsOpenModule('painel');
        await ate(() => document.querySelectorAll('.pan-widget').length > 0, 6000);
        const alvo = [].slice.call(document.querySelectorAll('.pan-widget'))
          .filter(w => (w.querySelector('.pan-w-tag') || {}).textContent === 'barra'
            && w.querySelector('canvas'))[0];
        if (!alvo) return { ok: false, msg: 'nenhum gráfico de barra no painel' };
        const antes = $('pan-info').textContent;
        const cv = alvo.querySelector('canvas');
        const r = cv.getBoundingClientRect();
        // 56px e' a margem esquerda do eixo; a primeira barra comeca logo depois.
        cv.dispatchEvent(new MouseEvent('click', {
          clientX: r.left + 56 + (r.width - 68) / 24, clientY: r.top + r.height / 2, bubbles: true
        }));
        await ate(() => document.querySelectorAll('.pan-foco-chip').length > 0, 4000);
        const filtrou = $('pan-info').textContent;
        const temChip = document.querySelectorAll('.pan-foco-chip').length === 1;
        const mudou = filtrou !== antes && filtrou.indexOf('(de ') > 0;
        const limpar = document.querySelector('.pan-foco-limpar');
        if (limpar) limpar.click();
        await ate(() => document.querySelectorAll('.pan-foco-chip').length === 0, 4000);
        const voltou = $('pan-info').textContent === antes;
        const ok = temChip && mudou && voltou;
        return {
          ok,
          msg: ok ? 'filtrou e desfez: ' + filtrou
            : 'chip=' + temChip + ' filtrou=' + mudou + ' desfez=' + voltou
        };
      },
      ir: () => ConcrestatsOpenModule('painel'),
    },
    {
      id: 'grafico-desenha',
      grupo: G_VIS,
      titulo: 'Gráfico desenha mesmo (não fica em branco)',
      olhar: 'Nenhum gráfico pode ficar branco, cortado ou com um fantasma no canto.',
      auto: async () => {
        // Este mede o canvas do PAINEL. Numa edição sem essa aba não há o que
        // medir - quem cobre o desenho ali é o teste da Análise.
        if (semAba('painel')) return pular('painel');
        ConcrestatsOpenModule('painel');
        await ate(() => document.querySelector('.pan-widget canvas'), 8000);
        const cv = document.querySelector('.pan-widget canvas');
        if (!cv || !cv.width) return { ok: false, msg: 'não achei o gráfico' };
        let pintados = 0;
        try {
          const d = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data;
          for (let i = 0; i < d.length; i += 40) { if (d[i + 3] > 10) pintados++; }
        } catch (e) { return { ok: false, msg: 'não consegui ler o gráfico: ' + e.message }; }
        const ok = pintados > 50;
        return { ok, msg: ok ? 'gráfico de ' + cv.width + '×' + cv.height + ' desenhado'
                             : 'a área do gráfico está vazia' };
      },
      ir: () => ConcrestatsOpenModule('painel'),
    },
    {
      id: 'nao-fechou-sozinho',
      grupo: G_ARQ,
      titulo: 'O programa não fechou sozinho',
      olhar: 'Se o programa sumiu da tela alguma vez, esta linha diz quando e em que aba - mande para mim.',
      auto: async () => {
        let j = null;
        try { j = await (await fetch('/api/quedas')).json(); } catch (e) { j = null; }
        if (!j) return { ok: true, pulou: true, msg: 'esta versão ainda não guarda esse registro' };
        const n = j.total || 0;
        if (!n) return { ok: true, msg: 'nenhuma vez desde que este registro começou' };
        // Falha de proposito: fechar sozinho e' defeito, e ficar em verde com o
        // numero escondido no meio do texto e' como isso passou despercebido
        // ate' o Naor reclamar.
        const ultimas = (j.quedas || []).slice(-3);
        return {
          ok: false,
          msg: n + (n === 1 ? ' vez que o programa fechou sozinho' : ' vezes que o programa fechou sozinho')
               + ' - arquivo: ' + (j.arquivo || 'quedas.txt'),
          subs: ultimas.map(l => ({ ok: false, texto: l })),
        };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'trocar-aba-nao-vaza',
      grupo: G_VIS,
      titulo: 'Trocar de aba muitas vezes não entope o programa',
      olhar: 'Passe de Planilhas para Gráficos e de volta umas dez vezes: o programa tem que continuar leve.',
      auto: async () => {
        // O Naor: "o app fica morrendo, acontece a cada algumas trocas de aba".
        // Era o chart-lite: cada gráfico criava a sua caixinha de dica presa no
        // <body> e o destroy() não a tirava. Com 61 receitas na tela, cada volta
        // na aba deixava 61 <div> position:fixed para trás. Em seis trocas o
        // <body> tinha 861 delas.
        const conta = () => ({
          dicas: document.querySelectorAll('.chart-lite-tooltip').length,
          corpo: document.body.children.length,
        });
        const antes = conta();
        for (let i = 0; i < 4; i++) {
          ConcrestatsOpenModule('spreadsheet');
          await espera(120);
          ConcrestatsOpenModule(semAba('charts') ? 'analise' : 'charts');
          await espera(320);
        }
        ConcrestatsOpenModule('spreadsheet');
        await espera(120);
        const depois = conta();
        const cresceu = depois.corpo - antes.corpo;
        // Uma caixinha de dica e' o certo: ela e' compartilhada por todos os
        // graficos. Duas ja' significa que voltaram a criar uma por grafico.
        const ok = depois.dicas <= 1 && cresceu <= 2;
        return {
          ok,
          msg: ok
            ? 'quatro idas e voltas sem sobra (' + depois.dicas + ' caixa de dica, ' +
              depois.corpo + ' elementos)'
            : 'sobrou lixo na tela: ' + depois.dicas + ' caixas de dica e ' +
              cresceu + ' elementos a mais no corpo da página'
        };
      },
      ir: () => ConcrestatsOpenModule('charts'),
    },
    {
      id: 'grafico-largura',
      grupo: G_VIS,
      titulo: 'Gráfico largo fica largo mesmo',
      olhar: 'Nos Gráficos, ponha 1800 de largura num gráfico: ele tem que ficar bem maior que a tela, com barra de rolagem.',
      auto: async () => {
        if (semAba('charts')) return pular('charts');
        ConcrestatsOpenModule('charts');
        await ate(() => document.querySelector('.graf-container'), 8000);
        const c = document.querySelector('.graf-container');
        if (!c) return { ok: false, msg: 'nenhuma receita na aba Gráficos' };
        // Mede uma peça de mentira, do mesmo tipo, sem mexer no layout de
        // ninguém. Havia um max-width de 900px: pedir 1800 dava 900, igual a
        // pedir 1000, que foi o que o Naor viu.
        const p = document.createElement('div');
        p.className = 'graf-widget graf-widget-chart';
        p.style.cssText = 'position:absolute;left:0;top:0;width:1400px;height:120px;visibility:hidden';
        c.appendChild(p);
        const larg = p.offsetWidth;
        p.remove();
        const ok = larg >= 1400;
        return { ok, msg: ok ? 'pedi 1400px e recebi ' + larg + 'px'
                             : 'pedi 1400px e a tela deu ' + larg + 'px (há um limite preso no CSS)' };
      },
      ir: () => ConcrestatsOpenModule('charts'),
    },
    {
      id: 'grafico-edicao',
      grupo: G_VIS,
      titulo: 'Modo de edição não encolhe o quadro',
      olhar: 'Nos Gráficos, ligue e desligue o "⊞ Layout": nada pode encolher, sumir ou ficar cortado.',
      auto: async () => {
        if (semAba('charts')) return pular('charts');
        ConcrestatsOpenModule('charts');
        await ate(() => document.querySelector('.graf-container .graf-widget'), 8000);
        const wrap = [].slice.call(document.querySelectorAll('.graf-receita-wrap'))
          .find(w => w.querySelector('.graf-container .graf-widget'));
        if (!wrap) return { ok: true, pulou: true, msg: 'nenhum gráfico montado para medir' };
        const c   = wrap.querySelector('.graf-container');
        const btn = wrap.querySelector('.graf-btn-edit-layout');
        const eraEdicao = c.classList.contains('edit-mode');
        const antes = c.offsetHeight;
        btn.click();  await espera(120);
        const ligado = c.offsetHeight;
        const alcas  = c.querySelectorAll('.graf-widget-resize').length;
        const widgets = c.querySelectorAll('.graf-widget').length;
        btn.click();  await espera(120);
        const desligado = c.offsetHeight;
        const sobrou    = c.querySelectorAll('.graf-widget-resize').length;
        if (c.classList.contains('edit-mode') !== eraEdicao) btn.click();
        const ok = ligado >= antes && desligado >= antes && alcas === widgets && sobrou === 0;
        return {
          ok,
          msg: ok ? 'altura firme em ' + antes + 'px, com alça de redimensionar só na edição'
                  : 'antes ' + antes + 'px, ligado ' + ligado + 'px, desligado ' + desligado +
                    'px; alças ' + alcas + '/' + widgets + ', sobraram ' + sobrou
        };
      },
      ir: () => ConcrestatsOpenModule('charts'),
    },
    {
      id: 'grafico-receita',
      grupo: G_VIS,
      titulo: 'Gráficos usam o fck do cadastro de receitas',
      olhar: 'Cadastre o fck de uma receita e veja o selo dela nos Gráficos dizer "cadastro".',
      auto: async () => {
        if (semAba('charts')) return pular('charts');
        ConcrestatsOpenModule('charts');
        await ate(() => document.querySelector('.graf-receita-wrap'), 8000);
        const wraps = [].slice.call(document.querySelectorAll('.graf-receita-wrap'));
        if (!wraps.length) return { ok: true, pulou: true, msg: 'nenhuma receita na planilha' };
        let cad = [];
        try {
          const r = await fetch('/api/receitas');
          if (r.ok) cad = await r.json();
        } catch (e) { cad = []; }
        const chave = x => String(x || '').trim().toUpperCase().replace(/\s+/g, ' ');
        const nomes = (Array.isArray(cad) ? cad : []).map(r => chave(r.nome));
        const comSelo = wraps.filter(w => w.querySelector('.graf-receita-fck')).length;
        const casados = wraps.filter(w =>
          nomes.indexOf(chave(w.querySelector('.graf-receita-nome') &&
                              w.querySelector('.graf-receita-nome').textContent)) >= 0);
        if (!casados.length) {
          return { ok: comSelo > 0, pulou: comSelo > 0,
                   msg: comSelo > 0
                     ? comSelo + ' receitas mostram o fck lido do nome; nenhuma está cadastrada ainda'
                     : 'nenhuma receita mostra o fck' };
        }
        const doCadastro = casados.filter(w => {
          const sel = w.querySelector('.graf-receita-fck');
          return sel && sel.textContent.indexOf('cadastro') >= 0;
        }).length;
        const ok = doCadastro === casados.length;
        return { ok, msg: ok ? doCadastro + ' de ' + casados.length + ' receitas cadastradas usando o fck oficial'
                             : 'só ' + doCadastro + ' de ' + casados.length + ' pegaram o fck do cadastro' };
      },
      ir: () => ConcrestatsOpenModule('charts'),
    },
    {
      id: 'analise-abre',
      grupo: G_VIS,
      titulo: 'Análise monta a tabela cruzada e os indicadores',
      olhar: 'Na Análise: os cartões do topo, a tabela cruzada e os insights têm que sair com números.',
      auto: async () => {
        if (semAba('analise')) return pular('analise');
        ConcrestatsOpenModule('analise');
        const sec = () => document.getElementById('module-analise');
        await ate(() => sec() && sec().querySelector('.ana-pivot-wrap table tbody tr'), 8000);
        const s = sec();
        if (!s) return { ok: false, msg: 'a Análise não abriu' };
        const linhas = s.querySelectorAll('.ana-pivot-wrap table tbody tr').length;
        const cartoes = s.querySelectorAll('.dash-card').length;
        const insights = s.querySelectorAll('.ins-card').length;
        const numeros = [].slice.call(s.querySelectorAll('.dash-card'))
          .filter(c => /\d/.test(c.textContent)).length;
        const ok = linhas > 0 && cartoes > 0 && numeros === cartoes;
        return {
          ok,
          msg: ok ? cartoes + ' indicadores, ' + linhas + ' linhas na tabela cruzada, ' +
                    insights + ' insights'
                  : 'tabela ' + linhas + ' linhas / ' + numeros + ' de ' + cartoes + ' cartões com número'
        };
      },
      ir: () => ConcrestatsOpenModule('analise'),
    },
    {
      id: 'analise-categoria',
      grupo: G_VIS,
      titulo: 'Análise não escolhe coluna de data como categoria',
      olhar: 'Abra a Análise numa planilha nova: a categoria tem que ser um nome (produto, cliente), nunca uma data.',
      auto: async () => {
        if (semAba('analise')) return pular('analise');
        const cab = ['DATA', 'Data 7', 'PRODUTO', 'M³'];
        const linhas = [];
        for (let i = 0; i < 40; i++) {
          linhas.push(['2026-0' + (1 + i % 6) + '-10', '2026-02-1' + (i % 2), 'FCK ' + (20 + 5 * (i % 4)), String(5 + (i % 7))]);
        }
        const m = window.ConcreAutoMap(cab, linhas);
        const ok = m.cat === 'PRODUTO';
        return { ok, msg: ok ? 'categoria: PRODUTO, com duas datas na planilha' : 'categoria: ' + m.cat };
      },
      ir: () => ConcrestatsOpenModule('analise'),
    },
    {
      id: 'dash-eixo',
      grupo: G_VIS,
      titulo: 'Dashboard: eixo com número redondo, sem "-0"',
      olhar: 'No Dashboard, os números do eixo dos gráficos têm que ser redondos (2.000, 4.000), nunca 5.785.',
      auto: async () => {
        const marcas = window.ConcreLab.marcasDoEixo(0, 7714).map(m => m.txt).join(' ');
        const pct = window.ConcreLab.marcasDoEixo(-17, 433).map(m => m.txt).join(' ');
        const ok = marcas === '0 2.000 4.000 6.000' && pct === '0 200 400';
        return { ok, msg: ok ? marcas + ' e ' + pct : marcas + ' | ' + pct };
      },
      ir: () => ConcrestatsOpenModule('dashboard'),
    },
    {
      id: 'dash-canvas-largura',
      grupo: G_VIS,
      titulo: 'Dashboard: gráfico desenhado no tamanho em que aparece',
      olhar: 'Com as animações do Windows desligadas, o texto dos gráficos do Dashboard não pode sair esticado.',
      auto: async () => {
        if (semAba('dashboard')) return pular('dashboard');
        ConcrestatsOpenModule('dashboard');
        await ate(() => $('dash-chart-prod') && $('dash-chart-prod').width > 0, 6000);
        await espera(150);
        const dpr = window.devicePixelRatio || 1;
        const tortos = ['dash-chart-prod', 'dash-vol-cli', 'dash-vol-prod'].map($).filter(c => c && c.clientWidth)
          .filter(c => Math.abs(c.width - c.clientWidth * dpr) > 2).map(c => c.id + ': ' + c.width + ' x ' + c.clientWidth);
        const ok = !tortos.length;
        return { ok, msg: ok ? 'largura do desenho = largura na tela' : tortos.join('; ') };
      },
      ir: () => ConcrestatsOpenModule('dashboard'),
    },
    {
      id: 'grade-largura-parada',
      grupo: G_PLAN,
      titulo: 'Colunas da planilha não mudam de largura ao rolar',
      olhar: 'Role uma planilha grande para baixo: os cabeçalhos têm que ficar parados, sem encolher nem esticar.',
      auto: async () => {
        ConcrestatsOpenModule('spreadsheet');
        await espera(300);
        const d = window.getConcrestatsData({ filtered: false });
        const regras = ($('larguras-colunas') || {}).textContent || '';
        const fixas = d.headers.filter((h, i) => regras.indexOf('th[data-col="' + i + '"]') >= 0).length;
        const ok = d.headers.length > 0 && fixas === d.headers.length;
        return { ok, msg: fixas + ' de ' + d.headers.length + ' colunas com largura fixa' };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'mes-solto',
      grupo: G_VIS,
      titulo: 'Mês solto fica fora do gráfico, com aviso',
      olhar: 'Painel, Dashboard e Análise: uma data digitada errada, longe do período, não vira mês no gráfico e o aviso diz qual ficou fora.',
      auto: async () => {
        const P = window.PainelModule;
        if (!P || !P._tirarMesesSoltos) return { ok: false, msg: 'sem o corte de meses' };
        const linhas = [];
        ['2026-01-10', '2026-02-10', '2026-03-10'].forEach(d => { for (let i = 0; i < 200; i++) linhas.push([d]); });
        linhas.push(['2026-12-10']);
        const r = P._tirarMesesSoltos(linhas, linhas, 0);
        const texto = r.fora ? P._textoForaDoEixo(r.fora) : '';
        const so = P._tirarMesesSoltos(linhas, [['2026-12-10']], 0);
        const ok = r.rows.length === 600 && /dez\/2026 \(1 linha\)/.test(texto) && !so.fora;
        return { ok, msg: ok ? texto : JSON.stringify({ n: r.rows.length, texto }) };
      },
      ir: () => ConcrestatsOpenModule('painel'),
    },
    {
      id: 'dash-ano-parcial',
      grupo: G_VIS,
      titulo: 'Dashboard: ano pela metade não vira queda',
      olhar: 'No Dashboard, Crescimento compara a média dos meses de cada ano, não a soma de um ano inteiro com um mês só.',
      auto: async () => {
        const linhas = ['2025-09-10', '2025-10-10', '2025-11-10', '2025-12-10', '2026-01-10'].map(d => [d, '100']);
        const g = window.ConcreLab.producaoPorPeriodo(linhas, 0, 1, 'ano');
        const ok = g.labels.join() === '2025,2026' && g.prod.join() === '400,100' && g.growth[1] === 0;
        return { ok, msg: ok ? '4 meses de 100 contra 1 mês de 100: crescimento 0%' : JSON.stringify(g) };
      },
      ir: () => ConcrestatsOpenModule('dashboard'),
    },
    {
      id: 'previa-falhas',
      grupo: G_PREVIA,
      titulo: 'Painel: falhas por receita',
      olhar: 'Painel › botão direito › + Falhas por receita: a pior é a que mais falha em proporção, não em número.',
      auto: async () => {
        if (semAba('painel')) return pular('painel');
        if (!emPrevia()) return pularPrevia();
        const H = ['PRODUTO', 'MPA 28', 'MPA 28.1'], rows = [];
        const add = (nome, ok, ruim) => {
          for (let i = 0; i < ok; i++) rows.push([nome, '32', '']);
          for (let i = 0; i < ruim; i++) rows.push([nome, '20', '21']);
        };
        add('A FCK 30', 90, 10);    // 10 falhas em 100
        add('B FCK 30', 3, 3);      // 3 em 6: a pior, mesmo com menos falhas
        add('C FCK 30', 0, 2);      // 2 ensaios: poucos para entrar
        const r = window.PainelModule._falhas({ headers: H, rows: rows }, { grupo: 'PRODUTO', minimo: 5 });
        const ordem = r.lista.map(g => g.k[0]).join('');
        const ok = ordem === 'BA' && r.lista[0].pct === 50 && r.poucos === 1;
        return { ok, msg: ok ? 'B (50%) na frente de A (10%), C fora por ter 2 ensaios' : JSON.stringify(r) };
      },
      ir: () => ConcrestatsOpenModule('painel'),
    },
    {
      id: 'previa-formula',
      grupo: G_PREVIA,
      titulo: 'Painel: criar a própria fórmula',
      olhar: 'Propriedades de uma tabela › + fórmula: clique em valor atual, valor anterior, A, B e veja a conta montada embaixo.',
      auto: async () => {
        if (semAba('painel')) return pular('painel');
        if (!emPrevia()) return pularPrevia();
        const F = window.PainelModule._formula;
        const conta = t => { const x = F.ler(t); return x.erro ? x.erro : F.calcular(x.arvore, { atual: 120, anterior: 100, total: 400, A: 50 }); };
        const cres = conta('(valor atual - valor anterior) / anterior * 100');
        const virgula = conta('A * 0,5 + raiz(16)');
        const erro = F.ler('(1 + 2').erro, estranho = F.ler('alert(1)').erro;
        const f = { headers: ['G', 'V'], rows: [['a', '10'], ['a', '30'], ['b', '60']] };
        const g = F.agrupar(f, f.rows, { grupo: 'G', valor: 'V', op: 'Fórmula', formula: 'atual / total * 100' });
        const pct = g.map(x => Math.round(x.v)).join(' ');
        const ok = cres === 20 && virgula === 29 && !!erro && !!estranho && pct === '60 40';
        return { ok, msg: ok ? 'crescimento 20, com vírgula 29, grupos ' + pct + ', código estranho recusado'
                             : JSON.stringify({ cres, virgula, erro, estranho, pct }) };
      },
      ir: () => ConcrestatsOpenModule('painel'),
    },
    {
      id: 'previa-barra-deitada',
      grupo: G_PREVIA,
      titulo: 'Painel: gráfico de linha e barra deitada',
      olhar: 'Propriedades de um gráfico › Tipo: Linha e Barra deitada têm que aparecer e desenhar.',
      auto: async () => {
        if (semAba('painel')) return pular('painel');
        if (!emPrevia()) return pularPrevia();
        const c = document.createElement('canvas');
        c.style.cssText = 'position:fixed;left:-2000px;width:500px;height:260px';
        document.body.appendChild(c);
        window.ConcreViz.drawBarsH(c, ['um nome bem comprido de cliente', 'b'], [10, 5], null, null, []);
        const px = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
        let tinta = 0;
        for (let i = 3; i < px.length; i += 4) if (px[i]) tinta++;
        c.remove();
        return { ok: tinta > 500, msg: tinta + ' pontos desenhados' };
      },
      ir: () => ConcrestatsOpenModule('painel'),
    },
    {
      id: 'analise-grafico',
      grupo: G_VIS,
      titulo: 'Os gráficos da Análise desenham sem fantasma',
      olhar: 'Nenhum gráfico pode ficar branco nem sobrar um pedaço de gráfico no canto.',
      auto: async () => {
        if (semAba('analise')) return pular('analise');
        ConcrestatsOpenModule('analise');
        await ate(() => document.querySelectorAll('#module-analise canvas').length > 0, 8000);
        const cvs = [].slice.call(document.querySelectorAll('#module-analise canvas'));
        if (!cvs.length) return { ok: false, msg: 'nenhum gráfico na Análise' };
        const vazios = [];
        cvs.forEach((cv, n) => {
          if (!cv.width || !cv.height) { vazios.push(n + 1); return; }
          try {
            const d = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data;
            let p = 0;
            for (let i = 0; i < d.length; i += 40) { if (d[i + 3] > 10) p++; }
            if (p < 50) vazios.push(n + 1);
          } catch (e) { vazios.push(n + 1); }
        });
        const ok = vazios.length === 0;
        return { ok, msg: ok ? cvs.length + ' gráficos desenhados' : 'vazios: ' + vazios.join(', ') };
      },
      ir: () => ConcrestatsOpenModule('analise'),
    },
    {
      id: 'relatorio-stats',
      grupo: G_VIS,
      titulo: 'As contas do relatório fecham com a planilha',
      olhar: 'No Relatório Técnico, confira se a média e o fck batem com os dados.',
      auto: async () => {
        const iMpa = state.headers.indexOf('MPA 28');
        const vals = state.data.map(l => parseFloat(String(l[iMpa]).replace(',', '.')))
                               .filter(v => !isNaN(v));
        const media = vals.reduce((a, b) => a + b, 0) / vals.length;
        const ok = vals.length > 30 && media > 10 && media < 100;
        return { ok, msg: ok ? vals.length + ' resultados, média ' + media.toFixed(1) + ' MPa'
                             : 'os números não fecham' };
      },
      ir: () => ConcrestatsOpenModule('relatorio'),
    },
    {
      id: 'relatorio-folha',
      grupo: G_VIS,
      titulo: 'O relatório sai como documento: folha, impressão e Excel',
      olhar: 'Relatório técnico: uma folha A4 deitada com cabeçalho, blocos de cliente/concreto/ensaio, '
           + 'resumo, tabela em 7 e 28 dias e assinatura. "Imprimir / PDF" abre a impressão; o visual '
           + '"Empresa" usa o logotipo da planilha (ou o de Campos fixos) e tira as cores dele.',
      auto: async () => {
        const M = window.RelatorioModule;
        // O relatório não é aba do topo (abre pelo botão "Relatório técnico"):
        // só não se aplica quando a edição tirou a tela inteira.
        if (!document.getElementById('module-relatorio')) return pular('relatorio');
        if (!M || typeof M._documento !== 'function') return { ok: false, msg: 'o módulo não expôs a folha' };
        // Um filtro esquecido na busca do relatório (de outra planilha) deixava
        // a folha com 0 linhas e o item falhava sem defeito nenhum.
        const busca = document.getElementById('rep-filter');
        if (busca && busca.value) { busca.value = ''; busca.dispatchEvent(new Event('input')); }
        ConcrestatsOpenModule('relatorio');
        await ate(() => document.querySelector('#rep-body .cert'), 8000);
        const folha = document.querySelector('#rep-body .cert');
        const linhas = folha ? folha.querySelectorAll('.cert-resultados:not(.cert-conformidade) .cert-tabela tbody tr').length : 0;
        const m = M._modelo();
        const esperadas = m ? Math.min(m.rows.length, 30) : -1;
        const temFolha = !!folha && linhas > 0 && linhas === esperadas;
        const html = await M._documento();
        const doc = /@page/.test(html) && /cert-tabela/.test(html) && !/<textarea/i.test(html) && /<\/html>$/.test(html.trim());
        // cores de um logotipo: laranja com uma faixa azul-petróleo
        const cv = document.createElement('canvas'); cv.width = 120; cv.height = 40;
        const cx = cv.getContext('2d');
        cx.fillStyle = '#fff'; cx.fillRect(0, 0, 120, 40);
        cx.fillStyle = '#e86a24'; cx.fillRect(0, 0, 70, 40);
        cx.fillStyle = '#125e70'; cx.fillRect(75, 0, 30, 40);
        const img = new Image();
        await new Promise(r => { img.onload = r; img.onerror = r; img.src = cv.toDataURL('image/png'); });
        const cores = M._coresDaImagem(img);
        const tema = M._temaDasCores(cores);
        const marca = !!cores && /^#e[0-9a-f]6[0-9a-f]2/i.test(cores.principal) && tema.forte.toLowerCase() === '#125e70';
        const x = M._aoa();
        const excel = !!x && x.fmt.cabecalho >= 0 && (x.fmt.dados[1] - x.fmt.dados[0] + 1) === (m ? m.rows.length : -1);
        const ok = temFolha && doc && marca && excel;
        return {
          ok,
          msg: ok ? `folha com ${linhas} linhas; documento de impressão e Excel com todas as ${m.rows.length}`
                  : JSON.stringify({ linhas, esperadas, doc, cores, forte: tema && tema.forte, excel }),
          itens: [
            { ok: temFolha, texto: 'a folha aparece com a tabela da planilha' },
            { ok: doc, texto: 'o documento impresso é página de verdade, sem os campos de edição' },
            { ok: marca, texto: 'visual Empresa: cores tiradas do logotipo, texto na cor que se lê' },
            { ok: excel, texto: 'o Excel leva todas as linhas, com a tabela no lugar certo' },
          ],
        };
      },
      ir: () => ConcrestatsOpenModule('relatorio'),
    },
    {
      id: 'relatorio-imprimir',
      grupo: G_OLHO,
      titulo: 'Imprimir / PDF do relatório no programa instalado',
      olhar: 'No .exe, Relatório técnico › Imprimir / PDF: tem de abrir a impressão do Windows com a folha '
           + 'deitada, e "Microsoft Print to PDF" tem de gerar o arquivo com número de página no rodapé.',
      manual: true,
      ir: () => ConcrestatsOpenModule('relatorio'),
    },
    /* -- grupo: novidades em prévia (lista do Naor, 12/10/2026) ------- */
    {
      id: 'previa-modo-planilha',
      grupo: G_PREVIA,
      titulo: 'Visualizar não deixa mudar dado; Editar deixa',
      olhar: 'A planilha abre em Visualizar: clicar numa célula só seleciona, Delete não apaga. Em Editar volta ao normal.',
      auto: async () => {
        if (!emPrevia()) return pularPrevia();
        const M = window.ConcrestatsModoPlanilha;
        const modoAntes = M.editando();
        ConcrestatsOpenModule('spreadsheet');
        const col = state.headers.indexOf('NF'), linha = 0;
        const antes = getDisplayRows()[linha][col];
        const tecla = k => document.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true }));
        M.definir(false);
        state.activeCell = { row: linha, col };
        tecla('Delete');
        const protegido = getDisplayRows()[linha][col] === antes;
        M.definir(true);
        state.activeCell = { row: linha, col };
        tecla('Delete');
        const apagou = getDisplayRows()[linha][col] === '';
        undo();
        const voltou = getDisplayRows()[linha][col] === antes;
        M.definir(modoAntes);
        const ok = protegido && apagou && voltou;
        return { ok, msg: ok ? 'Delete barrado em Visualizar e liberado em Editar' : JSON.stringify({ protegido, apagou, voltou }) };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'previa-barra-icones',
      grupo: G_PREVIA,
      titulo: 'Barra da planilha só com ícones, sem nada escondido',
      olhar: 'Planilhas: os botões viram ícones e a dica aparece na hora ao passar o mouse. Estreite a janela: a barra quebra em duas linhas, sem rolar, e a grade encolhe junto.',
      auto: async () => {
        if (!emPrevia()) return pularPrevia();
        ConcrestatsOpenModule('spreadsheet');
        const barra = document.querySelector('.barra-planilha');
        const visivel = el => getComputedStyle(el).display !== 'none';
        const botoes = [...barra.querySelectorAll('button')];
        const nome = b => b.id || b.dataset.modo || b.dataset.fmt || '?';
        const semRotulo = botoes.filter(b => !b.getAttribute('aria-label') || !b.title).map(nome);
        const comTexto = botoes.filter(b => [...b.querySelectorAll('.tb-nome')].some(visivel)).map(nome);
        const semIcone = botoes.filter(b => ![...b.querySelectorAll('svg')].some(visivel)).map(nome);
        const icone = id => ([...$(id).querySelectorAll('svg')].find(visivel) || {}).innerHTML;
        const linhasDiferentes = !!icone('btn-add-row') && icone('btn-add-row') !== icone('btn-del-row');
        const semRolar = barra.scrollWidth <= barra.clientWidth + 1;
        const grade = document.querySelector('#app > .grid-container').getBoundingClientRect();
        const gradeCabe = grade.height > 0 && grade.bottom <= window.innerHeight + 1;
        // o pontinho de "não salvo" não pode sumir junto com o nome
        const salvar = $('btn-save-file');
        const jaSujo = salvar.classList.contains('dirty');
        markDirty();
        const ponto = getComputedStyle(salvar, '::after').content.includes('●');
        if (!jaSujo) markSaved();
        const subs = [
          { ok: !semRotulo.length, texto: 'todo botão tem title e aria-label' + (semRotulo.length ? ': faltam ' + semRotulo.join(', ') : '') },
          { ok: !comTexto.length, texto: 'nenhum nome escrito no botão' + (comTexto.length ? ': sobrou ' + comTexto.join(', ') : '') },
          { ok: !semIcone.length, texto: 'todo botão tem ícone' + (semIcone.length ? ': faltam ' + semIcone.join(', ') : '') },
          { ok: linhasDiferentes, texto: 'os dois botões de linha têm ícones diferentes' },
          { ok: semRolar, texto: 'a barra não rola de lado' },
          { ok: gradeCabe, texto: 'a grade termina dentro da janela' },
          { ok: ponto, texto: 'o indicador de não salvo aparece no Salvar' },
        ];
        const ok = subs.every(s => s.ok);
        return { ok, msg: ok ? botoes.length + ' botões conferidos' : 'veja o que faltou', subs };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'previa-filtros-na-tela',
      grupo: G_PREVIA,
      titulo: 'Filtros abrem na própria aba, e a tela recalcula sem sair dali',
      olhar: 'Em cada aba clique em Filtros: o painel abre ali mesmo. Ao aplicar ele fecha, os números acompanham e a aba continua a mesma.',
      auto: async () => {
        if (!emPrevia()) return pularPrevia();
        const painel = $('filter-panel');
        const telas = [['inicio', 'module-inicio'], ['receitas', 'module-receitas'],
          ['charts', 'module-graficos'], ['analise', 'module-analise'], ['painel', 'module-painel'],
          ['dashboard', 'module-dashboard'], ['previsao', 'module-previsao'],
          ['agenda', 'module-agenda'], ['relatorio', 'module-relatorio']].filter(([, id]) => $(id));
        const subs = [];
        for (const [mod, id] of telas) {
          ConcrestatsOpenModule(mod);
          const tela = $(id);
          const botao = tela.querySelector('.gfilter-abrir');
          if (!botao) { subs.push({ ok: false, texto: mod + ': sem o botão de filtros' }); continue; }
          botao.click();
          const abriu = tela.contains(painel) && painel.style.display !== 'none';
          const regra = addFilterRule('CLIENTE');
          regra.querySelector('.f-op').value = '==';
          regra.querySelector('.f-val').value = 'Alfa Engenharia';
          let avisou = false;
          const ouvir = () => { avisou = true; };
          window.addEventListener('concrestats:datachanged', ouvir);
          $('btn-apply-filters').click();
          window.removeEventListener('concrestats:datachanged', ouvir);
          const n = state.filteredData.length;
          const filtrou = state.filterActive && n > 0 && n < state.data.length;
          const ficou = $('app').style.display === 'none';
          const voltou = $('app').contains(painel) && painel.style.display === 'none';
          // a Análise lia a planilha inteira: confere a conta, não só o aviso
          const conta = mod !== 'analise' ||
            await ate(() => $('ana-info').textContent.includes('/' + n + ' registros'));
          const ok = abriu && filtrou && avisou && ficou && voltou && conta;
          subs.push({ ok, texto: mod + (ok ? '' : ': ' + JSON.stringify({ abriu, filtrou, avisou, ficou, voltou, conta })) });
          state.filters = []; recomputeFilters(); syncFilterPanel(); notifyDataChanged('filter');
        }
        ConcrestatsOpenModule('spreadsheet');
        const ok = subs.length > 0 && subs.every(s => s.ok);
        return { ok, msg: ok ? subs.length + ' telas conferidas' : 'veja as telas abaixo', subs };
      },
      ir: () => ConcrestatsOpenModule('analise'),
    },
    {
      id: 'previa-agenda',
      grupo: G_PREVIA,
      titulo: 'Agenda de rompimento: moldagem + idade, dia a dia',
      olhar: 'Agenda: escolha a coluna de data e a de CP, clique num dia e confira a lista de 7 e 28 dias.',
      auto: async () => {
        if (!emPrevia()) return pularPrevia();
        const A = window.AgendaModule;
        const d = n => Date.UTC(2026, 0, n) / 86400000;
        const datas = A._diaDe('2026-01-30') === d(30) && A._diaDe('30/01/2026') === d(30) &&
                      A._diaDe(46052) === d(30) && A._diaDe('30/01/26') === d(30) && A._diaDe('') === null;
        // CP-101 foi moldado em 30/01/2026: rompe aos 28 dias em 27/02/2026
        await A.carregar();
        const r = A.resumo(Date.UTC(2026, 1, 27) / 86400000);
        const de28 = r && r.porIdade.find(x => x.idade === 28);
        const conta = !!de28 && de28.total >= 1 && de28.feitos === de28.total;
        A.irPara(Date.UTC(2026, 1, 27) / 86400000);
        ConcrestatsOpenModule('agenda');
        // espera o CP na lista, nao so' o calendario: a tela pode ja' estar
        // aberta de um teste anterior e ainda nao ter redesenhado
        await ate(() => /CP-101/.test((document.querySelector('#ag-corpo .ag-dir') || {}).textContent || ''), 4000);
        const tela = !!document.querySelector('#ag-corpo .ag-dia.escolhido') &&
                     /CP-101/.test((document.querySelector('#ag-corpo .ag-dir') || {}).textContent || '');
        const ok = datas && conta && tela;
        return { ok, msg: ok ? 'datas lidas nos 4 formatos; 27/02 lista o CP-101 já rompido' : JSON.stringify({ datas, conta, tela, de28 }),
          itens: [
            { ok: datas, texto: 'data ISO, dd/mm/aaaa, dd/mm/aa e número do Excel dão o mesmo dia' },
            { ok: conta, texto: 'o dia certo tem o CP de 28 dias, e com o resultado reconhecido' },
            { ok: tela, texto: 'o calendário marca o dia e a lista mostra o CP' },
          ] };
      },
      ir: () => ConcrestatsOpenModule('agenda'),
    },
    {
      id: 'relatorio-por-paginas',
      grupo: G_PREVIA,
      titulo: 'Relatório: a tela mostra todos os exemplares, página por página',
      olhar: 'Relatório sem filtro: ande pelas páginas até a última.',
      auto: async () => {
        ConcrestatsOpenModule('relatorio');
        await ate(() => document.querySelector('#rep-paginas'), 4000);
        const caixa = () => document.querySelector('#rep-paginas');
        if (!caixa()) return { ok: false, msg: 'sem o seletor de páginas' };
        const linhas = () => document.querySelectorAll('#rep-body .cert-resultados:not(.cert-conformidade) tbody tr').length;
        const total = Number((caixa().querySelector('small').textContent.match(/de ([\d.]+) -/) || [0, '0'])[1].replace(/\./g, ''));
        const primeira = linhas();
        caixa().querySelector('[data-pag="fim"]').click();
        await ate(() => caixa() && caixa().querySelector('[data-pag="prox"]').disabled, 3000);
        const ultima = linhas();
        const esperada = total % 30 || 30;
        caixa().querySelector('[data-pag="ini"]').click();
        await ate(() => caixa() && caixa().querySelector('[data-pag="ant"]').disabled, 3000);
        const ok = primeira === 30 && ultima === esperada;
        return { ok, msg: ok ? total + ' exemplares, 30 por página, nenhum cortado' : JSON.stringify({ total, primeira, ultima, esperada }) };
      },
      ir: () => ConcrestatsOpenModule('relatorio'),
    },
    {
      id: 'receitas-status-versao',
      grupo: G_PREVIA,
      titulo: 'Receitas: ativa, teste e descontinuada valem por versão',
      olhar: 'Receitas: troque de versão e confira que cada uma guarda o próprio status.',
      auto: async () => {
        const R = window.ConcrestatsReceitas;
        const l = R._migrarStatus([{ status: 'teste', versoes: [{ id: 'a' }, { id: 'b', status: 'ativa' }] }]);
        const ok = l[0].versoes[0].status === 'teste' && l[0].versoes[1].status === 'ativa';
        return { ok, msg: ok ? 'versão sem status herda o do produto; a que tem o seu mantém' : JSON.stringify(l[0].versoes) };
      },
      ir: () => ConcrestatsOpenModule('receitas'),
    },
    {
      id: 'previa-receitas-nomes',
      grupo: G_PREVIA,
      titulo: 'Receitas: o campo Nome sugere os nomes já usados',
      olhar: 'Receitas: clique no Nome de um material e veja os já usados primeiro.',
      auto: async () => {
        if (!emPrevia()) return pularPrevia();
        const R = window.ConcrestatsReceitas;
        const props = n => ({ versoes: [{ propriedades: n.map(nome => ({ nome })) }] });
        const lista = [props(['Granilha', 'Brita 1']), props(['GRANILHA', 'Areia'])];
        const tudo = R._sugerir(lista, 'Agregado graúdo', '');
        const achou = R._sugerir(lista, '', 'gran');
        const ok = tudo[0].nome === 'Granilha' && tudo[0].vezes === 2 &&
                   tudo.filter(o => /brita 1/i.test(o.nome)).length === 1 &&
                   achou.length === 1 && R._sugerir(lista, '', 'silica').length === 0;
        return { ok, msg: ok ? 'mais usado primeiro, sem repetir, ignorando caixa' : JSON.stringify({ tudo, achou }) };
      },
      ir: () => ConcrestatsOpenModule('receitas'),
    },
    {
      id: 'previa-agenda-idade',
      grupo: G_PREVIA,
      titulo: 'Agenda: idade criada por engano pode ser editada e apagada',
      olhar: 'Agenda: botão direito numa idade abre Editar idade e Apagar idade.',
      auto: async () => {
        if (!emPrevia()) return pularPrevia();
        const A = window.AgendaModule;
        await A.carregar();
        const antes = A._estado();
        A._criarIdade(90);
        const criou = A._estado().idades.includes(90);
        A._editarIdade(90, 91);
        const e1 = A._estado();
        const editou = e1.idades.includes(91) && !e1.idades.includes(90) && e1.extras.includes(91);
        A._apagarIdade(91);
        const e2 = A._estado();
        const apagou = !e2.idades.includes(91) && !e2.extras.includes(91);
        A._apagarIdade(14);
        const retirou = A._estado().retiradas.includes(14);
        A._criarIdade(14);
        const voltou = !A._estado().retiradas.includes(14);
        A._restaurarIdades(antes);
        const ok = criou && editou && apagou && retirou && voltou;
        return { ok, msg: ok ? 'cria, edita, apaga, retira padrão e traz de volta'
                             : JSON.stringify({ criou, editou, apagou, retirou, voltou }) };
      },
      ir: () => ConcrestatsOpenModule('agenda'),
    },
    {
      id: 'previa-inicio',
      grupo: G_PREVIA,
      titulo: 'Tela de Início mostra o resumo do dia',
      olhar: 'Início: rompimentos de hoje, atrasados, reprovações recentes, calibração da prensa e últimos arquivos.',
      auto: async () => {
        if (!emPrevia()) return pularPrevia();
        ConcrestatsOpenModule('inicio');
        await ate(() => document.querySelectorAll('#ini-corpo .ini-cartao').length >= 4, 4000);
        const cartoes = document.querySelectorAll('#ini-corpo .ini-cartao').length;
        const rep = window.InicioModule._reprovacoes();
        // na demonstração, 1 em cada 3 CPs de janeiro e 1 por mês depois ficam abaixo do fck
        const reprova = !!rep && rep.comFck > 0 && rep.lista.every(x => x.ex < x.fck);
        const ok = cartoes >= 4 && reprova;
        return { ok, msg: ok ? cartoes + ' cartões; reprovações conferidas contra o fck de cada linha' : JSON.stringify({ cartoes, rep }) };
      },
      ir: () => ConcrestatsOpenModule('inicio'),
    },
    {
      id: 'previa-configuracoes',
      grupo: G_PREVIA,
      titulo: 'Configurações vão para uma pasta e voltam iguais',
      olhar: 'Engrenagem › Exportar para uma pasta: um arquivo por assunto e o logotipo como imagem. Importar no outro computador.',
      auto: async () => {
        if (!emPrevia()) return pularPrevia();
        const C = window.ConcreAparencia;
        const logo = 'data:image/png;base64,iVBORw0KGgo=';
        const p = {
          ensaio_fixos: { empresa: 'Laboratório Exemplo', prensa: 'Prensa 100 t', identidade: 'empresa', cor: '#125e70', logo },
          ensaio_por_cliente: { ALFA: { nome: 'Alfa', cnpj: '00.000.000/0001-00' } },
          colunas_por_formato: { 'CP|DATA': { mpa28: 5 } }, agenda: { idades: [7, 28] },
          recentes: [{ path: 'C:/x.xlsx' }],
        };
        const arqs = C._montarArquivos(p);
        const ler = n => JSON.parse(arqs[n]);
        const separado = !!arqs['empresa.json'] && !('logo' in ler('empresa.json').chaves.ensaio_fixos) &&
                         arqs['relatorio-logotipo.png'] === logo && !!arqs['LEIA-ME.txt'] &&
                         !JSON.stringify(arqs).includes('C:/x.xlsx');
        const achados = {};
        Object.keys(arqs).forEach(n => { achados[n] = /\.json$/.test(n) ? ler(n) : arqs[n]; });
        const volta = C._montarImportacao(achados, new Set(Object.keys(arqs)), {});
        const igual = JSON.stringify(volta.ensaio_fixos) === JSON.stringify(p.ensaio_fixos) &&
                      JSON.stringify(volta.ensaio_por_cliente) === JSON.stringify(p.ensaio_por_cliente) &&
                      JSON.stringify(volta.colunas_por_formato) === JSON.stringify(p.colunas_por_formato) && !volta.recentes;
        const ok = separado && igual;
        return { ok, msg: ok ? Object.keys(arqs).length + ' arquivos; a ida e a volta dão o mesmo' : JSON.stringify({ separado, igual, volta }) };
      },
    },
    {
      id: 'previa-relatorio-cliente',
      grupo: G_PREVIA,
      titulo: 'Relatório: dados de cada cliente e calibração da prensa',
      olhar: 'Relatório técnico de um cliente só: "Guardar dados deste cliente" e, em Campos fixos, a validade da calibração.',
      auto: async () => {
        if (!emPrevia()) return pularPrevia();
        const M = window.RelatorioModule;
        const busca = document.getElementById('rep-filter');
        const chaveFx = 'concrestats_ensaio_fixos', chaveCl = 'concrestats_ensaio_por_cliente';
        const guardado = [localStorage.getItem(chaveFx), localStorage.getItem(chaveCl)];
        try {
          const fx = JSON.parse(guardado[0] || '{}');
          localStorage.setItem(chaveFx, JSON.stringify(Object.assign({}, fx,
            { calibracao_certificado: 'T-1', calibracao_validade: '2020-01-31', cnpj: 'do campo fixo' })));
          localStorage.setItem(chaveCl, JSON.stringify({ ALFAENGENHARIA: { nome: 'Alfa Engenharia', cnpj: '11.111.111/0001-11' } }));
          if (busca) { busca.value = 'Alfa Engenharia'; busca.dispatchEvent(new Event('input')); }
          const m = M._modelo();
          const cliente = !!m && m.campos.cnpj === '11.111.111/0001-11';
          const calib = !!m && /T-1/.test(m.campos.calibracao) && /31\/01\/2020/.test(m.campos.calibracao);
          const cal = window.ConcreCalibracao();
          const vencida = !!cal && cal.dias < 0;
          if (busca) { busca.value = 'Beta Construtora'; busca.dispatchEvent(new Event('input')); }
          const m2 = M._modelo();
          const outro = !!m2 && m2.campos.cnpj === 'do campo fixo';
          const ok = cliente && calib && vencida && outro;
          return { ok, msg: ok ? 'cada cliente com o seu CNPJ; calibração vencida reconhecida' : JSON.stringify({ cliente, calib, vencida, outro }) };
        } finally {
          if (guardado[0] == null) localStorage.removeItem(chaveFx); else localStorage.setItem(chaveFx, guardado[0]);
          if (guardado[1] == null) localStorage.removeItem(chaveCl); else localStorage.setItem(chaveCl, guardado[1]);
          if (busca) { busca.value = ''; busca.dispatchEvent(new Event('input')); }
        }
      },
      ir: () => ConcrestatsOpenModule('relatorio'),
    },
    {
      id: 'previa-comparar',
      grupo: G_PREVIA,
      titulo: 'Painel: comparar dois meses',
      olhar: 'Painel › botão direito › + Comparar meses: média, desvio e % abaixo do fck de um mês contra o outro.',
      auto: async () => {
        if (semAba('painel')) return pular('painel');
        if (!emPrevia()) return pularPrevia();
        const r = window.PainelModule._compararMeses({ colData: 'DATA', grupo: 'CLIENTE' });
        // A demonstração vai de janeiro a junho de 2026; o automático pega maio
        // x junho. Junho tem os 9 de sempre mais os dois casos de borda: o
        // CP-999 (31,0 com fck 25, passa) e o CP-998 ("n/d", sem resultado).
        const meses = !!r && r.A === '2026-05' && r.B === '2026-06';
        const total = r && r.total;
        const conta = !!total && total.a.n === 9 && total.a.rompidos === 9 && total.a.abaixo === 1 &&
                      total.b.n === 11 && total.b.rompidos === 10 && total.b.abaixo === 1;
        const ok = meses && conta;
        return { ok, msg: ok ? 'maio x junho: 9 e 11 ensaios (o "n/d" fica fora da média), 1 abaixo do fck em cada'
                             : JSON.stringify({ A: r && r.A, B: r && r.B, total }) };
      },
      ir: () => ConcrestatsOpenModule('painel'),
    },
    {
      id: 'previa-grafico-linha-receita',
      grupo: G_PREVIA,
      titulo: 'Gráficos: linha de referência com a resistência de cada receita',
      olhar: 'Gráficos > + Gráfico > De onde vem o valor: Receita cadastrada. Salve num template e aplique em "⬇ Todas": '
           + 'cada container com a linha no seu fck; receita sem o dado fica sem linha, e o diálogo avisa.',
      auto: async () => {
        if (semAba('charts')) return pular('charts');
        if (!emPrevia()) return pularPrevia();
        const G = window.GraficosModule;
        // O número salvo no item não pode valer com a fonte na receita: num
        // template ele daria a mesma linha em todo container.
        const cfg = { linhaHFonte: 'receita', linhaH: 99 };
        const cadastroReal = G._cadastro([
          { nome: 'Teste A', versaoAtiva: 'v', versoes: [{ id: 'v', nome: 'v', fck: 32 }] },
          { nome: 'Teste B', versaoAtiva: 'v', versoes: [{ id: 'v', nome: 'v', propriedades: [{ nome: 'fck', consumo: 40 }] }] },
          { nome: 'Teste FCK 35', versaoAtiva: 'v', versoes: [{ id: 'v', nome: 'v' }] },
        ]);
        let porReceita, semDado, avisa, digitado;
        try {
          porReceita = G._valorDaLinha(cfg, 'Teste A') === 32 && G._valorDaLinha(cfg, 'Teste B') === 40 &&
                       G._valorDaLinha(cfg, 'Teste FCK 35') === 35;
          semDado = isNaN(G._valorDaLinha(cfg, 'Sem resistencia'));
          avisa = !G._avisoDaLinha('Sem resistencia').ok && G._avisoDaLinha('Teste A').ok;
          digitado = G._valorDaLinha({ linhaH: 28 }, 'Teste A') === 28 && isNaN(G._valorDaLinha({}, 'Teste A'));
        } finally { G._cadastro(cadastroReal); }

        // O desenho de verdade. Os pontos da demonstração ficam longe do fck:
        // sem o eixo alcançar a linha, ela não sai e a tinta fica em zero.
        ConcrestatsOpenModule('charts');
        await ate(() => document.querySelector('.graf-receita-nome'), 8000);
        const nome = (document.querySelector('.graf-receita-nome') || {}).textContent || '';
        const el = G._grafico(nome, { colunaY: 'MPA 28', tipoGrafico: 'Linha', linhaHFonte: 'receita',
                                      linhaHCor: '#ff00ff', linhaHLabel: 'f_ck' });
        let tinta = 0;
        if (el) {
          await ate(() => el.querySelector('canvas'), 3000);
          try {
            const c = el.querySelector('canvas');
            const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
            for (let i = 0; i < d.length; i += 4) {
              if (d[i] > 180 && d[i + 1] < 90 && d[i + 2] > 180 && d[i + 3] > 100) tinta++;
            }
          } catch (e) { tinta = 0; }
          el.remove();
        }

        // O diálogo mora na mesma caixa do painel do Modo Teste: guarda e devolve.
        const conteudo = $('modal-content'), caixa = $('modal-box'), fundo = $('modal-overlay');
        const guardados = Array.from(conteudo.childNodes);
        const classeCaixa = caixa.className, displayFundo = fundo.style.display;
        let dialogo = false;
        try {
          const b = document.querySelector('.graf-btn-add-chart');
          if (b) b.click();
          const sel = $('gc-linhaHFonte'), campo = $('gc-linhaH'), nota = $('gc-linhaH-nota');
          if (sel && campo && nota) {
            const troca = v => { sel.value = v; sel.dispatchEvent(new Event('change')); };
            troca('receita');
            const naReceita = campo.disabled && !nota.hidden && !!nota.textContent;
            troca('fixo');
            dialogo = naReceita && !campo.disabled && nota.hidden && campo.type === 'text';
          }
        } finally {
          conteudo.replaceChildren(...guardados);
          caixa.className = classeCaixa;
          fundo.style.display = displayFundo;
        }

        const ok = porReceita && semDado && avisa && digitado && tinta > 30 && dialogo;
        return {
          ok,
          msg: ok ? 'cada receita com a sua linha, desenhada mesmo com os pontos longe dela'
                  : JSON.stringify({ porReceita, semDado, avisa, digitado, tinta, dialogo }),
          subs: [
            { ok: porReceita, texto: 'cadastro primeiro, depois o nome; o número salvo no item não vale' },
            { ok: semDado && avisa, texto: 'receita sem resistência: sem linha, e com aviso' },
            { ok: digitado, texto: 'valor digitado continua como antes' },
            { ok: tinta > 30, texto: 'a linha sai no gráfico (' + tinta + ' pontos da cor dela)' },
            { ok: dialogo, texto: 'o diálogo troca entre digitado e receita' },
          ],
        };
      },
      ir: () => ConcrestatsOpenModule('charts'),
    },
    {
      id: 'previa-grafico-rotulo',
      grupo: G_PREVIA,
      titulo: 'Gráficos: rótulo da linha faz conta e escreve f_ck e m^3',
      olhar: 'Rótulo "f_ck = {FCK*0,9} kg/m^3": o "ck" sai pequeno embaixo, o "3" pequeno em cima, e a conta vira número. '
           + 'Com "{FCK*}" o texto aparece como foi escrito e o gráfico continua de pé.',
      auto: async () => {
        if (semAba('charts')) return pular('charts');
        if (!emPrevia()) return pularPrevia();
        const G = window.GraficosModule;
        const vars = { FCK: 25, Y: 30 };
        const igual = (rotulo, esperado) => JSON.stringify(G._rotulo(rotulo, vars).map(p => [p.t, p.nivel])) ===
                                            JSON.stringify(esperado);
        const normal = igual('fck', [['fck (30)', 0]]) && igual('', [['30', 0]]) &&
                       igual('FCK mín', [['FCK mín (30)', 0]]) && igual('a_ b ^ c', [['a_ b ^ c (30)', 0]]);
        const conta = igual('{FCK}', [['25', 0]]) && igual('{fck*0,9} MPa', [['22,5 MPa', 0]]) &&
                      igual('{Y}', [['30', 0]]) && igual('{(FCK+5)/2}', [['15', 0]]) &&
                      igual('{-FCK+2^3}', [['-17', 0]]);
        const invalida = igual('{FCK*}', [['{FCK*} (30)', 0]]) && igual('{1/0}', [['{1/0} (30)', 0]]) &&
                         igual('{alert(1)}', [['{alert(1)} (30)', 0]]) && igual('{}', [['{} (30)', 0]]) &&
                         igual('{constructor}', [['{constructor} (30)', 0]]) &&
                         JSON.stringify(G._rotulo('{FCK}', { FCK: NaN, Y: 30 })) === JSON.stringify([{ t: '{FCK} (30)', nivel: 0 }]);
        const notacao = igual('f_ck', [['f', 0], ['ck', -1], [' (30)', 0]]) &&
                        igual('kg/m^3', [['kg/m', 0], ['3', 1], [' (30)', 0]]) &&
                        igual('f_{ck,est}', [['f', 0], ['ck,est', -1], [' (30)', 0]]) &&
                        igual('m^{-1}', [['m', 0], ['-1', 1], [' (30)', 0]]) &&
                        igual('f_ck = {FCK} MPa', [['f', 0], ['ck', -1], [' = 25 MPa', 0]]);

        // O desenho: letra menor, para baixo e para cima, sem encavalar.
        const chamadas = [];
        G._desenharRotulo({
          font: '', fillText(t, x, y) { chamadas.push({ t, x, y, font: this.font }); },
          measureText(t) { return { width: t.length * 6 }; },
        }, G._rotulo('f_ck m^3', vars), 10, 50);
        const [base, indice, meio, expoente] = chamadas;
        const desenho = chamadas.length === 5 && /^10px/.test(base.font) && /^8px/.test(indice.font) &&
                        indice.y > base.y && expoente.y < base.y && meio.y === base.y &&
                        indice.x === 16 && meio.x === 16 + 12;

        const ok = normal && conta && invalida && notacao && desenho;
        return {
          ok,
          msg: ok ? 'texto normal igual, conta resolvida, o inválido vira texto, índice e expoente deslocados'
                  : JSON.stringify({ normal, conta, invalida, notacao, desenho, chamadas }),
          subs: [
            { ok: normal, texto: 'texto normal continua igual, com o valor entre parênteses' },
            { ok: conta, texto: '{FCK}, {FCK*0,9} e {Y} viram número, com vírgula' },
            { ok: invalida, texto: 'expressão inválida fica como texto, e nada dela roda' },
            { ok: notacao, texto: 'f_ck, f_{ck,est}, m^3 e m^{-1} viram índice e expoente' },
            { ok: desenho, texto: 'índice e expoente saem menores e deslocados' },
          ],
        };
      },
      ir: () => ConcrestatsOpenModule('charts'),
    },
    {
      id: 'modulos-abrem',
      grupo: G_VIS,
      titulo: 'Todas as abas do topo abrem sem travar',
      olhar: 'Passe por Planilhas, Receitas, Gráficos, Análise, Painel, Dashboard e Relatório.',
      auto: async () => {
        const mods = ['receitas', 'charts', 'analise', 'painel', 'dashboard', 'relatorio']
          .concat(emPrevia() ? ['inicio', 'agenda'] : []).concat('spreadsheet');
        const falhas = [];
        const antes = window.onerror;
        let erro = null;
        window.onerror = m => { erro = String(m); };
        for (let i = 0; i < mods.length; i++) {
          try {
            ConcrestatsOpenModule(mods[i]);
            await espera(320);
            if (erro) { falhas.push(mods[i] + ' (' + erro + ')'); erro = null; }
          } catch (e) { falhas.push(mods[i] + ' (' + e.message + ')'); }
        }
        window.onerror = antes;
        ConcrestatsOpenModule('spreadsheet');
        return { ok: !falhas.length, msg: falhas.length ? 'problema em: ' + falhas.join(', ')
                                                        : mods.length + ' abas abriram' };
      },
      ir: () => ConcrestatsOpenModule('spreadsheet'),
    },
    {
      id: 'prefs',
      grupo: G_VIS,
      titulo: 'O que você configura continua salvo',
      olhar: 'Salve um template de gráfico, feche o app e abra de novo: tem que continuar lá.',
      auto: async () => {
        const marca = 'teste-' + Date.now();
        await fetch('/api/prefs', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ __teste_modo_teste: marca })
        });
        const p = await window.prefsGet(true);
        const ok = !!p && p.__teste_modo_teste === marca;
        fetch('/api/prefs', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ __teste_modo_teste: null })
        });
        return { ok, msg: ok ? 'gravou e leu de volta do disco' : 'não voltou igual' };
      },
      ir: () => ConcrestatsOpenModule('charts'),
    },

    /* -- grupo: precisa do olho ------------------------ */
    {
      id: 'largura',
      grupo: G_OLHO,
      titulo: 'Gráfico passa de 1000px de largura',
      olhar: 'Em Gráficos, aumente a largura de um gráfico para 2000: deve rolar, não cortar.',
      manual: true,
      ir: () => ConcrestatsOpenModule('charts'),
    },
    {
      id: 'png',
      grupo: G_OLHO,
      titulo: 'Exportar imagem pergunta onde salvar',
      olhar: 'Na Análise, botão Imagem: deve abrir a janela do Windows perguntando a pasta.',
      manual: true,
      ir: () => ConcrestatsOpenModule('analise'),
    },
    {
      id: 'excel',
      grupo: G_OLHO,
      titulo: 'Exportar Excel no computador da empresa',
      olhar: 'Só dá para confirmar no computador do cliente - é lá que falhava.',
      manual: true,
      ir: () => ConcrestatsOpenModule('relatorio'),
    },
  ];

  /* -- tela ------------------------------------------- */
  let resultados = {};
  let versaoApp = '';
  let filtroAtual = 'tudo';

  function abrir() {
    fetch('/static/versao.json').then(r => r.ok ? r.json() : null).then(v => {
      versaoApp = (v && v.versao) || '';
      desenhar((v && v.novidades) || [], versaoApp);
    }).catch(() => desenhar([], ''));
  }

  function icone(it) {
    const r = resultados[it.id];
    if (it.manual) return { txt: '👁', cls: 'olho' };
    if (!r) return { txt: '', cls: 'vazio' };
    if (r.pulou) return { txt: '–', cls: 'pulou' };
    return r.ok ? { txt: '✓', cls: 'ok' } : { txt: '✕', cls: 'falhou' };
  }

  function linhaItem(it) {
    const ic = icone(it);
    const r = resultados[it.id];
    const subs = (r && r.subs) ? r.subs.map(s =>
      '<div class="tst-sub ' + (s.ok ? 'ok' : 'falhou') + '">' +
      '<span>' + (s.ok ? '✓' : '✕') + '</span><span>' + esc(s.texto) + '</span></div>').join('') : '';
    return '' +
      '<div class="tst-item ' + (r && !r.ok && !r.pulou ? 'e-falha' : '') + '" data-id="' + it.id + '" data-tipo="' +
        (it.manual ? 'manual' : (r ? (r.pulou ? 'pulou' : (r.ok ? 'ok' : 'falha')) : 'pendente')) + '">' +
        '<div class="tst-status ' + ic.cls + '" id="tst-st-' + it.id + '">' + ic.txt + '</div>' +
        '<div class="tst-txt">' +
          '<b>' + esc(it.titulo) + '</b>' +
          '<span class="tst-como">' + esc(it.olhar) + '</span>' +
          '<span class="tst-msg" id="tst-msg-' + it.id + '">' + esc((r && r.msg) || '') + '</span>' +
          '<div class="tst-subs" id="tst-subs-' + it.id + '">' + subs + '</div>' +
        '</div>' +
        '<button class="tst-ir" data-ir="' + it.id + '">Levar até lá</button>' +
      '</div>';
  }

  function desenhar(novidades, versao) {
    const grupos = [];
    ITENS.forEach(it => {
      let g = grupos.find(x => x.nome === it.grupo);
      if (!g) { g = { nome: it.grupo, itens: [] }; grupos.push(g); }
      g.itens.push(it);
    });

    const cab = novidades.length
      ? '<details class="tst-novidades"><summary>O que mudou nesta versão' +
        (versao ? ' (' + esc(versao) + ')' : '') + '</summary><ul>' +
        novidades.map(n => '<li>' + esc(n) + '</li>').join('') + '</ul></details>'
      : '';

    const auto = ITENS.filter(i => !i.manual).length;
    const olho = ITENS.length - auto;

    const lista = grupos.map(g =>
      '<div class="tst-grupo"><h4>' + esc(g.nome) +
      '<span>' + g.itens.length + '</span></h4>' +
      g.itens.map(linhaItem).join('') + '</div>').join('');

    const html = '' +
      cab +
      '<div class="tst-topo">' +
        '<button class="primary-btn" id="tst-rodar">▶ Rodar as ' + auto + ' verificações</button>' +
        '<button class="secondary-btn" id="tst-demo">Planilha de exemplo</button>' +
        '<button class="secondary-btn" id="tst-limpar">Remover demonstração</button>' +
        '<button class="secondary-btn" id="tst-copiar" title="Copia o resultado para colar no WhatsApp ou no Trello">Copiar resultado</button>' +
      '</div>' +
      '<div class="tst-barra" id="tst-barra"><i id="tst-barra-fill"></i></div>' +
      '<div class="tst-placar" id="tst-placar">' +
        '<span class="p-ok"><b id="tst-n-ok">0</b> passaram</span>' +
        '<span class="p-falha"><b id="tst-n-falha">0</b> falharam</span>' +
        '<span class="p-olho"><b id="tst-n-olho">' + olho + '</b> para olhar</span>' +
        '<span class="tst-tempo" id="tst-tempo"></span>' +
      '</div>' +
      '<div class="tst-chips">' +
        '<button class="tst-chip ativo" data-filtro="tudo">Tudo</button>' +
        '<button class="tst-chip" data-filtro="falha">Só as falhas</button>' +
        '<button class="tst-chip" data-filtro="manual">Só as de olho</button>' +
      '</div>' +
      '<p class="tst-aviso">A demonstração é uma planilha de mentira, criada só para o teste, ' +
        'e some no fim. Ela <b>nunca</b> entra no seu arquivo - nem se você salvar com ela aberta. ' +
        'Os itens com 👁 precisam do seu olho: use "Levar até lá" que o app já monta a cena.</p>' +
      '<div class="tst-lista" id="tst-lista">' + lista + '</div>';

    openModal('Modo Teste', html, () => closeModal(), 'modal-teste');
    setTimeout(ligarBotoes, 40);
  }

  function ligarBotoes() {
    const b = id => $(id);
    // o rodape padrao (Cancelar / Confirmar) nao faz sentido aqui
    const rodape = document.querySelector('#modal-content .modal-footer');
    if (rodape) {
      const cancelar = rodape.querySelector('.secondary-btn');
      if (cancelar) cancelar.style.display = 'none';
      const fechar = rodape.querySelector('.primary-btn');
      if (fechar) fechar.textContent = 'Fechar';
    }
    b('tst-rodar') && b('tst-rodar').addEventListener('click', rodarTudo);
    b('tst-limpar') && b('tst-limpar').addEventListener('click', async () => {
      try { await limparDemo(); toast('Demonstração removida', 'success'); }
      catch (e) { toast('Erro: ' + e.message, 'error'); }
    });
    b('tst-demo') && b('tst-demo').addEventListener('click', async () => {
      try { await carregarDemo(true); toast('Planilha de demonstração carregada', 'success'); }
      catch (e) { toast('Erro: ' + e.message, 'error'); }
    });
    b('tst-copiar') && b('tst-copiar').addEventListener('click', copiarResultado);
    document.querySelectorAll('.tst-chip').forEach(c => {
      c.addEventListener('click', () => {
        filtroAtual = c.dataset.filtro;
        document.querySelectorAll('.tst-chip').forEach(x => x.classList.toggle('ativo', x === c));
        aplicarFiltro();
      });
    });
    document.querySelectorAll('[data-ir]').forEach(bt => {
      bt.addEventListener('click', async () => {
        const it = ITENS.find(x => x.id === bt.dataset.ir);
        if (!it) return;
        closeModal();
        try {
          if (!state.headers.length || !criadasAqui.has(state.activeSheet)) await carregarDemo(true);
          it.ir();
          toast(it.olhar, 'success');
        } catch (e) { toast('Erro: ' + e.message, 'error'); }
      });
    });
    atualizarPlacar();
    aplicarFiltro();
  }

  function aplicarFiltro() {
    document.querySelectorAll('.tst-item').forEach(el => {
      const t = el.dataset.tipo;
      const mostra = filtroAtual === 'tudo' ||
                     (filtroAtual === 'falha' && t === 'falha') ||
                     (filtroAtual === 'manual' && t === 'manual');
      el.style.display = mostra ? '' : 'none';
    });
    document.querySelectorAll('.tst-grupo').forEach(g => {
      const algum = [].slice.call(g.querySelectorAll('.tst-item')).some(i => i.style.display !== 'none');
      g.style.display = algum ? '' : 'none';
    });
  }

  function atualizarPlacar() {
    const vals = Object.values(resultados);
    const ok = vals.filter(r => r.ok && !r.pulou).length;
    const falha = vals.filter(r => !r.ok && !r.pulou).length;
    if ($('tst-n-ok')) $('tst-n-ok').textContent = ok;
    if ($('tst-n-falha')) $('tst-n-falha').textContent = falha;
    const placar = $('tst-placar');
    if (placar) placar.classList.toggle('tem-falha', falha > 0);
  }

  function pintar(id, r) {
    const st = $('tst-st-' + id), msg = $('tst-msg-' + id), subs = $('tst-subs-' + id);
    const item = document.querySelector('.tst-item[data-id="' + id + '"]');
    const marca = r.pulou ? '–' : (r.ok ? '✓' : '✕');
    const classe = r.pulou ? 'pulou' : (r.ok ? 'ok' : 'falhou');
    if (st) { st.textContent = marca; st.className = 'tst-status ' + classe; }
    if (msg) msg.textContent = r.msg || '';
    if (item) {
      item.dataset.tipo = r.pulou ? 'pulou' : (r.ok ? 'ok' : 'falha');
      item.classList.toggle('e-falha', !r.ok && !r.pulou);
    }
    if (subs) {
      subs.innerHTML = (r.subs || []).map(s =>
        '<div class="tst-sub ' + (s.ok ? 'ok' : 'falhou') + '">' +
        '<span>' + (s.ok ? '✓' : '✕') + '</span><span>' + esc(s.texto) + '</span></div>').join('');
    }
    atualizarPlacar();
  }

  function marcarRodando(id) {
    const st = $('tst-st-' + id);
    if (st) { st.textContent = '⋯'; st.className = 'tst-status rodando'; }
    const item = document.querySelector('.tst-item[data-id="' + id + '"]');
    if (item && item.scrollIntoView) item.scrollIntoView({ block: 'nearest' });
  }

  function progresso(feitos, total) {
    const f = $('tst-barra-fill');
    if (f) f.style.width = Math.round((feitos / total) * 100) + '%';
  }

  function copiarResultado() {
    const linhas = ['Concrestats - resultado do teste' + (versaoApp ? ' (' + versaoApp + ')' : '')];
    let grupo = '';
    ITENS.forEach(it => {
      if (it.grupo !== grupo) { grupo = it.grupo; linhas.push('', '[' + grupo + ']'); }
      const r = resultados[it.id];
      const marca = it.manual ? 'OLHAR'
        : (r ? (r.pulou ? 'PULOU' : (r.ok ? 'OK   ' : 'FALHA')) : '--   ');
      linhas.push(marca + '  ' + it.titulo + (r && r.msg ? '  (' + r.msg + ')' : ''));
      if (r && r.subs) r.subs.forEach(s => linhas.push('        ' + (s.ok ? '-' : 'X') + ' ' + s.texto));
    });
    const txt = linhas.join('\n');
    const fim = () => toast('Resultado copiado - é só colar', 'success');
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(txt).then(fim).catch(() => caiuNoTextarea(txt, fim));
    } else caiuNoTextarea(txt, fim);
  }

  function caiuNoTextarea(txt, fim) {
    const ta = document.createElement('textarea');
    ta.value = txt; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); fim(); } catch (e) { toast('Não consegui copiar', 'error'); }
    document.body.removeChild(ta);
  }

  async function rodarTudo() {
    const btn = $('tst-rodar');
    if (btn) { btn.disabled = true; btn.textContent = 'Rodando...'; }
    const t0 = Date.now();
    const antes = {
      filtros: JSON.parse(JSON.stringify(state.filters || [])),
      cores: JSON.parse(JSON.stringify(state.regrasCor || [])),
      congelar: state.colunasFixas.slice(),
      ordem: state.sortState ? JSON.parse(JSON.stringify(state.sortState)) : null,
    };
    try { await carregarDemo(true); } catch (e) {
      toast('Não consegui montar a demonstração: ' + e.message, 'error');
      if (btn) { btn.disabled = false; btn.textContent = '▶ Rodar de novo'; }
      return;
    }
    // Os testes da planilha editam células; em Visualizar seriam barrados e
    // falhariam sem defeito nenhum. Roda em Editar e devolve como estava.
    const modo = window.ConcrestatsModoPlanilha;
    const modoAntes = modo ? modo.editando() : true;
    if (modo) modo.definir(true);
    const autos = ITENS.filter(i => !i.manual);
    let feitos = 0, ok = 0, falhou = 0, pulados = 0;
    for (let i = 0; i < autos.length; i++) {
      const it = autos[i];
      marcarRodando(it.id);
      let r;
      const ti = Date.now();
      try { r = await it.auto(); }
      catch (e) { r = { ok: false, msg: 'erro: ' + e.message }; }
      if (r.itens && !r.subs) r.subs = r.itens;
      r.ms = Date.now() - ti;
      resultados[it.id] = r;
      pintar(it.id, r);
      if (r.pulou) pulados++; else if (r.ok) ok++; else falhou++;
      progresso(++feitos, autos.length);
      await espera(40);
    }
    // devolve o app como estava e APAGA a demonstração
    state.filters = antes.filtros; state.regrasCor = antes.cores;
    state.colunasFixas = antes.congelar; state.sortState = antes.ordem;
    try { await limparDemo(); } catch (e) {}
    if (modo) modo.definir(modoAntes);
    recomputeFilters();
    ConcrestatsOpenModule('spreadsheet');
    renderGrid();
    const seg = ((Date.now() - t0) / 1000).toFixed(1);
    if ($('tst-tempo')) $('tst-tempo').textContent = 'em ' + seg + 's';
    atualizarPlacar();
    aplicarFiltro();
    if (btn) { btn.disabled = false; btn.textContent = '▶ Rodar de novo'; }
    // "Pulado" nao e' falha nem acerto: e' verificacao que nao se aplica a esta
    // copia. Uma edicao que esconde uma aba faria os testes dela falharem em
    // vermelho, e quem visse pensaria que o programa esta' quebrado.
    const nota = pulados ? ' (' + pulados + ' não se aplicam a esta edição)' : '';
    toast(falhou ? falhou + ' item(ns) falharam - veja a lista'
                 : 'Tudo certo: ' + ok + ' verificações passaram' + nota,
          falhou ? 'error' : 'success');
  }

  // Este arquivo é injetado DEPOIS de /api/ambiente responder - quase sempre
  // com a página já montada. Esperar o DOMContentLoaded, nesse caso, era
  // esperar um evento que já passou: o botão nunca aparecia.
  function criarBotao() {
    if (document.getElementById('btn-modo-teste')) return;
    const b = document.createElement('button');
    b.id = 'btn-modo-teste';
    b.className = 'btn-modo-teste';
    b.title = 'Modo Teste: planilha de exemplo, autoteste e roteiro do que olhar';
    b.textContent = '✓ Testar';
    b.addEventListener('click', abrir);
    document.body.appendChild(b);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', criarBotao);
  else criarBotao();

  window.ModoTeste = { abrir };
})();
