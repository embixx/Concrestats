// Avisos usam o toast do app (o alert do Windows trava a janela e some
// atras dela em algumas maquinas).
function aviso(msg, tipo) {
  if (window.toast) window.toast(msg, tipo || 'success');
  else alert(msg);
}
/* relatorio.js - o certificado de ensaio de compressão.
 *
 * Refeito em 24/09/2026. O anterior era uma tabela com um cabeçalho em cima:
 * faltava metade do que o formulário do próprio laboratório tem (7 dias, o
 * segundo corpo de prova, retificação, neoprene, quem assina) e nada nele
 * parecia um documento. Agora é uma folha A4 deitada, com o mesmo desenho na
 * tela, na impressão (PDF) e no HTML exportado - uma folha de estilo só.
 *
 * Dois visuais: o do Concrestats (padrão) e o da EMPRESA, que usa o logotipo
 * achado dentro da planilha aberta (ou o enviado em Campos fixos) e tira as
 * cores dele. O conteúdo é o mesmo nos dois.
 */
(function(){
  'use strict';

  const $ = id => document.getElementById(id);
  let selectedCols = null;
  let ensaioManual = {};   // edições feitas na folha (durante a sessão)
  let donoDosManuais = null;  // de quem são essas edições: "planilha || cliente"
  let lastReport = null;   // {grupos, headers, data} - TODAS as linhas filtradas, p/ o Excel
  let ultimoModelo = null;
  // A tela mostra uma folha de cada vez, com as linhas de uma pagina impressa.
  // Antes parava em 350 exemplares: sem filtro, o resto nao aparecia em lugar
  // nenhum da tela. Impressao e Excel continuam levando tudo de uma vez.
  const EXEMPLARES_POR_PAGINA = 30;
  let paginaTela = 0, totalDaTela = -1;
  // Logotipo achado na planilha aberta: {chave, logo, cores}. A chave vem do
  // servidor (caminho + data do arquivo); igual, não baixa de novo.
  let marcaPlanilha = { chave: null, logo: '', cores: null, buscando: false, procurou: false };
  const coresCache = new Map();

  // Sem empresa, prensa ou cidade de fábrica: o programa atende vários
  // laboratórios, e um padrão de um deles sairia no laudo dos outros. Quem
  // emite preenche uma vez em Campos fixos.

  // Campos fixos: cache em localStorage + persistência real em /api/prefs
  // (prefs.json ao lado do exe) - não somem ao fechar o app.
  function getFixos(){ try { return JSON.parse(localStorage.getItem('concrestats_ensaio_fixos')||'{}'); } catch(_){ return {}; } }
  function setFixos(o){
    try { localStorage.setItem('concrestats_ensaio_fixos', JSON.stringify(o)); } catch(_){}
    try { fetch('/api/prefs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ensaio_fixos:o})}); } catch(_){}
  }
  function carregarFixosServidor(){
    try{
      window.prefsGet().then(p=>{
        let mudou = false;
        if(p && p.ensaio_fixos && typeof p.ensaio_fixos==='object'){
          try { localStorage.setItem('concrestats_ensaio_fixos', JSON.stringify(p.ensaio_fixos)); } catch(_){}
          mudou = true;
        }
        if(p && p.ensaio_por_cliente && typeof p.ensaio_por_cliente==='object'){
          try { localStorage.setItem('concrestats_ensaio_por_cliente', JSON.stringify(p.ensaio_por_cliente)); } catch(_){}
          mudou = true;
        }
        const m = $('module-relatorio');
        if (mudou && m && m.style.display !== 'none') render();
      }).catch(()=>{});
    }catch(_){}
  }

  // Recursos em prévia (edição do testador) - ver app.previa().
  let previaLigada = false;
  if (window.ConcrePrevia) window.ConcrePrevia.then(s => {
    previaLigada = !!s;
    const m = $('module-relatorio');
    if (previaLigada && m && m.style.display !== 'none') render();
  });

  // Preenchimento POR CLIENTE. O Naor, em 12/10/2026: "configurar
  // preenchimento por cliente". CNPJ, obra, endereço e contato são do
  // cliente; guardados em Campos fixos valiam para todos e saíam no laudo do
  // cliente seguinte. Agora ficam com o nome de cada um e entram sozinhos
  // quando o relatório é de um cliente só.
  const CAMPOS_DO_CLIENTE = ['cnpj','obra','endereco','cidade','contato','fone','email','finalidade'];
  function getPorCliente(){
    try { const o = JSON.parse(localStorage.getItem('concrestats_ensaio_por_cliente')||'{}'); return o && typeof o === 'object' ? o : {}; }
    catch(_){ return {}; }
  }
  function setPorCliente(o){
    try { localStorage.setItem('concrestats_ensaio_por_cliente', JSON.stringify(o)); } catch(_){}
    try { fetch('/api/prefs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ensaio_por_cliente:o})}); } catch(_){}
  }
  function dadosDoCliente(nome){
    if (!previaLigada || !String(nome || '').trim()) return null;
    return getPorCliente()[norm(nome)] || null;
  }

  // Calibração da prensa (item 18 da lista): o número do certificado e a
  // validade, guardados em Campos fixos. Sai no relatório junto da prensa, e
  // a tela avisa antes de vencer - laudo com prensa fora da calibração não
  // vale, e ninguém olha a data do certificado na parede.
  const DIAS_AVISO_CALIBRACAO = 30;
  function validadeCalibracao(fx){
    const m = String((fx || {}).calibracao_validade || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!m) return null;
    const venc = new Date(+m[1], +m[2] - 1, +m[3]);
    const hj = new Date(); hj.setHours(0, 0, 0, 0);
    return { data: `${m[3]}/${m[2]}/${m[1]}`, dias: Math.round((venc - hj) / 86400000) };
  }
  function textoCalibracao(fx){
    if (!previaLigada) return '';
    const v = validadeCalibracao(fx);
    return [fx.calibracao_certificado ? 'Certificado nº ' + fx.calibracao_certificado : '',
            fx.calibracao_laboratorio ? 'por ' + fx.calibracao_laboratorio : '',
            v ? 'válida até ' + v.data : ''].filter(Boolean).join(' · ');
  }
  window.ConcreCalibracao = () => validadeCalibracao(getFixos());

  function esc(s){
    return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }

  function norm(s){
    return String(s ?? '')
      .normalize('NFD').replace(/[̀-ͯ]/g,'')
      .replace(/[²2]/g,'2').replace(/[³3]/g,'3')
      .replace(/\([^)]*\)$/,'')
      .replace(/[^A-Z0-9]+/gi,'')
      .toUpperCase();
  }

  function data(){
    return window.getConcrestatsData ? window.getConcrestatsData({filtered:true}) : null;
  }

  function headerIndex(headers, aliases){
    const ns = headers.map(norm);
    for(const a of aliases){
      const na = norm(a);
      let i = ns.findIndex(h => h === na);
      if(i >= 0) return i;
    }
    for(const a of aliases){
      const na = norm(a);
      let i = ns.findIndex(h => h.includes(na) || na.includes(h));
      if(i >= 0) return i;
    }
    return -1;
  }

  // De qual coluna ler CP, NF, volume, rompimento... vem da escolha de colunas
  // comum a todas as telas (colunas.js). Sem ela, os apelidos de antes.
  function papel(headers, id, apelidos){
    const c = window.ConcreColunas;
    return c ? c.indice(headers, id) : headerIndex(headers, apelidos);
  }
  // Colunas sem papel próprio (datas de ruptura, carga aos 7 dias): nome
  // tolerante, mas sem o "pedaço" frouxo do headerIndex - "DATA 7" não pode
  // cair na coluna DATA da moldagem.
  function colunaPorNome(headers, nomes){
    const c = window.ConcreColunas;
    if (c && c.coluna) return c.coluna(headers, nomes);
    const ns = headers.map(norm);
    for (const n of nomes) { const i = ns.indexOf(norm(n)); if (i >= 0) return i; }
    return -1;
  }
  // A coluna irmã (CP 2) de uma coluna de 28 dias: "TNF 28" -> "TNF 28.1".
  function colunaIrma(headers, i){
    if (i < 0) return -1;
    const c = window.ConcreColunas;
    if (c && c.irma) return c.irma(headers, i);
    const alvo = norm(headers[i]) + '1';
    return headers.findIndex((h, j) => j !== i && norm(h) === alvo);
  }

  // O fck pedido: da coluna própria, quando a planilha tem uma; senão, de
  // dentro do texto da receita ou do produto ("CONCRETO FCK 30 S100 LAJE").
  function fckDe(r, iFck, textos){
    if(iFck >= 0){
      const v = String(r[iFck] ?? '').trim();
      const m = v.toUpperCase().match(/FCK\s*[-:_]*\s*(\d+(?:[\.,]\d+)?)/) || v.match(/(\d+(?:[\.,]\d+)?)/);
      if(m) return m[1].replace(',','.');
    }
    for(const c of textos){
      if(c >= 0){ const m = String(r[c]||'').toUpperCase().match(/FCK\s*[-:_]*\s*(\d+(?:[\.,]\d+)?)/); if(m) return m[1].replace(',','.'); }
    }
    return '';
  }

  function byName(headers, name){
    const n = norm(name);
    return headers.findIndex(h => norm(h) === n || norm(h).replace(/\d+$/,'') === n.replace(/\d+$/,''));
  }

  function defaultCols(headers){
    const out = [];
    [['cp',['CP']],['nf',['NF']],['volume',['M³','M3','VOLUME']],['data',['DATA']],['tnf28',['TNF 28','TNF28']],
     ['mpa28',['MPA 28','MPA28']],['receita',['RECEITA']]].forEach(([id, al]) => {
      const i = papel(headers, id, al); if(i >= 0 && !out.includes(headers[i])) out.push(headers[i]);
    });
    return out;
  }

  function parseNum(v){
    if(v === null || v === undefined) return NaN;
    if(typeof v === 'number') return Number.isFinite(v) ? v : NaN;
    let s = String(v).trim().replace(/\s/g,'').replace(/ /g,'');
    if(!s) return NaN;
    s = s.replace(/[^0-9,\.\-]/g,'');
    if(!s || ['-',',','.'].includes(s)) return NaN;
    if(s.includes(',') && s.includes('.')){
      if(s.lastIndexOf(',') > s.lastIndexOf('.')) s = s.replace(/\./g,'').replace(',','.');
      else s = s.replace(/,/g,'');
    } else if(s.includes(',')) s = s.replace(',','.');
    const n = Number(s);
    return Number.isFinite(n) ? n : NaN;
  }

  function fmtNum(v, dec=2){
    const n = parseNum(v);
    if(!Number.isFinite(n)) return esc(v);
    return n.toLocaleString('pt-BR', {maximumFractionDigits:dec, minimumFractionDigits:0});
  }
  // Casas fixas por grandeza: resistência com uma (ABNT NBR 5739 pede
  // 0,1 MPa), carga com duas, volume com uma ou duas. "30" ao lado de
  // "26,14" na mesma coluna é o que faz uma tabela parecer rascunho.
  const CASAS = { mpa: [1, 1], carga: [2, 2], vol: [1, 2], fck: [0, 1] };
  function numero(v, tipo){
    const n = typeof v === 'number' ? v : parseNum(v);
    if (!Number.isFinite(n) || n === 0) return '';
    const [mi, ma] = CASAS[tipo] || [0, 2];
    return n.toLocaleString('pt-BR', { minimumFractionDigits: mi, maximumFractionDigits: ma });
  }

  function fmtDate(v){
    if(v === null || v === undefined || v === '') return '';
    if(typeof v === 'number' && Number.isFinite(v) && v > 20000 && v < 80000){
      const d = new Date(Math.round((v - 25569) * 86400 * 1000));
      return d.toLocaleDateString('pt-BR');
    }
    const s = String(v).trim();
    const m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if(m) return `${m[3]}/${m[2]}/${m[1]}`;
    // esc() aqui também: o que não é data reconhecida vai direto para o HTML.
    return esc(s);
  }

  function filteredRows(d){
    const q = ($('rep-filter')?.value || '').toLowerCase().trim();
    const rows = Array.isArray(d.data) ? d.data : [];
    if(!q) return rows;
    return rows.filter(r => r.some(c => String(c || '').toLowerCase().includes(q)));
  }

  // Vazio e "vários" devolvem VAZIO: "424 valores" no campo Cliente de um
  // certificado não é informação, é o programa dizendo que não sabe.
  function uniqueVal(rows, idx){
    if(idx < 0) return '';
    const vals = [...new Set(rows.map(r => String(r[idx] ?? '').trim()).filter(Boolean))];
    return vals.length === 1 ? vals[0] : '';
  }
  function quantosDistintos(rows, idx){
    if(idx < 0) return 0;
    return new Set(rows.map(r => String(r[idx] ?? '').trim()).filter(Boolean)).size;
  }

  /* -- marca: Concrestats ou a da empresa -------------------------------- */
  const LUPA = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="10.4" cy="10" r="6.6" stroke="currentColor" stroke-width="2.1"/><rect x="7.2" y="9.6" width="1.9" height="3.6" rx="0.6" fill="currentColor" opacity=".72"/><rect x="9.6" y="6.7" width="1.9" height="6.5" rx="0.6" fill="#2f7df0"/><rect x="12.0" y="9.6" width="1.9" height="3.6" rx="0.6" fill="currentColor" opacity=".72"/><path d="M15.4 15l4.1 4.1" stroke="#2f7df0" stroke-width="2.5" stroke-linecap="round"/></svg>';

  const TEMA_CONCRESTATS = {
    marca: '#2f7df0', forte: '#1a3a6e', suave: '#edf3fd', segunda: '#a8c5f5',
    tinta: '#1c1b18', tinta2: '#57554f', tinta3: '#8f8b82', linha: '#dcd9cf', fraca: '#ebe9e2', fundo: '#f7f6f2',
  };
  const NEUTROS_EMPRESA = { tinta: '#1b1e24', tinta2: '#535966', tinta3: '#8a909b', linha: '#dadde3', fraca: '#e9ebef', fundo: '#f5f6f8' };

  function hexRgb(h){ const m = /^#?([0-9a-f]{6})$/i.exec(String(h || '').trim()); if (!m) return null; const n = parseInt(m[1], 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
  function rgbHex(c){ return '#' + c.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join(''); }
  function luz(c){ const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); }
  function contraste(a, b){ const x = luz(a), y = luz(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
  function mistura(a, b, t){ return a.map((v, i) => v + (b[i] - v) * t); }
  function escurecer(c, alvo){ let x = c.slice(); for (let i = 0; i < 40 && contraste(x, [255, 255, 255]) < alvo; i++) x = mistura(x, [0, 0, 0], 0.08); return x; }
  function matiz(c){
    const [r, g, b] = c.map(v => v / 255), mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    if (!d) return 0;
    let h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    return (h * 60 + 360) % 360;
  }

  // As cores de um logotipo: descarta branco, preto e cinza; agrupa o resto por
  // matiz e clareza; a mais frequente é a principal. Quando as duas primeiras
  // empatam (±25%), vale a mais escura - texto e fio precisam aparecer no
  // branco, e um verde-limão não sustenta um título.
  function coresDaImagem(img){
    try {
      const esc_ = Math.min(1, 180 / Math.max(img.naturalWidth || 1, img.naturalHeight || 1));
      const w = Math.max(1, Math.round((img.naturalWidth || 1) * esc_)), h = Math.max(1, Math.round((img.naturalHeight || 1) * esc_));
      const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
      const ctx = cv.getContext('2d'); ctx.drawImage(img, 0, 0, w, h);
      const px = ctx.getImageData(0, 0, w, h).data;
      const baldes = new Map();
      for (let i = 0; i < px.length; i += 4) {
        if (px[i + 3] < 200) continue;
        const c = [px[i], px[i + 1], px[i + 2]], mx = Math.max(...c), mn = Math.min(...c);
        if (mn > 232 || mx < 48) continue;
        const l = (mx + mn) / 510, s = mx === mn ? 0 : (mx - mn) / 255 / (1 - Math.abs(2 * l - 1));
        if (s < 0.28) continue;
        const k = Math.round(matiz(c) / 15) % 24 + '_' + (l < 0.38 ? 0 : l < 0.66 ? 1 : 2);
        const b = baldes.get(k) || { n: 0, r: 0, g: 0, bl: 0 };
        b.n++; b.r += c[0]; b.g += c[1]; b.bl += c[2]; baldes.set(k, b);
      }
      const lista = [...baldes.values()].sort((a, b) => b.n - a.n)
        .map(b => ({ n: b.n, c: [b.r / b.n, b.g / b.n, b.bl / b.n] }));
      if (!lista.length) return null;
      let [p, ...resto] = lista;
      const s = resto.find(x => Math.abs(matiz(x.c) - matiz(p.c)) % 360 > 35 && x.n >= p.n * 0.08);
      if (s && s.n >= p.n * 0.75 && luz(s.c) < luz(p.c)) return { principal: rgbHex(s.c), segunda: rgbHex(p.c) };
      return { principal: rgbHex(p.c), segunda: s ? rgbHex(s.c) : null };
    } catch (e) { return null; }   // imagem de outra origem ou canvas bloqueado
  }

  function temaDasCores(cores, corManual){
    const p = hexRgb(corManual) || hexRgb(cores && cores.principal);
    if (!p) return Object.assign({ marca: '#3b4252', forte: '#262b35', suave: '#eef0f3', segunda: '#8a909b' }, NEUTROS_EMPRESA);
    // Cor de TEXTO (títulos, rótulos de grupo): a principal, se ela já se lê
    // no branco; senão a segunda cor da marca, se essa se lê; só em último
    // caso a principal escurecida - laranja escurecido vira marrom.
    const seg = hexRgb(cores && cores.segunda);
    const branco = [255, 255, 255];
    const forte = contraste(p, branco) >= 4.5 || !seg || contraste(seg, branco) < 4.5
      ? escurecer(p, 6.5) : escurecer(seg, 6.5);
    return Object.assign({
      marca: rgbHex(p), forte: rgbHex(forte), suave: rgbHex(mistura(p, [255, 255, 255], 0.9)),
      segunda: seg ? rgbHex(seg) : rgbHex(mistura(forte, [255, 255, 255], 0.45)),
    }, NEUTROS_EMPRESA);
  }

  function carregarImagem(src){
    return new Promise(res => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = src; });
  }
  // Reduz para caber no cabeçalho sem pesar no prefs.json nem no PDF.
  function reduzirImagem(img, maxW = 720, maxH = 220){
    const k = Math.min(1, maxW / img.naturalWidth, maxH / img.naturalHeight);
    const cv = document.createElement('canvas');
    cv.width = Math.max(1, Math.round(img.naturalWidth * k)); cv.height = Math.max(1, Math.round(img.naturalHeight * k));
    cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
    try { return cv.toDataURL('image/png'); } catch (e) { return img.src; }
  }
  async function coresDoLogo(src){
    if (!src) return null;
    const k = src.length + ':' + src.slice(-40);
    if (coresCache.has(k)) return coresCache.get(k);
    const img = await carregarImagem(src);
    const c = img ? coresDaImagem(img) : null;
    coresCache.set(k, c);
    return c;
  }

  // Procura o logotipo dentro da planilha aberta. Assíncrono: a folha é
  // desenhada logo, e redesenhada se aparecer um logo novo.
  async function buscarLogoDaPlanilha(){
    if (marcaPlanilha.buscando) return;
    marcaPlanilha.buscando = true;
    try {
      const sid = (typeof SESSION_ID !== 'undefined') ? SESSION_ID : 'default';
      const r = await fetch('/api/logo_da_planilha', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ session_id: sid, chave: marcaPlanilha.chave || '' }) }).then(x => x.json()).catch(() => null);
      marcaPlanilha.procurou = true;
      if (!r || !r.success || r.mesma) return;
      let logo = '', cores = null;
      for (const im of (r.imagens || [])) {
        const img = await carregarImagem(im.dados);
        if (!img || img.naturalWidth < 32 || img.naturalHeight < 12) continue;
        logo = reduzirImagem(img);
        cores = coresDaImagem(img);
        break;
      }
      const mudou = logo !== marcaPlanilha.logo;
      marcaPlanilha.chave = r.chave || null;
      marcaPlanilha.logo = logo; marcaPlanilha.cores = cores;
      if (mudou && identidade() === 'empresa') render();
    } finally { marcaPlanilha.buscando = false; }
  }

  function identidade(){ return getFixos().identidade === 'empresa' ? 'empresa' : 'concrestats'; }

  // {modo, tema, logo, origemLogo, nomeEmpresa}
  async function marcaAtual(){
    const fx = getFixos();
    const nomeEmpresa = String(fx.empresa || '').trim();
    if (identidade() !== 'empresa') return { modo: 'concrestats', tema: TEMA_CONCRESTATS, logo: '', origemLogo: '', nomeEmpresa };
    // O logotipo da planilha investigada vem primeiro: é a cara dela. O
    // enviado em Campos fixos é o reserva, para planilha sem logo.
    const logo = marcaPlanilha.logo || fx.logo || '';
    const origemLogo = marcaPlanilha.logo ? 'planilha' : (fx.logo ? 'fixo' : '');
    const cores = marcaPlanilha.logo ? marcaPlanilha.cores : await coresDoLogo(fx.logo);
    return { modo: 'empresa', tema: temaDasCores(cores, fx.cor), logo, origemLogo, nomeEmpresa };
  }

  function varsDoTema(t){
    return `--c-marca:${t.marca};--c-forte:${t.forte};--c-suave:${t.suave};--c-segunda:${t.segunda};` +
      `--c-tinta:${t.tinta};--c-tinta2:${t.tinta2};--c-tinta3:${t.tinta3};--c-linha:${t.linha};--c-fraca:${t.fraca};--c-fundo:${t.fundo}`;
  }

  /* -- a folha ----------------------------------------------------------- */
  const FONTE_SANS = "'IBM Plex Sans','Segoe UI',system-ui,-apple-system,Arial,sans-serif";
  const FONTE_MONO = "'IBM Plex Mono','Cascadia Mono',Consolas,'Courier New',monospace";
  const CERT_CSS = `
.cert{position:relative;background:#fff;color:var(--c-tinta);font-family:${FONTE_SANS};font-size:11px;line-height:1.45;
  width:297mm;min-height:210mm;padding:10mm 12mm 9mm;box-sizing:border-box;text-align:left;
  font-variant-numeric:tabular-nums lining-nums;-webkit-font-smoothing:antialiased;
  -webkit-print-color-adjust:exact;print-color-adjust:exact}
.cert *,.cert *::before,.cert *::after{box-sizing:border-box;margin:0;padding:0}
.cert .mono,.cert-rotulo{font-family:${FONTE_MONO}}
.cert-cab{display:flex;align-items:center;justify-content:space-between;gap:28px;padding-bottom:8px}
.cert-marca{display:flex;align-items:center;gap:11px;min-height:34px}
.cert-selo{width:31px;height:31px;border-radius:7px;background:#1a1f2c;color:#fff;display:flex;align-items:center;justify-content:center;flex:none}
.cert-selo svg{width:20px;height:20px;display:block}
.cert-palavra{font-family:${FONTE_MONO};font-weight:600;font-size:14.5px;letter-spacing:.17em;line-height:1;color:var(--c-tinta)}
.cert-palavra small{display:block;font-weight:400;font-size:7px;letter-spacing:.2em;color:var(--c-tinta3);margin-top:5px;text-transform:uppercase}
.cert-logo{display:block;max-height:42px;max-width:260px;width:auto;height:auto;object-fit:contain}
.cert-nome-empresa{font-weight:600;font-size:15px;letter-spacing:.07em;text-transform:uppercase;color:var(--c-forte);line-height:1.2;max-width:420px}
.cert-doc{text-align:right;flex:none}
.cert-doc-tipo{font-family:${FONTE_MONO};font-size:8.5px;letter-spacing:.2em;text-transform:uppercase;color:var(--c-forte);font-weight:600}
.cert-doc-meta{display:flex;gap:20px;justify-content:flex-end;margin-top:5px}
.cert-doc-meta>div{display:flex;flex-direction:column;align-items:flex-end;min-width:0}
.cert-doc-meta dt{font-family:${FONTE_MONO};font-size:7px;letter-spacing:.16em;text-transform:uppercase;color:var(--c-tinta3)}
.cert-doc-meta dd{font-size:11.5px;font-weight:500;margin-top:2px;white-space:nowrap}
.cert-doc-meta .cert-inp{text-align:right;min-width:74px}
.cert-faixa{height:1.5px;background:var(--c-tinta);position:relative;margin-bottom:11px}
.cert-faixa::before{content:"";position:absolute;left:0;top:-1.25px;height:4px;width:72px;background:var(--c-marca)}
.cert-faixa::after{content:"";position:absolute;left:76px;top:-1.25px;height:4px;width:16px;background:var(--c-segunda)}
.cert-titulo{margin-bottom:11px;display:flex;justify-content:space-between;align-items:flex-end;gap:24px}
.cert-kicker{font-family:${FONTE_MONO};font-size:8.5px;letter-spacing:.18em;text-transform:uppercase;color:var(--c-forte);font-weight:500}
.cert-titulo h1{font-size:19.5px;font-weight:600;letter-spacing:-.012em;line-height:1.18;margin-top:4px;color:var(--c-tinta)}
.cert-sub{font-size:9.5px;color:var(--c-tinta2);margin-top:4px}
.cert-emitente{text-align:right;flex:none;max-width:95mm}
.cert-emitente .cert-rotulo{display:block;font-size:7px;letter-spacing:.16em;text-transform:uppercase;color:var(--c-tinta3)}
.cert-emitente b{display:block;font-size:11px;font-weight:600;margin-top:2px;line-height:1.3}
.cert-blocos{display:grid;grid-template-columns:1.6fr 1.05fr .85fr;border-top:1px solid var(--c-linha);border-bottom:1px solid var(--c-linha);margin-bottom:10px}
.cert-bloco{padding:8px 16px 9px 0;min-width:0}
.cert-bloco+.cert-bloco{border-left:1px solid var(--c-linha);padding-left:16px}
.cert-bloco h2,.cert-secao{font-family:${FONTE_MONO};font-size:8px;font-weight:600;letter-spacing:.18em;text-transform:uppercase;color:var(--c-tinta);display:flex;align-items:center;gap:8px;margin-bottom:6px}
.cert-bloco h2::before,.cert-secao::before{content:"";width:6px;height:6px;border-radius:1px;background:var(--c-marca);flex:none}
.cert-cliente{font-size:13.5px;font-weight:600;line-height:1.3;margin-bottom:5px;letter-spacing:-.005em}
.cert-campos{display:grid;grid-template-columns:auto minmax(0,1fr);column-gap:12px;row-gap:3px;align-items:baseline}
.cert-campos.duas{grid-template-columns:auto minmax(0,1fr) auto minmax(0,1fr)}
.cert-campo{display:contents}
.cert-campo dt{font-family:${FONTE_MONO};font-size:7.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--c-tinta3);white-space:nowrap}
.cert-campo dd{font-size:10.5px;color:var(--c-tinta);min-width:0;overflow-wrap:anywhere}
.cert-resumo{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;background:var(--c-fundo);border-radius:3px;margin-bottom:11px}
.cert-kpi{padding:7px 14px 7px;min-width:0}
.cert-kpi+.cert-kpi{border-left:1px solid var(--c-linha)}
.cert-kpi dt{font-family:${FONTE_MONO};font-size:7px;letter-spacing:.16em;text-transform:uppercase;color:var(--c-tinta3);white-space:nowrap}
.cert-kpi dd{font-size:17px;font-weight:600;letter-spacing:-.015em;line-height:1.1;margin-top:3px;white-space:nowrap}
.cert-kpi dd small{font-size:9.5px;font-weight:500;color:var(--c-tinta2);margin-left:3px;letter-spacing:0}
.cert-kpi dd.nota{font-size:8px;font-weight:400;letter-spacing:0;line-height:1.3;color:var(--c-tinta3);margin-top:2px;overflow:hidden;text-overflow:ellipsis}
.cert-kpi.principal dd:not(.nota){color:var(--c-forte)}
.cert-secao{justify-content:flex-start}
.cert-secao span{margin-left:auto;font-weight:400;letter-spacing:.1em;color:var(--c-tinta3)}
.cert-conformidade{margin-top:14px}.cert-conf-nota{font-size:8.5px;color:var(--c-tinta3);margin:5px 0 0}
.cert-tabela{width:100%;border-collapse:collapse;font-size:10px}
.cert-tabela th{font-weight:600;font-size:8.5px;color:var(--c-tinta2);text-align:right;padding:3px 6px 4px;vertical-align:bottom;line-height:1.25}
.cert-tabela th small{display:block;font-family:${FONTE_MONO};font-weight:400;font-size:7px;letter-spacing:.06em;color:var(--c-tinta3);margin-top:1px}
.cert-tabela thead tr:last-child th,.cert-tabela th[rowspan]{border-bottom:1.5px solid var(--c-tinta)}
.cert-tabela th.grupo{padding:0 6px 4px;text-align:center;vertical-align:bottom}
.cert-tabela th.grupo span{display:block;font-family:${FONTE_MONO};font-size:7.5px;font-weight:600;letter-spacing:.2em;text-transform:uppercase;color:var(--c-forte);border-bottom:1.5px solid var(--c-marca);padding-bottom:3px}
.cert-tabela td{padding:2.5px 6px;line-height:1.38;border-bottom:1px solid var(--c-fraca);text-align:right;white-space:nowrap}
.cert-tabela tbody tr:nth-child(even) td{background:var(--c-fundo)}
.cert-tabela .t{text-align:left}
.cert-tabela .d{text-align:center}
.cert-tabela .ini{border-left:1px solid var(--c-linha)}
.cert-tabela td.cod{font-family:${FONTE_MONO};font-size:9.5px;color:var(--c-tinta2)}
.cert-tabela td.largo{white-space:normal;min-width:58mm;max-width:100mm;font-size:9.5px;line-height:1.3}
.cert-tabela td.suspeito{color:#b33a2a;box-shadow:inset 0 -2px 0 rgba(179,58,42,.55);cursor:help}
.cert-tabela td.exemplar{font-weight:600;color:var(--c-tinta)}
.cert-tabela td .nulo{color:var(--c-tinta3);opacity:.7}
.cert-tabela tbody tr{break-inside:avoid;page-break-inside:avoid}
.cert-tabela thead{display:table-header-group}
.cert-mais td{text-align:center!important;font-size:9.5px;color:var(--c-tinta3);padding:9px!important;background:#fff!important;border-bottom:0!important;font-style:italic}
.cert-fim{break-inside:avoid;page-break-inside:avoid}
.cert-fecho{display:grid;grid-template-columns:minmax(0,1fr) 84mm;gap:30px;margin-top:12px;align-items:end;break-inside:avoid;page-break-inside:avoid}
.cert-notas ol{list-style:none;counter-reset:nota}
.cert-notas li{counter-increment:nota;position:relative;padding-left:15px;font-size:8.5px;line-height:1.45;color:var(--c-tinta2);margin-top:1px}
.cert-notas li::before{content:counter(nota);position:absolute;left:0;top:0;font-family:${FONTE_MONO};font-size:7.5px;font-weight:600;color:var(--c-forte)}
.cert-obs{margin-top:9px;font-size:9.5px;color:var(--c-tinta)}
.cert-obs .cert-rotulo{display:block;font-size:7px;letter-spacing:.16em;text-transform:uppercase;color:var(--c-tinta3);margin-bottom:2px}
.cert-assinatura{text-align:center}
.cert-local{font-size:9.5px;color:var(--c-tinta2);margin-bottom:40px}
.cert-traco{border-top:1px solid var(--c-tinta);margin:0 5mm 6px}
.cert-nome{font-size:11px;font-weight:600;min-height:16px}
.cert-cargo{font-family:${FONTE_MONO};font-size:7px;letter-spacing:.18em;text-transform:uppercase;color:var(--c-tinta3);margin-top:3px}
.cert-registro{font-size:9px;color:var(--c-tinta2);margin-top:2px}
.cert-rodape{display:flex;justify-content:space-between;align-items:center;gap:24px;margin-top:11px;padding-top:6px;border-top:1px solid var(--c-linha);font-size:8px;color:var(--c-tinta3)}
.cert-rodape b{color:var(--c-tinta2);font-weight:600}
.cert-software{display:flex;align-items:center;gap:6px;font-family:${FONTE_MONO};font-size:7px;letter-spacing:.18em;text-transform:uppercase;white-space:nowrap;color:var(--c-tinta3)}
.cert-software svg{width:12px;height:12px;color:var(--c-tinta2);display:block}
.cert-inp{font:inherit;color:inherit;letter-spacing:inherit;text-transform:inherit;background:transparent;border:0;outline:0;resize:none;overflow:hidden;
  width:100%;display:block;padding:0 3px;margin:0 -3px;border-radius:2px;line-height:inherit;min-height:1.45em;height:auto;box-shadow:none}
.cert-inp:hover{background:var(--c-suave)}
.cert-inp:focus{background:#fff;box-shadow:0 0 0 1.5px var(--c-marca)}
.cert-inp::placeholder{color:var(--c-tinta3);opacity:.55;font-weight:400;font-style:normal}
.cert-dica{color:var(--c-tinta3);font-weight:400;font-style:italic}
`;
  // Só no documento impresso/exportado: a folha vira página de verdade.
  //
  // Todas as seis posições da margem são ocupadas - as que não usamos, com
  // conteúdo vazio. O WebView2 do programa imprime com "cabeçalhos e rodapés"
  // ligados, e o Chromium escreve data, título da janela e endereço em toda
  // posição de margem que o documento deixa livre: o laudo saía com
  // "9/24/26, 3:17 PM · CONCRESTATS · Sistema de Dados" no topo. content:none
  // conta como livre; content:"" não.
  const PAGINA_CSS_BASE = `
@page{size:A4 landscape;margin:10mm 11mm 12mm}
@page{@bottom-right{content:"CONCRESTATS  ·  Página " counter(page) " de " counter(pages);font:7.5px ${FONTE_MONO};letter-spacing:.12em;color:#8f8b82}}
@page{@bottom-left{content:var_rodape_empresa;font:7.5px ${FONTE_SANS};color:#57554f}}
@page{@top-left{content:var_cabecalho_corrido;font:7.5px ${FONTE_MONO};letter-spacing:.12em;color:#8f8b82;text-transform:uppercase}}
@page{@top-center{content:""}@top-right{content:""}@bottom-center{content:""}}
@page :first{@top-left{content:""}}
html,body{margin:0;padding:0;background:#fff}
.cert{width:auto;min-height:0;padding:0}
@media print{.cert-rodape{display:none}}
@media screen{body{background:#e9e7e1;padding:24px}.cert{width:297mm;padding:12mm 13mm 10mm;margin:0 auto;box-shadow:0 14px 36px rgba(28,27,24,.14)}}
`;

  // Documento que passa um pouco de uma página encolhe para caber em uma - o
  // fecho (notas e assinatura) sozinho na folha 2 é o que mais parece
  // descuido. Nunca abaixo de 80%: menos que isso, a letra da tabela some, e
  // documento longo continua em várias páginas, no tamanho certo.
  const AJUSTE_JS = `<script>(function(){
  var UTIL = (210 - 22) * 96 / 25.4;
  function ajustar(){
    var c = document.querySelector('.cert'); if (!c) return;
    var s = document.getElementById('cert-ajuste');
    if (!s) { s = document.createElement('style'); s.id = 'cert-ajuste'; document.head.appendChild(s); }
    s.textContent = '';
    var cs = getComputedStyle(c);
    var h = c.getBoundingClientRect().height - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom);
    // o rodapé da tela não vai ao papel (vira timbre na margem)
    var rp = c.querySelector('.cert-rodape');
    if (rp) h -= rp.getBoundingClientRect().height + 11;
    var r = UTIL / h;
    if (r < 1 && r >= 0.8) s.textContent = '@media print{.cert{zoom:' + (Math.floor(r * 100) / 100 - 0.01) + '}}';
  }
  window.__ajustar = ajustar;
  window.addEventListener('load', ajustar);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(ajustar);
})();<\/script>`;

  // Nas páginas 2 em diante, uma linha discreta no alto diz de que documento
  // é a folha solta: "Ensaio de compressão · cliente · emissão".
  // E no rodapé de toda página, o timbre da empresa. Como bloco no fim do
  // texto, ele caía sozinho numa página quando a assinatura preenchida
  // empurrava a folha - a página 3 do laudo era só o rodapé.
  function paginaCss(m, marca){
    const limpo = t => String(t || '').replace(/[\\"\n\r]/g, ' ').trim();
    const partes = ['Ensaio de compressão', m.campos.cliente, m.emissao].map(limpo).filter(Boolean);
    const fx = m.fixos || {};
    const rodape = [marca && marca.nomeEmpresa, fx.empresa_endereco, fx.empresa_contato].map(limpo).filter(Boolean);
    return PAGINA_CSS_BASE
      .replace('var_cabecalho_corrido', '"' + partes.join('  ·  ') + '"')
      .replace('var_rodape_empresa', '"' + rodape.join('  ·  ') + '"');
  }

  // Tudo o que a folha precisa, calculado uma vez: serve à tela, à impressão e
  // aos dois arquivos.
  function montarModelo(){
    const d = data();
    if(!d || !Array.isArray(d.headers) || !d.headers.length) return null;
    const rows = filteredRows(d).filter(r => Array.isArray(r) && r.some(c => String(c ?? '').trim() !== ''));
    const H = d.headers;
    const ix = {
      cp: papel(H, 'cp', ['CP','CORPO DE PROVA','COD','CÓD']),
      nf: papel(H, 'nf', ['NF','NOTA FISCAL']),
      volume: papel(H, 'volume', ['M³','M3','VOLUME']),
      data: papel(H, 'data', ['DATA','DATA DE MOLDAGEM','MOLDAGEM']),
      obra: papel(H, 'obra', ['OBRA']),
      cliente: papel(H, 'cliente', ['CLIENTE']),
      produto: papel(H, 'produto', ['PRODUTO']),
      receita: papel(H, 'receita', ['RECEITA','TRAÇO','TRACO']),
      fck: papel(H, 'fck', []),
      mpa7: papel(H, 'mpa7', ['MPA 7','MPA7']),
      mpa28: papel(H, 'mpa28', ['MPA 28','MPA28']),
      mpa28b: window.ConcreColunas ? papel(H, 'mpa28b', []) : colunaIrma(H, papel(H, 'mpa28', ['MPA 28','MPA28'])),
      tnf28: papel(H, 'tnf28', ['TNF 28','TNF28']),
      data7: colunaPorNome(H, ['DATA 7','DATA RUPTURA 7','DATA DE RUPTURA 7','ROMPIMENTO 7','RUPTURA 7 DATA']),
      tnf7: colunaPorNome(H, ['TNF 7','TNF7','CARGA 7','CARGA 7D','RUPTURA TON 7']),
      data28: colunaPorNome(H, ['DATA 28','DATA RUPTURA 28','DATA DE RUPTURA 28','ROMPIMENTO 28','RUPTURA 28 DATA']),
    };
    ix.tnf28b = ix.mpa28b >= 0 ? colunaIrma(H, ix.tnf28) : -1;
    const fckRow = r => fckDe(r, ix.fck, [ix.receita, ix.produto]);
    const fckVals = [...new Set(rows.map(fckRow).filter(Boolean))];

    // Colunas do certificado - as do formulário do laboratório, na ordem dele.
    let cols;
    if (selectedCols) {
      cols = selectedCols.map(c => ({ rotulo: c, idx: byName(H, c), tipo: /data/i.test(c) ? 'data' : 'auto' })).filter(c => c.idx >= 0);
      // Coluna escolhida à mão: número à direita, texto à esquerda - pela
      // maioria das primeiras linhas preenchidas.
      cols.forEach(c => {
        const amostra = rows.map(r => String(r[c.idx] ?? '').trim()).filter(Boolean).slice(0, 40);
        c.numerico = amostra.length > 0 && amostra.filter(v => /^-?[\d.,\s]+$/.test(v)).length >= amostra.length * 0.8;
      });
    } else {
      cols = [];
      const add = c => { if (c.idx >= 0) cols.push(c); };
      add({ id: 'cp', rotulo: 'Código', idx: ix.cp, tipo: 'cod' });
      if (quantosDistintos(rows, ix.obra) > 1) add({ id: 'obra', rotulo: 'Obra', idx: ix.obra, tipo: 'txt' });
      add({ id: 'nf', rotulo: 'NF', idx: ix.nf, tipo: 'cod' });
      add({ id: 'volume', rotulo: 'Volume', unidade: 'm³', idx: ix.volume, tipo: 'vol' });
      if (quantosDistintos(rows, ix.produto) > 1) add({ id: 'produto', rotulo: 'Produto', idx: ix.produto, tipo: 'txt', largo: true });
      add({ id: 'data', rotulo: 'Moldagem', idx: ix.data, tipo: 'data' });
      const g7 = [
        { id: 'data7', rotulo: 'Ruptura', idx: ix.data7, tipo: 'data' },
        { id: 'tnf7', rotulo: 'Carga', unidade: 'tf', idx: ix.tnf7, tipo: 'carga' },
        { id: 'mpa7', rotulo: 'Resistência', unidade: 'MPa', idx: ix.mpa7, tipo: 'mpa' },
      ].filter(c => c.idx >= 0);
      if (g7.some(c => c.tipo !== 'data')) g7.forEach(c => cols.push(Object.assign(c, { grupo: '7 dias' })));
      const dois = ix.mpa28b >= 0;
      [
        { id: 'data28', rotulo: 'Ruptura', idx: ix.data28, tipo: 'data' },
        { id: 'tnf28', rotulo: dois && ix.tnf28b >= 0 ? 'Carga CP 1' : 'Carga', unidade: 'tf', idx: ix.tnf28, tipo: 'carga' },
        { id: 'tnf28b', rotulo: 'Carga CP 2', unidade: 'tf', idx: ix.tnf28b, tipo: 'carga' },
        { id: 'mpa28', rotulo: dois ? 'Resist. CP 1' : 'Resistência', unidade: 'MPa', idx: ix.mpa28, tipo: 'mpa', par: dois ? ix.mpa28b : -1 },
        { id: 'mpa28b', rotulo: 'Resist. CP 2', unidade: 'MPa', idx: ix.mpa28b, tipo: 'mpa', par: ix.mpa28 },
      ].filter(c => c.idx >= 0).forEach(c => cols.push(Object.assign(c, { grupo: '28 dias' })));
      if (fckVals.length > 1) cols.push({ id: 'fck', rotulo: 'fck', unidade: 'MPa', idx: -1, tipo: 'fck' });
    }

    // O resumo: com dois corpos de prova, vale o maior (ABNT NBR 12655).
    const valido = v => Number.isFinite(v) && v > 0 && v < 150;
    const exemplar = r => {
      const a = parseNum(r[ix.mpa28]), b = ix.mpa28b >= 0 ? parseNum(r[ix.mpa28b]) : NaN;
      const va = valido(a), vb = valido(b);
      return va && vb ? Math.max(a, b) : va ? a : vb ? b : NaN;
    };
    const v28 = ix.mpa28 >= 0 ? rows.map(exemplar).filter(valido) : [];
    const v7 = ix.mpa7 >= 0 ? rows.map(r => parseNum(r[ix.mpa7])).filter(valido) : [];
    const media = a => a.length ? a.reduce((s, v) => s + v, 0) / a.length : NaN;
    const m28 = media(v28);
    const sd28 = v28.length > 1 ? Math.sqrt(v28.reduce((s, v) => s + (v - m28) ** 2, 0) / (v28.length - 1)) : NaN;
    const vols = ix.volume >= 0 ? rows.map(r => parseNum(r[ix.volume])).filter(v => Number.isFinite(v) && v > 0) : [];
    const resumo = {
      exemplares: rows.length, rompidos28: v28.length,
      volume: vols.length ? vols.reduce((s, v) => s + v, 0) : NaN,
      media7: media(v7), n7: v7.length, media28: m28, sd28,
      min28: v28.length ? Math.min(...v28) : NaN, max28: v28.length ? Math.max(...v28) : NaN,
      doisCPs: ix.mpa28b >= 0,
    };

    // Campos: edição na folha > campos fixos > o que os dados dizem.
    const fixos = getFixos();
    const autoVals = {
      cliente: uniqueVal(rows, ix.cliente), produto: uniqueVal(rows, ix.produto), obra: uniqueVal(rows, ix.obra),
      fck: fckVals.length === 1 ? String(fckVals[0]).replace('.', ',') + ' MPa' : '',
    };
    // Trocou de cliente ou de planilha? As edições feitas à mão na folha
    // anterior NÃO valem para esta - CNPJ de A com o nome de B sai com cara
    // de certo, e é laudo.
    const donoAgora = (d.activeSheet || '') + ' || ' + (autoVals.cliente || '');
    if (donoDosManuais !== null && donoDosManuais !== donoAgora) ensaioManual = {};
    donoDosManuais = donoAgora;
    // Edição na folha > dados do cliente > campos fixos > o que os dados dizem.
    const nomeCliente = (ensaioManual.cliente != null && String(ensaioManual.cliente).trim())
      ? String(ensaioManual.cliente).trim() : autoVals.cliente;
    const doCliente = dadosDoCliente(nomeCliente) || {};
    const campo = f => (ensaioManual[f] != null ? ensaioManual[f]
      : (doCliente[f] != null && doCliente[f] !== '') ? doCliente[f]
      : ((fixos[f] != null && fixos[f] !== '') ? fixos[f] : (autoVals[f] || '')));
    const campos = {};
    ['cliente','cnpj','obra','endereco','cidade','contato','fone','email','produto','fck','finalidade',
     'dimensao','retificado','neoprene','prensa','numero','observacoes'].forEach(f => { campos[f] = campo(f); });
    campos.calibracao = ensaioManual.calibracao != null ? ensaioManual.calibracao : textoCalibracao(fixos);

    const misturado = [];
    if (quantosDistintos(rows, ix.cliente) > 1) misturado.push('clientes');
    if (quantosDistintos(rows, ix.produto) > 1) misturado.push('produtos');
    if (fckVals.length > 1) misturado.push('fck');

    const hoje = new Date();
    return {
      d, H, rows, ix, cols, fckRow, fckVals, resumo, campos, misturado, fixos,
      nomeCliente, clienteCadastrado: !!dadosDoCliente(nomeCliente),
      emissao: hoje.toLocaleDateString('pt-BR'),
      emissaoExtenso: hoje.toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' }),
    };
  }

  function valorCelula(m, c, r){
    if (c.tipo === 'fck') { const f = m.fckRow(r); return f ? numero(f, 'fck') : ''; }
    const v = r[c.idx];
    if (c.tipo === 'data') return fmtDate(v ?? '');
    if (c.tipo === 'mpa' || c.tipo === 'carga' || c.tipo === 'vol') return numero(v, c.tipo);
    if (c.tipo === 'auto') { const n = parseNum(v); return Number.isFinite(n) && /^[\s\d.,\-]+$/.test(String(v)) ? fmtNum(v) : esc(v ?? ''); }
    return esc(v ?? '');
  }
  // Para o Excel: número vira número, o resto texto.
  function valorCru(m, c, r){
    if (c.tipo === 'fck') { const f = parseNum(m.fckRow(r)); return Number.isFinite(f) ? f : ''; }
    const v = r[c.idx];
    if (c.tipo === 'data') return fmtDate(v ?? '').replace(/&[a-z#0-9]+;/gi, '');
    if (c.tipo === 'mpa' || c.tipo === 'carga' || c.tipo === 'vol') {
      const n = parseNum(v); if (!Number.isFinite(n) || n === 0) return '';
      const casas = (CASAS[c.tipo] || [0, 2])[1]; return Math.round(n * 10 ** casas) / 10 ** casas;
    }
    if (c.tipo === 'auto') { const n = parseNum(v); return Number.isFinite(n) && /^[\s\d.,\-]+$/.test(String(v)) ? n : String(v ?? ''); }
    return String(v ?? '');
  }

  const ROTULOS = {
    cliente: 'Cliente', cnpj: 'CNPJ', obra: 'Obra', endereco: 'Endereço', cidade: 'Cidade', contato: 'Contato',
    fone: 'Telefone', email: 'E-mail', produto: 'Produto', fck: 'fck especificado', finalidade: 'Finalidade',
    dimensao: 'Dimensão', retificado: 'Retificado', neoprene: 'Neoprene', prensa: 'Prensa', numero: 'Nº',
    observacoes: 'Observações', calibracao: 'Calibração da prensa',
  };

  // Um campo da folha. Na tela é editável e aparece mesmo vazio (com o lugar
  // marcado); impresso, campo vazio simplesmente não existe - uma folha cheia
  // de traços anuncia o que não tem.
  function campoHtml(m, f, tela, extra){
    const v = m.campos[f] || '';
    if (!tela && !String(v).trim()) return '';
    const val = tela
      ? `<textarea class="cert-inp" data-f="${f}" rows="1" placeholder="—" spellcheck="false">${esc(v)}</textarea>`
      : esc(v).replace(/\n/g, '<br>');
    return `<div class="cert-campo${extra ? ' ' + extra : ''}"><dt>${ROTULOS[f]}</dt><dd>${val}</dd></div>`;
  }

  function kpi(rotulo, valor, unidade, nota, principal){
    return `<div class="cert-kpi${principal ? ' principal' : ''}"><dt>${rotulo}</dt><dd>${valor}${unidade ? `<small>${unidade}</small>` : ''}</dd>${nota ? `<dd class="nota">${nota}</dd>` : ''}</div>`;
  }
  const n1 = v => Number.isFinite(v) ? v.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) : '—';

  function certificadoHtml(m, marca, opts){
    const tela = !!opts.tela;
    const r = m.resumo;
    const fx = m.fixos;

    const marcaHtml = marca.modo === 'empresa'
      ? (marca.logo ? `<img class="cert-logo" src="${marca.logo}" alt="${esc(marca.nomeEmpresa)}">`
                    : `<div class="cert-nome-empresa">${esc(marca.nomeEmpresa || 'Laboratório')}</div>`)
      : `<div class="cert-selo">${LUPA}</div><div class="cert-palavra">CONCRESTATS<small>Controle tecnológico do concreto</small></div>`;

    const numeroHtml = tela
      ? `<div><dt>Nº</dt><dd><textarea class="cert-inp" data-f="numero" rows="1" placeholder="—" spellcheck="false">${esc(m.campos.numero)}</textarea></dd></div>`
      : (String(m.campos.numero).trim() ? `<div><dt>Nº</dt><dd>${esc(m.campos.numero)}</dd></div>` : '');

    const blocoCliente = (() => {
      const nome = tela
        ? `<textarea class="cert-inp" data-f="cliente" rows="1" placeholder="Nome do cliente" spellcheck="false">${esc(m.campos.cliente)}</textarea>`
        : esc(m.campos.cliente);
      const campos = ['cnpj','obra','endereco','cidade','contato','fone','email'].map(f => campoHtml(m, f, tela)).join('');
      if (!tela && !String(m.campos.cliente).trim() && !campos) return '';
      return `<div class="cert-bloco"><h2>Cliente</h2>${tela || String(m.campos.cliente).trim() ? `<p class="cert-cliente">${nome}</p>` : ''}<dl class="cert-campos duas">${campos}</dl></div>`;
    })();
    const bloco = (titulo, lista) => {
      const campos = lista.map(f => campoHtml(m, f, tela)).join('');
      return campos ? `<div class="cert-bloco"><h2>${titulo}</h2><dl class="cert-campos">${campos}</dl></div>` : '';
    };
    const blocos = [blocoCliente, bloco('Concreto', ['produto','fck','finalidade']),
                    bloco('Corpos de prova e ensaio', ['dimensao','retificado','neoprene','prensa'].concat(previaLigada ? ['calibracao'] : []))].filter(Boolean);

    const kpis = [
      kpi('Exemplares', r.exemplares.toLocaleString('pt-BR'), '', r.rompidos28 === r.exemplares ? 'todos rompidos aos 28 dias' : `${r.rompidos28.toLocaleString('pt-BR')} rompidos aos 28 dias`),
      Number.isFinite(r.volume) ? kpi('Volume', r.volume.toLocaleString('pt-BR', { maximumFractionDigits: 1 }), 'm³', 'concretado') : '',
      r.n7 ? kpi('Média aos 7 dias', n1(r.media7), 'MPa', `${r.n7.toLocaleString('pt-BR')} resultados`) : '',
      kpi('Média aos 28 dias', n1(r.media28), 'MPa', r.doisCPs ? 'valor do exemplar' : `${r.rompidos28.toLocaleString('pt-BR')} resultados`, true),
      Number.isFinite(r.sd28) ? kpi('Desvio padrão', n1(r.sd28), 'MPa', 'aos 28 dias') : '',
      Number.isFinite(r.min28) ? kpi('Mínimo · máximo', `${n1(r.min28)} – ${n1(r.max28)}`, 'MPa', 'aos 28 dias') : '',
    ].filter(Boolean).join('');

    // Cabeçalho da tabela em dois andares quando há grupos (7 e 28 dias).
    const cols = m.cols;
    const temGrupo = cols.some(c => c.grupo);
    const alinh = c => c.tipo === 'txt' || c.tipo === 'cod' || (c.tipo === 'auto' && !c.numerico) ? 't' : c.tipo === 'data' ? 'd' : '';
    const cls = (c, i) => [alinh(c), c.grupo && (i === 0 || cols[i - 1].grupo !== c.grupo) ? 'ini' : '', c.tipo === 'cod' ? 'cod' : '', c.largo ? 'largo' : ''].filter(Boolean).join(' ');
    const rotuloTh = c => `${esc(c.rotulo)}${c.unidade ? `<small>${c.unidade}</small>` : ''}`;
    let thead = '';
    if (temGrupo) {
      let a = '', b = '';
      for (let i = 0; i < cols.length; i++) {
        const c = cols[i];
        if (!c.grupo) { a += `<th rowspan="2" class="${cls(c, i)}">${rotuloTh(c)}</th>`; continue; }
        if (i === 0 || cols[i - 1].grupo !== c.grupo) {
          let n = 1; while (i + n < cols.length && cols[i + n].grupo === c.grupo) n++;
          a += `<th colspan="${n}" class="grupo ini"><span>${esc(c.grupo)}</span></th>`;
        }
        b += `<th class="${cls(c, i)}">${rotuloTh(c)}</th>`;
      }
      thead = `<tr>${a}</tr><tr>${b}</tr>`;
    } else {
      thead = `<tr>${cols.map((c, i) => `<th class="${cls(c, i)}">${rotuloTh(c)}</th>`).join('')}</tr>`;
    }
    const linhas = [];
    const mostrar = tela
      ? m.rows.slice(paginaTela * EXEMPLARES_POR_PAGINA, (paginaTela + 1) * EXEMPLARES_POR_PAGINA)
      : m.rows;
    // Só na TELA: valor que o concreto não produz, ou data depois da emissão,
    // é quase sempre digitação - marcado para conferir antes de emitir. No
    // papel o valor sai como está na planilha: o certificado não corrige dado.
    const hojeFim = new Date(); hojeFim.setHours(23, 59, 59, 999);
    const dataBR = t => { const x = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(t); return x ? new Date(+x[3], +x[2] - 1, +x[1]) : null; };
    const suspeito = (c, v) => {
      if (!tela || v === '') return '';
      if (c.tipo === 'mpa' && parseNum(v) > 120) return 'resistência acima do que o concreto dessa usina alcança';
      if (c.tipo === 'carga' && parseNum(v) > 95) return 'carga que daria mais de 120 MPa num CP de 10 cm';
      if (c.tipo === 'data') { const dt = dataBR(v); if (dt && dt > hojeFim) return 'data depois de hoje'; }
      return '';
    };
    // O aviso conta a planilha inteira, nao so' a pagina que esta' na tela.
    if (tela) m.rows.forEach(row => cols.forEach(c => {
      if (suspeito(c, valorCelula(m, c, row))) m.suspeitos = (m.suspeitos || 0) + 1;
    }));
    mostrar.forEach(row => {
      linhas.push('<tr>' + cols.map((c, i) => {
        let v = valorCelula(m, c, row);
        let extra = '';
        const porque = suspeito(c, v);
        if (porque) extra += ' suspeito';
        // Com dois CPs, o maior dos dois é o valor do exemplar: em destaque.
        if (c.tipo === 'mpa' && c.par >= 0) {
          const a = parseNum(row[c.idx]), b = parseNum(row[c.par]);
          if (Number.isFinite(a) && Number.isFinite(b) && a > 0 && b > 0 && a >= b && (a > b || c.id === 'mpa28')) extra = ' exemplar';
        }
        if (v === '' && c.tipo !== 'txt') v = '<span class="nulo">–</span>';
        return `<td class="${cls(c, i)}${extra}"${porque ? ` title="Confira: ${porque}"` : ''}>${v}</td>`;
      }).join('') + '</tr>');
    });

    const notas = [
      'Resultados restritos aos corpos de prova ensaiados, identificados na tabela acima.',
      'Resistência à compressão: carga de ruptura dividida pela área da seção transversal do corpo de prova (ABNT NBR 5739).',
      r.doisCPs ? 'Em destaque, o valor do exemplar: a maior resistência entre os corpos de prova do mesmo exemplar (ABNT NBR 12655).' : '',
      'Este relatório só pode ser reproduzido por completo.',
    ].filter(Boolean).map(t => `<li>${t}</li>`).join('');
    const obs = tela
      ? `<div class="cert-obs"><span class="cert-rotulo">Observações</span><textarea class="cert-inp" data-f="observacoes" rows="1" placeholder="—" spellcheck="false">${esc(m.campos.observacoes)}</textarea></div>`
      : (String(m.campos.observacoes).trim() ? `<div class="cert-obs"><span class="cert-rotulo">Observações</span>${esc(m.campos.observacoes).replace(/\n/g, '<br>')}</div>` : '');

    const local = fx.local ? esc(fx.local) + ', ' : '';
    const nome = fx.responsavel ? esc(fx.responsavel) : (tela ? '<span class="cert-dica">nome em Campos fixos</span>' : '');
    const registro = fx.registro ? `<p class="cert-registro">${esc(fx.registro)}</p>` : '';

    const rodapeEmpresa = [marca.nomeEmpresa ? `<b>${esc(marca.nomeEmpresa)}</b>` : '', esc(fx.empresa_endereco || ''), esc(fx.empresa_contato || '')]
      .filter(Boolean).join(' &nbsp;·&nbsp; ');

    return `
<article class="cert cert--${marca.modo}" style="${varsDoTema(marca.tema)}">
  <header class="cert-cab">
    <div class="cert-marca">${marcaHtml}</div>
    <div class="cert-doc">
      <div class="cert-doc-tipo">Relatório de ensaio</div>
      <dl class="cert-doc-meta">${numeroHtml}<div><dt>Emissão</dt><dd>${m.emissao}</dd></div></dl>
    </div>
  </header>
  <div class="cert-faixa"></div>
  <section class="cert-titulo">
    <div>
      <p class="cert-kicker">Resistência à compressão</p>
      <h1>Ensaio de compressão axial de corpos de prova cilíndricos</h1>
      <p class="cert-sub">Moldagem e cura conforme ABNT NBR 5738:2015 &nbsp;·&nbsp; Ensaio conforme ABNT NBR 5739:2018</p>
    </div>
    ${marca.nomeEmpresa && marca.modo === 'concrestats' ? `<div class="cert-emitente"><span class="cert-rotulo">Emitente</span><b>${esc(marca.nomeEmpresa)}</b></div>` : ''}
  </section>
  ${blocos.length ? `<section class="cert-blocos" style="grid-template-columns:${blocos.length === 3 ? '1.6fr 1.05fr .85fr' : blocos.length === 2 ? '1.5fr 1fr' : '1fr'}">${blocos.join('')}</section>` : ''}
  <dl class="cert-resumo">${kpis}</dl>
  <section class="cert-resultados">
    <h2 class="cert-secao">Resultados<span>${m.rows.length.toLocaleString('pt-BR')} ${m.rows.length === 1 ? 'exemplar' : 'exemplares'}</span></h2>
    <table class="cert-tabela"><thead>${thead}</thead><tbody>${linhas.join('')}</tbody></table>
  </section>
  ${secaoConformidade()}
  <div class="cert-fim">
  <section class="cert-fecho">
    <div class="cert-notas"><h2 class="cert-secao">Notas</h2><ol>${notas}</ol>${obs}</div>
    <div class="cert-assinatura">
      <p class="cert-local">${local}${m.emissaoExtenso}</p>
      <div class="cert-traco"></div>
      <p class="cert-nome">${nome}</p>
      <p class="cert-cargo">Responsável técnico</p>
      ${registro}
    </div>
  </section>
  <footer class="cert-rodape">
    <div>${rodapeEmpresa}</div>
    <div class="cert-software">${LUPA}<span>Concrestats</span></div>
  </footer>
  </div>
</article>`;
  }

  /* -- conformidade junto do ensaio ---------------------------------------
   * O relatorio de conformidade sozinho continua na Previsao. Aqui ele vem por
   * padrao junto do ensaio, com a mesma conta da Previsao e os mesmos filtros.
   */
  function incluiConformidade(){ return previaLigada && getFixos().conformidade !== false; }

  function dadosDeConformidade(){
    const P = window.PrevisaoModule;
    if (!incluiConformidade() || !P || typeof P._analisar !== 'function') return null;
    let lista;
    try { lista = P._analisar() || []; } catch (e) { return null; }
    const julgadas = lista.filter(a => Number.isFinite(a.folga)).sort((x, y) => x.folga - y.folga);
    if (!julgadas.length) return null;
    const uso = P._colunasEmUso ? P._colunasEmUso() : null;
    return { rotulo: uso && uso.porVersao ? 'Versão' : 'Receita', julgadas, deFora: lista.length - julgadas.length };
  }
  const sinal1 = v => (v >= 0 ? '+' : '') + n1(v);
  const fck0 = v => Number.isFinite(v) ? v.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) : '—';
  const notaConformidade = c => 'Critério da ABNT NBR 12655: fck estimado = média - 1,65 x desvio padrão.' +
    (c.deFora ? ' ' + c.deFora + ' sem histórico ou sem fck ficaram de fora da conta.' : '');

  function secaoConformidade(){
    const c = dadosDeConformidade();
    if (!c) return '';
    const fora = c.julgadas.filter(a => a.folga < 0).length;
    const esq = 'style="text-align:left"';
    return `<section class="cert-resultados cert-conformidade">
    <h2 class="cert-secao">Conformidade<span>${fora} de ${c.julgadas.length} abaixo do fck</span></h2>
    <table class="cert-tabela"><thead><tr><th ${esq}>${c.rotulo}</th><th>Ensaios</th><th>fck pedido</th><th>Média</th><th>Desvio</th><th>fck estimado</th><th>Folga</th><th ${esq}>Situação</th></tr></thead>
    <tbody>${c.julgadas.map(a => `<tr><td ${esq}>${esc(a.nome)}</td><td>${a.n}</td><td>${fck0(a.alvo.valor)}</td><td>${n1(a.media)}</td><td>${n1(a.desvio)}</td><td>${n1(a.fckEst)}</td><td>${sinal1(a.folga)}</td><td ${esq}>${a.folga < 0 ? 'Não atende' : 'Atende'}</td></tr>`).join('')}</tbody></table>
    <p class="cert-conf-nota">${notaConformidade(c)}</p>
  </section>`;
  }

  function abaDeConformidade(){
    const c = dadosDeConformidade();
    if (!c) return null;
    const d = (v, k) => Number.isFinite(v) ? +v.toFixed(k) : '';
    return { nome: 'Conformidade', aoa: [[c.rotulo, 'Ensaios', 'fck pedido', 'Média', 'Desvio', 'fck estimado', 'Folga', 'Situação']]
      .concat(c.julgadas.map(a => [a.nome, a.n, d(a.alvo.valor, 1), d(a.media, 2), d(a.desvio, 2), d(a.fckEst, 2), d(a.folga, 2), a.folga < 0 ? 'Não atende' : 'Atende']))
      .concat([[], [notaConformidade(c)]]) };
  }

  function paginadorHtml(total){
    const paginas = Math.ceil(total / EXEMPLARES_POR_PAGINA);
    if (paginas <= 1) return '';
    const ini = paginaTela * EXEMPLARES_POR_PAGINA + 1;
    const fim = Math.min(total, ini + EXEMPLARES_POR_PAGINA - 1);
    const botao = (acao, txt, dica, off) => `<button type="button" data-pag="${acao}" title="${dica}" aria-label="${dica}"${off ? ' disabled' : ''}>${txt}</button>`;
    const noFim = paginaTela >= paginas - 1;
    return `<div class="rep-paginas" id="rep-paginas">` +
      botao('ini', '«', 'Primeira página', paginaTela === 0) + botao('ant', '‹', 'Página anterior', paginaTela === 0) +
      `<span>Página <input id="rep-pag-n" type="text" inputmode="numeric" value="${paginaTela + 1}" aria-label="Ir para a página"> de ${paginas.toLocaleString('pt-BR')}</span>` +
      botao('prox', '›', 'Próxima página', noFim) + botao('fim', '»', 'Última página', noFim) +
      `<small>exemplares ${ini.toLocaleString('pt-BR')} a ${fim.toLocaleString('pt-BR')} de ${total.toLocaleString('pt-BR')} - a impressão e o Excel levam todos</small></div>`;
  }

  function ligarPaginador(total){
    const caixa = $('rep-paginas');
    if (!caixa) return;
    const paginas = Math.ceil(total / EXEMPLARES_POR_PAGINA);
    const ir = p => { paginaTela = Math.min(paginas - 1, Math.max(0, p)); render(); };
    caixa.addEventListener('click', e => {
      const b = e.target.closest('[data-pag]');
      if (!b || b.disabled) return;
      ir({ ini: 0, ant: paginaTela - 1, prox: paginaTela + 1, fim: paginas - 1 }[b.dataset.pag]);
    });
    const campo = $('rep-pag-n');
    campo.addEventListener('change', () => { const n = parseInt(campo.value, 10); if (n > 0) ir(n - 1); else campo.value = paginaTela + 1; });
    campo.addEventListener('keydown', e => { if (e.key === 'Enter') campo.blur(); });
  }

  function garantirEstilo(){
    let s = document.getElementById('cert-estilo');
    if (!s) { s = document.createElement('style'); s.id = 'cert-estilo'; document.head.appendChild(s); }
    if (s.textContent !== CERT_CSS) s.textContent = CERT_CSS;
  }

  // A folha tem 297 mm; numa janela menor ela encolhe inteira, sem rolagem
  // lateral - o que se vê é a página como vai sair.
  function ajustarEscala(){
    const body = $('rep-body');
    const folha = body && body.querySelector('.cert');
    if (!folha) return;
    folha.style.zoom = '';
    const cabe = (body.clientWidth - 40) / folha.offsetWidth;
    folha.style.zoom = cabe < 1 ? String(Math.max(0.45, cabe)) : '';
  }

  let desenhando = 0;
  async function render(){
    const body = $('rep-body');
    if(!body) return;
    const m = montarModelo();
    if(!m){
      body.innerHTML = '<div class="graf-empty-state"><div class="empty-icon">◈</div><p>Sem planilha ativa</p><p class="empty-sub">Importe a planilha de rompimentos em Planilhas.</p></div>';
      return;
    }
    if(!m.cols.length){
      body.innerHTML = '<div class="graf-empty-state"><div class="empty-icon">◈</div><p>Não encontrei colunas válidas para o relatório.</p><p class="empty-sub">Confira em Planilhas › Colunas de onde sai cada informação.</p></div>';
      return;
    }
    const vez = ++desenhando;
    if (identidade() === 'empresa' && !marcaPlanilha.buscando) buscarLogoDaPlanilha();
    const marca = await marcaAtual();
    if (vez !== desenhando) return;          // outra atualização passou na frente
    ultimoModelo = m;
    lastReport = {
      grupos: m.cols.map(c => c.grupo || ''),
      headers: m.cols.map(c => c.rotulo + (c.unidade ? ` (${c.unidade})` : '')),
      data: m.rows.map(r => m.cols.map(c => valorCru(m, c, r))),
    };
    garantirEstilo();
    marcarVisual();

    // Avisos da TELA - ficam fora da folha e nunca saem impressos.
    const avisos = [];
    if (m.misturado.length) avisos.push(`<div class="rep-aviso"><b>Esta seleção tem ${m.misturado.join(', ')} diferentes.</b> O certificado é emitido para um cliente e um produto - filtre por eles antes de imprimir, ou preencha os campos à mão.</div>`);
    if (!marca.nomeEmpresa) avisos.push(`<div class="rep-aviso rep-aviso-leve">Falta a <b>empresa emissora</b>: preencha em <b>Campos fixos</b> - ela sai no cabeçalho e no rodapé de cada página.</div>`);
    if (marca.modo === 'empresa' && !marca.logo && marcaPlanilha.procurou) avisos.push(`<div class="rep-aviso rep-aviso-leve">Não achei logotipo nesta planilha. Envie o da empresa em <b>Campos fixos</b> - as cores do relatório saem dele.</div>`);
    if (marca.modo === 'empresa' && marca.origemLogo === 'planilha') avisos.push(`<div class="rep-aviso rep-aviso-leve">Logotipo e cores tirados da própria planilha aberta.</div>`);
    if (previaLigada) {
      const cal = validadeCalibracao(m.fixos);
      if (cal && cal.dias < 0) avisos.push(`<div class="rep-aviso"><b>A calibração da prensa venceu em ${cal.data}.</b> Ensaio feito com a prensa fora da calibração não tem validade - atualize o certificado em <b>Campos fixos</b>.</div>`);
      else if (cal && cal.dias <= DIAS_AVISO_CALIBRACAO) avisos.push(`<div class="rep-aviso rep-aviso-leve">A calibração da prensa vence ${cal.dias === 0 ? 'hoje' : `em ${cal.dias} dia${cal.dias === 1 ? '' : 's'}`} (${cal.data}).</div>`);
      if (m.nomeCliente && !m.misturado.includes('clientes')) {
        avisos.push(m.clienteCadastrado
          ? `<div class="rep-aviso rep-aviso-leve rep-cliente"><span>CNPJ, obra, endereço e contato de <b>${esc(m.nomeCliente)}</b> vieram do cadastro do cliente.</span><button type="button" class="rep-cliente-btn" id="rep-cliente-dados">Editar dados do cliente</button></div>`
          : `<div class="rep-aviso rep-aviso-leve rep-cliente"><span>Os dados de <b>${esc(m.nomeCliente)}</b> - CNPJ, obra, endereço, contato - podem ficar guardados para os próximos relatórios dele.</span><button type="button" class="rep-cliente-btn" id="rep-cliente-dados">Guardar dados deste cliente</button></div>`);
      }
    }

    m.suspeitos = 0;
    if (m.rows.length !== totalDaTela) { totalDaTela = m.rows.length; paginaTela = 0; }
    const folha = certificadoHtml(m, marca, { tela: true });
    if (m.suspeitos) avisos.unshift(`<div class="rep-aviso"><b>${m.suspeitos} ${m.suspeitos === 1 ? 'valor parece' : 'valores parecem'} digitação errada</b> - marcados em vermelho na folha (passe o mouse para ver o motivo). Confira na planilha antes de emitir: o certificado imprime o que está lá.</div>`);
    body.innerHTML = `<div class="rep-mesa">${avisos.join('')}${paginadorHtml(m.rows.length)}${folha}</div>`;
    ligarPaginador(m.rows.length);
    const caixaConf = $('rep-conformidade');
    if (caixaConf) caixaConf.checked = getFixos().conformidade !== false;
    $('rep-cliente-dados')?.addEventListener('click', () => dadosClienteModal(m));
    const fitInp = t => { t.style.height = 'auto'; t.style.height = t.scrollHeight + 'px'; };
    body.querySelectorAll('.cert-inp').forEach(inp => {
      inp.addEventListener('input', () => { ensaioManual[inp.dataset.f] = inp.value; if (ultimoModelo) ultimoModelo.campos[inp.dataset.f] = inp.value; fitInp(inp); });
      fitInp(inp);
    });
    ajustarEscala();
    requestAnimationFrame(() => { body.scrollTop = 0; });
  }

  function marcarVisual(){
    const v = identidade();
    document.querySelectorAll('#rep-visual button[data-visual]').forEach(b => {
      b.classList.toggle('on', b.dataset.visual === v);
      b.setAttribute('aria-pressed', b.dataset.visual === v ? 'true' : 'false');
    });
  }

  /* -- documento: impressão e HTML --------------------------------------- */
  function lerEdicoesDaTela(){
    document.querySelectorAll('#rep-body .cert-inp').forEach(i => { ensaioManual[i.dataset.f] = i.value; });
  }

  async function documentoCompleto(){
    lerEdicoesDaTela();
    const m = montarModelo();
    if (!m) return null;
    const marca = await marcaAtual();
    const titulo = 'Ensaio de compressão' + (m.campos.cliente ? ' - ' + m.campos.cliente : '');
    return { m, html: `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>${esc(titulo)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>${CERT_CSS}${paginaCss(m, marca)}</style></head><body>${certificadoHtml(m, marca, { tela: false })}${AJUSTE_JS}</body></html>` };
  }

  async function confirmarTamanho(m){
    if (m.misturado.length && window.perguntar) {
      const ok = await window.perguntar('Seleção misturada',
        `Esta seleção tem ${m.misturado.join(', ')} diferentes, e o certificado é de um cliente e um produto. Continuar assim mesmo?`, 'Continuar');
      if (!ok) return false;
    }
    if (m.rows.length > 600 && window.perguntar) {
      // Na folha cabem menos que na tela: 4.809 exemplares deram 182 páginas.
      const paginas = Math.ceil(m.rows.length / 26.4);
      return await window.perguntar('Documento grande',
        `São ${m.rows.length.toLocaleString('pt-BR')} exemplares - perto de ${paginas.toLocaleString('pt-BR')} páginas. Filtrar antes costuma ser o certo. Continuar assim mesmo?`, 'Continuar');
    }
    return true;
  }

  // O WebView2 não abre janela nova nem about:blank: imprime por um quadro
  // com srcdoc, fora da vista (mas com tamanho - 0x0 sai em branco).
  async function imprimir(){
    const doc = await documentoCompleto();
    if (!doc) { aviso('Abra uma planilha primeiro', 'error'); return; }
    if (!(await confirmarTamanho(doc.m))) return;
    const antigo = $('rep-quadro-impressao');
    if (antigo) antigo.remove();
    const q = document.createElement('iframe');
    q.id = 'rep-quadro-impressao';
    q.setAttribute('aria-hidden', 'true');
    q.style.cssText = 'position:fixed;right:0;bottom:0;width:1123px;height:794px;opacity:0;pointer-events:none;border:0;z-index:-1;';
    document.body.appendChild(q);
    let saiu = false;
    const vai = async () => {
      if (saiu) return; saiu = true;
      try {
        const fontes = q.contentDocument && q.contentDocument.fonts;
        if (fontes && fontes.ready) await Promise.race([fontes.ready, new Promise(r => setTimeout(r, 1500))]);
        try { if (q.contentWindow.__ajustar) q.contentWindow.__ajustar(); } catch (e) { /* sem ajuste, imprime igual */ }
        q.contentWindow.focus();
        q.contentWindow.print();
        setTimeout(() => { try { q.remove(); } catch (e) { /* já foi */ } }, 2000);
      } catch (e) {
        try { q.remove(); } catch (e2) { /* já foi */ }
        aviso('Não consegui abrir a impressão do relatório', 'error');
      }
    };
    q.addEventListener('load', () => setTimeout(vai, 250));
    q.srcdoc = doc.html;
    setTimeout(vai, 3000);
  }

  function nomeDoArquivo(m, ext){
    const base = 'ensaio_de_compressao' + (m.campos.cliente ? '_' + m.campos.cliente : '');
    return base.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w\-]+/g, '_').replace(/_+/g, '_').slice(0, 80) + '.' + ext;
  }

  async function exportarHtml(){
    const doc = await documentoCompleto();
    if (!doc) { aviso('Abra uma planilha primeiro', 'error'); return; }
    if (!(await confirmarTamanho(doc.m))) return;
    const nome = nomeDoArquivo(doc.m, 'html');
    // No app instalado o download do navegador não pergunta onde salvar e o
    // arquivo "sumia": diálogo do Windows e gravação pelo servidor.
    if (window.pywebview?.api?.save_file_dialog) {
      try {
        const caminho = await window.pywebview.api.save_file_dialog(nome);
        if (!caminho) return;
        const b64 = btoa(unescape(encodeURIComponent(doc.html)));
        const j = await fetch('/api/salvar_binario', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ path: caminho, base64: b64 }) }).then(r => r.json());
        aviso(j.success ? `Relatório salvo em "${String(j.path).split(/[\\\/]/).pop()}"` : 'Erro ao salvar: ' + (j.error || ''), j.success ? 'success' : 'error');
      } catch (e) { aviso('Falha ao salvar o relatório', 'error'); }
      return;
    }
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([doc.html], { type: 'text/html' }));
    a.download = nome; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  /* -- Excel ------------------------------------------------------------- */
  // A mesma folha, em células: cabeçalho, campos, resumo, a tabela em dois
  // andares e o fecho. O servidor aplica a formatação (formato: 'certificado').
  function montarAoa(m){
    const aoa = [], fmt = { mesclas: [], titulo: [], rotulos: [], secoes: [], grupos: -1, cabecalho: -1, dados: [-1, -1], ncol: 0 };
    const ncol = Math.max(8, m.cols.length);
    fmt.ncol = ncol;
    const linha = arr => { aoa.push(arr); return aoa.length - 1; };
    fmt.titulo.push(linha(['ENSAIO DE COMPRESSÃO AXIAL DE CORPOS DE PROVA CILÍNDRICOS']));
    fmt.mesclas.push([aoa.length - 1, 0, aoa.length - 1, ncol - 1]);
    const sub = linha(['ABNT NBR 5738:2015 - moldagem e cura  ·  ABNT NBR 5739:2018 - ensaio de compressão']);
    fmt.mesclas.push([sub, 0, sub, ncol - 1]); fmt.secoes.push(-1);
    const emp = String(getFixos().empresa || '').trim();
    linha(['Emitente', emp, '', '', 'Emissão', m.emissao].concat(m.campos.numero ? ['Nº', m.campos.numero] : []));
    fmt.rotulos.push([aoa.length - 1, [0, 4, 6]]);
    linha([]);
    const pares = ['cliente','cnpj','obra','endereco','cidade','contato','fone','email','produto','fck','finalidade','dimensao','retificado','neoprene','prensa','calibracao']
      .filter(f => String(m.campos[f] || '').trim()).map(f => [ROTULOS[f], m.campos[f]]);
    for (let i = 0; i < pares.length; i += 2) {
      const a = pares[i], b = pares[i + 1];
      const r = linha(b ? [a[0], a[1], '', '', b[0], b[1]] : [a[0], a[1]]);
      fmt.rotulos.push([r, b ? [0, 4] : [0]]);
    }
    linha([]);
    const r = m.resumo;
    const res = [['Exemplares', r.exemplares], ['Volume (m³)', Number.isFinite(r.volume) ? Math.round(r.volume * 10) / 10 : ''],
      r.n7 ? ['Média 7 dias (MPa)', Math.round(r.media7 * 10) / 10] : null,
      ['Média 28 dias (MPa)', Number.isFinite(r.media28) ? Math.round(r.media28 * 10) / 10 : ''],
      Number.isFinite(r.sd28) ? ['Desvio padrão (MPa)', Math.round(r.sd28 * 10) / 10] : null].filter(Boolean);
    fmt.resumo = [linha(res.map(x => x[0])), linha(res.map(x => x[1]))];
    linha([]);
    if (m.cols.some(c => c.grupo)) {
      fmt.grupos = linha(m.cols.map((c, i) => c.grupo && (i === 0 || m.cols[i - 1].grupo !== c.grupo) ? c.grupo : ''));
      let i = 0;
      while (i < m.cols.length) {
        const g = m.cols[i].grupo; let n = 1;
        while (g && i + n < m.cols.length && m.cols[i + n].grupo === g) n++;
        if (g && n > 1) fmt.mesclas.push([fmt.grupos, i, fmt.grupos, i + n - 1]);
        i += n;
      }
    }
    fmt.cabecalho = linha(lastReport.headers.slice());
    const ini = aoa.length;
    lastReport.data.forEach(row => aoa.push(row));
    fmt.dados = [ini, aoa.length - 1];
    fmt.numeros = m.cols.map(c => c.tipo === 'mpa' ? '0.0' : c.tipo === 'carga' ? '0.00' : c.tipo === 'vol' ? '0.0#' : c.tipo === 'fck' ? '0.#' : '');
    linha([]);
    const notas = ['Resultados restritos aos corpos de prova ensaiados.',
      'Resistência = carga de ruptura ÷ área da seção transversal (ABNT NBR 5739).',
      r.doisCPs ? 'Valor do exemplar: a maior resistência entre os CPs do mesmo exemplar (ABNT NBR 12655).' : '',
      String(m.campos.observacoes || '').trim() ? 'Observações: ' + m.campos.observacoes : ''].filter(Boolean);
    notas.forEach(t => { const k = linha([t]); fmt.mesclas.push([k, 0, k, ncol - 1]); fmt.secoes.push(k); });
    linha([]);
    const fx = getFixos();
    const a1 = linha([(fx.local ? fx.local + ', ' : '') + m.emissaoExtenso]);
    const a2 = linha(['______________________________________']);
    const a3 = linha([fx.responsavel || '']);
    const a4 = linha(['Responsável técnico' + (fx.registro ? ' · ' + fx.registro : '')]);
    fmt.assinatura = [a1, a2, a3, a4];
    [a1, a2, a3, a4].forEach(k => fmt.mesclas.push([k, 0, k, ncol - 1]));
    const rod = [emp, fx.empresa_endereco, fx.empresa_contato].filter(Boolean).join('  ·  ');
    if (rod) { const k = linha([rod]); fmt.mesclas.push([k, 0, k, ncol - 1]); fmt.rodape = k; }
    return { aoa, fmt };
  }

  async function exportarExcel(){
    lerEdicoesDaTela();
    const m = montarModelo();
    if (!m) { aviso('Abra uma planilha primeiro', 'error'); return; }
    if (!lastReport || !lastReport.data || !lastReport.data.length) { aviso('Sem dados para exportar - confira o filtro', 'error'); return; }
    const { aoa, fmt } = montarAoa(m);
    fmt.tema = (await marcaAtual()).tema;     // o Excel segue o visual escolhido
    const conf = abaDeConformidade();
    if (conf) fmt.abas = [conf];
    const nome = nomeDoArquivo(m, 'xlsx').replace(/\.xlsx$/, '');
    if (await exportAoaBackend(aoa, nome, 'Ensaio de compressão', fmt)) return;
    if (typeof XLSX === 'undefined') { aviso('Não foi possível gerar a planilha', 'error'); return; }
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!merges'] = fmt.mesclas.map(([r1, c1, r2, c2]) => ({ s: { r: r1, c: c1 }, e: { r: r2, c: c2 } }));
    ws['!cols'] = Array.from({ length: fmt.ncol }, () => ({ wch: 14 }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Ensaio de compressão');
    (fmt.abas || []).forEach(a => XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(a.aoa), a.nome));
    XLSX.writeFile(wb, nome + '.xlsx');
  }

  // Gera o .xlsx pelo backend. Com pywebview usa o diálogo "Salvar como" nativo
  // e grava no caminho escolhido; sem ele, baixa o arquivo. Retorna true se OK.
  async function exportAoaBackend(aoa, baseName, sheetName, formato){
    try{
      let path = null;
      if(window.pywebview?.api?.save_file_dialog){
        path = await window.pywebview.api.save_file_dialog(baseName + '.xlsx');
        if(!path) return true;              // usuário cancelou - nada a fazer
      }
      const r = await fetch('/api/export_aoa', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ aoa, path, sheet_name: sheetName, base_name: baseName, formato: formato || null })
      });
      if(!r.ok) return false;
      const ct = r.headers.get('content-type') || '';
      if(ct.includes('json')){
        const j = await r.json();
        if(!j.success){ aviso('Erro ao salvar: ' + (j.error || ''), 'error'); return true; }
        aviso(`Planilha salva em "${String(j.path).split(/[\\\/]/).pop()}"`, 'success');
        return true;
      }
      const blob = await r.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = baseName + '.xlsx'; a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      return true;
    }catch(_){ return false; }             // cai no SheetJS
  }

  /* -- colunas e campos fixos -------------------------------------------- */
  function chooseCols(){
    const d = data();
    if(!d || !d.headers) return;
    const current = new Set(selectedCols || defaultCols(d.headers));
    const html = '<p class="col-intro">Por padrão o relatório segue o formulário do laboratório (7 e 28 dias, os dois corpos de prova). Marque colunas aqui só para montar uma tabela diferente.</p><div class="rep-cols-box">' + d.headers.map(h => `
      <label class="rep-col-option"><input type="checkbox" class="rep-col-cb" value="${esc(h)}" ${current.has(h)?'checked':''}> <span>${esc(h)}</span></label>`).join('') + '</div>' +
      '<div class="rep-cols-acoes"><button id="rep-apply-cols" class="primary-btn">Usar estas colunas</button><button id="rep-padrao-cols" class="secondary-btn">Voltar ao formulário padrão</button></div>';
    if(window.openModal) openModal('Colunas do relatório', html, () => {}); else aviso('Não consegui abrir a seleção de colunas', 'error');
    setTimeout(() => {
      const b = $('rep-apply-cols');
      if(b) b.onclick = () => {
        selectedCols = [...document.querySelectorAll('.rep-col-cb:checked')].map(c => c.value);
        if (!selectedCols.length) selectedCols = null;
        if(window.closeModal) closeModal();
        render();
      };
      const p = $('rep-padrao-cols');
      if (p) p.onclick = () => { selectedCols = null; if (window.closeModal) closeModal(); render(); };
    }, 50);
  }

  const ROTULO_CLIENTE = { cnpj: 'CNPJ', obra: 'Obra', endereco: 'Endereço', cidade: 'Cidade', contato: 'Contato',
    fone: 'Telefone', email: 'E-mail', finalidade: 'Finalidade' };
  function dadosClienteModal(m){
    // Sem lerEdicoesDaTela() aqui: ele copia TODOS os campos da folha como se
    // tivessem sido digitados, e a calibração (ou qualquer campo fixo) mudada
    // depois deixava de chegar à folha. O que foi digitado de verdade já está
    // em ensaioManual, pelo evento de cada campo.
    const nome = m.nomeCliente;
    if (!nome || !window.openModal) return;
    const cad = dadosDoCliente(nome);
    // O que está na folha agora (editado à mão, do cadastro ou de Campos fixos)
    // já vem preenchido: quem acabou de digitar o CNPJ na folha não digita de novo.
    const valor = f => (ensaioManual[f] != null ? ensaioManual[f] : (m.campos[f] || ''));
    const body = `<p class="col-intro">Ficam guardados com o nome deste cliente e preenchem sozinhos todo relatório dele. Campos fixos continuam valendo para quem não tem cadastro.</p>
      <div class="fx-cliente-nome">${esc(nome)}</div>
      <div class="fx-grade">${CAMPOS_DO_CLIENTE.map(f => `<div class="fx-campo${f === 'endereco' ? ' largo' : ''}"><label for="cl-${f}">${ROTULO_CLIENTE[f]}</label><input id="cl-${f}" class="cl-inp" data-f="${f}" value="${esc(valor(f))}"></div>`).join('')}</div>
      ${cad ? '<div class="fx-rodape"><button type="button" class="secondary-btn" id="cl-esquecer">Esquecer este cliente</button></div>' : ''}`;
    openModal('Dados do cliente', body, () => {
      const o = { nome };
      document.querySelectorAll('.cl-inp').forEach(i => { if (i.value.trim()) o[i.dataset.f] = i.value.trim(); });
      const todos = getPorCliente();
      todos[norm(nome)] = o;
      setPorCliente(todos);
      // Na folha, estes campos passam a vir do cadastro.
      CAMPOS_DO_CLIENTE.forEach(f => { delete ensaioManual[f]; });
      if (window.closeModal) closeModal();
      render();
      aviso(`Dados de ${nome} guardados`);
    }, 'modal-fixos');
    const ok = $('modal-confirm');
    if (ok) ok.textContent = 'Guardar';
    $('cl-esquecer')?.addEventListener('click', () => {
      const todos = getPorCliente();
      delete todos[norm(nome)];
      setPorCliente(todos);
      if (window.closeModal) closeModal();
      render();
      aviso(`Cadastro de ${nome} apagado`);
    });
  }

  function secoesPrevia(fx){
    const cal = validadeCalibracao(fx);
    const selo = !cal ? ''
      : cal.dias < 0 ? `<span class="fx-selo vencida">vencida há ${-cal.dias} dia${cal.dias === -1 ? '' : 's'}</span>`
      : cal.dias <= DIAS_AVISO_CALIBRACAO ? `<span class="fx-selo perto">vence em ${cal.dias} dia${cal.dias === 1 ? '' : 's'}</span>`
      : '<span class="fx-selo ok">em dia</span>';
    const clientes = Object.entries(getPorCliente())
      .sort((a, b) => String(a[1].nome || a[0]).localeCompare(String(b[1].nome || b[0]), 'pt-BR'));
    const lista = clientes.length
      ? `<ul class="fx-clientes">${clientes.map(([k, c]) => `<li><span>${esc(c.nome || k)}</span><small>${esc(CAMPOS_DO_CLIENTE.filter(f => c[f]).map(f => ROTULO_CLIENTE[f]).join(', ') || 'sem campos')}</small><button type="button" class="fx-esquecer" data-k="${esc(k)}">Esquecer</button></li>`).join('')}</ul>`
      : '<p class="fx-nota">Nenhum cliente cadastrado ainda. Com o relatório de um cliente só na tela, use <b>Guardar dados deste cliente</b>, acima da folha.</p>';
    return `<div class="fx-secao">Calibração da prensa ${selo}</div>
      <div class="fx-grade">
        <div class="fx-campo"><label for="fx-calibracao_certificado">Nº do certificado</label><input id="fx-calibracao_certificado" class="fx-inp" data-f="calibracao_certificado" value="${esc(fx.calibracao_certificado || '')}" placeholder="ex.: 1234/2026"></div>
        <div class="fx-campo"><label for="fx-calibracao_validade">Válida até</label><input id="fx-calibracao_validade" type="date" class="fx-inp" data-f="calibracao_validade" value="${esc(fx.calibracao_validade || '')}"></div>
        <div class="fx-campo largo"><label for="fx-calibracao_laboratorio">Laboratório que calibrou</label><input id="fx-calibracao_laboratorio" class="fx-inp" data-f="calibracao_laboratorio" value="${esc(fx.calibracao_laboratorio || '')}" placeholder="opcional"></div>
      </div>
      <p class="fx-nota">Sai no relatório junto da prensa. A tela avisa ${DIAS_AVISO_CALIBRACAO} dias antes de vencer.</p>
      <div class="fx-secao">Preenchimento por cliente</div>${lista}`;
  }

  function configFixos(){
    const fx = getFixos();
    let logo = fx.logo || '';
    const inp = (f, lab, dica, largo) => `<div class="fx-campo${largo ? ' largo' : ''}"><label for="fx-${f}">${lab}</label><input id="fx-${f}" class="fx-inp" data-f="${f}" value="${esc(fx[f] || '')}"${dica ? ` placeholder="${esc(dica)}"` : ''}></div>`;
    const corAtual = fx.cor || '#2f7df0';
    const body = `
      <p class="col-intro">Ficam guardados e preenchem o relatório sozinhos. Qualquer campo ainda pode ser corrigido direto na folha.</p>
      <div class="fx-secao">Emitente</div>
      <div class="fx-grade">${inp('empresa', 'Empresa emissora', 'razão social de quem emite o relatório', true)}${inp('empresa_endereco', 'Endereço da empresa', 'rua, bairro, CEP, cidade', true)}${inp('empresa_contato', 'Telefone e e-mail da empresa', '')}${inp('local', 'Local de emissão', 'ex.: Cidade-UF')}</div>
      <div class="fx-secao">Visual da empresa</div>
      <div class="fx-marca">
        <div class="fx-logo" id="fx-logo-caixa">${logo ? `<img src="${logo}" alt="">` : '<span>sem logotipo</span>'}</div>
        <div class="fx-marca-acoes">
          <label class="secondary-btn fx-arquivo">Escolher logotipo<input type="file" id="fx-logo-arq" accept="image/png,image/jpeg,image/webp,image/gif,image/bmp"></label>
          <button type="button" class="secondary-btn" id="fx-logo-tirar">Remover</button>
          <label class="fx-cor"><input type="checkbox" id="fx-cor-auto" ${fx.cor ? '' : 'checked'}> cor tirada do logotipo</label>
          <input type="color" id="fx-cor" value="${esc(corAtual)}" ${fx.cor ? '' : 'disabled'}>
        </div>
      </div>
      <p class="fx-nota">Usado no visual <b>Empresa</b> quando a planilha aberta não traz logotipo próprio.</p>
      <div class="fx-secao">Responsável técnico</div>
      <div class="fx-grade">${inp('responsavel', 'Nome', 'ex.: Eng. Fulana de Tal')}${inp('registro', 'Registro profissional', 'ex.: CREA-MT 00000 · RNP 0000000000')}</div>
      <div class="fx-secao">Preenchimento padrão da folha</div>
      <div class="fx-grade">${inp('dimensao', 'Dimensão do CP', 'ex.: 10 x 20 cm')}${inp('retificado', 'Retificado', 'Sim / Não')}${inp('neoprene', 'Neoprene', 'ex.: 70 Shore')}${inp('prensa', 'Prensa', 'marca e capacidade')}${inp('finalidade', 'Finalidade', '')}${inp('obra', 'Obra', '')}${inp('contato', 'Contato', '')}${inp('email', 'E-mail', '')}${inp('cnpj', 'CNPJ', '')}${inp('fone', 'Telefone', '')}${inp('endereco', 'Endereço', '')}${inp('cidade', 'Cidade', '')}</div>${previaLigada ? secoesPrevia(fx) : ''}`;
    if(!window.openModal){ aviso('Indisponível', 'error'); return; }
    openModal('Campos fixos do relatório', body, () => {
      const o = { identidade: fx.identidade };
      document.querySelectorAll('.fx-inp').forEach(i => { if(i.value.trim()) o[i.dataset.f] = i.value.trim(); });
      if (logo) o.logo = logo;
      const auto = document.getElementById('fx-cor-auto');
      const cor = document.getElementById('fx-cor');
      if (auto && !auto.checked && cor) o.cor = cor.value;
      setFixos(o);
      if(window.closeModal) closeModal();
      render();
    }, 'modal-fixos');
    document.querySelectorAll('.fx-esquecer[data-k]').forEach(b => b.addEventListener('click', () => {
      const todos = getPorCliente();
      delete todos[b.dataset.k];
      setPorCliente(todos);
      b.closest('li')?.remove();
    }));
    const caixa = document.getElementById('fx-logo-caixa');
    const arq = document.getElementById('fx-logo-arq');
    if (arq) arq.addEventListener('change', () => {
      const f = arq.files && arq.files[0];
      if (!f) return;
      if (f.size > 8 * 1024 * 1024) { aviso('Imagem grande demais (máx. 8 MB)', 'error'); return; }
      const fr = new FileReader();
      fr.onload = async () => {
        const img = await carregarImagem(String(fr.result));
        if (!img) { aviso('Não consegui ler essa imagem', 'error'); return; }
        logo = reduzirImagem(img);
        if (caixa) caixa.innerHTML = `<img src="${logo}" alt="">`;
      };
      fr.readAsDataURL(f);
    });
    const tirar = document.getElementById('fx-logo-tirar');
    if (tirar) tirar.addEventListener('click', () => { logo = ''; if (caixa) caixa.innerHTML = '<span>sem logotipo</span>'; });
    const auto = document.getElementById('fx-cor-auto');
    if (auto) auto.addEventListener('change', () => { const c = document.getElementById('fx-cor'); if (c) c.disabled = auto.checked; });
  }

  function trocarVisual(v){
    const fx = getFixos();
    fx.identidade = v === 'empresa' ? 'empresa' : 'concrestats';
    setFixos(fx);
    render();
  }

  function init(){
    carregarFixosServidor();
    $('rep-refresh')?.addEventListener('click', render);
    $('rep-filter')?.addEventListener('input', render);
    $('rep-cols')?.addEventListener('click', chooseCols);
    $('rep-fixos')?.addEventListener('click', configFixos);
    $('rep-imprimir')?.addEventListener('click', imprimir);
    $('rep-export-html')?.addEventListener('click', exportarHtml);
    $('rep-export-xlsx')?.addEventListener('click', exportarExcel);
    $('rep-conformidade')?.addEventListener('change', e => {
      const f = getFixos();
      f.conformidade = !!e.target.checked;
      setFixos(f);
      render();
    });
    document.querySelectorAll('#rep-visual button[data-visual]').forEach(b => b.addEventListener('click', () => trocarVisual(b.dataset.visual)));
    window.addEventListener('concrestats:datachanged', () => { marcaPlanilha.procurou = false; setTimeout(render, 50); });
    window.addEventListener('resize', () => { clearTimeout(init._t); init._t = setTimeout(ajustarEscala, 120); });
    marcarVisual();
  }

  window.RelatorioModule = {
    onModuleEnter: render,
    // para o Modo Teste
    _modelo: () => montarModelo(),
    _documento: async () => { const d = await documentoCompleto(); return d ? d.html : ''; },
    _aoa: () => { const m = montarModelo(); return m && lastReport ? montarAoa(m) : null; },
    _coresDaImagem: coresDaImagem,
    _temaDasCores: temaDasCores,
    _identidade: identidade,
    _marcaPlanilha: () => Object.assign({}, marcaPlanilha),
  };
  document.addEventListener('DOMContentLoaded', init);
})();
