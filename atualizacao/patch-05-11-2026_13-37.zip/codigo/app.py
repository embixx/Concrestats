"""
Concrestats - servidor (Flask).

Atende a tela: abrir e salvar planilha, filtros, exportar, relatório, licença
e atualização. Sobe junto com a janela (pywebview) em 127.0.0.1:5000.

No .exe (PyInstaller, onedir) templates/ e static/ vêm de dentro do pacote
(sys._MEIPASS); uploads/ e exports/ ficam ao lado do executável.

Dependências no requirements.txt. Build: Concrestats.spec / build.bat.
"""

import os
import sys
import io
import json
import datetime
import re
import shutil
import threading
import time
import webbrowser

import atualizador
import licenca
import pagamento
import numpy as np
import pandas as pd
from flask import (
    Flask, request, jsonify, send_file, Response
)

# --------------------------------------------------------------------------
# Localização de recursos (compatível com PyInstaller)
# --------------------------------------------------------------------------
def resource_path(rel):
    """templates/ e static/ - embutidos no bundle (sys._MEIPASS quando frozen)."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, rel)


def app_dir():
    """Pasta GRAVÁVEL ao lado do executável (uploads/exports/receitas.json)."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


UPLOADS_DIR = os.path.join(app_dir(), "uploads")
EXPORTS_DIR = os.path.join(app_dir(), "exports")
RECEITAS_FILE = os.path.join(app_dir(), "receitas.json")
PREFS_FILE = os.path.join(app_dir(), "prefs.json")


def _pasta_da_sessao():
    """Onde fica a marca de sessão aberta - FORA da pasta do programa.

    O sessao.json é regravado a cada 30 segundos e a CADA TROCA DE ABA (a
    batida de coração da tela). Ficava ao lado do .exe. Na máquina do Naor,
    o .exe está em OneDrive\\Desktop - pasta de documentos do usuário,
    sincronizada, e justamente a que o Kaspersky vigia contra sequestro de
    arquivos. Ele relatou "fecha quando troca de aba", e o Kaspersky matou o
    processo por "análise de comportamento" 9 segundos depois de um sinal.

    Não tenho como provar daqui que esta gravação pesa na conta do
    antivírus. Mas ela é a única coisa que o programa faz a cada troca de
    aba, e não tem motivo nenhum para morar numa pasta de documentos
    sincronizada. Vai para %LOCALAPPDATA%, que é onde programa grava o que é
    dele, e com um nome por instalação: o Naor guarda várias versões lado a
    lado, e duas abertas ao mesmo tempo não podem dividir a mesma marca.

    O quedas.txt continua ao lado do .exe: é escrito só quando houve queda,
    e é o arquivo que a pessoa precisa achar para mandar.
    """
    base = os.environ.get("LOCALAPPDATA")
    if base:
        import hashlib
        pasta = os.path.join(base, "Concrestats")
        try:
            os.makedirs(pasta, exist_ok=True)
            marca = hashlib.sha1(os.path.normcase(app_dir()).encode("utf-8")).hexdigest()[:10]
            return os.path.join(pasta, "sessao-%s.json" % marca)
        except OSError:
            pass
    return os.path.join(app_dir(), "sessao.json")


SESSAO_FILE = _pasta_da_sessao()
# Onde a marca ficava até 22/09/2026. Uma cópia que atualiza com uma sessão
# aberta (ou caída) lá precisa ler a marca antiga uma vez, senão aquela queda
# some do registro - e o arquivo fica largado na pasta para sempre.
SESSAO_ANTIGA = os.path.join(app_dir(), "sessao.json")
QUEDAS_FILE = os.path.join(app_dir(), "quedas.txt")
os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(EXPORTS_DIR, exist_ok=True)

app = Flask(
    __name__,
    template_folder=resource_path("templates"),
    static_folder=resource_path("static"),
)
# Limite de upload (evita travar o app com um arquivo gigante). Planilhas
# reais têm poucos MB; 200 MB é folga de sobra.
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024

# --------------------------------------------------------------------------
# Estado de sessão (em memória, por session_id)
#   SESSIONS[sid] = {
#       "sheets": { nome: {"headers": [...], "data": [[...]]} },
#       "active": nome,
#       "path":   caminho do arquivo original (para "Salvar"),
#   }
# --------------------------------------------------------------------------
SESSIONS = {}

# --------------------------------------------------------------------------
# MODO DE EXECUÇÃO
#   True  = servido na web (gunicorn/host) -> recursos que tocam o disco do
#           servidor ficam BLOQUEADOS (ler caminho arbitrário, salvar no
#           arquivo de origem, recarregar). Sem isso, um usuário remoto
#           conseguiria ler/escrever arquivos da máquina que hospeda.
#   False = app de mesa (definido em __main__), tudo liberado.
# --------------------------------------------------------------------------
MODO_WEB = os.environ.get("CONCRESTATS_WEB", "1") != "0"


def _bloqueado_na_web():
    return jsonify({
        "success": False,
        "error": ("recurso disponível apenas no aplicativo instalado - "
                  "na versão web use Abrir/Adicionar para enviar o arquivo "
                  "e Exportar para baixar o resultado")
    }), 403


def edicao():
    """Le' edicao.json, ao lado do executavel. Diz o que esta cópia mostra.

    Serve para entregar o mesmo programa com abas diferentes por cliente. E'
    decisao de EXECUCAO, nao de arquivo: se eu tirasse a aba editando o
    index.html, a primeira atualizacao automatica traria ela de volta, porque
    o pacote substitui templates/ e static/ inteiros. Lido aqui, sobrevive a
    qualquer atualizacao.

    Duas origens, nesta ordem:

    1. edicao.json ao lado do executavel. Serve para ligar uma edicao numa
       instalacao que ja' existe, ou para desligar a embutida.
    2. edicao_embutida.json, gravado DENTRO do programa na hora de compilar
       (tools/build_edicao.py). E' o que faz a copia da Usinop chegar pronta:
       baixa, abre, e a aba ja' nao esta' la' - sem ninguem ter que colocar
       arquivo em pasta nenhuma.
    3. o que veio no manifesto de atualizacao, guardado em prefs. E' a via sem
       download nenhum: a instalacao pergunta se ha' versao nova, e a resposta
       ASSINADA diz tambem quais abas esta copia mostra. So' e' gravado depois
       de conferida a assinatura (ver api_atualizacao).

    A embutida fica na raiz do bundle, nao em static/ nem templates/ - que sao
    as duas pastas que o pacote de atualizacao substitui inteiras. Por isso a
    atualizacao nao a apaga.

    Sem nenhum dos dois, nada e' escondido - que e' o comportamento de sempre.
    """
    d = _edicao_bruta()
    if d is None:
        return {"nome": "", "ocultar": []}
    ocultar = d.get("ocultar") or []
    if not isinstance(ocultar, list):
        ocultar = []
    return {"nome": str(d.get("nome") or ""),
            "ocultar": [str(x).strip().lower() for x in ocultar if str(x).strip()]}


def previa():
    """Recursos em PREVIA: o que ainda esta' sendo testado so' aparece na copia
    de quem testa.

    O canal estavel serve o testador e os clientes ao mesmo tempo. Uma tela
    nova pela metade nao pode cair no laboratorio de um cliente so' porque
    saiu na mesma atualizacao. A edicao "Completa" e' a do testador; qualquer
    outra liga com "previa": true no proprio json. Sem edicao nenhuma, fica
    desligada - e' o comportamento que o cliente ja' conhece.
    """
    forcada = os.environ.get("CONCRE_PREVIA")
    if forcada is not None:
        return forcada == "1"
    if os.environ.get("CONCRE_DEV") == "1":
        return True
    d = _edicao_bruta()
    if not d:
        return False
    if "previa" in d:
        return bool(d.get("previa"))
    return str(d.get("nome") or "").strip().lower() == "completa"


def _edicao_bruta():
    """O json da edicao como esta' escrito, na ordem de precedencia."""
    d = None
    try:
        with open(os.path.join(app_dir(), "edicao.json"), encoding="utf-8") as fh:
            d = json.load(fh) or {}
    except Exception:  # noqa: BLE001
        d = None
    if d is None:
        try:
            with open(resource_path("edicao_embutida.json"), encoding="utf-8") as fh:
                d = json.load(fh) or {}
        except Exception:  # noqa: BLE001
            d = None
    if d is None:
        remota = _prefs_cru().get("__edicao_remota")
        d = remota if isinstance(remota, dict) else None
    return d if isinstance(d, dict) else None


# -- SESSÕES E QUEDAS --------------------------------------------------------
# O programa não gravava NADA quando morria. O Naor relatou "o app fica
# morrendo, acontece a cada algumas trocas de aba" e não havia um arquivo
# sequer, aqui ou na máquina dele, que dissesse o que tinha acontecido - nem se
# tinha sido o programa, nem o antivírus, nem quantas vezes. Corrigir no escuro
# é adivinhar; e eu adivinhei uma vez.
#
# A ideia é a mais simples que funciona: enquanto o programa está aberto existe
# um sessao.json. Ao fechar pela janela, ele é apagado. Se ele AINDA existe na
# próxima abertura, a vez anterior não terminou - e o que ela estava fazendo
# vai para quedas.txt.


def _agora_texto():
    return time.strftime("%d/%m/%Y %H:%M:%S")


def _versao_instalada():
    try:
        with open(resource_path(os.path.join("static", "versao.json")),
                  encoding="utf-8") as fh:
            return (json.load(fh) or {}).get("versao") or "?"
    except Exception:  # noqa: BLE001
        return "?"


def abrir_sessao():
    """Registra a queda anterior (se houve) e marca esta sessão como aberta."""
    anterior = None
    # A marca antiga, ao lado do .exe, so' e' lida uma vez: na primeira
    # abertura depois da mudanca de lugar. Depois sai de la'.
    antiga = SESSAO_ANTIGA if os.path.normcase(SESSAO_ANTIGA) != os.path.normcase(SESSAO_FILE) else None
    for lugar in (SESSAO_FILE, antiga):
        if not lugar or anterior is not None:
            continue
        try:
            if os.path.exists(lugar):
                with open(lugar, encoding="utf-8") as fh:
                    anterior = json.load(fh) or {}
        except Exception:  # noqa: BLE001
            anterior = {"aba": "?", "inicio": "?", "ultimo_sinal": "?", "sinais": 0}
    if antiga:
        try:
            os.remove(antiga)
        except OSError:
            pass

    # Em desenvolvimento o servidor e' morto a' forca o tempo todo (reiniciar
    # para recarregar o backend), e cada morte dessas virava uma "queda" no
    # registro. O Modo Teste ficava vermelho por causa do meu proprio trabalho,
    # e o registro que existe para investigar a maquina do cliente enchia de
    # ruido meu. Em dev a sessao ainda e' marcada - o que se perde e' so' a
    # anotacao no historico.
    if anterior and os.environ.get("CONCRE_DEV") != "1":
        try:
            with open(QUEDAS_FILE, "a", encoding="utf-8") as fh:
                fh.write(
                    "%s | fechou sem avisar | aberto em %s | ultimo sinal %s | "
                    "estava na aba %s | %s sinais | versao %s\n" % (
                        _agora_texto(),
                        anterior.get("inicio", "?"),
                        anterior.get("ultimo_sinal", "?"),
                        anterior.get("aba") or "?",
                        anterior.get("sinais", 0),
                        anterior.get("versao", "?")))
        except OSError:
            pass

    try:
        with open(SESSAO_FILE, "w", encoding="utf-8") as fh:
            json.dump({"inicio": _agora_texto(), "ultimo_sinal": _agora_texto(),
                       "aba": "", "sinais": 0, "versao": _versao_instalada()},
                      fh, ensure_ascii=False)
    except OSError:
        pass
    return anterior


def fechar_sessao():
    """Fechou pela janela: some com a marca, para não contar como queda."""
    try:
        os.remove(SESSAO_FILE)
    except OSError:
        pass


def _quantas_quedas():
    try:
        with open(QUEDAS_FILE, encoding="utf-8") as fh:
            return sum(1 for linha in fh if linha.strip())
    except OSError:
        return 0


@app.route("/api/sinal", methods=["POST"])
def api_sinal():
    """Batida de coração da tela: diz que está viva e em que aba está."""
    body = request.get_json(force=True, silent=True) or {}
    try:
        with open(SESSAO_FILE, encoding="utf-8") as fh:
            dados = json.load(fh) or {}
    except Exception:  # noqa: BLE001
        dados = {"inicio": _agora_texto(), "sinais": 0,
                 "versao": _versao_instalada()}
    dados["ultimo_sinal"] = _agora_texto()
    dados["aba"] = str(body.get("aba") or "")[:40]
    dados["sinais"] = int(dados.get("sinais") or 0) + 1
    try:
        with open(SESSAO_FILE, "w", encoding="utf-8") as fh:
            json.dump(dados, fh, ensure_ascii=False)
    except OSError:
        pass
    return jsonify({"success": True})


@app.route("/api/quedas")
def api_quedas():
    """As últimas quedas, em texto, para quem estiver ajudando a diagnosticar."""
    linhas = []
    try:
        with open(QUEDAS_FILE, encoding="utf-8") as fh:
            linhas = [x.strip() for x in fh if x.strip()][-20:]
    except OSError:
        pass
    return jsonify({"quedas": linhas, "total": _quantas_quedas(),
                    "arquivo": QUEDAS_FILE})


@app.route("/api/diagnostico")
def api_diagnostico():
    """O que o botão "Reportar problema" precisa saber do lado do programa.

    O Naor, em 24/08: "tem uns bug que eu vejo e não falo, que são de coisas
    que eu não tenho nem pista de o que possivelmente poderia ser". O que
    faltava não era vontade de reportar - era saber o que dizer. Esta rota
    junta o que ele não tem como saber: versão, edição, licença, de onde o
    programa está rodando, se o código atualizado está em uso, e as últimas
    quedas registradas.

    Não abre conexão nenhuma e não manda nada a ninguém: devolve para a tela,
    que monta o texto e deixa a pessoa copiar ou salvar. Quem decide enviar é
    ela. Por isso também não entra aqui nada que não ajude a diagnosticar -
    nem o conteúdo da planilha, nem caminhos de arquivos abertos.
    """
    import platform
    linhas = []
    try:
        with open(QUEDAS_FILE, encoding="utf-8") as fh:
            linhas = [x.strip() for x in fh if x.strip()][-5:]
    except OSError:
        pass
    lic = {}
    try:
        # licenca.situacao() e nao estado_licenca(): esta grava o relogio e o
        # inicio do teste nas preferencias. Diagnostico so' le'.
        p = _prefs_cru()
        s = licenca.situacao(_LICENCA["dados"], marca_do_relogio=p.get("__relogio"),
                             inicio_do_teste=p.get("__teste_desde"))
        lic = {"estado": s.get("estado"), "texto": s.get("texto"),
               "vence": s.get("vence"), "cliente": s.get("cliente"),
               "arquivo": os.path.basename(_LICENCA.get("arquivo") or "") or None,
               "erro": _LICENCA.get("erro")}
    except Exception:  # noqa: BLE001 -- diagnóstico não pode falhar por causa dele
        lic = {"estado": "?"}
    e = edicao()
    # O programa roda do código atualizado (codigo/) ou do que veio no .exe?
    # Faz diferença para saber se uma correção publicada já chegou.
    do_pacote = any(os.path.normcase(os.sep + "codigo" + os.sep) in
                    os.path.normcase(p + os.sep) for p in sys.path[:3])
    return jsonify({
        "versao": _versao_instalada(),
        "edicao": e["nome"] or "(padrão)",
        "ocultar": e["ocultar"],
        "previa": previa(),
        "canal": _canal_atual(),
        "instalacao": _id_da_instalacao(),
        "licenca": lic,
        "pasta": app_dir(),
        "pasta_temporaria": _pasta_temporaria(),
        "codigo_atualizado": do_pacote,
        "empacotado": bool(getattr(sys, "frozen", False)),
        "windows": platform.platform(),
        "python": platform.python_version(),
        "quedas_total": _quantas_quedas(),
        "quedas_ultimas": linhas,
        "agora": _agora_texto(),
    })


@app.route("/api/diagnostico/salvar", methods=["POST"])
def api_diagnostico_salvar():
    """Grava o texto do "Reportar problema" em exports/, para anexar.

    Só grava o que a tela mandou, com nome escolhido aqui - a tela não diz
    onde gravar. Tamanho limitado: é um relatório, não um arquivo qualquer.
    """
    if MODO_WEB:
        return _bloqueado_na_web()
    body = request.get_json(force=True, silent=True) or {}
    texto = body.get("texto")
    if not isinstance(texto, str) or not texto.strip():
        return jsonify({"success": False, "error": "relatório vazio"}), 400
    if len(texto) > 64 * 1024:
        return jsonify({"success": False, "error": "relatório grande demais"}), 413
    base = "problema_%s" % datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    destino = os.path.join(EXPORTS_DIR, base + ".txt")
    n = 2
    while os.path.exists(destino):          # dois cliques no mesmo segundo
        destino = os.path.join(EXPORTS_DIR, "%s_%d.txt" % (base, n))
        n += 1
    try:
        os.makedirs(EXPORTS_DIR, exist_ok=True)
        with open(destino, "w", encoding="utf-8") as fh:
            fh.write(texto)
    except OSError as e:
        return jsonify({"success": False, "error": str(e)}), 500
    return jsonify({"success": True, "arquivo": destino})


def _pasta_temporaria():
    """O programa está rodando de dentro de um arquivo compactado?

    "A minha cópia diária fica nos .rar" - disse o Naor. Ele abre o
    Concrestats.exe de dentro do .rar. O WinRAR extrai tudo para uma pasta
    temporária (%TEMP%\\Rar$EX...), roda de lá e apaga a pasta quando o
    programa fecha. Tudo o que o programa grava ao lado de si - licença,
    receitas, preferências, o registro de quedas, e cada atualização aplicada
    - some ao fechar. Na abertura seguinte: licença de novo, receitas antigas
    coladas de novo ("com ele aberto coloquei os json antigos"), e a mesma
    atualização oferecida de novo, baixada de novo - e o antivírus reagindo
    de novo a um executável que se reescreve dentro da pasta temporária, que
    é exatamente de onde vírus costumam rodar.

    Não há como o programa consertar isso sozinho. O que dá para fazer é
    PERCEBER e dizer, e não fazer o que se perderia de qualquer jeito.
    """
    try:
        import tempfile
        aqui = os.path.normcase(os.path.abspath(app_dir()))
        temp = os.path.normcase(os.path.abspath(tempfile.gettempdir()))
        if aqui == temp or aqui.startswith(temp + os.sep):
            return True
        # Os extratores mais comuns, caso o TEMP desta máquina tenha outro nome:
        # WinRAR (Rar$EX...), 7-Zip (7zO...) e o zip do próprio Windows (Temp1_...).
        partes = [p.lower() for p in aqui.split(os.sep)]
        return any(p.startswith(("rar$ex", "7zo", "temp1_")) for p in partes)
    except Exception:  # noqa: BLE001 -- na dúvida, não atrapalha ninguém
        return False


_AVISO_PASTA_TEMPORARIA = (
    "O Concrestats está aberto de dentro de um arquivo compactado (.rar ou .zip). "
    "Nessa situação tudo o que ele grava - licença, receitas, preferências e "
    "atualizações - é apagado quando ele fecha. Extraia a pasta para um lugar fixo, "
    "por exemplo C:\\Concrestats, e abra o Concrestats.exe de lá.")


@app.route("/api/ambiente")
def api_ambiente():
    """O frontend usa isto para esconder botões que só existem no app de mesa."""
    e = edicao()
    temporaria = _pasta_temporaria()
    return jsonify({"web": MODO_WEB, "versao": "2.0",
                    "dev": os.environ.get("CONCRE_DEV") == "1",
                    "quedas": _quantas_quedas(),
                    "edicao": e["nome"], "ocultar": e["ocultar"],
                    "previa": previa(),
                    "pasta_temporaria": temporaria,
                    "aviso_pasta": _AVISO_PASTA_TEMPORARIA if temporaria else ""})


def _usuario():
    """Identifica o usuário pelo cookie (a web separa as preferências de cada
    um; no app de mesa existe um só e o valor cai em 'default')."""
    u = (request.cookies.get("concre_uid") or "default").strip()
    return "".join(ch for ch in u if ch.isalnum() or ch in "-_")[:40] or "default"


SESSOES_MAX = 6          # quantas sessoes ficam na memoria
SESSOES_TTL = 3600       # segundos sem uso ate' poder descartar


def _limpar_sessoes():
    """Cada recarregar da janela cria uma sessao nova. Sem limpeza, a planilha
    inteira ficava na memoria uma vez por recarregada."""
    agora = time.time()
    for chave in [c for c, v in SESSIONS.items()
                  if agora - v.get("visto", 0) > SESSOES_TTL]:
        SESSIONS.pop(chave, None)
    if len(SESSIONS) >= SESSOES_MAX:
        antigas = sorted(SESSIONS.items(), key=lambda kv: kv[1].get("visto", 0))
        for chave, _ in antigas[:len(SESSIONS) - SESSOES_MAX + 1]:
            SESSIONS.pop(chave, None)


# Duas requisicoes criando sessao ao mesmo tempo (duas abas, ou varias
# chamadas de uma recarga antes de a sessao existir) faziam uma limpar o
# dicionario enquanto a outra o percorria: "dictionary changed size during
# iteration". O erro subia como um 500 sem relacao nenhuma com o que a pessoa
# estava fazendo - abrir um arquivo.
_TRAVA_SESSOES = threading.Lock()


def _session(sid):
    sess = SESSIONS.get(sid)
    if sess is None:
        with _TRAVA_SESSOES:
            sess = SESSIONS.get(sid)      # outra thread pode ter criado
            if sess is None:
                _limpar_sessoes()
                sess = SESSIONS[sid] = {"sheets": {}, "active": None,
                                        "path": None, "demo": []}
    sess["visto"] = time.time()
    return sess


# --------------------------------------------------------------------------
# Conversão célula -> string (o formato que a tela espera)
#   - datas  -> "YYYY-MM-DD"
#   - NaN / None / NaT -> ""
#   - float inteiro (8.0) -> "8"   |  float real (0.5) -> "0.5"
#   - resto -> str(v)
# --------------------------------------------------------------------------
def _cell(v):
    if v is None:
        return ""
    try:
        if pd.isna(v):
            return ""
    except (TypeError, ValueError):
        pass
    if isinstance(v, (pd.Timestamp, datetime.datetime, datetime.date)):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, np.datetime64):
        return pd.Timestamp(v).strftime("%Y-%m-%d")
    if isinstance(v, (float, np.floating)):
        f = float(v)
        return str(int(f)) if f.is_integer() else str(f)
    if isinstance(v, (int, np.integer)):
        return str(int(v))
    return str(v)


def df_to_payload(df):
    """DataFrame -> {"headers": [...], "data": [[str, ...], ...]}."""
    df = df.copy()
    headers = [str(c) for c in df.columns]
    # Datas -> ISO antes de extrair (evita numpy.datetime64 solto)
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%Y-%m-%d")
    records = df.where(pd.notna(df), None).values.tolist()
    data = [[_cell(v) for v in row] for row in records]
    return {"headers": headers, "data": data}


def payload_to_df(headers, data):
    """{headers, data} -> DataFrame (tudo string; usado para exportar/salvar)."""
    return pd.DataFrame(data, columns=headers, dtype=object)


# --------------------------------------------------------------------------
# Leitura de arquivos (xlsx/xls/csv)
# --------------------------------------------------------------------------
def read_any(path_or_buffer, filename):
    """Retorna OrderedDict {nome_planilha: DataFrame}. Mantém o dedup de
    cabeçalhos do pandas ("Data 28", "Data 28.1"), que a tela já espera."""
    name = (filename or "").lower()
    if name.endswith(".csv"):
        for enc in ("utf-8-sig", "utf-8", "latin-1"):
            try:
                df = pd.read_csv(path_or_buffer, sep=None, engine="python",
                                 encoding=enc, dtype=object)
                return {"Plan1": df}
            except Exception:  # noqa: BLE001 -- tenta a próxima codificação
                if hasattr(path_or_buffer, "seek"):
                    path_or_buffer.seek(0)
                continue
        # último recurso
        if hasattr(path_or_buffer, "seek"):
            path_or_buffer.seek(0)
        return {"Plan1": pd.read_csv(path_or_buffer, engine="python", dtype=object)}
    # Excel: todas as planilhas.
    # dtype=object e' obrigatorio: sem ele o pandas "adivinha" e transforma
    # codigos como 007 em 7 e 1E5 em 100000 - corpo de prova e nota fiscal
    # perdiam os zeros a' esquerda.
    sheets = pd.read_excel(path_or_buffer, sheet_name=None, dtype=object)
    return sheets


def load_into_session(sid, sheets, path=None, mode="replace", copia=False):
    """mode='replace' troca a sessão; mode='add' ANEXA as abas do arquivo às
    existentes (permite cruzar planilhas de arquivos diferentes)."""
    sess = _session(sid)
    novos = {name: df_to_payload(df) for name, df in sheets.items()}
    if mode == "add" and sess["sheets"]:
        primeiro = None
        for name, payload in novos.items():
            final, k = name, 2
            while final in sess["sheets"]:
                final = f"{name} ({k})"; k += 1
            sess["sheets"][final] = payload
            if primeiro is None:
                primeiro = final
        sess["active"] = primeiro or sess["active"]
        # 'path' continua apontando para o arquivo base (Salvar não muda de alvo)
    else:
        sess["sheets"] = novos
        sess["active"] = next(iter(sess["sheets"]), None)
        # A marca de "planilha de demonstracao" vale so' para as abas criadas
        # pelo Modo Teste. Ao abrir um arquivo, tudo que entra e' do usuario -
        # sem isto, uma aba dele chamada "Cadastro" herdava a marca e ficava
        # de fora do Salvar, em silencio.
        sess["demo"] = []
        if path:
            sess["path"] = path
            sess["copia"] = bool(copia)
            # quem veio do arquivo: so' estas podem ser apagadas la' no Salvar
            sess["abas_origem"] = list(novos.keys())
    return sess


def sheet_response(sess, extra=None):
    name = sess["active"]
    payload = sess["sheets"].get(name, {"headers": [], "data": []})
    out = {
        "success": True,
        "active_sheet": name,
        "sheet_name": name,
        "sheets": list(sess["sheets"].keys()),
        "data": payload,
    }
    if extra:
        out.update(extra)
    return jsonify(out)


# --------------------------------------------------------------------------
# Rotas
# --------------------------------------------------------------------------
@app.route("/")
def index():
    # Serve o HTML diretamente (sem Jinja) para não interpretar chaves no markup.
    return send_file(resource_path(os.path.join("templates", "index.html")),
                     mimetype="text/html")


@app.route("/api/upload", methods=["POST"])
def api_upload():
    sid = request.form.get("session_id", "default")
    f = request.files.get("file")
    if not f:
        return jsonify({"success": False, "error": "nenhum arquivo enviado"}), 400
    try:
        # Salva uma cópia em uploads/ (permite "Salvar no arquivo original")
        safe = os.path.basename(f.filename)
        path = os.path.join(UPLOADS_DIR, safe)
        f.save(path)
        sheets = read_any(path, safe)
        mode = request.form.get("mode", "replace")
        # ATENCAO: este 'path' e' a copia dentro de uploads/, NAO o arquivo do
        # usuario. Marcamos como copia para o Salvar nao mentir dizendo que
        # gravou no original (era exatamente o que acontecia ao arrastar).
        sess = load_into_session(sid, sheets, path=path, mode=mode, copia=True)
        return sheet_response(sess, extra={"copia": True})
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/load_path", methods=["POST"])
def api_load_path():
    if MODO_WEB:
        return _bloqueado_na_web()
    # App nativo: abre o arquivo DIRETO do caminho real (via diálogo do Windows).
    # Assim o "Salvar" grava no próprio arquivo original, não numa cópia.
    body = request.get_json(force=True, silent=True) or {}
    sid = body.get("session_id", "default")
    path = body.get("path") or ""
    if not path or not os.path.isfile(path):
        return jsonify({"success": False, "error": "arquivo não encontrado"}), 400
    try:
        sheets = read_any(path, os.path.basename(path))
        sess = load_into_session(sid, sheets, path=path,
                                 mode=body.get("mode", "replace"))
        return sheet_response(sess, extra={"path": path})
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": str(e)}), 500


# Pasta de planilhas, o "database" do Naor: "adicione o caminho de pastas como
# recentes, pode ter na UI o caminho da pasta com o nome e tambem a lista dos
# arquivos como uma tree". Os limites existem porque a pessoa pode escolher o
# disco inteiro: a tela precisa responder na hora, nao varrer tudo.
PLANILHA_EXT = (".xlsx", ".xlsm", ".xls", ".csv")
PASTA_PROFUNDIDADE = 4
PASTA_MAX_ARQUIVOS = 400


def _arvore_da_pasta(pasta, nivel, conta):
    """Planilhas da pasta e as subpastas que tem planilha em algum lugar."""
    try:
        entradas = sorted(os.scandir(pasta), key=lambda e: e.name.lower())
    except OSError:
        return []
    subpastas, arquivos = [], []
    for e in entradas:
        # "~$" e' o arquivo de trava que o Excel deixa ao lado da planilha aberta.
        if e.name.startswith((".", "~$")):
            continue
        try:
            if e.is_dir(follow_symlinks=False):
                if nivel < PASTA_PROFUNDIDADE:
                    itens = _arvore_da_pasta(e.path, nivel + 1, conta)
                    if itens:
                        subpastas.append({"nome": e.name, "caminho": e.path, "itens": itens})
            elif e.name.lower().endswith(PLANILHA_EXT):
                if conta["arquivos"] >= PASTA_MAX_ARQUIVOS:
                    conta["cortada"] = True
                    continue
                conta["arquivos"] += 1
                arquivos.append({"nome": e.name, "caminho": e.path})
        except OSError:
            continue
    return subpastas + arquivos


@app.route("/api/pasta", methods=["POST"])
def api_pasta():
    if MODO_WEB:
        return _bloqueado_na_web()
    body = request.get_json(force=True, silent=True) or {}
    path = body.get("path") or ""
    if not path or not os.path.isdir(path):
        return jsonify({"success": False, "error": "pasta não encontrada"}), 400
    conta = {"arquivos": 0, "cortada": False}
    itens = _arvore_da_pasta(path, 0, conta)
    return jsonify({"success": True, "path": path, "itens": itens,
                    "arquivos": conta["arquivos"], "cortada": conta["cortada"]})


@app.route("/api/import_merge", methods=["POST"])
def api_import_merge():
    # Importar: anexa as linhas do arquivo na planilha alvo (mode=append).
    sid = request.form.get("session_id", "default")
    target = request.form.get("target_sheet")
    f = request.files.get("file")
    sess = _session(sid)
    if not f or target not in sess["sheets"]:
        return jsonify({"success": False, "error": "planilha alvo inválida"}), 400
    try:
        sheets = read_any(f.stream, f.filename)
        incoming = next(iter(sheets.values()))
        inc_payload = df_to_payload(incoming)
        cur = sess["sheets"][target]
        # Alinha colunas pelo NOME (ignorando maiúsculas/espaços). Se nenhuma
        # coluna casar, o append geraria só linhas vazias - avisa em vez disso.
        norm = lambda h: str(h).strip().upper()
        idx = {norm(h): i for i, h in enumerate(inc_payload["headers"])}
        casadas = [h for h in cur["headers"] if norm(h) in idx]
        if not casadas:
            return jsonify({
                "success": False,
                "error": ("nenhuma coluna em comum entre as planilhas - "
                          "os cabeçalhos precisam ter os mesmos nomes. "
                          "Para juntar por uma chave, use o botão Cruzar; "
                          "para abrir como outra aba, use Adicionar.")
            }), 400
        # Coluna que so' existe no arquivo importado ENTRA na planilha, em vez
        # de ser jogada fora em silencio (as linhas antigas ficam vazias nela).
        ja_tem = {norm(h) for h in cur["headers"]}
        novas = []
        for h in inc_payload["headers"]:
            if norm(h) not in ja_tem:
                novas.append(h)
                ja_tem.add(norm(h))
        if novas:
            cur["headers"] = list(cur["headers"]) + novas
            for linha in cur["data"]:
                linha.extend([""] * len(novas))

        for row in inc_payload["data"]:
            new_row = []
            for h in cur["headers"]:
                j = idx.get(norm(h))
                new_row.append(row[j] if j is not None and j < len(row) else "")
            cur["data"].append(new_row)
        return jsonify({"success": True, "data": cur,
                        "colunas_casadas": len(casadas),
                        "colunas_novas": novas,
                        "colunas_total": len(cur["headers"]),
                        "linhas_add": len(inc_payload["data"])})
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": str(e)}), 500


BACKUP_DIR = os.path.join(app_dir(), "copias")
BACKUP_MAX = 10          # quantas copias por arquivo


def _guardar_copia(path):
    """Guarda o arquivo ANTES de grava-lo por cima. E' a rede de seguranca de
    quem salva errado: da' para voltar a versao anterior sem depender do Excel."""
    try:
        if not path or not os.path.isfile(path):
            return None
        os.makedirs(BACKUP_DIR, exist_ok=True)
        nome = os.path.basename(path)
        base, ext = os.path.splitext(nome)
        base = "".join(ch for ch in base if ch.isalnum() or ch in " -_")[:40].strip() or "planilha"
        carimbo = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")[:-3]
        destino = os.path.join(BACKUP_DIR, f"{base}__{carimbo}{ext}")
        shutil.copy2(path, destino)

        # mantem so' as ultimas BACKUP_MAX copias DESTE arquivo
        anteriores = sorted(
            (f for f in os.listdir(BACKUP_DIR) if f.startswith(base + "__")),
            reverse=True)
        for velho in anteriores[BACKUP_MAX:]:
            try:
                os.remove(os.path.join(BACKUP_DIR, velho))
            except OSError:
                pass
        return destino
    except Exception:  # noqa: BLE001 -- copia e' proteção extra, nunca impede salvar
        return None


@app.route("/api/copias", methods=["POST"])
def api_copias():
    """Lista as copias guardadas do arquivo aberto (as mais novas primeiro)."""
    if MODO_WEB:
        return _bloqueado_na_web()
    body = request.get_json(force=True, silent=True) or {}
    sess = _session(body.get("session_id", "default"))
    path = sess.get("path") or ""
    if not path:
        return jsonify({"success": True, "copias": []})
    base, _ = os.path.splitext(os.path.basename(path))
    base = "".join(ch for ch in base if ch.isalnum() or ch in " -_")[:40].strip()
    saida = []
    try:
        for f in sorted(os.listdir(BACKUP_DIR), reverse=True):
            if not f.startswith(base + "__"):
                continue
            inteiro = os.path.join(BACKUP_DIR, f)
            marca = f[len(base) + 2:].rsplit(".", 1)[0]
            try:                       # 2026-08-23_18-36-58 -> 23/08/2026 18:36
                d, h = marca.split("_")
                a_, m_, d_ = d.split("-")
                partes = h.split("-")
                hh, mm = partes[0], partes[1]
                ss = partes[2] if len(partes) > 2 else "00"
                # com os segundos da' para diferenciar dois Salvar seguidos
                quando = f"{d_}/{m_}/{a_} às {hh}:{mm}:{ss}"
            except ValueError:
                quando = marca
            saida.append({
                "arquivo": inteiro,
                "quando": quando,
                "tamanho": os.path.getsize(inteiro),
            })
    except OSError:
        pass
    return jsonify({"success": True, "copias": saida, "pasta": BACKUP_DIR})


@app.route("/api/restaurar_copia", methods=["POST"])
def api_restaurar_copia():
    """Volta o arquivo aberto para uma copia anterior (guardando o estado atual
    antes, para o 'voltar atras' tambem ter volta)."""
    if MODO_WEB:
        return _bloqueado_na_web()
    travado = _bloqueado_sem_licenca()
    if travado:
        return travado
    body = request.get_json(force=True, silent=True) or {}
    sid = body.get("session_id", "default")
    sess = _session(sid)
    copia = (body.get("arquivo") or "").strip()
    destino = sess.get("path")
    if not copia or not os.path.isfile(copia):
        return jsonify({"success": False, "error": "copia nao encontrada"}), 400
    if os.path.dirname(os.path.abspath(copia)) != os.path.abspath(BACKUP_DIR):
        return jsonify({"success": False, "error": "caminho invalido"}), 400
    if not destino:
        return jsonify({"success": False, "error": "sem arquivo aberto"}), 400
    try:
        _guardar_copia(destino)          # o estado de agora vira copia tambem
        shutil.copy2(copia, destino)
        sess_novo = load_into_session(sid, read_any(destino, destino), path=destino)
        return sheet_response(sess_novo, extra={"restaurado": True})
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/join_preview", methods=["POST"])
def api_join_preview():
    """Diz ANTES de confirmar quantas linhas vao achar par. Sem isto, o
    cruzamento era um salto no escuro: so' dava para saber depois de feito."""
    body = request.get_json(force=True, silent=True) or {}
    sess = _session(body.get("session_id", "default"))
    la, lb = body.get("left_sheet"), body.get("right_sheet")
    ka, kb = body.get("left_key"), body.get("right_key")
    if la not in sess["sheets"] or lb not in sess["sheets"]:
        return jsonify({"success": False, "error": "planilha invalida"}), 400
    pa, pb = sess["sheets"][la], sess["sheets"][lb]
    try:
        ia = pa["headers"].index(ka)
        ib = pb["headers"].index(kb)
    except ValueError:
        return jsonify({"success": False, "error": "coluna invalida"}), 400

    def chave(v):
        return str(v).strip().upper()

    direita = {chave(r[ib]) for r in pb["data"] if ib < len(r)}
    total = len(pa["data"])
    casaram = 0
    exemplo = ""
    for r in pa["data"]:
        if ia < len(r) and chave(r[ia]) in direita:
            casaram += 1
            if not exemplo:
                exemplo = str(r[ia]).strip()[:28]
    return jsonify({"success": True, "matched": casaram, "total": total,
                    "exemplo": exemplo})


@app.route("/api/sheets_info", methods=["POST"])
def api_sheets_info():
    # Cabeçalhos de todas as abas da sessão (p/ montar o modal de cruzamento).
    body = request.get_json(force=True, silent=True) or {}
    sess = _session(body.get("session_id", "default"))
    return jsonify({
        "success": True,
        "sheets": {n: p.get("headers", []) for n, p in sess["sheets"].items()},
        "active": sess["active"],
        "path": sess.get("path"),
        # quem e' de demonstracao: o Modo Teste limpa POR ESTA marca, nunca
        # pelo nome - o usuario pode ter uma aba chamada "Cadastro" de verdade
        "demo": list(sess.get("demo") or []),
    })


@app.route("/api/join_sheets", methods=["POST"])
def api_join_sheets():
    # "PROCV automático": traz colunas da planilha B para a A casando pela
    # coluna-chave (merge left). Chave duplicada em B usa a 1ª ocorrência.
    body = request.get_json(force=True, silent=True) or {}
    sess = _session(body.get("session_id", "default"))
    la, lb = body.get("left_sheet"), body.get("right_sheet")
    ka, kb = body.get("left_key"), body.get("right_key")
    cols = body.get("columns") or []
    destino = body.get("destino", "nova")  # 'nova' | 'atual'
    if la not in sess["sheets"] or lb not in sess["sheets"]:
        return jsonify({"success": False, "error": "planilha inválida"}), 400
    pa, pb = sess["sheets"][la], sess["sheets"][lb]
    if ka not in pa["headers"] or kb not in pb["headers"]:
        return jsonify({"success": False, "error": "coluna-chave inválida"}), 400
    cols = [c for c in cols if c in pb["headers"] and c != kb]
    if not cols:
        return jsonify({"success": False, "error": "escolha ao menos uma coluna para trazer"}), 400
    try:
        dfa = payload_to_df(pa["headers"], pa["data"])
        dfb = payload_to_df(pb["headers"], pb["data"])
        # normaliza a chave dos dois lados (trim + sem diferenciar maiúsculas)
        dfa["__k"] = dfa[ka].astype(str).str.strip().str.upper()
        dfb["__k"] = dfb[kb].astype(str).str.strip().str.upper()
        dfb = dfb.drop_duplicates("__k")[["__k"] + cols]
        # evita colisão de nomes: sufixa colunas que já existem em A
        ren = {}
        for c in cols:
            nc, k = c, 2
            while nc in dfa.columns:
                nc = f"{c} ({k})"; k += 1
            if nc != c:
                ren[c] = nc
        if ren:
            dfb = dfb.rename(columns=ren)
        out = dfa.merge(dfb, on="__k", how="left").drop(columns="__k")
        out = out.where(pd.notna(out), "")
        payload = {"headers": [str(c) for c in out.columns],
                   "data": [[str(v) for v in row] for row in out.values.tolist()]}
        matched = int((dfa["__k"].isin(dfb["__k"])).sum()) if len(dfb) else 0
        if destino == "atual":
            sess["sheets"][la] = payload
            sess["active"] = la
        else:
            name, k = f"{la} + {lb}", 2
            while name in sess["sheets"]:
                name = f"{la} + {lb} ({k})"; k += 1
            sess["sheets"][name] = payload
            sess["active"] = name
            # Cruzamento de abas de demonstracao continua sendo demonstracao:
            # o resultado nao pode acabar dentro do arquivo de quem usa.
            demo = set(sess.get("demo") or [])
            if la in demo and lb in demo:
                sess.setdefault("demo", []).append(name)
        return sheet_response(sess, extra={"matched": matched, "total": len(dfa)})
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/reload", methods=["POST"])
def api_reload():
    if MODO_WEB:
        return _bloqueado_na_web()
    # "Atualizar tudo": relê o arquivo de origem do disco e recarrega a sessão.
    body = request.get_json(force=True, silent=True) or {}
    sid = body.get("session_id", "default")
    sess = _session(sid)
    path = sess.get("path")
    if not path or not os.path.isfile(path):
        return jsonify({"success": False, "error": "sem arquivo de origem para recarregar"}), 400
    try:
        ativo = sess["active"]
        sheets = read_any(path, os.path.basename(path))
        sess = load_into_session(sid, sheets, path=path)
        if ativo in sess["sheets"]:
            sess["active"] = ativo
        return sheet_response(sess, extra={"path": path})
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/get_sheet", methods=["POST"])
def api_get_sheet():
    body = request.get_json(force=True, silent=True) or {}
    sess = _session(body.get("session_id", "default"))
    name = body.get("sheet_name")
    if name in sess["sheets"]:
        sess["active"] = name
    return sheet_response(sess)


@app.route("/api/new_sheet", methods=["POST"])
def api_new_sheet():
    body = request.get_json(force=True, silent=True) or {}
    sess = _session(body.get("session_id", "default"))
    name = (body.get("sheet_name") or "Nova Planilha").strip() or "Nova Planilha"
    base, n = name, 2
    while name in sess["sheets"]:
        name = f"{base} ({n})"
        n += 1
    sess["sheets"][name] = {"headers": ["A", "B", "C"], "data": [["", "", ""]]}
    sess["active"] = name
    # Aba criada pelo Modo Teste: nunca deve entrar no arquivo do usuario.
    if body.get("demo"):
        sess.setdefault("demo", [])
        if name not in sess["demo"]:
            sess["demo"].append(name)
    return sheet_response(sess)


@app.route("/api/delete_sheet", methods=["POST"])
def api_delete_sheet():
    body = request.get_json(force=True, silent=True) or {}
    sess = _session(body.get("session_id", "default"))
    name = body.get("sheet_name")
    # O Modo Teste pede a limpeza com somente_demo=True. Assim, mesmo que a tela
    # erre o alvo, o servidor recusa apagar uma aba que veio do arquivo.
    if body.get("somente_demo") and name not in (sess.get("demo") or []):
        return jsonify({"success": False,
                        "error": "esta aba nao e' de demonstracao",
                        "sheets": list(sess["sheets"].keys()),
                        "active_sheet": sess["active"]}), 400
    if name in sess["sheets"] and len(sess["sheets"]) > 1:
        sess["sheets"].pop(name, None)
        if name in (sess.get("demo") or []):
            sess["demo"].remove(name)      # nome livre de novo
        if sess["active"] == name:
            sess["active"] = next(iter(sess["sheets"]), None)
    return jsonify({
        "success": True,
        "sheets": list(sess["sheets"].keys()),
        "active_sheet": sess["active"],
    })


@app.route("/api/save_data", methods=["POST"])
def api_save_data():
    # Atualiza o sheet em memória (auto-save do grid).
    body = request.get_json(force=True, silent=True) or {}
    sess = _session(body.get("session_id", "default"))
    name = body.get("sheet_name")
    if not name:
        # sem nome nao ha' o que gravar: devolver "ok" aqui escondia perda de
        # dados (o front achava que salvou).
        return jsonify({"success": False, "error": "sheet_name ausente"}), 400
    sess["sheets"][name] = {
        "headers": body.get("headers", []),
        "data": body.get("data", []),
    }
    sess["active"] = name
    return jsonify({"success": True})


def _excel_sheet_name(name):
    """Nome de aba aceito pelo Excel: sem []:*?/\\ , <=31 chars, não vazio.
    (openpyxl levanta erro com caracteres inválidos - era fonte de export falho.)"""
    s = "".join(c for c in str(name) if c not in "[]:*?/\\").strip()
    return (s[:31] or "Plan1")


def _safe_sheet_name(name, used):
    """Nome de aba válido p/ Excel e único no arquivo."""
    base = _excel_sheet_name(name)
    out, k = base, 1
    while out in used:
        suf = f"_{k}"
        out = base[: 31 - len(suf)] + suf
        k += 1
    used.add(out)
    return out


@app.route("/api/save_file", methods=["POST"])
def api_save_file():
    if MODO_WEB:
        return _bloqueado_na_web()
    travado = _bloqueado_sem_licenca()
    if travado:
        return travado
    # Grava a sessão de volta no arquivo de origem (ou num caminho novo vindo
    # do "Salvar como" nativo). Excel: escreve TODAS as planilhas.
    body = request.get_json(force=True, silent=True) or {}
    sess = _session(body.get("session_id", "default"))
    new_path = (body.get("path") or "").strip()
    if new_path:
        if not os.path.splitext(new_path)[1]:
            new_path += ".xlsx"
        sess["path"] = new_path
        sess["copia"] = False
    path = sess.get("path")
    if not path or not sess["sheets"]:
        return jsonify({"success": False, "error": "sem arquivo de origem"}), 400
    if sess.get("copia") and not new_path:
        # O arquivo entrou por arrastar/anexar: o app so' tem uma copia e nao
        # sabe onde esta' o original. Antes gravava na copia e dizia "salvo".
        return jsonify({"success": False, "precisa_destino": True,
                        "error": "este arquivo foi aberto por arrastar, entao o app "
                                 "tem so' uma copia dele. Escolha onde gravar."}), 400
    try:
        if path.lower().endswith(".csv"):
            # CSV só comporta uma planilha: grava a ativa.
            name = body.get("sheet_name") or sess["active"]
            if name in (sess.get("demo") or []):
                return jsonify({"success": False,
                                "error": "a planilha aberta e' a de demonstracao "
                                         "do Modo Teste - ela nao vai para o seu "
                                         "arquivo"}), 400
            payload = sess["sheets"].get(name)
            if not payload:
                return jsonify({"success": False, "error": "planilha inválida"}), 400
            copia_anterior = _guardar_copia(path)
            payload_to_df(payload["headers"], payload["data"]).to_csv(
                path, index=False, encoding="utf-8-sig")
        else:
            used = set()
            # As abas de demonstracao do Modo Teste ficam de fora: elas existem
            # so' para o teste e nao podem contaminar a planilha de trabalho.
            demo = set(sess.get("demo") or [])
            reais = {n: p for n, p in sess["sheets"].items() if n not in demo}
            if not reais:
                return jsonify({"success": False,
                                "error": "so' ha planilha de demonstracao aberta"}), 400
            ext = os.path.splitext(path)[1].lower()
            copia_anterior = _guardar_copia(path)   # como estava antes deste Salvar
            if os.path.exists(path) and ext in (".xlsx", ".xlsm"):
                # arquivo ja' existe: gravar POR CIMA, mexendo so' no que mudou
                _gravar_preservando(path, reais, sess.get("abas_origem"))
            else:
                if ext == ".xls":          # openpyxl nao escreve .xls
                    path = path[:-4] + ".xlsx"
                    sess["path"] = path
                with pd.ExcelWriter(path, engine="openpyxl") as w:
                    for sheet_name, payload in reais.items():
                        df = payload_to_df(payload["headers"], payload["data"])
                        # numeros e datas como numeros e datas, nao como texto
                        df = df.map(_tipar) if hasattr(df, "map") else df.applymap(_tipar)
                        df.to_excel(w, sheet_name=_safe_sheet_name(sheet_name, used),
                                    index=False)
        # Arquivo novo (Salvar como): nao havia estado anterior para guardar.
        # Sem isto, o primeiro Salvar deixava a lista de Versoes vazia e parecia
        # que o recurso nao funcionava.
        if not copia_anterior:
            _guardar_copia(path)
        return jsonify({"success": True, "path": path})
    except PermissionError:
        return jsonify({"success": False,
                        "error": "arquivo em uso - feche-o no Excel e salve de novo"}), 500
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": str(e)}), 500


# --------------------------------------------------------------------------
# Gravacao preservando o arquivo do usuario
# --------------------------------------------------------------------------
_RE_INT = re.compile(r"^-?\d+$")
_RE_DEC_PONTO = re.compile(r"^-?\d*\.\d+$")
_RE_DEC_VIRG = re.compile(r"^-?\d*,\d+$")
_RE_MILHAR_BR = re.compile(r"^-?\d{1,3}(\.\d{3})+(,\d+)?$")
_RE_DATA_ISO = re.compile(r"^(\d{4})-(\d{2})-(\d{2})$")


def _tipar(txt):
    """Texto da grade -> valor com o tipo certo para o Excel. Sem isso todo
    numero vira 'numero armazenado como texto' e SOMA/grafico param de somar."""
    if txt is None:
        return None
    s = str(txt).strip()
    if s == "":
        return None
    if _RE_INT.match(s):
        # "007" e' codigo, nao numero: virar 7 perde o zero a' esquerda (o
        # Excel faz igual). "0" sozinho continua sendo numero.
        semSinal = s[1:] if s[:1] == "-" else s
        if len(semSinal) > 1 and semSinal[0] == "0":
            return s
        try:
            return int(s)
        except ValueError:
            return s
    if _RE_DEC_PONTO.match(s):
        return float(s)
    if _RE_DEC_VIRG.match(s):
        return float(s.replace(",", "."))
    if _RE_MILHAR_BR.match(s):
        return float(s.replace(".", "").replace(",", "."))
    m = _RE_DATA_ISO.match(s)
    if m:
        try:
            return datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return s
    return s


def _igual_ao_que_o_app_mostra(valor_arquivo, texto_app):
    """O app so' enxerga texto. Se o texto bate com o que ja' esta' na celula,
    a celula NAO e' reescrita - e assim formula, formato e tipo ficam de pe'."""
    a = _cell(valor_arquivo)
    b = "" if texto_app is None else str(texto_app)
    if a == b.strip() or a.strip() == b.strip():
        return True
    na, nb = _tipar(a), _tipar(b)
    if isinstance(na, (int, float)) and isinstance(nb, (int, float)):
        try:
            return abs(float(na) - float(nb)) < 1e-9
        except (TypeError, ValueError):
            return False
    return False


def _gravar_preservando(path, reais, abas_origem):
    """Grava por cima do .xlsx/.xlsm mexendo SO' nas celulas que mudaram.
    Mantem formatacao, largura de coluna, celulas mescladas, paineis
    congelados, validacoes e - o mais importante - as formulas."""
    from openpyxl import load_workbook

    ext = os.path.splitext(path)[1].lower()
    wb = load_workbook(path, keep_vba=(ext == ".xlsm"))

    # O 2o carregamento (valores ja' calculados) custa caro e so' serve para
    # planilha com formula - por isso e' feito na primeira formula encontrada.
    caixa = {"calc": None, "tentou": False}

    def valor_calculado(aba, i, j):
        if not caixa["tentou"]:
            caixa["tentou"] = True
            try:
                caixa["calc"] = load_workbook(path, data_only=True)
            except Exception:  # noqa: BLE001
                caixa["calc"] = None
        c = caixa["calc"]
        if not c or aba not in c.sheetnames:
            return None
        return c[aba].cell(row=i, column=j).value

    usados = set(wb.sheetnames)
    for nome, payload in reais.items():
        headers = payload.get("headers") or []
        data = payload.get("data") or []
        if nome in wb.sheetnames:
            ws = wb[nome]
        else:
            ws = wb.create_sheet(title=_safe_sheet_name(nome, usados))
        linhas = [headers] + list(data)
        for i, linha in enumerate(linhas, start=1):
            for j in range(1, len(headers) + 1):
                novo = linha[j - 1] if j - 1 < len(linha) else ""
                cel = ws.cell(row=i, column=j)
                atual = cel.value
                # Celula com formula: comparar com o VALOR CALCULADO. Se o
                # usuario nao mexeu, a formula continua viva.
                if isinstance(atual, str) and atual.startswith("="):
                    ref = valor_calculado(ws.title, i, j)
                    # Se a segunda leitura do arquivo falhou, nao ha' com o que
                    # comparar - e sem comparacao a celula caia no "mudou" e a
                    # formula era trocada por texto fixo. Uma falha pontual do
                    # openpyxl apagava TODAS as formulas da planilha de uma vez,
                    # respondendo sucesso. Na duvida, a formula fica.
                    if caixa["calc"] is None:
                        continue
                    if _igual_ao_que_o_app_mostra(ref, novo):
                        continue
                elif _igual_ao_que_o_app_mostra(atual, novo):
                    continue
                cel.value = _tipar(novo)

        # sobras de quando a planilha encolheu
        fim = len(data) + 1
        if ws.max_row > fim:
            ws.delete_rows(fim + 1, ws.max_row - fim)
        if ws.max_column > len(headers) and len(headers) > 0:
            ws.delete_cols(len(headers) + 1, ws.max_column - len(headers))

    # abas que vieram do arquivo e o usuario apagou dentro do app
    for nome in list(abas_origem or []):
        if nome not in reais and nome in wb.sheetnames and len(wb.sheetnames) > 1:
            del wb[nome]

    wb.save(path)


def _send_dataframe(df, fmt, base_name):
    """Gera CSV / XLSX / HTML a partir de um DataFrame e devolve como download."""
    if fmt == "csv":
        buf = io.BytesIO(df.to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig"))
        return send_file(buf, mimetype="text/csv", as_attachment=True,
                         download_name=f"{base_name}.csv")
    if fmt in ("html", "report"):
        html = (
            "<html><head><meta charset='utf-8'><style>"
            "table{border-collapse:collapse;font-family:Arial;font-size:12px}"
            "th,td{border:1px solid #ccc;padding:4px 8px;text-align:left}"
            "th{background:#1d1c18;color:#fff}</style></head><body>"
            f"<h2>{base_name}</h2>"
            + df.to_html(index=False, border=0)
            + "</body></html>"
        )
        buf = io.BytesIO(html.encode("utf-8"))
        return send_file(buf, mimetype="text/html", as_attachment=True,
                         download_name=f"{base_name}.html")
    # xlsx (default)
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as w:
        # numeros como numeros: senao o Excel abre tudo como texto e nao soma
        saida = df.map(_tipar) if hasattr(df, "map") else df.applymap(_tipar)
        saida.to_excel(w, index=False, sheet_name=_excel_sheet_name(base_name))
    buf.seek(0)
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=f"{base_name}.xlsx",
    )


@app.route("/api/export", methods=["POST"])
def api_export():
    travado = _bloqueado_sem_licenca()
    if travado:
        return travado
    body = request.get_json(force=True, silent=True) or {}
    sess = _session(body.get("session_id", "default"))
    name = body.get("sheet_name") or sess["active"]
    fmt = (body.get("format") or "xlsx").lower()
    payload = sess["sheets"].get(name, {"headers": [], "data": []})
    # Lista VAZIA é diferente de "não mandou lista". Com `or`, um filtro que
    # resulta em zero linhas exportava a planilha INTEIRA, sem filtro nenhum -
    # e o aviso dizia "Exportado" como se estivesse certo. Num laboratório que
    # atende vários clientes isso é mandar os dados de um para outro, e não há
    # como perceber: a tela mostrava zero linhas e o arquivo saiu.
    filtradas = body.get("filtered_data")
    rows = payload["data"] if filtradas is None else filtradas
    df = payload_to_df(payload["headers"], rows)
    return _send_dataframe(df, fmt, str(name or "planilha"))


@app.route("/api/export_report_custom", methods=["POST"])
def api_export_report_custom():
    travado = _bloqueado_sem_licenca()
    if travado:
        return travado
    body = request.get_json(force=True, silent=True) or {}
    fmt = (body.get("format") or "xlsx").lower()
    columns = body.get("columns") or []
    data = body.get("data") or []
    title = body.get("title") or "relatorio"
    # Reordena/seleciona as colunas pedidas (data pode trazer linhas completas).
    df_full = payload_to_df(columns, data) if data and len(data[0]) == len(columns) \
        else pd.DataFrame(data)
    if list(df_full.columns) != columns and columns:
        try:
            df_full.columns = columns[: len(df_full.columns)]
        except Exception:  # noqa: BLE001
            pass
    base = f"relatorio_{title}"
    return _send_dataframe(df_full, fmt, base)


def _xlsx_certificado(aoa, fmt, nome_aba):
    """O relatório de ensaio em Excel com cara de documento: título, campos,
    resumo, tabela em dois andares (7 e 28 dias), fecho e rodapé - formatado
    e pronto para imprimir em A4 deitado. `fmt` diz em que linha está cada
    parte (montado pela tela, relatorio.js › montarAoa)."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter

    def cor(v, padrao):
        v = str(v or "").lstrip("#")
        return v.upper() if re.match(r"^[0-9a-fA-F]{6}$", v) else padrao

    tema = fmt.get("tema") or {}
    TINTA, TINTA2, TINTA3 = cor(tema.get("tinta"), "1C1B18"), cor(tema.get("tinta2"), "57554F"), cor(tema.get("tinta3"), "8F8B82")
    FORTE, MARCA = cor(tema.get("forte"), "1A3A6E"), cor(tema.get("marca"), "2F7DF0")
    FUNDO, FRACA = cor(tema.get("fundo"), "F7F6F2"), cor(tema.get("fraca"), "EBE9E2")
    fonte = "Calibri"
    ncol = max(int(fmt.get("ncol") or 0), max((len(r) for r in aoa), default=1))
    wb = Workbook()
    ws = wb.active
    ws.title = nome_aba
    ws.sheet_view.showGridLines = False

    ini, fim = (fmt.get("dados") or [-1, -1])[:2]
    numeros = fmt.get("numeros") or []
    re_data = re.compile(r"^(\d{2})/(\d{2})/(\d{4})$")
    for i, linha in enumerate(aoa):
        valores = []
        for j, v in enumerate(linha):
            if ini <= i <= fim and isinstance(v, str):
                m = re_data.match(v.strip())
                if m:
                    try:
                        v = datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
                    except ValueError:
                        pass
            valores.append(v if v != "" else None)
        ws.append(valores)

    for r1, c1, r2, c2 in fmt.get("mesclas") or []:
        if r2 > r1 or c2 > c1:
            ws.merge_cells(start_row=r1 + 1, start_column=c1 + 1, end_row=r2 + 1, end_column=c2 + 1)

    fino = Side(style="thin", color=FRACA)
    def estilo(r, **kw):
        for c in range(1, ncol + 1):
            cel = ws.cell(row=r + 1, column=c)
            for k, v in kw.items():
                setattr(cel, k, v)

    for r in fmt.get("titulo") or []:
        estilo(r, font=Font(name=fonte, size=15, bold=True, color=TINTA))
        ws.row_dimensions[r + 1].height = 26
    if (fmt.get("titulo") or []):
        estilo(fmt["titulo"][0] + 1, font=Font(name=fonte, size=9, color=TINTA2))
    for r, cols in fmt.get("rotulos") or []:
        for c in range(ncol):
            ws.cell(row=r + 1, column=c + 1).font = Font(
                name=fonte, size=8 if c in cols else 10, bold=c in cols, color=TINTA3 if c in cols else TINTA)
    res = fmt.get("resumo") or []
    if len(res) == 2:
        estilo(res[0], font=Font(name=fonte, size=8, bold=True, color=TINTA3), fill=PatternFill("solid", fgColor=FUNDO))
        estilo(res[1], font=Font(name=fonte, size=13, bold=True, color=FORTE), fill=PatternFill("solid", fgColor=FUNDO),
               alignment=Alignment(horizontal="left"))
        ws.row_dimensions[res[1] + 1].height = 20
    g = fmt.get("grupos", -1)
    if g is not None and g >= 0:
        for c in range(1, ncol + 1):
            cel = ws.cell(row=g + 1, column=c)
            cel.font = Font(name=fonte, size=8, bold=True, color=FORTE)
            cel.alignment = Alignment(horizontal="center")
            if cel.value or any(c1 < c <= c2 + 1 for (r1, c1, r2, c2) in (fmt.get("mesclas") or []) if r1 == g):
                cel.border = Border(bottom=Side(style="medium", color=MARCA))
    cab = fmt.get("cabecalho", -1)
    if cab is not None and cab >= 0:
        estilo(cab, font=Font(name=fonte, size=8.5, bold=True, color=TINTA2),
               alignment=Alignment(horizontal="center", vertical="bottom", wrap_text=True),
               border=Border(bottom=Side(style="medium", color=TINTA)))
        ws.row_dimensions[cab + 1].height = 28
        ws.freeze_panes = ws.cell(row=cab + 2, column=1)
        ws.print_title_rows = "%d:%d" % ((g + 1) if g is not None and g >= 0 else cab + 1, cab + 1)
    if 0 <= ini <= fim:
        zebra = PatternFill("solid", fgColor=FUNDO)
        for r in range(ini, fim + 1):
            for c in range(1, ncol + 1):
                cel = ws.cell(row=r + 1, column=c)
                cel.font = Font(name=fonte, size=10, color=TINTA)
                cel.border = Border(bottom=fino)
                if (r - ini) % 2 == 1:
                    cel.fill = zebra
                nf = numeros[c - 1] if c - 1 < len(numeros) else ""
                if isinstance(cel.value, datetime.date):
                    cel.number_format = "dd/mm/yyyy"
                    cel.alignment = Alignment(horizontal="center")
                elif nf and isinstance(cel.value, (int, float)):
                    cel.number_format = nf
    for r in fmt.get("secoes") or []:
        if r >= 0:
            estilo(r, font=Font(name=fonte, size=8.5, color=TINTA2))
    ass = fmt.get("assinatura") or []
    for k, r in enumerate(ass):
        estilo(r, alignment=Alignment(horizontal="center"),
               font=Font(name=fonte, size=11 if k == 2 else 9, bold=(k == 2), color=TINTA if k == 2 else TINTA2))
    if fmt.get("rodape") is not None:
        estilo(fmt["rodape"], alignment=Alignment(horizontal="center"), font=Font(name=fonte, size=8, color=TINTA3))

    # Largura pelo conteúdo da tabela (cabeçalho e dados), com teto.
    for c in range(1, ncol + 1):
        larg = 10
        for r in ([cab] if cab is not None and cab >= 0 else []) + list(range(max(ini, 0), fim + 1 if fim >= 0 else 0)):
            v = ws.cell(row=r + 1, column=c).value
            if v is None:
                continue
            t = v.strftime("%d/%m/%Y") if isinstance(v, datetime.date) else str(v)
            larg = max(larg, min(40, len(t) + 2))
        ws.column_dimensions[get_column_letter(c)].width = larg

    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.print_options.horizontalCentered = True
    ws.page_margins.left = ws.page_margins.right = 0.4
    ws.page_margins.top = ws.page_margins.bottom = 0.5
    ws.oddFooter.right.text = "Página &P de &N"
    ws.oddFooter.right.size = 8

    # Abas a mais no mesmo arquivo (a conformidade junto do ensaio): primeira
    # linha e' o cabecalho, repetido em cada pagina impressa.
    for extra in fmt.get("abas") or []:
        linhas = (extra or {}).get("aoa") or []
        if not linhas:
            continue
        wx = wb.create_sheet(_excel_sheet_name(extra.get("nome") or "Aba"))
        wx.sheet_view.showGridLines = False
        for i, linha in enumerate(linhas, start=1):
            for j, valor in enumerate(linha, start=1):
                cel = wx.cell(row=i, column=j, value=valor)
                cel.font = Font(name=fonte, size=10, bold=i == 1, color="FFFFFF" if i == 1 else TINTA)
                if i == 1:
                    cel.fill = PatternFill("solid", fgColor=FORTE)
                    cel.alignment = Alignment(horizontal="left" if j == 1 else "center", vertical="center")
        wx.column_dimensions["A"].width = 52
        for j in range(2, len(linhas[0]) + 1):
            wx.column_dimensions[get_column_letter(j)].width = 13
        wx.freeze_panes = "A2"
        wx.print_title_rows = "1:1"
        wx.page_setup.orientation = "landscape"
        wx.page_setup.paperSize = wx.PAPERSIZE_A4
        wx.page_setup.fitToWidth = 1
        wx.page_setup.fitToHeight = 0
        wx.sheet_properties.pageSetUpPr.fitToPage = True
        wx.oddFooter.right.text = "Página &P de &N"
        wx.oddFooter.right.size = 8
    return wb


@app.route("/api/export_aoa", methods=["POST"])
def api_export_aoa():
    """Gera .xlsx REAL no servidor a partir de uma matriz (lista de listas).

    Existe porque o download via JS (SheetJS) falhava em algumas máquinas -
    aqui o arquivo é escrito com openpyxl, que já vem no executável. Se vier
    'path', grava direto no disco (diálogo nativo); senão devolve o arquivo.
    """
    travado = _bloqueado_sem_licenca()
    if travado:
        return travado
    body = request.get_json(force=True, silent=True) or {}
    aoa = body.get("aoa") or []
    if not isinstance(aoa, list) or not aoa:
        return jsonify({"success": False, "error": "sem dados"}), 400
    nome = _excel_sheet_name(body.get("sheet_name") or "Planilha")
    path = (body.get("path") or "").strip()
    formato = body.get("formato")
    if isinstance(formato, dict):
        # O relatório de ensaio: planilha já formatada como documento.
        try:
            wb = _xlsx_certificado(aoa, formato, nome)
            if path:
                if MODO_WEB:
                    return _bloqueado_na_web()
                if not os.path.splitext(path)[1]:
                    path += ".xlsx"
                wb.save(path)
                return jsonify({"success": True, "path": path})
            buf = io.BytesIO()
            wb.save(buf)
            buf.seek(0)
            return send_file(
                buf,
                mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                as_attachment=True,
                download_name=f"{body.get('base_name') or 'relatorio'}.xlsx",
            )
        except PermissionError:
            return jsonify({"success": False,
                            "error": "arquivo em uso - feche-o no Excel e tente de novo"}), 500
        except Exception as e:  # noqa: BLE001
            return jsonify({"success": False, "error": str(e)}), 500
    try:
        ncol = max(len(r) for r in aoa)
        linhas = [list(r) + [""] * (ncol - len(r)) for r in aoa]
        df = pd.DataFrame(linhas[1:], columns=[str(c) for c in linhas[0]]) \
            if len(linhas) > 1 else pd.DataFrame(columns=[str(c) for c in linhas[0]])
        # mesma regra do Salvar: numero sai numero, data sai data
        if len(df):
            df = df.map(_tipar) if hasattr(df, "map") else df.applymap(_tipar)
        if path:
            # Na versao web ninguem pode escolher onde gravar no servidor:
            # gravar em caminho livre so' faz sentido no app de mesa.
            if MODO_WEB:
                return _bloqueado_na_web()
            if not os.path.splitext(path)[1]:
                path += ".xlsx"
            with pd.ExcelWriter(path, engine="openpyxl") as w:
                df.to_excel(w, sheet_name=nome, index=False)
            return jsonify({"success": True, "path": path})
        buf = io.BytesIO()
        with pd.ExcelWriter(buf, engine="openpyxl") as w:
            df.to_excel(w, sheet_name=nome, index=False)
        buf.seek(0)
        return send_file(
            buf,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            as_attachment=True,
            download_name=f"{body.get('base_name') or 'planilha'}.xlsx",
        )
    except PermissionError:
        return jsonify({"success": False,
                        "error": "arquivo em uso - feche-o no Excel e tente de novo"}), 500
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/salvar_binario", methods=["POST"])
def api_salvar_binario():
    """Grava um arquivo binario (ex.: PNG) no caminho escolhido pelo usuario.
    Existe porque no app nativo o download do navegador nao pergunta onde
    salvar - o arquivo 'sumia'."""
    if MODO_WEB:
        return _bloqueado_na_web()
    travado = _bloqueado_sem_licenca()
    if travado:
        return travado
    import base64
    body = request.get_json(force=True, silent=True) or {}
    path = (body.get("path") or "").strip()
    dados = body.get("base64") or ""
    if not path or not dados:
        return jsonify({"success": False, "error": "caminho ou conteudo ausente"}), 400
    try:
        if "," in dados[:64]:            # remove prefixo data:image/png;base64,
            dados = dados.split(",", 1)[1]
        with open(path, "wb") as fh:
            fh.write(base64.b64decode(dados))
        return jsonify({"success": True, "path": path})
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": str(e)}), 500


# -- Logotipo de dentro da planilha ------------------------------------------
# O relatório pode sair com a cara da empresa cujos dados estão abertos. Muita
# planilha de laboratório traz o logotipo colado no topo: ele está no .xlsx, em
# xl/media/, e o desenho diz em que linha foi ancorado. Só biblioteca padrão -
# o Pillow não vai no .exe. Reduzir a imagem e tirar as cores dela fica com a
# tela (canvas).
_IMAGEM_MIME = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                ".gif": "image/gif", ".bmp": "image/bmp", ".webp": "image/webp"}


def _imagens_da_planilha(caminho, limite=4, maximo=3 * 1024 * 1024):
    """Imagens de um .xlsx, primeiro as ancoradas mais no alto da planilha.

    Devolve [{nome, mime, linha, bytes}] - linha e' a da ancoragem (None
    quando a imagem nao aparece em desenho nenhum). Arquivo que nao e' zip, ou
    zip sem imagem, devolve lista vazia: nao e' erro, e' planilha sem logo.
    """
    import zipfile
    import xml.etree.ElementTree as ET
    try:
        z = zipfile.ZipFile(caminho)
    except (zipfile.BadZipFile, OSError):
        return []
    with z:
        nomes = z.namelist()
        midias = [n for n in nomes if n.startswith("xl/media/")
                  and os.path.splitext(n)[1].lower() in _IMAGEM_MIME]
        if not midias:
            return []
        linha = {}
        R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
        for des in nomes:
            if not re.match(r"xl/drawings/drawing\d+\.xml$", des):
                continue
            rels_nome = "xl/drawings/_rels/" + des.rsplit("/", 1)[1] + ".rels"
            try:
                rels = ET.fromstring(z.read(rels_nome))
                desenho = ET.fromstring(z.read(des))
            except (KeyError, ET.ParseError):
                continue
            alvo = {}
            for rel in rels:
                t = rel.get("Target") or ""
                if rel.get("Id") and "media/" in t:
                    alvo[rel.get("Id")] = "xl/media/" + t.rsplit("media/", 1)[1]
            for ancora in desenho:
                if not ancora.tag.endswith(("twoCellAnchor", "oneCellAnchor", "absoluteAnchor")):
                    continue
                onde = 0
                for el in ancora.iter():
                    if el.tag.endswith("}from"):
                        for f in el:
                            if f.tag.endswith("}row") and (f.text or "").strip().isdigit():
                                onde = int(f.text)
                        break
                for el in ancora.iter():
                    rid = el.get(R + "embed")
                    if rid and rid in alvo:
                        m = alvo[rid]
                        linha[m] = min(linha.get(m, onde), onde)
        ordem = sorted(midias, key=lambda n: (linha.get(n, 10 ** 6), -z.getinfo(n).file_size))
        saida = []
        for n in ordem:
            if z.getinfo(n).file_size > maximo:
                continue
            saida.append({"nome": n.rsplit("/", 1)[1],
                          "mime": _IMAGEM_MIME[os.path.splitext(n)[1].lower()],
                          "linha": linha.get(n), "bytes": z.read(n)})
            if len(saida) >= limite:
                break
        return saida


@app.route("/api/logo_da_planilha", methods=["POST"])
def api_logo_da_planilha():
    import base64
    import hashlib
    body = request.get_json(force=True, silent=True) or {}
    sess = _session(body.get("session_id", "default"))
    caminho = sess.get("path") or ""
    if not caminho or not os.path.isfile(caminho) \
            or not caminho.lower().endswith((".xlsx", ".xlsm")):
        return jsonify({"success": True, "chave": "", "imagens": []})
    try:
        chave = hashlib.sha1(("%s|%s" % (caminho, os.path.getmtime(caminho)))
                             .encode("utf-8")).hexdigest()[:16]
    except OSError:
        chave = ""
    # A tela guarda a última resposta: planilha igual, nada vai de novo.
    if chave and body.get("chave") == chave:
        return jsonify({"success": True, "chave": chave, "mesma": True})
    imagens = [{"nome": i["nome"], "linha": i["linha"],
                "dados": "data:%s;base64,%s" % (i["mime"],
                                                base64.b64encode(i["bytes"]).decode("ascii"))}
               for i in _imagens_da_planilha(caminho)]
    return jsonify({"success": True, "chave": chave, "imagens": imagens})


@app.route("/api/autoteste_arquivo", methods=["POST"])
def api_autoteste_arquivo():
    """Prova, num arquivo descartavel, que o Salvar nao estraga a planilha de
    quem usa: formula, formatacao, data, zero a' esquerda e numero de verdade.
    E' o unico teste que NAO da' para fazer pela tela - so' olhando o .xlsx."""
    if MODO_WEB:
        return _bloqueado_na_web()
    import tempfile
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, PatternFill

    checks = []

    def anota(nome, ok, detalhe):
        checks.append({"nome": nome, "ok": bool(ok), "detalhe": detalhe})

    pasta = tempfile.mkdtemp(prefix="concre_teste_")
    caminho = os.path.join(pasta, "teste_do_modo_teste.xlsx")
    try:
        wb = Workbook()
        ws = wb.active
        ws.title = "Ensaios"
        ws.append(["CP", "DATA", "FCK", "MPA", "SITUACAO"])
        ws.append(["007", datetime.date(2026, 3, 1), 25, 28.4, None])
        ws.append(["008", datetime.date(2026, 3, 2), 25, 22.1, None])
        for r in (2, 3):
            ws.cell(r, 5).value = f'=IF(D{r}>=C{r},"OK","NAO")'
        ws["A1"].font = Font(bold=True, color="FFFFFF")
        ws["A1"].fill = PatternFill("solid", fgColor="1D1C18")
        ws.column_dimensions["B"].width = 21
        ws.freeze_panes = "A2"
        ws["D2"].number_format = "0.00"
        wb.create_sheet("Nao mexer")["A1"] = "intacto"
        wb.save(caminho)

        sid = "__autoteste_arquivo__"
        SESSIONS.pop(sid, None)
        load_into_session(sid, read_any(caminho, caminho), path=caminho)
        sess = _session(sid)
        grade = sess["sheets"]["Ensaios"]

        anota("Código com zero à esquerda (007) não vira 7",
              grade["data"][0][0] == "007",
              f'a grade mostra "{grade["data"][0][0]}"')

        # o usuario corrige um ensaio e salva
        grade["data"][0][3] = "29,9"
        _guardar_copia(caminho)        # mesmo caminho do botao Salvar
        _gravar_preservando(caminho, sess["sheets"], sess.get("abas_origem"))

        wb2 = load_workbook(caminho)
        w2 = wb2["Ensaios"]
        anota("A correção foi gravada como NÚMERO, não como texto",
              isinstance(w2["D2"].value, (int, float)) and abs(float(w2["D2"].value) - 29.9) < 1e-9,
              f"D2 = {w2['D2'].value!r} ({type(w2['D2'].value).__name__})")
        anota("As fórmulas da planilha continuam vivas",
              isinstance(w2["E2"].value, str) and w2["E2"].value.startswith("="),
              f"E2 = {w2['E2'].value!r}")
        anota("As datas continuam datas",
              isinstance(w2["B2"].value, (datetime.date, datetime.datetime)),
              f"B2 = {w2['B2'].value!r}")
        anota("O que não foi tocado ficou igual",
              w2["D3"].value == 22.1 and w2["A3"].value == "008",
              f"D3 = {w2['D3'].value!r}, A3 = {w2['A3'].value!r}")
        anota("Negrito, cor e largura de coluna continuam iguais",
              bool(w2["A1"].font.bold) and str(w2["A1"].fill.fgColor.rgb).endswith("1D1C18")
              and float(w2.column_dimensions["B"].width) == 21,
              f"largura B = {w2.column_dimensions['B'].width}")
        anota("Painel congelado e formato de número continuam iguais",
              w2.freeze_panes == "A2" and w2["D2"].number_format == "0.00",
              f"congelado em {w2.freeze_panes}, formato {w2['D2'].number_format}")
        anota("As outras abas do arquivo não foram mexidas",
              "Nao mexer" in wb2.sheetnames and wb2["Nao mexer"]["A1"].value == "intacto",
              f"abas: {wb2.sheetnames}")

        # o app tem que ter guardado uma copia ANTES de sobrescrever
        base_copia = "".join(ch for ch in os.path.splitext(os.path.basename(caminho))[0]
                             if ch.isalnum() or ch in " -_")[:40].strip()
        copias = [f for f in os.listdir(BACKUP_DIR)] if os.path.isdir(BACKUP_DIR) else []
        anota("Guardou uma copia do arquivo antes de gravar por cima",
              any(f.startswith(base_copia + "__") for f in copias),
              f"{len([f for f in copias if f.startswith(base_copia + '__')])} copia(s) na pasta 'copias'")

        # a planilha de demonstracao nunca pode entrar no arquivo
        sess["sheets"]["DEMONSTRACAO_FALSA"] = {"headers": ["X"], "data": [["lixo"]]}
        sess.setdefault("demo", []).append("DEMONSTRACAO_FALSA")
        reais = {n: p for n, p in sess["sheets"].items()
                 if n not in set(sess.get("demo") or [])}
        _gravar_preservando(caminho, reais, sess.get("abas_origem"))
        anota("A planilha de demonstração não entra no arquivo",
              "DEMONSTRACAO_FALSA" not in load_workbook(caminho).sheetnames,
              f"abas: {load_workbook(caminho).sheetnames}")

        SESSIONS.pop(sid, None)
    except Exception as e:  # noqa: BLE001
        anota("O teste do arquivo rodou até o fim", False, f"{type(e).__name__}: {e}")
    finally:
        shutil.rmtree(pasta, ignore_errors=True)

    return jsonify({"success": True, "checks": checks,
                    "ok": all(c["ok"] for c in checks)})


# --------------------------------------------------------------------------
# Mensalidade
# --------------------------------------------------------------------------
# Onde o app procura versao nova. Ja' vem preenchido para quem recebe o
# programa nao precisar configurar nada; da' para trocar pelas preferencias
# (__url_atualizacao) se um dia o endereco mudar.
# Numa linha so' de proposito: quebrado no meio do caminho, nenhuma busca
# por "usuario/repositorio" encontra este endereco - e trocar de lugar sem
# perceber que um dos arquivos ficou para tras nao da' erro, da' "nao
# consegui verificar", que parece falta de internet.
URL_ATUALIZACAO_PADRAO = "https://raw.githubusercontent.com/embixx/Concrestats/main/atualizacao/manifesto.json"

_LICENCA = {"dados": None, "erro": None, "arquivo": None}


# O Flask atende com varias threads. Ler-alterar-gravar o mesmo arquivo sem
# combinar significa que duas gravacoes ao mesmo tempo se sobrescrevem: as duas
# leem, as duas alteram a sua copia, e a ultima a gravar apaga o que a outra
# fez - depois de ja' ter respondido que deu certo. Acontece na pratica porque
# estado_licenca() grava a cada tela protegida, e o autosave de template do
# usuario grava junto.
_TRAVA_PREFS = threading.Lock()


def _prefs_cru():
    try:
        with open(PREFS_FILE, "r", encoding="utf-8") as fh:
            return json.load(fh) or {}
    except Exception:  # noqa: BLE001
        return {}


def _gravar_json_atomico(caminho, dados):
    """Grava inteiro ou nao grava.

    open(..., "w") esvazia o arquivo antes de escrever: fechar o programa no
    meio do json.dump deixava um prefs.json cortado. E _prefs_cru() engole erro
    de leitura e devolve {} - entao o arquivo estragado ficava indistinguivel
    de "nunca configurou nada", e o usuario perdia os templates sem aviso.
    """
    temporario = caminho + ".novo"
    with open(temporario, "w", encoding="utf-8") as fh:
        json.dump(dados, fh, ensure_ascii=False, indent=2)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(temporario, caminho)


def _prefs_grava(campos):
    with _TRAVA_PREFS:
        atual = _prefs_cru()
        atual.update(campos)
        try:
            _gravar_json_atomico(PREFS_FILE, atual)
        except OSError:
            pass


def _carregar_licenca():
    """Procura a licença ao lado do executável e na pasta de cima.

    A pasta de cima entrou por causa de como a licença chega: o programa vem
    num .rar e a licença num anexo à parte. O Naor guardou os dois lado a lado
    - a licença em Concrestats_versions/ e o programa extraído em
    Concrestats_versions/2026-09-18_Concrestats/ - e perguntou, com razão, por
    que ela não valia dali. Quem guarda várias versões para comparar tem o
    mesmo arquivo servindo todas, e baixar o programa de novo não desfaz a
    licença.
    """
    pasta = app_dir()
    caminho = licenca.procurar(pasta, os.path.dirname(pasta))
    if not caminho:
        _LICENCA.update({"dados": None, "erro": None, "arquivo": None})
        return
    dados, erro = licenca.ler_arquivo(caminho)
    _LICENCA.update({"dados": dados, "erro": erro, "arquivo": caminho})


def estado_licenca():
    """Situação atual + marca o relógio, para atrasá-lo não render licença."""
    p = _prefs_cru()
    s = licenca.situacao(_LICENCA["dados"],
                         marca_do_relogio=p.get("__relogio"),
                         inicio_do_teste=p.get("__teste_desde"))
    hoje = datetime.date.today().isoformat()
    novos = {}
    if not p.get("__relogio") or hoje > p["__relogio"]:
        novos["__relogio"] = hoje
    if not _LICENCA["dados"] and not p.get("__teste_desde"):
        novos["__teste_desde"] = hoje
    if novos:
        _prefs_grava(novos)
    if _LICENCA["erro"]:
        s = dict(s)
        s["aviso_arquivo"] = _LICENCA["erro"]
    return s


def _bloqueado_sem_licenca():
    """Vencido não tranca os dados: só fecha gravar e exportar."""
    s = estado_licenca()
    if s.get("pode_gravar"):
        return None
    return jsonify({"success": False, "sem_licenca": True,
                    "estado": s["estado"], "error": s["texto"]}), 402


@app.route("/api/licenca", methods=["GET", "POST"])
def api_licenca():
    if request.method == "GET":
        return jsonify(estado_licenca())
    # POST: instalar um licenca.key que o cliente recebeu
    if MODO_WEB:
        return _bloqueado_na_web()
    body = request.get_json(force=True, silent=True) or {}
    origem = (body.get("path") or "").strip()
    conteudo = body.get("conteudo")
    if conteudo:
        dados, erro = licenca.interpretar(conteudo)
    elif origem:
        dados, erro = licenca.ler_arquivo(origem)
    else:
        return jsonify({"success": False, "error": "informe o arquivo da licença"}), 400
    if erro:
        return jsonify({"success": False, "error": erro}), 400
    try:
        destino = os.path.join(app_dir(), "licenca.key")
        if origem and os.path.abspath(origem) != os.path.abspath(destino):
            shutil.copy2(origem, destino)
        elif conteudo:
            with open(destino, "w", encoding="utf-8") as fh:
                fh.write(conteudo)
        _carregar_licenca()
        return jsonify({"success": True, "situacao": estado_licenca()})
    except OSError as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/pagamento")
def api_pagamento():
    """Dados para a tela de pagamento: planos, codigo PIX e QR.

    Se ninguem configurou a chave PIX, devolve configurado=False e a tela nem
    aparece - melhor nao ter botao de pagar do que ter um que nao recebe.
    """
    try:
        return jsonify(pagamento.cobranca(request.args.get("plano")))
    except Exception as e:  # noqa: BLE001 -- a tela some, o app continua
        return jsonify({"configurado": False, "error": str(e)})


_carregar_licenca()      # lê a licença uma vez, quando o app sobe


def _url_de_atualizacao_segura(url):
    """Devolve None se o endereco pode ser consultado, ou o motivo da recusa."""
    import ipaddress
    import socket
    import urllib.parse
    try:
        u = urllib.parse.urlparse(url)
    except ValueError:
        return "endereco de atualizacao invalido"
    if u.scheme not in ("http", "https"):
        return "so' http ou https"
    if not u.hostname:
        return "endereco sem servidor"
    try:
        infos = socket.getaddrinfo(u.hostname, None)
    except OSError:
        return "servidor nao encontrado"
    for familia, _, _, _, endereco in infos:
        ip = ipaddress.ip_address(endereco[0])
        if (ip.is_private or ip.is_loopback or ip.is_link_local
                or ip.is_reserved or ip.is_multicast):
            return "endereco interno nao e' consultado"
    return None


# -- quem recebe qual versao -------------------------------------------------
# Duas maneiras, que servem a coisas diferentes:
#
#   CANAL   e' o do dia a dia. Quem testa fica no canal "teste" e recebe as
#           versoes novas primeiro; o cliente fica no "estavel" e so' recebe o
#           que ja' passou por eles. Cada canal e' um manifesto proprio.
#
#   LIBERADO PARA  e' o controle fino: o manifesto pode trazer uma lista de
#           instalacoes, e so' elas recebem aquela versao. Serve para mandar uma
#           correcao para UMA pessoa antes de soltar para o resto.
#
# Nenhum dos dois e' barreira de seguranca - a assinatura e' que garante que o
# pacote e' nosso. Estes dois decidem so' a QUEM ele e' oferecido. Ainda assim a
# lista viaja dentro do que e' assinado, para ninguem reescrever a mao e
# empurrar uma versao antiga para quem nao devia.
CANAIS = ("estavel", "teste")


def _id_da_instalacao():
    """Identificador curto e estavel desta copia instalada.

    Nao e' o nome de ninguem: sao 10 caracteres sorteados na primeira vez que o
    programa roda, guardados nas preferencias. Serve para o autor dizer 'essa
    versao vai so' para esta instalacao aqui' sem precisar de cadastro, login
    nem servidor.
    """
    prefs = _prefs_cru()
    ident = str(prefs.get("__instalacao") or "").strip()
    if not ident:
        import secrets
        ident = secrets.token_hex(5)
        _prefs_grava({"__instalacao": ident})
    return ident


def _canal_de_arquivo():
    """canal.txt ao lado do executavel. Vazio/ausente = estavel.

    O canal deixou de ser um seletor na tela. Ele existia para quem testa
    receber antes - mas virou tambem a porta de saida da edicao do cliente: o
    canal de teste nao esconde a aba PAINEL, entao um cliente que mexesse no
    seletor desfazia sozinho o que foi combinado com ele.

    Como arquivo, quem testa liga em dois cliques (Canal_Teste.bat) e o cliente
    nao tem por onde chegar.
    """
    try:
        with open(os.path.join(app_dir(), "canal.txt"), encoding="utf-8") as fh:
            c = fh.read().strip().lower()
    except Exception:  # noqa: BLE001
        return None
    return c if c in CANAIS else None


def _pode_trocar_canal():
    """So' quem ja' tem o arquivo (ou esta' em desenvolvimento) troca de canal."""
    return _canal_de_arquivo() is not None or os.environ.get("CONCRE_DEV") == "1"


def _canal_atual():
    do_arquivo = _canal_de_arquivo()
    if do_arquivo:
        return do_arquivo
    c = str(_prefs_cru().get("__canal_atualizacao") or "estavel").strip().lower()
    return c if c in CANAIS else "estavel"


def _url_do_canal(base, canal):
    """No canal de teste o manifesto e' outro arquivo, ao lado do primeiro:
    .../manifesto.json  ->  .../manifesto-teste.json"""
    if canal == "estavel" or not base:
        return base
    if base.endswith(".json"):
        return base[:-5] + "-" + canal + ".json"
    return base


def _mais_nova(anunciada, instalada):
    """A versao anunciada e' realmente mais recente que a instalada?

    Comparar com != aceitava qualquer diferenca, inclusive para tras: bastava
    publicar por engano um manifesto antigo e o programa ofereceria voltar a
    uma versao anterior chamando isso de atualizacao. E comparar como TEXTO
    tambem nao serve - "01/12/2026" vem antes de "29/08/2026" no alfabeto.

    Se as duas datas nao forem legiveis, cai no comportamento antigo (qualquer
    diferenca conta), que e' o mais seguro para versao escrita a mao.
    """
    def data(v):
        try:
            return datetime.datetime.strptime(str(v).strip(), "%d/%m/%Y %H:%M")
        except (ValueError, TypeError):
            return None
    a, i = data(anunciada), data(instalada)
    if a and i:
        return a > i
    return bool(anunciada) and anunciada != instalada


def _liberado_para_mim(info, ident):
    """A versao anunciada vale para esta instalacao? Devolve None se sim, ou o
    motivo de nao. Manifesto sem lista vale para todo mundo (o caso normal)."""
    lista = info.get("liberado_para")
    if not lista:
        return None
    if not isinstance(lista, list):
        return "lista de liberacao invalida no manifesto"
    if ident in [str(x).strip() for x in lista]:
        return None
    return "esta versao foi liberada so' para algumas instalacoes"


@app.route("/api/atualizacao", methods=["GET", "POST"])
def api_atualizacao():
    """Diz se saiu versão nova. A fonte é um endereço configurável em
    prefs.json (__url_atualizacao); sem ele, não incomoda ninguém."""
    # O canal e' da MAQUINA, nao da aba do navegador. Gravar por /api/prefs
    # colocava o valor num balde por usuario, e a leitura acontece na raiz -
    # entao a escolha era salva e ignorada, calada.
    if request.method == "POST":
        if MODO_WEB:
            return _bloqueado_na_web()
        body = request.get_json(force=True, silent=True) or {}
        canal = str(body.get("canal") or "").strip().lower()
        if canal not in CANAIS:
            return jsonify({"success": False,
                            "error": "canal deve ser um de: " + ", ".join(CANAIS)}), 400
        # Esconder o seletor da tela nao basta: sem esta trava, bastava chamar
        # a rota para o cliente sair da edicao combinada com ele.
        if not _pode_trocar_canal():
            return jsonify({"success": False,
                            "error": "esta cópia não escolhe canal"}), 403
        _prefs_grava({"__canal_atualizacao": canal})
        return jsonify({"success": True, "canal": canal})

    atual = _versao_instalada()
    ident, canal = _id_da_instalacao(), _canal_atual()
    base = _prefs_cru().get("__url_atualizacao") or URL_ATUALIZACAO_PADRAO
    url = _url_do_canal(base, canal)
    comum = {"success": True, "versao_atual": atual, "instalacao": ident,
             "canal": canal,
             # A tela so' mostra o seletor para quem pode trocar. Lista vazia
             # para o cliente: nao ha' o que escolher.
             "canais": list(CANAIS) if _pode_trocar_canal() else []}
    if not url:
        return jsonify(dict(comum, verificou=False))

    # O endereco vem das preferencias, que sao gravaveis pela propria tela.
    # Sem estas travas, alguem podia apontar para file:// (ler arquivo do
    # disco) ou para um endereco interno da rede e usar a resposta como
    # espelho. So' http/https, e nada de endereco privado.
    erro = _url_de_atualizacao_segura(url)
    if erro:
        return jsonify(dict(comum, verificou=False, motivo=erro))
    # Pedido de quem vai buscar o manifesto por conta propria (ver
    # /api/manifesto): devolve o que esta' nesta maquina e o endereco, sem
    # abrir conexao nenhuma.
    if request.args.get("local"):
        return jsonify(dict(comum, verificou=False, local=True,
                            url_do_manifesto=url))

    try:
        import urllib.request
        pedido = urllib.request.Request(url, headers={"User-Agent": "Concrestats"})
        with urllib.request.urlopen(pedido, timeout=6) as r:
            if int(r.headers.get("Content-Length") or 0) > 64 * 1024:
                raise ValueError("resposta grande demais")
            info = json.loads(r.read(64 * 1024).decode("utf-8", "replace"))
        return jsonify(_resposta_do_manifesto(info, comum, atual, ident))
    except Exception as e:  # noqa: BLE001 -- sem rede não é erro do usuário
        return jsonify(dict(comum, verificou=False, motivo=str(e)[:80]))


@app.route("/api/manifesto", methods=["POST"])
def api_manifesto():
    """Recebe o manifesto que a TELA buscou e responde a mesma coisa.

    Por que isto existe
    -------------------
    O antivirus do Naor (Kaspersky) nao para de avisar sobre o programa. Ele
    reparou no que faltava: na versao antiga, que so' procurava atualizacao
    quando ele clicava, o aviso nao aparecia.

    E' coerente. O que pontua num modulo de comportamento nao e' ler um arquivo
    JSON - e' um executavel desconhecido e sem assinatura digital abrir uma
    conexao para a internet um segundo depois de ser aberto, sem ninguem pedir.
    Era exatamente o que acontecia: a tela chamava /api/atualizacao ao abrir e
    quem ia a' rede era o Concrestats.exe.

    Agora quem busca o manifesto e' a TELA, com o fetch do proprio WebView2 -
    isto e', o navegador da Microsoft, assinado e conhecido por todo antivirus,
    fazendo o que navegador faz. O exe nao toca a rede ao abrir.

    E a seguranca?
    --------------
    Nao muda nada. O que torna um manifesto confiavel e' a ASSINATURA, nao por
    onde ele passou: aqui ele vai pela mesma conferencia de sempre, e um
    manifesto trocado no caminho continua sendo recusado. Quem baixa e aplica o
    pacote continua sendo /api/atualizar, no servidor, conferindo de novo por
    conta propria - e so' quando a pessoa clica.
    """
    body = request.get_json(force=True, silent=True) or {}
    info = body.get("manifesto")
    if not isinstance(info, dict):
        return jsonify({"success": False, "error": "manifesto ausente"}), 400

    atual = _versao_instalada()
    ident, canal = _id_da_instalacao(), _canal_atual()
    comum = {"success": True, "versao_atual": atual, "instalacao": ident,
             "canal": canal,
             "canais": list(CANAIS) if _pode_trocar_canal() else []}
    return jsonify(_resposta_do_manifesto(info, comum, atual, ident))


def _resposta_do_manifesto(info, comum, atual, ident):
    """Le um manifesto ja' em maos e diz o que a tela precisa saber."""
    nova = str(info.get("versao", "")).strip()
    # A versao pode existir e mesmo assim nao ser para esta instalacao.
    # Nesse caso a tela nao mente dizendo "voce esta' na mais recente":
    # diz que ha' uma versao restrita, e continua sem oferecer o download.
    restricao = _liberado_para_mim(info, ident)
    # A edicao vem junto na resposta - e' a via que nao pede download.
    # O manifesto do canal manda, inclusive para DESLIGAR: sem edicao
    # nenhuma, volta tudo. (Se so' ligasse, trocar de canal nao desfazia.)
    # Assinatura conferida antes de gravar, senao um manifesto trocado no
    # caminho escondia aba na maquina dos outros.
    edicao_nova = None
    if atualizador.conferir_manifesto(info, licenca.CHAVE_PUBLICA) is None:
        edicao_nova = atualizador.edicao_do_manifesto(info, ident)
        if edicao_nova != _prefs_cru().get("__edicao_remota"):
            _prefs_grava({"__edicao_remota": edicao_nova})
    return dict(comum, verificou=True, versao_nova=nova,
                edicao_aplicada=bool(edicao_nova),
                tem_nova=bool(nova) and _mais_nova(nova, atual) and not restricao,
                restrita=bool(restricao),
                motivo=restricao or "",
                novidades=[] if restricao else info.get("novidades", []),
                onde=info.get("onde", ""))


@app.route("/api/atualizar", methods=["POST"])
def api_atualizar():
    """Baixa e aplica a atualização anunciada no manifesto.

    A ordem importa: conferir a assinatura ANTES de descompactar. Um pacote de
    origem duvidosa não chega nem a ser aberto."""
    if MODO_WEB:
        return _bloqueado_na_web()
    if _pasta_temporaria():
        return jsonify({"success": False, "error": _AVISO_PASTA_TEMPORARIA}), 409
    base = _prefs_cru().get("__url_atualizacao") or URL_ATUALIZACAO_PADRAO
    url = _url_do_canal(base, _canal_atual())
    if not url:
        return jsonify({"success": False, "error": "sem endereço de atualização"}), 400
    erro = _url_de_atualizacao_segura(url)
    if erro:
        return jsonify({"success": False, "error": erro}), 400
    try:
        import urllib.request
        pedido = urllib.request.Request(url, headers={"User-Agent": "Concrestats"})
        with urllib.request.urlopen(pedido, timeout=10) as r:
            manifesto = json.loads(r.read(64 * 1024).decode("utf-8", "replace"))
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": f"não consegui ler o manifesto ({e})"}), 502

    # A mesma trava da tela vale aqui. Sem isto, quem chamasse este endereco
    # direto baixaria a versao restrita assim mesmo - a tela seria enfeite.
    restricao = _liberado_para_mim(manifesto, _id_da_instalacao())
    if restricao:
        return jsonify({"success": False, "error": restricao}), 403

    arquivo = manifesto.get("arquivo") or ""
    erro = _url_de_atualizacao_segura(arquivo)
    if erro:
        return jsonify({"success": False, "error": f"endereço do pacote recusado: {erro}"}), 400
    try:
        # A validacao vai junto: ela precisa ser refeita a cada
        # redirecionamento, senao conferir so' o primeiro endereco nao vale
        # nada - ele redireciona para onde quiser depois de passar.
        pacote = atualizador.baixar(
            arquivo, conferir_endereco=_url_de_atualizacao_segura)
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": f"falhou ao baixar ({e})"}), 502

    motivo = atualizador.conferir_pacote(pacote, manifesto, licenca.CHAVE_PUBLICA)
    if motivo:
        return jsonify({"success": False, "error": motivo}), 400

    destino = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    ok, msg = atualizador.aplicar(pacote, destino)
    if not ok:
        return jsonify({"success": False, "error": msg}), 500
    return jsonify({"success": True, "mensagem": msg,
                    "versao": manifesto.get("versao", ""),
                    "reiniciar": True})


# Onde o pacote e' gravado. Fica numa funcao para o teste poder trocar: gravar
# por cima do proprio codigo-fonte durante um teste seria um desastre.
def _pasta_do_programa():
    return getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))


@app.route("/api/atualizar_recebido", methods=["POST"])
def api_atualizar_recebido():
    """Aplica um pacote que a TELA baixou. O programa nao vai a' internet.

    Por que existe
    --------------
    Em 22/09/2026 o Kaspersky do Naor matou o programa com
    PDM:Trojan.Win32.Generic, pos o Concrestats.exe em quarentena e ofereceu
    "desinfectar e reiniciar" - o PC travou e ele teve de desligar a' forca.
    O registro de quedas mostra o programa aberto as 21:10:39 e morto as
    21:12:51; a pasta _internal foi modificada as 21:11. Numa copia recem-
    baixada nada escreve em _internal - so' a atualizacao.

    O que o /api/atualizar faz e' exatamente o que um modulo de comportamento
    procura: um executavel sem assinatura digital abre conexao com a internet,
    baixa um arquivo, apaga pastas inteiras dentro da propria instalacao e as
    reescreve com codigo que vai executar na proxima vez. Em 18/09 tiramos a
    rede da ABERTURA (o manifesto passou a ser buscado pela tela) e o aviso
    deixou de aparecer sempre para aparecer "de vez em quando" - nas vezes em
    que alguem clicava em atualizar.

    Agora quem baixa o pacote tambem e' a tela, com o fetch do WebView2 - o
    navegador da Microsoft, assinado. O programa so' recebe os bytes pela
    conexao local, confere e grava. A correlacao "baixou da internet e
    escreveu codigo" deixa de existir dentro do mesmo processo.

    O que isto NAO garante: que o Kaspersky pare. Nao tenho Kaspersky aqui para
    medir. A solucao que resolve de verdade e' o executavel assinado.

    E a seguranca?
    --------------
    O que torna o pacote confiavel sempre foi a ASSINATURA, nao por onde ele
    veio: o sha256 do que chegou tem de bater com o manifesto, e o manifesto
    tem de estar assinado pela nossa chave. Como agora o manifesto tambem vem
    da tela, entram duas travas que o caminho antigo nao precisava:
      - so' aceita versao MAIS NOVA que a instalada. Um manifesto antigo e
        legitimo continua passando na assinatura; sem esta trava, daria para
        "atualizar" para tras, para uma versao com defeito conhecido;
      - o canal do manifesto tem de ser o desta copia. Ele nao e' assinado,
        entao isto e' trava de engano, nao de seguranca.
    """
    if MODO_WEB:
        return _bloqueado_na_web()
    # Aberto de dentro do .rar: a atualizacao seria gravada numa pasta que o
    # WinRAR apaga ao fechar. Aplicar seria so' dar ao antivirus mais um motivo
    # - e oferecer a mesma atualizacao de novo na proxima abertura.
    if _pasta_temporaria():
        return jsonify({"success": False, "error": _AVISO_PASTA_TEMPORARIA}), 409

    try:
        manifesto = json.loads(request.form.get("manifesto") or "")
    except ValueError:
        manifesto = None
    if not isinstance(manifesto, dict):
        return jsonify({"success": False, "error": "manifesto ausente"}), 400

    enviado = request.files.get("pacote")
    if enviado is None:
        return jsonify({"success": False, "error": "pacote ausente"}), 400
    pacote = enviado.read(atualizador.TAMANHO_MAXIMO + 1)
    if len(pacote) > atualizador.TAMANHO_MAXIMO:
        return jsonify({"success": False, "error": "pacote grande demais"}), 413

    # A mesma ordem de sempre: conferir ANTES de qualquer outra coisa. Depois
    # daqui, versao e liberado_para sao confiaveis - estao dentro da assinatura.
    motivo = atualizador.conferir_pacote(pacote, manifesto, licenca.CHAVE_PUBLICA)
    if motivo:
        return jsonify({"success": False, "error": motivo}), 400

    restricao = _liberado_para_mim(manifesto, _id_da_instalacao())
    if restricao:
        return jsonify({"success": False, "error": restricao}), 403

    nova = str(manifesto.get("versao", "")).strip()
    instalada = _versao_instalada()
    if not _mais_nova(nova, instalada):
        return jsonify({"success": False,
                        "error": "a versão %s não é mais nova que a instalada (%s)"
                                 % (nova or "?", instalada)}), 409

    canal = str(manifesto.get("canal") or "").strip().lower()
    if canal and canal != _canal_atual():
        return jsonify({"success": False,
                        "error": "este pacote é do canal %s, e esta cópia está no %s"
                                 % (canal, _canal_atual())}), 409

    ok, msg = atualizador.aplicar(pacote, _pasta_do_programa())
    if not ok:
        return jsonify({"success": False, "error": msg}), 500
    return jsonify({"success": True, "mensagem": msg, "versao": nova,
                    "reiniciar": True})


@app.route("/api/prefs", methods=["GET", "POST"])
def api_prefs():
    # Preferências persistentes (templates/layouts de gráficos, campos fixos do
    # certificado...) num JSON ao lado do executável - sobrevivem a reinstalar,
    # trocar de máquina ou limpar o cache do WebView2.
    u = _usuario()
    if request.method == "GET":
        try:
            with open(PREFS_FILE, "r", encoding="utf-8") as fh:
                todos = json.load(fh) or {}
        except Exception:  # noqa: BLE001
            return jsonify({})
        # Formato antigo (um usuário só) continua funcionando no app de mesa.
        if u == "default" and not isinstance(todos.get(u), dict):
            return jsonify({k: v for k, v in todos.items() if not isinstance(v, dict) or k != "__users__"})
        return jsonify((todos.get("__users__", {}) or {}).get(u, {}))
    body = request.get_json(force=True, silent=True)
    if not isinstance(body, dict):
        return jsonify({"success": False, "error": "esperado objeto JSON"}), 400

    # Chaves do servidor, não da tela. O POST caía direto na raiz sem filtro:
    # qualquer coisa que falasse com 127.0.0.1 podia trocar de onde vêm as
    # atualizações, zerar o teste ou esconder abas. Não dá pra instalar nada
    # falso (a assinatura continua valendo), mas isso não é assunto de página.
    reservadas = [k for k in body if k in (
        "__url_atualizacao", "__canal_atualizacao", "__edicao_remota",
        "__instalacao", "__relogio", "__teste_desde", "__users__")]
    if reservadas:
        return jsonify({"success": False,
                        "error": "estas preferências são do programa, não da tela: "
                                 + ", ".join(sorted(reservadas))}), 403

    try:
        # A mesma trava do _prefs_grava: sem ela, este merge e o da licença
        # rodam ao mesmo tempo e o último a gravar apaga o que o outro fez.
        with _TRAVA_PREFS:
            # Mescla com o que já existe (cada módulo grava só as suas chaves).
            cur = {}
            if os.path.exists(PREFS_FILE):
                try:
                    with open(PREFS_FILE, "r", encoding="utf-8") as fh:
                        cur = json.load(fh) or {}
                except Exception:  # noqa: BLE001
                    cur = {}
            if u == "default":
                cur.update(body)            # app de mesa: como sempre foi
            else:
                users = cur.setdefault("__users__", {})
                users.setdefault(u, {}).update(body)
            _gravar_json_atomico(PREFS_FILE, cur)
        return jsonify({"success": True})
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": str(e)}), 500


# -- CONFIGURAÇÕES NUMA PASTA ------------------------------------------------
# Item 13 da lista do Naor: levar dados da empresa, colunas e modelos para
# outro computador. Ele respondeu "a aparência do relatório precisa de um
# arquivo próprio, então uma pasta de arquivos talvez" - então é uma pasta,
# um arquivo por assunto, e o logotipo como imagem de verdade (abre em
# qualquer visualizador, troca-se sem mexer em JSON).
#
# Quem monta o conteúdo é a tela, que já lê as preferências do usuário certo;
# aqui só se grava e se lê, e só nomes conhecidos - nada de caminho vindo de
# fora virar arquivo arbitrário no disco.
_CONFIG_ARQUIVOS = {
    "LEIA-ME.txt": "texto",
    "empresa.json": "json",
    "relatorio-aparencia.json": "json",
    "relatorio-logotipo.png": "imagem",
    "relatorio-logotipo.jpg": "imagem",
    "clientes.json": "json",
    "colunas.json": "json",
    "graficos.json": "json",
    "painel.json": "json",
    "planilha.json": "json",
    "previsao.json": "json",
    "agenda.json": "json",
    "programa.json": "json",
}
_CONFIG_MAX_BYTES = 6 * 1024 * 1024


@app.route("/api/configuracoes/exportar", methods=["POST"])
def api_configuracoes_exportar():
    if MODO_WEB:
        return _bloqueado_na_web()
    import base64  # noqa: PLC0415
    body = request.get_json(force=True, silent=True) or {}
    pasta = str(body.get("pasta") or "").strip()
    arquivos = body.get("arquivos") or {}
    if not pasta or not os.path.isdir(pasta):
        return jsonify({"success": False, "error": "pasta não encontrada"}), 400
    if not isinstance(arquivos, dict) or not arquivos:
        return jsonify({"success": False, "error": "nada para gravar"}), 400
    base = "Concrestats - configurações " + datetime.date.today().strftime("%d-%m-%Y")
    destino = os.path.join(pasta, base)
    n = 2
    while os.path.exists(destino):
        destino = os.path.join(pasta, f"{base} ({n})")
        n += 1
    try:
        os.makedirs(destino)
        gravados = []
        for nome, conteudo in arquivos.items():
            tipo = _CONFIG_ARQUIVOS.get(nome)
            if not tipo or not isinstance(conteudo, str):
                continue
            if tipo == "imagem":
                dados = base64.b64decode(conteudo.split(",", 1)[-1])
            else:
                dados = conteudo.encode("utf-8")
            if len(dados) > _CONFIG_MAX_BYTES:
                continue
            with open(os.path.join(destino, nome), "wb") as fh:
                fh.write(dados)
            gravados.append(nome)
        return jsonify({"success": True, "pasta": destino, "arquivos": gravados})
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/configuracoes/ler", methods=["POST"])
def api_configuracoes_ler():
    if MODO_WEB:
        return _bloqueado_na_web()
    import base64  # noqa: PLC0415
    body = request.get_json(force=True, silent=True) or {}
    pasta = str(body.get("pasta") or "").strip()
    if not pasta or not os.path.isdir(pasta):
        return jsonify({"success": False, "error": "pasta não encontrada"}), 400
    achados = {}
    problemas = []
    for nome, tipo in _CONFIG_ARQUIVOS.items():
        caminho = os.path.join(pasta, nome)
        if tipo == "texto" or not os.path.isfile(caminho):
            continue
        try:
            if os.path.getsize(caminho) > _CONFIG_MAX_BYTES:
                problemas.append(nome + " (grande demais)")
                continue
            with open(caminho, "rb") as fh:
                dados = fh.read()
            if tipo == "imagem":
                mime = "image/png" if nome.endswith(".png") else "image/jpeg"
                achados[nome] = "data:" + mime + ";base64," + base64.b64encode(dados).decode("ascii")
            else:
                achados[nome] = json.loads(dados.decode("utf-8-sig"))
        except Exception:  # noqa: BLE001 -- um arquivo estragado não derruba os outros
            problemas.append(nome)
    return jsonify({"success": True, "pasta": pasta, "arquivos": achados, "problemas": problemas})


@app.route("/api/receitas", methods=["GET", "POST"])
def api_receitas():
    # Receitas ficam num JSON ao lado do executável.
    if request.method == "GET":
        if os.path.exists(RECEITAS_FILE):
            try:
                with open(RECEITAS_FILE, "r", encoding="utf-8") as fh:
                    return jsonify(json.load(fh))
            except Exception:  # noqa: BLE001
                return jsonify([])
        return jsonify([])
    body = request.get_json(force=True, silent=True)
    # Corpo que não chegou inteiro virava lista vazia, e o arquivo era
    # sobrescrito com ela - TODAS as receitas apagadas, respondendo
    # {"success": true}. Diferente das planilhas, receitas.json não tem cópia
    # de segurança: era perda definitiva e silenciosa. Basta um POST truncado.
    if not isinstance(body, list):
        return jsonify({"success": False,
                        "error": "esperado uma lista de receitas"}), 400
    try:
        with open(RECEITAS_FILE, "w", encoding="utf-8") as fh:
            json.dump(body, fh, ensure_ascii=False, indent=2)
        return jsonify({"success": True})
    except Exception as e:  # noqa: BLE001
        return jsonify({"success": False, "error": str(e)}), 500


# --------------------------------------------------------------------------
# Inicialização
# --------------------------------------------------------------------------
def open_browser():
    try:
        webbrowser.open("http://127.0.0.1:5000")
    except Exception:  # noqa: BLE001
        pass


def _run_server():
    app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False, threaded=True)


class FecharJanela:
    """O X da janela: pergunta antes de perder o que nao foi salvo.

    O Naor: "eu editei e fechei. nao apareceu a janela Deseja salvar antes de
    sair?". Nao tinha como aparecer: a janela do WebView2 fecha sem passar pelo
    beforeunload da pagina. Quem fica sabendo do X e' o pywebview, no evento
    closing, e ele tem duas condicoes:

      * roda NA LINHA DA JANELA (e' o FormClosing do WinForms). evaluate_js fica
        parado num semaforo esperando a resposta, e quem entrega a resposta e'
        essa mesma linha: perguntar a' tela de dentro dele congela o programa;
      * so' cancela o fechamento quem devolver False na hora.

    Entao o X sempre cancela, e a conversa com a tela acontece em outra linha.
    Se ela disser que nao ha' nada pendente, fecha de verdade. Se ela abriu a
    caixa, quem decide e' a pessoa, e a tela chama liberar() pela JsApi. Tela
    travada, com erro ou sem resposta em ESPERA segundos nunca prende ninguem:
    fecha do mesmo jeito.
    """

    ESPERA = 5.0
    PERGUNTA = "window.ConcrestatsFechar ? window.ConcrestatsFechar.pedir() : 'livre'"

    def __init__(self, janela):
        self.janela = janela
        self.liberado = False
        self._consultando = False

    def ao_fechar(self):
        """O handler do closing: tem de voltar na hora, sem falar com a tela."""
        if self.liberado:
            return True
        # Clique duplo no X nao vale como "fecha logo": a primeira consulta
        # ainda vai dizer se ha' o que salvar.
        if not self._consultando:
            self._consultando = True
            threading.Thread(target=self._consultar, daemon=True).start()
        return False

    def _consultar(self):
        resposta = self._perguntar_a_tela()
        self._consultando = False
        if resposta != "perguntando":
            self.liberar()

    def _perguntar_a_tela(self):
        """O que a tela respondeu, ou None se ela nao respondeu a tempo.

        A pergunta vai numa linha propria porque evaluate_js nao tem prazo: com
        a tela travada ela nunca volta, e fica la' esquecida (daemon).
        """
        resposta = []

        def ler():
            try:
                resposta.append(self.janela.evaluate_js(self.PERGUNTA))
            except Exception:  # noqa: BLE001 -- tela quebrada tambem nao segura
                resposta.append(None)

        linha = threading.Thread(target=ler, daemon=True)
        linha.start()
        linha.join(self.ESPERA)
        return resposta[0] if resposta else None

    def liberar(self):
        """Fecha de verdade. E' o que a tela chama depois de salvar."""
        self.liberado = True
        try:
            self.janela.destroy()
        except Exception:  # noqa: BLE001 -- liberado ja' vale: o proximo X passa
            pass


if __name__ == "__main__":
    # Executado como app de mesa: libera os recursos locais (abrir por caminho,
    # salvar no arquivo de origem, recarregar). Servido por gunicorn/host, o
    # módulo é só importado e MODO_WEB continua True.
    MODO_WEB = False
    abrir_sessao()
    # Saida limpa por qualquer caminho (janela fechada, Ctrl+C, sem janela)
    # apaga a marca. Morte de verdade - processo derrubado pelo WebView2 ou
    # encerrado pelo antivirus - nao roda isto, e e' assim que as duas coisas
    # se distinguem no quedas.txt.
    import atexit
    atexit.register(fechar_sessao)
    # Flask sobe numa thread em segundo plano.
    threading.Thread(target=_run_server, daemon=True).start()

    # Sem janela: serve para conferir uma versão sem uma tela abrir na cara de
    # quem está usando o computador. É o que permite testar de verdade que o
    # programa SOBE pelo código atualizado - e não só que os arquivos chegaram.
    if os.environ.get("CONCRE_NO_WINDOW") == "1":
        print("Concrestats no ar em http://127.0.0.1:5000 (sem janela)")
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            raise SystemExit(0)

    # App NATIVO do Windows: abre numa JANELA PRÓPRIA (WebView2), como Spotify -
    # nada de navegador. Se o pywebview não estiver presente, cai pro navegador.
    try:
        import webview  # pywebview
        time.sleep(1.0)  # garante o servidor no ar antes de criar a janela

        class JsApi:
            """Diálogos NATIVOS do Windows (window.pywebview.api.* no frontend).
            Entregam o caminho REAL do arquivo - o Salvar grava no próprio .xlsx."""

            _FT = ("Planilhas (*.xlsx;*.xls;*.csv)", "Todos os arquivos (*.*)")

            def _win(self):
                return webview.windows[0] if webview.windows else None

            def open_file_dialog(self):
                w = self._win()
                if not w:
                    return None
                mode = getattr(webview, "OPEN_DIALOG", None)
                if mode is None:
                    mode = webview.FileDialog.OPEN
                res = w.create_file_dialog(mode, allow_multiple=False,
                                           file_types=self._FT)
                if not res:
                    return None
                return res[0] if isinstance(res, (list, tuple)) else res

            def open_licenca_dialog(self):
                """O seletor da licença usava o mesmo filtro das planilhas.
                O Windows abria mostrando só .xlsx/.xls/.csv, o licenca.key
                ficava escondido, e o cliente concluía que o arquivo não
                servia - "o que eu faço com esse .key?"."""
                w = self._win()
                if not w:
                    return None
                mode = getattr(webview, "OPEN_DIALOG", None)
                if mode is None:
                    mode = webview.FileDialog.OPEN
                res = w.create_file_dialog(
                    mode, allow_multiple=False,
                    file_types=("Licença do Concrestats (*.key)",
                                "Todos os arquivos (*.*)"))
                if not res:
                    return None
                return res[0] if isinstance(res, (list, tuple)) else res

            def save_file_dialog(self, default_name="planilha.xlsx"):
                w = self._win()
                if not w:
                    return None
                mode = getattr(webview, "SAVE_DIALOG", None)
                if mode is None:
                    mode = webview.FileDialog.SAVE
                res = w.create_file_dialog(mode, save_filename=str(default_name),
                                           file_types=self._FT)
                if not res:
                    return None
                return res[0] if isinstance(res, (list, tuple)) else res

            def escolher_pasta(self):
                """Pasta para gravar ou ler as configurações (Aparência e
                configurações > Levar para outro computador)."""
                w = self._win()
                if not w:
                    return None
                mode = getattr(webview, "FOLDER_DIALOG", None)
                if mode is None:
                    mode = webview.FileDialog.FOLDER
                res = w.create_file_dialog(mode)
                if not res:
                    return None
                return res[0] if isinstance(res, (list, tuple)) else res

            def definir_zoom(self, fator):
                """Tamanho da letra (item 23 da lista do Naor).

                É o zoom do próprio WebView2, e não CSS: com zoom de CSS o
                arrastar do Painel e a largura das colunas andam numa escala e
                o mouse noutra. O do navegador aumenta tudo junto, como o
                Ctrl + do Edge."""
                try:
                    f = float(fator)
                except (TypeError, ValueError):
                    return False
                f = min(1.6, max(0.8, f))
                w = self._win()
                forma = getattr(w, "native", None) if w else None
                controle = getattr(forma, "webview", None) if forma else None
                if controle is None:
                    return False
                try:
                    # O mesmo jeito do pywebview de rodar na linha da janela.
                    from System import Func, Type  # noqa: PLC0415 -- pythonnet, só no Windows

                    def _aplicar():
                        controle.ZoomFactor = f
                    forma.Invoke(Func[Type](_aplicar))
                    return True
                except Exception:  # noqa: BLE001
                    return False

            def fechar_agora(self):
                """A tela resolveu o X: salvou, ou a pessoa escolheu não salvar."""
                fechamento.liberar()

        janela = webview.create_window(
            "Concrestats", "http://127.0.0.1:5000",
            width=1280, height=820, min_size=(900, 600),
            js_api=JsApi(),
        )
        fechamento = FecharJanela(janela)
        janela.events.closing += fechamento.ao_fechar

        # private_mode=False + storage_path: o WebView2 usa um perfil PERSISTENTE
        # ao lado do exe (por padrão o pywebview é "anônimo" e o localStorage -
        # templates, layouts, campos fixos - sumia ao fechar o app).
        # Icone da JANELA: sem isto o pywebview extrai o icone de sys.executable
        # - que no modo de desenvolvimento e' o python.exe, e a janela abria com
        # o icone da cobrinha.
        _ico = resource_path("icon.ico")
        webview.start(
            private_mode=False,
            storage_path=os.path.join(app_dir(), "webview_data"),
            icon=_ico if os.path.isfile(_ico) else None,
        )  # bloqueia até fechar a janela
        # Chegou aqui: a janela foi fechada por quem estava usando. Isso NAO e'
        # queda, entao a marca sai.
        fechar_sessao()
    except Exception:  # noqa: BLE001 -- fallback: navegador
        threading.Timer(1.0, open_browser).start()
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            pass
