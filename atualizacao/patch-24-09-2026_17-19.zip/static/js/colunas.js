/* colunas.js — de qual coluna o programa lê o quê, em TODAS as telas.
 *
 * O Naor, em 24/09/2026: "Se alguém tiver uma tabela diferente, funciona
 * também? Se não, precisa da opção de escolher as colunas."
 *
 * Só funcionava em parte. A Previsão ganhou um seletor de colunas em 18/09,
 * mas o Dashboard, o Painel automático, o Relatório técnico e os padrões dos
 * Gráficos procuravam nomes fixos — "MPA 28", "CLIENTE", "PRODUTO", "DATA",
 * "M³". Numa planilha com "Resistência 28d" e "Volume (m³)", essas telas
 * saíam com partes vazias, sem aviso e sem jeito de corrigir.
 *
 * Aqui mora o que todas passam a usar:
 *   - os PAPÉIS que o programa precisa (produto, receita, cliente, data,
 *     volume, rompimentos de 28 e 7 dias, fck pedido, CP, NF...);
 *   - o reconhecimento pelo nome, tolerante a acento, maiúscula, pontuação e
 *     espaço — o mesmo que já funcionava na Previsão;
 *   - a escolha manual, guardada por FORMATO de planilha (mesma sequência de
 *     cabeçalhos): quem usa o mesmo modelo todo mês responde uma vez só;
 *   - a caixa para escolher, aberta pelo botão "Colunas" da planilha ou de
 *     qualquer tela que precise.
 *
 * A escolha manual sempre vence o reconhecimento automático: ela foi feita
 * por quem olhou a planilha.
 */
(function () {
  'use strict';

  const PAPEIS = [
    { id: 'produto', rotulo: 'Produto', dica: 'o que foi vendido (ex.: "FCK 30 S100 laje")',
      apelidos: ['PRODUTO', 'DESCRICAO', 'DESCRIÇÃO', 'MATERIAL', 'SERVICO', 'SERVIÇO',
                 'APLICACAO', 'APLICAÇÃO', 'PECA', 'PEÇA'] },
    { id: 'receita', rotulo: 'Receita / traço', dica: 'a dosagem usada',
      apelidos: ['RECEITA', 'TRACO', 'TRAÇO', 'DOSAGEM', 'MIX', 'RECIPE'] },
    { id: 'cliente', rotulo: 'Cliente', apelidos: ['CLIENTE', 'CONTRATANTE', 'COMPRADOR'] },
    { id: 'obra', rotulo: 'Obra', apelidos: ['OBRA', 'LOCAL DA OBRA'] },
    { id: 'data', rotulo: 'Data de moldagem',
      apelidos: ['DATA', 'DATA DE MOLDAGEM', 'DATA MOLDAGEM', 'MOLDAGEM'] },
    { id: 'volume', rotulo: 'Volume (m³)', apelidos: ['M³', 'M3', 'VOLUME', 'MC'] },
    { id: 'mpa28', rotulo: 'Rompimento aos 28 dias (MPa)', essencial: true,
      apelidos: ['MPA 28', 'MPA28', 'MPA 28D', 'FC 28', 'FCJ 28', 'RESISTENCIA 28',
                 'RESISTÊNCIA 28', '28 DIAS', 'RUPTURA 28'] },
    { id: 'mpa28b', rotulo: '2º corpo de prova aos 28 dias (MPa)',
      dica: 'o segundo CP rompido do mesmo exemplar — vale o maior dos dois (NBR 12655)',
      apelidos: ['MPA 28 1', 'MPA28 1', 'MPA 28 2', 'MPA 28 CP2', 'MPA 28 B', 'FC 28 2',
                 'CP2 28', 'CP 2 28'] },
    { id: 'mpa7', rotulo: 'Rompimento aos 7 dias (MPa)',
      apelidos: ['MPA 7', 'MPA7', 'MPA 7D', 'FC 7', 'FCJ 7', 'RESISTENCIA 7',
                 'RESISTÊNCIA 7', '7 DIAS', 'RUPTURA 7'] },
    { id: 'tnf28', rotulo: 'Carga de ruptura aos 28 dias (tf)',
      apelidos: ['TNF 28', 'TNF28', 'CARGA 28', 'RUPTURA TON', 'RUPTURA (TON)'] },
    { id: 'fck', rotulo: 'fck pedido (MPa)',
      dica: 'o que o cliente pediu — nunca a mesma coluna do rompimento',
      apelidos: ['FCK', 'FCK PEDIDO', 'FCK MPA', 'FCK PROJETO', 'RESISTENCIA PEDIDA',
                 'RESISTÊNCIA PEDIDA', 'RESISTENCIA CARACTERISTICA'] },
    { id: 'cp', rotulo: 'Corpo de prova (código)',
      apelidos: ['CP', 'CORPO DE PROVA', 'N CORPO DE PROVA', 'AMOSTRA', 'COD', 'CÓD'] },
    { id: 'nf', rotulo: 'Nota fiscal', apelidos: ['NF', 'NOTA FISCAL', 'NOTA'] },
  ];
  const POR_ID = {};
  PAPEIS.forEach(p => { POR_ID[p.id] = p; });

  // Papéis que nunca podem cair na mesma coluna: o fck pedido lido da coluna
  // do rompimento aprovaria qualquer coisa; o 2º CP igual ao 1º dobraria a
  // conta; 7 e 28 dias na mesma coluna fariam a previsão prever a si mesma.
  const EXCLUSIVOS = ['mpa28', 'mpa28b', 'mpa7', 'fck', 'tnf28'];

  /* ── o nome, sem o que não importa ────────────────────────────────── */
  function normaliza(s) {
    return String(s == null ? '' : s)
      .replace(/³/g, '3').replace(/²/g, '2')
      .normalize('NFD').replace(/[̀-ͯ]/g, '')
      .toUpperCase().replace(/[^A-Z0-9]+/g, ' ').trim();
  }

  // Inteiro primeiro, depois palavra inteira na ponta, depois pedaço (só para
  // nome longo — senão "M3" casaria dentro de tudo).
  function coluna(headers, nomes) {
    const hs = (headers || []).map(normaliza);
    const alvos = (nomes || []).map(normaliza).filter(Boolean);
    for (const a of alvos) {
      const i = hs.indexOf(a);
      if (i >= 0) return i;
    }
    for (const a of alvos) {
      const i = hs.findIndex(h => h.startsWith(a + ' ') || h.endsWith(' ' + a));
      if (i >= 0) return i;
    }
    for (const a of alvos) {
      if (a.length < 4) continue;
      const i = hs.findIndex(h => h.indexOf(a) >= 0);
      if (i >= 0) return i;
    }
    return -1;
  }

  function formato(headers) {
    return (headers || []).map(normaliza).join('|').slice(0, 400);
  }

  /* ── o que foi escolhido à mão ────────────────────────────────────── */
  // { formato: { papel: índice } }. -1 guardado = "esta planilha não tem".
  let escolhas = {};
  let carregado = false;
  // O Dashboard pergunta o fck linha por linha — 4.809 vezes na planilha da
  // Usinop. Refazer o reconhecimento a cada pergunta custaria segundos; a
  // resposta fica guardada por lista de cabeçalhos, e qualquer escolha nova
  // (ou a leitura das preferências) invalida tudo.
  let versao = 0;
  let cache = new WeakMap();
  function mudou() { versao++; cache = new WeakMap(); }

  function carregar() {
    if (typeof window.prefsGet !== 'function') { carregado = true; return Promise.resolve(); }
    return window.prefsGet().then(p => {
      escolhas = (p && p.colunas_por_formato) || {};
      // A Previsão guardava as dela à parte até 24/09/2026. Entram aqui, sem
      // passar por cima do que já foi escolhido no lugar novo.
      const antigas = (p && p.previsao_colunas) || {};
      Object.keys(antigas).forEach(f => {
        const a = antigas[f] || {};
        const alvo = escolhas[f] = Object.assign({}, escolhas[f] || {});
        if (Number.isInteger(a.r) && !('produto' in alvo)) alvo.produto = a.r;
        if (Number.isInteger(a.d28) && !('mpa28' in alvo)) alvo.mpa28 = a.d28;
        if (Number.isInteger(a.d7) && !('mpa7' in alvo)) alvo.mpa7 = a.d7;
      });
      carregado = true;
      mudou();
      avisarMudanca();
    }).catch(() => { carregado = true; });
  }

  function gravar() {
    try {
      fetch('/api/prefs', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ colunas_por_formato: escolhas }),
      }).catch(() => {});
    } catch (e) { /* sem prefs, vale só nesta abertura */ }
  }

  function manual(headers) {
    return escolhas[formato(headers)] || null;
  }

  /* ── a resposta: qual coluna faz qual papel ───────────────────────── */
  function mapa(headers) {
    headers = headers || [];
    const guardado = cache.get(headers);
    if (guardado && guardado.versao === versao) return guardado.r;
    const r = calcularMapa(headers);
    try { cache.set(headers, { versao, r }); } catch (e) { /* não é objeto: sem cache */ }
    return r;
  }

  // semManual: o que eu acharia sozinho — a caixa grava só o que a pessoa
  // mudou em relação a isto, e o resto continua se ajustando pelo nome.
  function calcularMapa(headers, semManual) {
    const m = (!semManual && manual(headers)) || {};
    const usados = new Set();
    const saida = {};
    const origem = {};
    // Escolhas manuais primeiro: elas reservam as colunas.
    PAPEIS.forEach(p => {
      if (Object.prototype.hasOwnProperty.call(m, p.id)) {
        const v = m[p.id];
        saida[p.id] = Number.isInteger(v) && v >= 0 && v < headers.length ? v : -1;
        origem[p.id] = 'manual';
        if (saida[p.id] >= 0 && EXCLUSIVOS.includes(p.id)) usados.add(saida[p.id]);
      }
    });
    PAPEIS.forEach(p => {
      if (p.id in saida) return;
      let i = coluna(headers, p.apelidos);
      if (i >= 0 && EXCLUSIVOS.includes(p.id) && usados.has(i)) i = -1;
      saida[p.id] = i;
      origem[p.id] = i >= 0 ? 'nome' : 'nenhum';
      if (i >= 0 && EXCLUSIVOS.includes(p.id)) usados.add(i);
    });
    // O 2º corpo de prova raramente tem nome próprio: é a coluna IRMÃ da
    // primeira — "Resistência 28d CP1" e "CP2", "FC 28 A" e "B", ou a
    // numeração que o pandas dá ao cabeçalho repetido ("MPA 28" e "MPA 28.1").
    if (saida.mpa28b < 0 && origem.mpa28b !== 'manual' && saida.mpa28 >= 0) {
      const j = colunaIrma(headers, saida.mpa28, usados);
      if (j >= 0) { saida.mpa28b = j; origem.mpa28b = 'nome'; usados.add(j); }
    }
    return { idx: saida, origem };
  }

  function colunaIrma(headers, i, usados) {
    const hs = headers.map(normaliza);
    const a = hs[i].split(' ');
    const par = (x, y) => x.replace(/1$/, '2') === y && x !== y ||
      (x === 'A' && y === 'B') || (x === 'I' && y === 'II');
    for (let j = 0; j < hs.length; j++) {
      if (j === i || usados.has(j) || !hs[j]) continue;
      const b = hs[j].split(' ');
      if (b.length === a.length + 1 && b.slice(0, a.length).join(' ') === hs[i] &&
          /^([1-9]|B|II|CP2)$/.test(b[b.length - 1])) return j;
      if (b.length !== a.length) continue;
      const dif = a.map((t, k) => (t !== b[k] ? k : -1)).filter(k => k >= 0);
      if (dif.length === 1 && par(a[dif[0]], b[dif[0]])) return j;
    }
    return -1;
  }

  function indice(headers, papel) {
    const r = mapa(headers).idx[papel];
    return Number.isInteger(r) ? r : -1;
  }
  function nome(headers, papel) {
    const i = indice(headers, papel);
    return i >= 0 ? headers[i] : '';
  }

  /* ── a caixa ─────────────────────────────────────────────────────── */
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g,
      c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function dadosAtuais() {
    const d = window.getConcrestatsData ? window.getConcrestatsData({ filtered: false }) : null;
    return d && Array.isArray(d.headers) && d.headers.length ? d : null;
  }

  function abrir() {
    const d = dadosAtuais();
    const abrirModal = window.openModal;
    if (typeof abrirModal !== 'function') return;
    if (!d) {
      if (window.toast) window.toast('Abra uma planilha primeiro', 'error');
      return;
    }
    const h = d.headers;
    const r = mapa(h);
    const exemplo = i => {
      const linha = (d.data || []).find(l => l && String(l[i] ?? '').trim() !== '');
      return linha ? String(linha[i]).trim().slice(0, 28) : '';
    };
    const linhas = PAPEIS.map(p => {
      const atual = r.idx[p.id];
      const opcoes = ['<option value="-1"' + (atual < 0 ? ' selected' : '') + '>— esta planilha não tem —</option>']
        .concat(h.map((x, i) => '<option value="' + i + '"' + (i === atual ? ' selected' : '') + '>' +
          esc(String(x == null ? '' : x).trim() || ('coluna ' + (i + 1))) +
          (exemplo(i) ? '  ·  ex.: ' + esc(exemplo(i)) : '') + '</option>'));
      const selo = r.origem[p.id] === 'manual' ? '<span class="col-selo manual">escolhida</span>'
        : r.origem[p.id] === 'nome' ? '<span class="col-selo">achei pelo nome</span>'
          : '<span class="col-selo falta">' + (p.essencial ? 'falta' : 'não achei') + '</span>';
      return '<div class="col-linha">' +
        '<label for="col-' + p.id + '">' + esc(p.rotulo) + selo +
        (p.dica ? '<span class="col-dica">' + esc(p.dica) + '</span>' : '') + '</label>' +
        '<select id="col-' + p.id + '" data-papel="' + p.id + '">' + opcoes.join('') + '</select></div>';
    }).join('');

    abrirModal('Colunas desta planilha',
      '<p class="col-intro">De qual coluna cada tela lê o quê. O que eu achei pelo nome já vem ' +
      'marcado; corrija o que estiver errado. Vale para todas as telas — Dashboard, Painel, ' +
      'Relatório, Gráficos e Previsão — e fica guardado para planilhas com os mesmos cabeçalhos.</p>' +
      '<div class="col-grade">' + linhas + '</div>' +
      '<div class="col-rodape"><button type="button" class="secondary-btn" id="col-automatico">' +
      'Voltar ao que eu acho sozinho</button><span id="col-aviso" class="col-aviso"></span></div>',
      () => {
        // Guarda só o que difere do que eu acharia sozinho. Gravar tudo
        // congelava também o que ficou em "não tem": escolher a coluna de 28
        // dias à mão deixava o 2º corpo de prova preso em vazio, mesmo com a
        // coluna irmã ao lado.
        const auto = calcularMapa(h, true).idx;
        const escolha = {};
        const vistos = {};
        let repetido = null;
        document.querySelectorAll('.col-grade select[data-papel]').forEach(s => {
          let v = parseInt(s.value, 10);
          if (!Number.isInteger(v)) v = -1;
          if (v !== auto[s.dataset.papel]) escolha[s.dataset.papel] = v;
          if (v >= 0 && EXCLUSIVOS.includes(s.dataset.papel)) {
            if (vistos[v]) repetido = [vistos[v], s.dataset.papel];
            vistos[v] = s.dataset.papel;
          }
        });
        if (repetido) {
          const aviso = document.getElementById('col-aviso');
          if (aviso) aviso.textContent = '"' + POR_ID[repetido[0]].rotulo + '" e "' +
            POR_ID[repetido[1]].rotulo + '" não podem ser a mesma coluna.';
          return;
        }
        if (Object.keys(escolha).length) escolhas[formato(h)] = escolha;
        else delete escolhas[formato(h)];
        mudou();
        gravar();
        if (window.closeModal) window.closeModal();
        avisarMudanca();
        if (window.toast) window.toast('Colunas guardadas para esta planilha', 'success');
      }, 'modal-colunas');

    const ok = document.getElementById('modal-confirm');
    if (ok) ok.textContent = 'Usar estas colunas';
    // Escolheu o 28 dias à mão e o 2º CP está vazio: sugerir a coluna irmã.
    const s28 = document.getElementById('col-mpa28');
    const s28b = document.getElementById('col-mpa28b');
    if (s28 && s28b) s28.addEventListener('change', () => {
      const i = parseInt(s28.value, 10);
      if (!(i >= 0) || parseInt(s28b.value, 10) >= 0) return;
      const outros = new Set();
      document.querySelectorAll('.col-grade select[data-papel]').forEach(s => {
        const v = parseInt(s.value, 10);
        if (v >= 0 && s !== s28 && EXCLUSIVOS.includes(s.dataset.papel)) outros.add(v);
      });
      const j = colunaIrma(h, i, outros);
      if (j >= 0) s28b.value = String(j);
    });
    const auto = document.getElementById('col-automatico');
    if (auto) auto.addEventListener('click', () => {
      delete escolhas[formato(h)];
      mudou();
      gravar();
      if (window.closeModal) window.closeModal();
      avisarMudanca();
      if (window.toast) window.toast('Voltei a achar as colunas pelo nome', 'success');
    });
  }

  // Quem mostra dados redesenha: o Dashboard, o Painel, a Previsão e o
  // Relatório escutam a troca de planilha; a troca de colunas usa o mesmo
  // caminho, com um evento a mais para quem quiser saber o motivo.
  function avisarMudanca() {
    window.dispatchEvent(new CustomEvent('concrestats:colunas'));
    try {
      if (typeof window.notifyDataChanged === 'function') window.notifyDataChanged('colunas');
    } catch (e) { /* a tela redesenha na próxima troca */ }
  }

  // Planilha aberta sem o essencial (o rompimento de 28 dias): oferecer a
  // escolha na hora, uma vez por formato — e não esperar a pessoa descobrir
  // sozinha por que o Dashboard veio vazio.
  const jaOfereceu = new Set();
  function conferirAoAbrir() {
    const d = dadosAtuais();
    if (!d || !window.toast) return;
    const f = formato(d.headers);
    if (jaOfereceu.has(f)) return;
    if (indice(d.headers, 'mpa28') >= 0) return;
    if (d.headers.length < 3 || !(d.data || []).length) return;
    jaOfereceu.add(f);
    window.toast('Não reconheci a coluna do rompimento de 28 dias nesta planilha.', 'error',
                 { texto: 'Escolher colunas', fn: abrir });
  }

  window.ConcreColunas = {
    PAPEIS, normaliza, coluna, formato, mapa, indice, nome, abrir, carregar,
    // a coluna irmã (2º CP) de qualquer coluna — o relatório usa para a carga
    irma: (headers, i) => colunaIrma(headers || [], i, new Set()),
    pronto: () => carregado,
    // para o Modo Teste e a Previsão: gravar uma escolha sem passar pela caixa
    _escolher: (headers, escolha) => {
      escolhas[formato(headers)] = Object.assign({}, escolhas[formato(headers)] || {}, escolha);
      mudou(); gravar(); avisarMudanca();
    },
    _esquecer: headers => { delete escolhas[formato(headers)]; mudou(); gravar(); avisarMudanca(); },
  };

  document.addEventListener('DOMContentLoaded', () => {
    carregar();
    const b = document.getElementById('btn-colunas');
    if (b) b.addEventListener('click', abrir);
    window.addEventListener('concrestats:datachanged', () => setTimeout(conferirAoAbrir, 600));
  });
})();
