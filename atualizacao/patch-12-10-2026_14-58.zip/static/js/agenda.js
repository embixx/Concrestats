/* agenda.js — quais corpos de prova rompem em cada dia.
 *
 * Pedido do Naor (12/10/2026), com as palavras dele: "selecione a coluna de
 * data, a coluna de ID do CP -> em um calendário vc clica no dia escolhe uma
 * idade de rompimento e uma lista será gerada."
 *
 * A conta é moldagem + idade. O calendário mostra, em cada dia, quantos CPs
 * de cada idade escolhida rompem nele; clicar no dia lista quais são. Quando
 * a planilha tem a coluna do resultado daquela idade (MPA 7, MPA 28...), a
 * lista diz também se o CP já foi rompido — e o que passou do dia sem
 * resultado aparece como atrasado.
 *
 * Usa a planilha aberta com os filtros aplicados, como as outras telas.
 */
(function () {
  'use strict';

  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const DIA_MS = 86400000;
  const IDADES_PADRAO = [3, 7, 14, 28, 63];
  const MESES = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho',
    'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  const SEMANA = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  // Uma cor por idade, a mesma no calendário e na lista.
  const COR_IDADE = { 3: '#8a6d1f', 7: '#2f7df0', 14: '#6b4fb8', 28: '#1a7a4c', 63: '#a8502a' };
  const corDa = i => COR_IDADE[i] || '#5a5852';

  const est = {
    colData: '', colCP: '',
    idades: [7, 28],
    extras: [],           // idades fora da lista padrão que alguém acrescentou
    ano: 0, mes: 0,       // mês à mostra
    dia: null,            // dia escolhido (número de dias desde 1970, em UTC)
    verAtrasados: false,
    carregou: false,
  };

  /* ── datas como número de dia ─────────────────────────────────────────
   * Tudo em dias inteiros contados em UTC: somar 28 dias nunca escorrega de
   * dia por causa de fuso ou horário de verão. */
  function diaDe(v) {
    if (v === null || v === undefined || v === '') return null;
    if (typeof v === 'number' && isFinite(v)) {
      return v > 20000 && v < 80000 ? Math.round(v) - 25569 : null;   // série do Excel
    }
    const s = String(v).trim();
    let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3]) / DIA_MS;
    m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/);
    if (m) {
      const ano = m[3].length === 2 ? 2000 + (+m[3]) : +m[3];
      return Date.UTC(ano, +m[2] - 1, +m[1]) / DIA_MS;
    }
    if (/^\d{5}(\.\d+)?$/.test(s)) return diaDe(Number(s));
    return null;
  }
  function hoje() {
    const d = new Date();
    return Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / DIA_MS;
  }
  const dataDoDia = n => new Date(n * DIA_MS);
  function fmtDia(n) {
    const d = dataDoDia(n);
    return String(d.getUTCDate()).padStart(2, '0') + '/' +
      String(d.getUTCMonth() + 1).padStart(2, '0') + '/' + d.getUTCFullYear();
  }
  function diaPorExtenso(n) {
    const d = dataDoDia(n);
    const semana = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira',
      'quinta-feira', 'sexta-feira', 'sábado'][d.getUTCDay()];
    return semana + ', ' + d.getUTCDate() + ' de ' + MESES[d.getUTCMonth()] + ' de ' + d.getUTCFullYear();
  }
  const num = v => {
    if (typeof v === 'number') return v;
    const t = String(v == null ? '' : v).trim().replace(/\s/g, '');
    if (!t) return NaN;
    const x = t.includes(',') && t.includes('.')
      ? (t.lastIndexOf(',') > t.lastIndexOf('.') ? t.replace(/\./g, '').replace(',', '.') : t.replace(/,/g, ''))
      : t.replace(',', '.');
    const n = Number(x);
    return isFinite(n) ? n : NaN;
  };
  const fmtMpa = n => n.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 });

  /* ── dados ─────────────────────────────────────────────────────────── */
  function dados() {
    const d = window.getConcrestatsData ? window.getConcrestatsData({ filtered: true }) : null;
    if (!d || !Array.isArray(d.headers) || !d.headers.length) return null;
    return { headers: d.headers, rows: d.data || [] };
  }
  const CC = () => window.ConcreColunas;

  function colunaPadrao(headers, papel) {
    const c = CC();
    return c ? c.nome(headers, papel) : '';
  }

  // De onde ler o resultado de cada idade. 7 e 28 vêm da escolha de colunas
  // comum (com o 2º CP); as outras idades, pelo nome ("MPA 63", "63 DIAS").
  function colunasDoResultado(headers, idade) {
    const c = CC();
    if (!c) return [];
    if (idade === 7) return [c.indice(headers, 'mpa7')].filter(i => i >= 0);
    if (idade === 28) return [c.indice(headers, 'mpa28'), c.indice(headers, 'mpa28b')].filter(i => i >= 0);
    const i = c.coluna(headers, ['MPA ' + idade, 'MPA' + idade, 'FC ' + idade, 'FCJ ' + idade,
      'RESISTENCIA ' + idade, idade + ' DIAS', 'RUPTURA ' + idade]);
    return i >= 0 ? [i] : [];
  }

  /* Monta, para as idades escolhidas, a lista de rompimentos:
   * { idade, dia (rompe), molde, row, cp, resultado (NaN se não rompeu) } */
  function montar(f) {
    const H = f.headers;
    const iD = H.indexOf(est.colData);
    const iC = H.indexOf(est.colCP);
    const c = CC();
    const papel = p => (c ? c.indice(H, p) : -1);
    const ix = { cliente: papel('cliente'), obra: papel('obra'), receita: papel('receita'),
      produto: papel('produto'), nf: papel('nf') };
    const saida = { itens: [], semData: 0, semCP: 0, futuro: [], ix, temResultado: {} };
    if (iD < 0) return saida;
    const hj = hoje();
    const res = {};
    est.idades.forEach(a => {
      res[a] = colunasDoResultado(H, a);
      saida.temResultado[a] = res[a].length > 0;
    });
    f.rows.forEach(r => {
      const molde = diaDe(r[iD]);
      if (molde === null) { saida.semData++; return; }
      const cp = iC >= 0 ? String(r[iC] == null ? '' : r[iC]).trim() : '';
      // Sem código de CP a linha é carga sem corpo de prova moldado: não há
      // o que romper. Contada à parte, para o número não sumir calado.
      if (iC >= 0 && !cp) { saida.semCP++; return; }
      // Moldado "depois de hoje" é digitação (2026 no lugar de 2025): entra
      // no calendário como está, mas o aviso diz qual CP conferir.
      if (molde > hj) saida.futuro.push(cp || fmtDia(molde));
      est.idades.forEach(a => {
        const vals = res[a].map(i => num(r[i])).filter(v => isFinite(v) && v > 0);
        saida.itens.push({ idade: a, dia: molde + a, molde, row: r, cp,
          resultado: vals.length ? Math.max(...vals) : NaN });
      });
    });
    return saida;
  }

  // Atrasado é o que passou do dia há pouco — ainda dá para romper ou ir
  // atrás. Na planilha da Usinop, 1.276 CPs antigos não têm resultado de 7 ou
  // 28 dias (argamassa não rompe aos 7, carga cancelada...): contados como
  // atrasados, afogavam os três ou quatro que importam hoje.
  const JANELA_ATRASO = 30;
  function situacao(it, temResultado, hj) {
    if (isFinite(it.resultado)) return 'rompido';
    if (!temResultado) return 'sem-coluna';
    if (it.dia >= hj) return 'pendente';
    return it.dia >= hj - JANELA_ATRASO ? 'atrasado' : 'sem-resultado';
  }

  /* ── preferências ──────────────────────────────────────────────────── */
  function gravar() {
    try {
      fetch('/api/prefs', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agenda: { colData: est.colData, colCP: est.colCP,
          idades: est.idades, extras: est.extras } }) }).catch(() => {});
    } catch (e) { /* vale só nesta abertura */ }
  }
  function carregar() {
    if (est.carregou || typeof window.prefsGet !== 'function') return Promise.resolve();
    return window.prefsGet().then(p => {
      const a = p && p.agenda;
      if (a && typeof a === 'object') {
        if (a.colData) est.colData = String(a.colData);
        if (a.colCP) est.colCP = String(a.colCP);
        if (Array.isArray(a.idades) && a.idades.length) {
          est.idades = a.idades.map(Number).filter(n => Number.isInteger(n) && n > 0 && n < 400);
        }
        if (Array.isArray(a.extras)) {
          est.extras = a.extras.map(Number).filter(n => Number.isInteger(n) && n > 0 && n < 400);
        }
      }
      est.carregou = true;
    }).catch(() => { est.carregou = true; });
  }

  // A coluna guardada vale enquanto existir nesta planilha; senão, a que o
  // programa reconhece pelo nome.
  function acertarColunas(H) {
    if (!H.includes(est.colData)) est.colData = colunaPadrao(H, 'data') || '';
    if (!H.includes(est.colCP)) est.colCP = colunaPadrao(H, 'cp') || '';
  }

  /* ── barra de cima ─────────────────────────────────────────────────── */
  function montarBarra(H) {
    const opts = (cur, vazio) => ['<option value="">' + vazio + '</option>'].concat(H.map(h =>
      '<option value="' + esc(h) + '"' + (h === cur ? ' selected' : '') + '>' + esc(h) + '</option>')).join('');
    const sd = $('ag-col-data'), sc = $('ag-col-cp');
    if (sd) sd.innerHTML = opts(est.colData, '— escolha —');
    if (sc) sc.innerHTML = opts(est.colCP, '— sem código —');
    const box = $('ag-idades');
    if (box) {
      const todas = [...new Set(IDADES_PADRAO.concat(est.extras, est.idades))].sort((a, b) => a - b);
      box.innerHTML = todas.map(a => '<button type="button" class="ag-idade' +
        (est.idades.includes(a) ? ' ativo' : '') + '" data-idade="' + a + '" aria-pressed="' +
        est.idades.includes(a) + '" style="--cor-idade:' + corDa(a) + '">' + a + ' dias</button>').join('') +
        '<button type="button" class="ag-idade ag-idade-mais" id="ag-idade-mais" title="Outra idade">+</button>';
    }
  }

  /* ── calendário ────────────────────────────────────────────────────── */
  function calendarioHtml(porDia, temResultado, hj) {
    const primeiro = Date.UTC(est.ano, est.mes, 1) / DIA_MS;
    const diasNoMes = new Date(Date.UTC(est.ano, est.mes + 1, 0)).getUTCDate();
    const recuo = dataDoDia(primeiro).getUTCDay();
    let cel = '';
    for (let i = 0; i < recuo; i++) cel += '<div class="ag-dia vazio"></div>';
    for (let d = 0; d < diasNoMes; d++) {
      const n = primeiro + d;
      const grupos = porDia.get(n) || {};
      const marcas = est.idades.map(a => {
        const lista = grupos[a] || [];
        if (!lista.length) return '';
        const atras = lista.filter(it => situacao(it, temResultado[a], hj) === 'atrasado').length;
        const feitos = lista.filter(it => isFinite(it.resultado)).length;
        const tudo = feitos === lista.length;
        return '<span class="ag-marca' + (atras ? ' atrasado' : tudo ? ' feito' : '') +
          '" style="--cor-idade:' + corDa(a) + '" title="' + lista.length + ' CP(s) de ' + a + ' dias' +
          (atras ? ' — ' + atras + ' sem resultado' : tudo ? ' — todos rompidos' : '') + '">' +
          '<i>' + a + 'd</i>' + lista.length + '</span>';
      }).join('');
      const cls = ['ag-dia', n === hj ? 'hoje' : '', n === est.dia ? 'escolhido' : '',
        dataDoDia(n).getUTCDay() === 0 ? 'domingo' : ''].filter(Boolean).join(' ');
      cel += '<button type="button" class="' + cls + '" data-dia="' + n + '"><span class="ag-num">' +
        (d + 1) + '</span><span class="ag-marcas">' + marcas + '</span></button>';
    }
    return '<div class="ag-cal">' +
      '<div class="ag-cal-cab"><button type="button" class="ag-nav" id="ag-ant" title="Mês anterior">‹</button>' +
      '<h2>' + MESES[est.mes] + ' <span>' + est.ano + '</span></h2>' +
      '<button type="button" class="ag-nav" id="ag-prox" title="Próximo mês">›</button></div>' +
      '<div class="ag-semana">' + SEMANA.map(s => '<span>' + s + '</span>').join('') + '</div>' +
      '<div class="ag-grade">' + cel + '</div></div>';
  }

  /* ── a lista do dia ────────────────────────────────────────────────── */
  function textoDe(row, i) { return i >= 0 ? String(row[i] == null ? '' : row[i]).trim() : ''; }

  function tabelaHtml(lista, m, temResultado, hj, comIdade) {
    const ix = m.ix;
    const colObra = ix.obra >= 0 ? ix.obra : -1;
    const colRec = ix.receita >= 0 ? ix.receita : ix.produto;
    return '<table class="ag-tab"><thead><tr><th>CP</th>' + (comIdade ? '<th class="c-idade">Idade</th><th class="c-data">Rompia em</th>' : '') +
      '<th class="c-data">Moldagem</th><th>Cliente</th>' + (colObra >= 0 ? '<th>Obra</th>' : '') +
      '<th>Receita</th><th class="c-nf">NF</th><th class="n">Resultado</th></tr></thead><tbody>' +
      lista.map(it => {
        const sit = situacao(it, temResultado[it.idade], hj);
        const res = sit === 'rompido' ? fmtMpa(it.resultado) + ' <small>MPa</small>'
          : sit === 'atrasado' ? '<span class="ag-sit atrasado">atrasado</span>'
            : sit === 'pendente' ? '<span class="ag-sit">a romper</span>'
              : sit === 'sem-resultado' ? '<span class="ag-sit">sem resultado</span>' : '<span class="ag-sit">—</span>';
        return '<tr class="' + sit + '"><td class="cp">' + esc(it.cp || '—') + '</td>' +
          (comIdade ? '<td>' + it.idade + ' d</td><td>' + fmtDia(it.dia) + '</td>' : '') +
          '<td>' + fmtDia(it.molde) + '</td><td class="txt" title="' + esc(textoDe(it.row, ix.cliente)) + '">' +
          esc(textoDe(it.row, ix.cliente)) + '</td>' +
          (colObra >= 0 ? '<td class="txt">' + esc(textoDe(it.row, colObra)) + '</td>' : '') +
          '<td class="txt" title="' + esc(textoDe(it.row, colRec)) + '">' + esc(textoDe(it.row, colRec)) + '</td>' +
          '<td>' + esc(textoDe(it.row, ix.nf)) + '</td><td class="n">' + res + '</td></tr>';
      }).join('') + '</tbody></table>';
  }

  function listaHtml(m, porDia, atrasados, hj) {
    if (est.verAtrasados) {
      if (!atrasados.length) {
        return '<div class="ag-lista"><div class="ag-lista-cab"><h3>Atrasados</h3></div>' +
          '<p class="ag-vazio">Nenhum corpo de prova passou do dia sem resultado nos últimos ' + JANELA_ATRASO + ' dias.</p></div>';
      }
      const ord = atrasados.slice().sort((a, b) => a.dia - b.dia || String(a.cp).localeCompare(String(b.cp)));
      return '<div class="ag-lista"><div class="ag-lista-cab"><h3>Atrasados <span>' + ord.length +
        ' CP(s) que passaram do dia sem resultado nos últimos ' + JANELA_ATRASO + ' dias</span></h3>' + botoesLista() + '</div>' +
        tabelaHtml(ord, m, m.temResultado, hj, true) + '</div>';
    }
    if (est.dia === null) return '<div class="ag-lista"><p class="ag-vazio">Clique num dia do calendário.</p></div>';
    const grupos = porDia.get(est.dia) || {};
    const total = est.idades.reduce((s, a) => s + (grupos[a] || []).length, 0);
    let corpo = '';
    est.idades.forEach(a => {
      const lista = (grupos[a] || []).slice().sort((x, y) => String(x.cp).localeCompare(String(y.cp), 'pt-BR', { numeric: true }));
      const feitos = lista.filter(it => isFinite(it.resultado)).length;
      corpo += '<section class="ag-grupo" style="--cor-idade:' + corDa(a) + '"><h4><i></i>' + a + ' dias' +
        '<span>moldados em ' + fmtDia(est.dia - a) + ' · ' + lista.length + ' CP(s)' +
        (m.temResultado[a] && lista.length ? ' · ' + feitos + ' rompido(s)' : '') + '</span></h4>' +
        (lista.length ? tabelaHtml(lista, m, m.temResultado, hj, false)
          : '<p class="ag-vazio">Nenhum corpo de prova de ' + a + ' dias neste dia.</p>') + '</section>';
    });
    return '<div class="ag-lista"><div class="ag-lista-cab"><h3>' + esc(diaPorExtenso(est.dia)) +
      '<span>' + total + ' corpo(s) de prova para romper</span></h3>' + (total ? botoesLista() : '') + '</div>' + corpo + '</div>';
  }
  const botoesLista = () => '<div class="ag-lista-acoes"><button type="button" class="tool-btn" id="ag-imprimir">Imprimir lista</button>' +
    '<button type="button" class="tool-btn" id="ag-excel">Excel</button></div>';

  /* ── a lista para levar ao laboratório ─────────────────────────────── */
  function linhasParaExportar(m, porDia, atrasados) {
    const ix = m.ix;
    const colRec = ix.receita >= 0 ? ix.receita : ix.produto;
    const lista = est.verAtrasados ? atrasados.slice().sort((a, b) => a.dia - b.dia)
      : est.idades.flatMap(a => (porDia.get(est.dia) || {})[a] || []);
    const hj = hoje();
    return [['CP', 'Idade (dias)', 'Rompe em', 'Moldagem', 'Cliente', 'Obra', 'Receita', 'NF', 'Resultado (MPa)', 'Situação']]
      .concat(lista.map(it => {
        const sit = situacao(it, m.temResultado[it.idade], hj);
        return [it.cp, it.idade, fmtDia(it.dia), fmtDia(it.molde), textoDe(it.row, ix.cliente),
          textoDe(it.row, ix.obra), textoDe(it.row, colRec), textoDe(it.row, ix.nf),
          isFinite(it.resultado) ? Math.round(it.resultado * 10) / 10 : '',
          { rompido: 'rompido', atrasado: 'atrasado', pendente: 'a romper', 'sem-resultado': 'sem resultado', 'sem-coluna': '' }[sit]];
      }));
  }

  async function exportarExcel(aoa, nome) {
    try {
      let path = null;
      if (window.pywebview && window.pywebview.api && window.pywebview.api.save_file_dialog) {
        path = await window.pywebview.api.save_file_dialog(nome + '.xlsx');
        if (!path) return;
      }
      const r = await fetch('/api/export_aoa', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ aoa, path, sheet_name: 'Rompimentos', base_name: nome }) });
      const ct = r.headers.get('content-type') || '';
      if (ct.includes('json')) {
        const j = await r.json();
        if (window.showToast) window.showToast(j.success ? 'Lista salva' : 'Erro ao salvar: ' + (j.error || ''), j.success ? 'success' : 'error');
        return;
      }
      const blob = await r.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = nome + '.xlsx'; a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    } catch (e) {
      if (window.showToast) window.showToast('Não consegui gerar o Excel', 'error');
    }
  }

  // Impressa, a lista é uma folha para a bancada da prensa: o código do CP
  // grande, e um espaço em branco para anotar a carga.
  function imprimir(aoa, titulo) {
    const cab = aoa[0];
    const corpo = aoa.slice(1);
    const usar = [0, 1, 3, 4, 6, 7];
    const html = '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><title>' + esc(titulo) + '</title><style>' +
      '@page{size:A4 portrait;margin:12mm}body{font:11px "IBM Plex Sans",Arial,sans-serif;color:#1c1b18;margin:0}' +
      'h1{font-size:15px;margin:0 0 2px}p{margin:0 0 10px;color:#5a5852}' +
      'table{width:100%;border-collapse:collapse}th{text-align:left;font-size:9px;text-transform:uppercase;letter-spacing:.06em;color:#5a5852;border-bottom:1.5px solid #1c1b18;padding:4px 5px}' +
      'td{border-bottom:1px solid #d4d2ca;padding:5px;vertical-align:top}td.cp{font:600 12px "IBM Plex Mono",monospace}' +
      'td.anot{width:24mm;border-left:1px solid #d4d2ca}tr{break-inside:avoid}</style></head><body>' +
      '<h1>' + esc(titulo) + '</h1><p>' + corpo.length + ' corpo(s) de prova · impresso em ' +
      new Date().toLocaleString('pt-BR') + '</p><table><thead><tr>' + usar.map(i => '<th>' + esc(cab[i]) + '</th>').join('') +
      '<th>Carga (tf)</th><th>MPa</th></tr></thead><tbody>' +
      corpo.map(l => '<tr>' + usar.map((i, k) => '<td' + (k === 0 ? ' class="cp"' : '') + '>' + esc(l[i]) + '</td>').join('') +
        '<td class="anot"></td><td class="anot">' + esc(l[8]) + '</td></tr>').join('') +
      '</tbody></table></body></html>';
    const fr = document.createElement('iframe');
    fr.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden';
    fr.srcdoc = html;
    fr.onload = () => {
      try { fr.contentWindow.focus(); fr.contentWindow.print(); } catch (e) { /* sem impressora */ }
      setTimeout(() => fr.remove(), 60000);
    };
    document.body.appendChild(fr);
  }

  /* ── desenho ───────────────────────────────────────────────────────── */
  function agrupar(m) {
    const porDia = new Map();
    m.itens.forEach(it => {
      let g = porDia.get(it.dia);
      if (!g) { g = {}; porDia.set(it.dia, g); }
      (g[it.idade] = g[it.idade] || []).push(it);
    });
    return porDia;
  }

  function render() {
    const host = $('ag-corpo');
    if (!host) return;
    const f = dados();
    if (!f) {
      montarBarra([]);
      host.innerHTML = '<div class="graf-empty-state"><p>Abra uma planilha para montar a agenda</p>' +
        '<p class="empty-sub">A agenda usa a data de moldagem e o código de cada corpo de prova</p></div>';
      return;
    }
    acertarColunas(f.headers);
    montarBarra(f.headers);
    if (!est.colData) {
      host.innerHTML = '<div class="graf-empty-state"><p>Escolha acima a coluna da <b>data de moldagem</b></p>' +
        '<p class="empty-sub">Não reconheci nenhuma pelo nome nesta planilha</p></div>';
      return;
    }
    if (!est.ano) {
      const d = dataDoDia(hoje());
      est.ano = d.getUTCFullYear(); est.mes = d.getUTCMonth();
      est.dia = hoje();
    }
    const hj = hoje();
    const m = montar(f);
    const porDia = agrupar(m);
    const atrasados = m.itens.filter(it => situacao(it, m.temResultado[it.idade], hj) === 'atrasado');

    const avisos = [];
    if (m.semData) avisos.push(m.semData + ' linha(s) sem data de moldagem ficaram de fora');
    if (m.semCP) avisos.push(m.semCP + ' linha(s) sem código de CP ficaram de fora');
    if (m.futuro.length) avisos.push('moldagem depois de hoje — confira: CP ' + m.futuro.slice(0, 4).join(', ') +
      (m.futuro.length > 4 ? ' e mais ' + (m.futuro.length - 4) : ''));
    const semRes = est.idades.filter(a => !m.temResultado[a]);
    if (semRes.length) avisos.push('sem coluna de resultado para ' + semRes.map(a => a + ' dias').join(', ') +
      ' — não dá para saber o que já foi rompido');

    host.innerHTML =
      '<div class="ag-esq">' + calendarioHtml(porDia, m.temResultado, hj) +
        '<div class="ag-rodape">' +
          '<button type="button" class="ag-atrasados' + (est.verAtrasados ? ' ativo' : '') + (atrasados.length ? ' tem' : '') +
            '" id="ag-ver-atrasados">' + (atrasados.length ? atrasados.length + ' atrasado(s)' : 'Nenhum atrasado') + '</button>' +
          (avisos.length ? '<p class="ag-avisos">' + avisos.map(esc).join(' · ') + '</p>' : '') +
        '</div></div>' +
      '<div class="ag-dir">' + listaHtml(m, porDia, atrasados, hj) + '</div>';

    host.querySelectorAll('.ag-dia[data-dia]').forEach(b => b.addEventListener('click', () => {
      est.dia = Number(b.dataset.dia); est.verAtrasados = false; render();
    }));
    $('ag-ant')?.addEventListener('click', () => mudarMes(-1));
    $('ag-prox')?.addEventListener('click', () => mudarMes(1));
    $('ag-ver-atrasados')?.addEventListener('click', () => { est.verAtrasados = !est.verAtrasados; render(); });
    const titulo = () => est.verAtrasados ? 'Corpos de prova atrasados' : 'Rompimentos de ' + fmtDia(est.dia);
    $('ag-imprimir')?.addEventListener('click', () => imprimir(linhasParaExportar(m, porDia, atrasados), titulo()));
    $('ag-excel')?.addEventListener('click', () => exportarExcel(linhasParaExportar(m, porDia, atrasados),
      (est.verAtrasados ? 'CPs atrasados ' : 'Rompimentos ') + fmtDia(est.verAtrasados ? hj : est.dia).replace(/\//g, '-')));
  }

  function mudarMes(passo) {
    est.mes += passo;
    if (est.mes < 0) { est.mes = 11; est.ano--; }
    if (est.mes > 11) { est.mes = 0; est.ano++; }
    render();
  }

  function irPara(dia) {
    const d = dataDoDia(dia);
    est.ano = d.getUTCFullYear(); est.mes = d.getUTCMonth(); est.dia = dia; est.verAtrasados = false;
  }

  /* ── o que a tela de Início pergunta ───────────────────────────────── */
  function resumo(dia) {
    const f = dados();
    if (!f) return null;
    acertarColunas(f.headers);
    if (!est.colData) return { semColuna: true };
    const hj = hoje();
    const alvo = dia == null ? hj : dia;
    const m = montar(f);
    const porIdade = est.idades.map(a => {
      const lista = m.itens.filter(it => it.idade === a && it.dia === alvo);
      return { idade: a, total: lista.length, feitos: lista.filter(it => isFinite(it.resultado)).length };
    });
    return {
      dia: alvo, porIdade, total: porIdade.reduce((s, x) => s + x.total, 0),
      atrasados: m.itens.filter(it => situacao(it, m.temResultado[it.idade], hj) === 'atrasado').length,
    };
  }

  /* ── ligação ───────────────────────────────────────────────────────── */
  function init() {
    $('ag-col-data')?.addEventListener('change', e => { est.colData = e.target.value; gravar(); render(); });
    $('ag-col-cp')?.addEventListener('change', e => { est.colCP = e.target.value; gravar(); render(); });
    $('ag-hoje')?.addEventListener('click', () => { irPara(hoje()); render(); });
    $('ag-idades')?.addEventListener('click', e => {
      const b = e.target.closest('button');
      if (!b) return;
      if (b.id === 'ag-idade-mais') { pedirIdade(); return; }
      const a = Number(b.dataset.idade);
      if (!a) return;
      if (est.idades.includes(a)) {
        if (est.idades.length === 1) return;          // sempre fica ao menos uma
        est.idades = est.idades.filter(x => x !== a);
      } else {
        est.idades = est.idades.concat(a).sort((x, y) => x - y);
      }
      gravar(); render();
    });
    window.addEventListener('concrestats:datachanged', () => {
      const m = $('module-agenda');
      if (m && m.style.display !== 'none') render();
    });
    carregar();
  }

  async function pedirIdade() {
    if (!window.openModal) return;
    window.openModal('Outra idade de rompimento',
      '<label for="ag-nova-idade">Idade em dias</label>' +
      '<input id="ag-nova-idade" type="number" min="1" max="365" step="1" placeholder="ex.: 91">', () => {
        const n = parseInt(($('ag-nova-idade') || {}).value, 10);
        if (!(n > 0 && n <= 365)) return;
        if (!IDADES_PADRAO.includes(n) && !est.extras.includes(n)) est.extras.push(n);
        if (!est.idades.includes(n)) est.idades = est.idades.concat(n).sort((x, y) => x - y);
        if (window.closeModal) window.closeModal();
        gravar(); render();
      });
    setTimeout(() => $('ag-nova-idade')?.focus(), 50);
  }

  window.AgendaModule = {
    onModuleEnter: () => carregar().then(render),
    resumo,
    carregar,
    irPara: dia => { irPara(dia); },
    verAtrasados: () => { est.verAtrasados = true; },
    // para o Modo Teste
    _diaDe: diaDe, _fmtDia: fmtDia, _estado: () => JSON.parse(JSON.stringify(est)),
  };
  document.addEventListener('DOMContentLoaded', init);
})();
