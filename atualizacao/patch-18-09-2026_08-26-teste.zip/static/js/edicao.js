/**
 * edicao.js — esconde as abas que esta cópia não mostra.
 *
 * Não dá pra apagar a aba do index.html: a atualização substitui templates/ e
 * static/ inteiros, e ela voltaria sozinha na primeira atualização.
 *
 * Quem decide é o servidor (edicao() no app.py), em três lugares: edicao.json
 * ao lado do exe, a edição compilada dentro, ou a que veio no manifesto.
 * Sem nenhum dos três, mostra tudo.
 */
(function () {
  'use strict';

  function esconder(quais) {
    if (!quais || !quais.length) return;

    quais.forEach(function (mod) {
      // o botão da barra de cima
      document.querySelectorAll('.nav-btn[data-module="' + mod + '"]').forEach(function (b) {
        b.remove();
      });
      // qualquer atalho que leve para lá
      document.querySelectorAll('[data-open-module="' + mod + '"]').forEach(function (b) {
        b.remove();
      });
      // e a tela em si, para não sobrar nada alcançável por teclado
      const painel = document.getElementById('module-' + mod) ||
                     document.getElementById(mod + '-module') ||
                     document.getElementById('view-' + mod);
      if (painel) painel.remove();
    });

    // Se a aba escondida era a que estava aberta, cai para a planilha —
    // senão o usuário abre o programa numa tela que não existe mais.
    const ativa = document.querySelector('.nav-btn.active');
    if (!ativa) {
      const primeira = document.querySelector('.nav-btn[data-module="spreadsheet"]') ||
                       document.querySelector('.nav-btn[data-module]');
      if (primeira) primeira.click();
    }
  }

  function marcar(nome) {
    if (!nome) return;
    if (document.querySelector('.empty-edicao')) return;   // ja' esta' na tela
    // deixa registrado na tela qual edição é esta, junto da versão —
    // sem isso, "sumiu uma aba" vira chamado de suporte.
    const carimbo = document.getElementById('empty-versao');
    if (!carimbo) return;
    carimbo.dataset.edicao = nome;
    const marca = document.createElement('span');
    marca.className = 'empty-edicao';
    marca.textContent = 'edição ' + nome;
    carimbo.parentElement.insertBefore(marca, carimbo.nextSibling);
  }

  function aplicar(a) {
    if (!a) return;
    esconder(a.ocultar);
    marcar(a.edicao);
  }

  function ambiente() {
    return fetch('/api/ambiente').then(function (r) { return r.json(); });
  }

  /* A edição também pode chegar pela ATUALIZAÇÃO, sem baixar nada: a resposta
   * assinada do manifesto diz quais abas esta cópia mostra, e o servidor
   * guarda isso. Mas a verificação só acontecia quando alguém abria a tela de
   * Atualização — numa máquina onde ninguém abre essa tela, a edição nunca
   * chegaria. Por isso a busca silenciosa aqui, uma vez por abertura.
   *
   * Na PRIMEIRA abertura depois de a edição ser publicada, a aba aparece por
   * um instante e some. Da segunda em diante já vem escondida, porque o que
   * foi aprendido fica gravado. */
  /* QUEM VAI A' REDE E' ESTA TELA, NAO O PROGRAMA.
   *
   * O Naor nao conseguia tirar o aviso do Kaspersky, e foi ele quem deu a
   * pista que faltava: "na versao antiga, que so' procurava atualizacao quando
   * eu clicava, esse incomodo nao tem".
   *
   * Faz sentido. O que pesa num modulo de comportamento nao e' ler um JSON: e'
   * um executavel desconhecido, sem assinatura digital, abrir uma conexao para
   * a internet um segundo depois de ser aberto, sem ninguem pedir. Era
   * exatamente o que acontecia aqui — esta funcao chamava /api/atualizacao ao
   * abrir, e quem ia a' rede era o Concrestats.exe.
   *
   * Agora o fetch e' daqui, feito pelo WebView2: o navegador da Microsoft,
   * assinado, fazendo o que navegador faz. O manifesto e' entregue ao programa
   * em seguida, e ele confere a assinatura como sempre conferiu — o que torna
   * o manifesto confiavel e' a assinatura, nao por onde ele passou.
   *
   * `permitirServidor` so' e' ligado quando a PESSOA pediu (o botao da tela de
   * Atualizacao). Na abertura fica desligado de proposito: cair de volta no
   * caminho antigo sozinho desfaria o conserto sem ninguem perceber.
   */
  function buscarAtualizacao(permitirServidor) {
    var pelaRede = function () {
      return fetch('/api/atualizacao').then(function (r) { return r.json(); });
    };
    return fetch('/api/atualizacao?local=1')
      .then(function (r) { return r.json(); })
      .then(function (base) {
        if (!base || !base.url_do_manifesto) return base;
        return fetch(base.url_do_manifesto, { cache: 'no-store' })
          .then(function (r) {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.json();
          })
          .then(function (manifesto) {
            return fetch('/api/manifesto', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ manifesto: manifesto })
            }).then(function (r) { return r.json(); });
          })
          .catch(function (e) {
            if (permitirServidor) return pelaRede();
            var motivo = String((e && e.message) || e).slice(0, 80);
            return Object.assign({}, base, { verificou: false, motivo: motivo });
          });
      });
  }
  window.buscarAtualizacao = buscarAtualizacao;

  function buscarEdicaoRemota() {
    return buscarAtualizacao(false)
      .then(function (j) {
        // A mesma busca serve para avisar que saiu versao nova. Uma segunda
        // chamada so' para isso seria pedir duas vezes a mesma coisa — e a
        // resposta ja' traz tudo. Quem monta o aviso e' o licenca.js, que e'
        // dono da tela de Atualizacao.
        if (j) {
          window.dispatchEvent(new CustomEvent('concrestats:atualizacao', { detail: j }));
        }
        if (!j || !j.edicao_aplicada) return null;
        return ambiente();
      })
      .catch(function () { return null; });   // sem rede, segue com o que tem
  }

  document.addEventListener('DOMContentLoaded', function () {
    ambiente()
      .then(function (a) {
        aplicar(a);
        return buscarEdicaoRemota();
      })
      .then(aplicar)
      .catch(function () { /* sem resposta, mostra tudo */ });
  });
})();
