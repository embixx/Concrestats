/**
 * painel.js — Painel livre (canvas) do Concrestats
 *
 * Implementa a ideia do Naor: a página inteira é um canvas. Botão direito no
 * vazio ADICIONA um widget; botão direito no widget EDITA/duplica/exclui.
 * Os widgets cobrem as três "qualidades" que ele descreveu: valor filtrado,
 * agrupado por X, e proporção do total.
 *
 * Tipos: dado (KPI) · tabela · gráfico (barra/linha/pizza/empilhado/mapa de calor) · insights
 * Layout persistido por planilha em /api/prefs (chave painel_layouts).
 * Os dados respeitam SEMPRE os filtros globais da aba Planilhas.
 */
(function () {
  'use strict';

  const $ = id => document.getElementById(id);
  const V = () => window.ConcreViz || {};
  const LAB = () => window.ConcreLab || {};
  const esc = s => String(s ?? '').replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const GRID = 10;
  const snap = v => Math.round(v / GRID) * GRID;
  const HEADER_H = 30;

  // Linha sem valor na coluna de agrupamento vira uma categoria propria — nao
  // da' para somar no que nao existe. Na planilha do laboratorio sao 826
  // linhas sem PRODUTO, 17,5% do volume: aparecia como a maior fatia nomeada,
  // chamada "—". Um traco nao diz que aquilo e' dado faltando; diz que alguem
  // batizou uma categoria de traco.
  const SEM_VALOR = '(em branco)';

  // Operações. As três derivadas usam período anterior / total — é a base do
  // "criar suas próprias fórmulas" pedido pelo Naor.
  const OPS = ['Soma', 'Média', 'Contagem', 'Mínimo', 'Máximo', 'Mediana',
    'Desvio padrão', '% do total', 'Crescimento %', 'Acumulado'];
  const OPS_BASE = ['Soma', 'Média', 'Contagem', 'Mínimo', 'Máximo', 'Mediana', 'Desvio padrão'];
  const TIPOS = [['barra', 'Barra'], ['pizza', 'Pizza'],
    ['empilhado', 'Barra empilhada'], ['calor', 'Mapa de calor']];

  const state = { sheet: null, layouts: {}, carregado: false };

  /* ── dados (sempre com o filtro global aplicado) ── */
  function dados() {
    const d = window.getConcrestatsData ? window.getConcrestatsData({ filtered: true }) : null;
    if (!d || !d.headers || !d.headers.length) return null;
    return { headers: d.headers, rows: d.data || [], sheet: d.activeSheet };
  }
  const layout = () => (state.layouts[state.sheet] = state.layouts[state.sheet] || []);
  const genId = () => 'w' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36);

  // O try/catch só pegava exceção síncrona, que praticamente nunca acontece.
  // Uma falha de gravação de verdade virava rejeição de promessa sem
  // tratamento: invisível na tela e no console. O usuário montava o painel
  // inteiro e só descobria que nada tinha sido salvo na próxima vez que
  // abrisse o programa, com o layout de volta ao que era antes.
  let avisouFalhaAoSalvar = false;
  function salvar() {
    fetch('/api/prefs', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ painel_layouts: state.layouts })
    })
      .then(r => r.json())
      .then(j => {
        if (j && j.success === false) throw new Error(j.error || 'recusado');
        avisouFalhaAoSalvar = false;
      })
      .catch(() => {
        // Uma vez por sequência de falhas: arrastar um widget dispara vários
        // salvamentos seguidos, e um aviso por arrasto viraria uma parede.
        if (avisouFalhaAoSalvar) return;
        avisouFalhaAoSalvar = true;
        if (window.showToast) {
          window.showToast('Não consegui salvar o painel — ele volta ao estado ' +
                           'anterior quando você fechar o programa', 'error');
        }
      });
  }
  function carregar() {
    return window.prefsGet().then(p => {
      if (p && p.painel_layouts && typeof p.painel_layouts === 'object') state.layouts = p.painel_layouts;
      state.carregado = true;
    }).catch(() => { state.carregado = true; });
  }

  /* ── agregação ─────────────────────────────────── */
  function calc(vals, op) {
    const ns = vals.filter(v => !isNaN(v));
    if (op === 'Contagem') return vals.length;
    if (!ns.length) return NaN;
    const soma = ns.reduce((a, b) => a + b, 0);
    switch (op) {
      case 'Soma': case '% do total': case 'Crescimento %': case 'Acumulado': return soma;
      case 'Média': return soma / ns.length;
      case 'Mínimo': return Math.min.apply(null, ns);
      case 'Máximo': return Math.max.apply(null, ns);
      case 'Mediana': {
        const b = ns.slice().sort((x, y) => x - y), m = b.length >> 1;
        return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2;
      }
      case 'Desvio padrão': {
        if (ns.length < 2) return 0;
        const md = soma / ns.length;
        return Math.sqrt(ns.reduce((s, v) => s + (v - md) * (v - md), 0) / (ns.length - 1));
      }
      default: return soma;
    }
  }

  // Chave de período no grão pedido (dia/mês/ano). Aceita ISO e data BR.
  function chavePeriodo(v, grao) {
    const s = String(v || '');
    let a, m, d;
    const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (iso) { a = iso[1]; m = iso[2]; d = iso[3]; }
    else {
      const br = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
      if (!br) return null;
      d = String(br[1]).padStart(2, '0');
      m = String(br[2]).padStart(2, '0');
      a = br[3];
    }
    return grao === 'ano' ? a : grao === 'dia' ? (a + '-' + m + '-' + d) : (a + '-' + m);
  }

  // Agrupa por coluna (ou por período) e aplica a operação escolhida.
  function agrupar(f, rows, cfg) {
    const num = V().num;
    const porPeriodo = cfg.grupo === '__periodo__';
    const iG = porPeriodo ? f.headers.indexOf(cfg.colData) : f.headers.indexOf(cfg.grupo);
    const iV = f.headers.indexOf(cfg.valor);
    if (iG < 0) return [];
    const g = new Map();
    rows.forEach(r => {
      const k = porPeriodo ? chavePeriodo(r[iG], cfg.grao || 'mes')
        : (String(r[iG] == null ? '' : r[iG]).trim() || SEM_VALOR);
      if (k === null) return;
      if (!g.has(k)) g.set(k, []);
      g.get(k).push(iV >= 0 ? num(r[iV]) : NaN);
    });
    let saida = [];
    g.forEach((vals, k) => saida.push({ k: k, v: calc(vals, cfg.op || 'Soma'), n: vals.length }));
    if (porPeriodo) saida.sort((a, b) => String(a.k).localeCompare(String(b.k)));
    else saida.sort((a, b) => (isNaN(b.v) ? -Infinity : b.v) - (isNaN(a.v) ? -Infinity : a.v));

    const op = cfg.op || 'Soma';
    if (op === '% do total') {
      const t = saida.reduce((s, x) => s + (isNaN(x.v) ? 0 : Math.abs(x.v)), 0) || 1;
      saida = saida.map(x => ({ k: x.k, n: x.n, v: Math.abs(x.v) / t * 100 }));
    } else if (op === 'Crescimento %') {
      const orig = saida.slice();
      saida = saida.map((x, i) => ({
        k: x.k, n: x.n,
        v: (i === 0 || !orig[i - 1].v) ? NaN : (x.v - orig[i - 1].v) / Math.abs(orig[i - 1].v) * 100
      }));
    } else if (op === 'Acumulado') {
      let acc = 0;
      saida = saida.map(x => { acc += isNaN(x.v) ? 0 : x.v; return { k: x.k, n: x.n, v: acc }; });
    }
    if (cfg.topN > 0 && !porPeriodo) saida = saida.slice(0, cfg.topN);
    return saida;
  }

  // Dois periodos sao vizinhos? (evita comparar dezembro com janeiro do mesmo
  // ano e chamar isso de "crescimento")
  function periodosVizinhos(a, b, grao) {
    if (!a || !b) return false;
    if (grao === 'ano') return (+b - +a) === 1;
    if (grao === 'dia') {
      const d = (k) => { const p = k.split('-'); return Date.UTC(+p[0], +p[1] - 1, +p[2]); };
      return Math.round((d(b) - d(a)) / 86400000) === 1;
    }
    const meses = k => { const p = k.split('-'); return (+p[0]) * 12 + (+p[1] - 1); };
    return (meses(b) - meses(a)) === 1;
  }

  const ehPct = op => op === '% do total' || op === 'Crescimento %';
  // Contagem é inteira; % ganha sufixo; demais usam o formato padrão.
  function fmtOp(v, op) {
    const viz = V();
    if (isNaN(v) || v === undefined) return '—';
    if (op === 'Contagem') return viz.fmt(v, 0);
    return viz.fmt0(v) + (ehPct(op) ? '%' : '');
  }

  /* ── export via backend (funciona no PC da empresa) ── */
  async function exportarAoa(aoa, baseName) {
    try {
      let path = null;
      if (window.pywebview && window.pywebview.api && window.pywebview.api.save_file_dialog) {
        path = await window.pywebview.api.save_file_dialog(baseName + '.xlsx');
        if (!path) return;
      }
      const r = await fetch('/api/export_aoa', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ aoa: aoa, path: path, sheet_name: 'Dados', base_name: baseName })
      });
      const ct = r.headers.get('content-type') || '';
      if (ct.indexOf('json') >= 0) {
        const j = await r.json();
        if (window.showToast) window.showToast(j.success ? 'Planilha salva' : ('Erro: ' + (j.error || '')), j.success ? 'success' : 'error');
        return;
      }
      const blob = await r.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = baseName + '.xlsx';
      a.click();
      URL.revokeObjectURL(a.href);
    } catch (_) {
      if (window.showToast) window.showToast('Falha ao exportar', 'error');
    }
  }


  /* ── foco: clicar num gráfico filtra o painel inteiro ──
   * É o que a Análise já fazia. Não é salvo em disco de propósito: filtro é
   * pergunta do momento, e reabrir mostrando um cliente só pareceria que a
   * planilha encolheu. */
  const foco = { tipo: null, col: null, grao: 'mes', vals: [] };

  function limparFoco() { foco.tipo = null; foco.col = null; foco.vals = []; }

  function focar(cfg, rotulo) {
    const porPeriodo = cfg.grupo === '__periodo__';
    const col = porPeriodo ? cfg.colData : cfg.grupo;
    const tipo = porPeriodo ? 'periodo' : 'coluna';
    if (!col || rotulo == null) return;
    // Trocar de coluna zera a seleção. Empilhar "CLIENTE = A" com "PRODUTO = B"
    // dá interseção, e quase sempre vazia — o painel esvaziaria e pareceria bug.
    if (foco.col !== col || foco.tipo !== tipo) {
      foco.tipo = tipo; foco.col = col; foco.grao = cfg.grao || 'mes'; foco.vals = [];
    }
    const i = foco.vals.indexOf(rotulo);
    if (i >= 0) foco.vals.splice(i, 1); else foco.vals.push(rotulo);
    if (!foco.vals.length) limparFoco();
    render();
  }

  function aplicarFoco(f) {
    if (!foco.tipo || !foco.vals.length) return f;
    const i = f.headers.indexOf(foco.col);
    if (i < 0) return f;                       // coluna sumiu: mostra tudo
    const rows = f.rows.filter(r => {
      const k = foco.tipo === 'periodo'
        ? chavePeriodo(r[i], foco.grao)
        : (String(r[i] == null ? '' : r[i]).trim() || SEM_VALOR);
      return foco.vals.indexOf(k) >= 0;
    });
    return { headers: f.headers, rows: rows, sheet: f.sheet };
  }

  // Só devolve a função de clique quando há mesmo por onde filtrar; senão o
  // cursor vira mãozinha num gráfico que não reage.
  function cliqueDe(cfg) {
    const col = cfg.grupo === '__periodo__' ? cfg.colData : cfg.grupo;
    return col ? (rotulo => focar(cfg, rotulo)) : null;
  }

  function barraDeFoco(host) {
    if (!foco.vals.length) return;
    const nome = foco.tipo === 'periodo' ? 'período' : foco.col;
    const barra = document.createElement('div');
    barra.className = 'pan-foco';
    barra.innerHTML = '<span class="pan-foco-tit">Filtrando por ' + esc(nome) + ':</span>' +
      foco.vals.map((v, i) => '<button type="button" class="pan-foco-chip" data-i="' + i + '">' +
        esc(v) + ' <i>✕</i></button>').join('') +
      '<button type="button" class="pan-foco-limpar">limpar</button>';
    barra.querySelectorAll('.pan-foco-chip').forEach(b => {
      b.addEventListener('click', () => {
        foco.vals.splice(parseInt(b.dataset.i), 1);
        if (!foco.vals.length) limparFoco();
        render();
      });
    });
    barra.querySelector('.pan-foco-limpar').addEventListener('click', () => { limparFoco(); render(); });
    host.appendChild(barra);
  }

  /* ── render do canvas ──────────────────────────── */
  function render() {
    const host = $('pan-body');
    if (!host) return;
    let f = dados();
    if (!f) {
      host.innerHTML = '<div class="graf-empty-state"><div class="empty-icon">◈</div>' +
        '<p>Abra uma planilha para montar seu painel</p>' +
        '<p class="empty-sub">Depois clique com o botão direito no espaço vazio para adicionar gráficos e tabelas</p></div>';
      const i0 = $('pan-info');
      if (i0) i0.textContent = 'Sem planilha ativa';
      return;
    }
    // Planilha nova, pergunta nova: um filtro de CLIENTE herdado de outra
    // planilha esconderia quase tudo sem explicação.
    if (f.sheet !== state.sheet) { state.sheet = f.sheet; limparFoco(); }
    const L = layout();
    const total = f.rows.length;
    f = aplicarFoco(f);
    host.innerHTML = '';
    barraDeFoco(host);
    const div = document.createElement('div');
    div.id = 'pan-canvas'; div.className = 'pan-canvas';
    host.appendChild(div);
    const canvas = $('pan-canvas');

    if (!L.length) {
      canvas.innerHTML = '<div class="pan-hint"><b>Painel vazio</b>' +
        '<span>Clique com o botão direito no fundo para adicionar um widget</span>' +
        '<button class="primary-btn" id="pan-add-first" type="button">Montar painel automático</button></div>';
      const bt = $('pan-add-first');
      if (bt) bt.addEventListener('click', ev => { ev.stopPropagation(); painelAutomatico(); });
    }

    // Duas passadas, e nao uma: PRIMEIRO todos os widgets entram na tela,
    // DEPOIS eles se desenham.
    //
    // Desenhando junto com a criacao, o canvas ainda estava fora da pagina e
    // medir a largura dele dava zero — caia no tamanho de reserva (700px) e o
    // CSS esticava para o tamanho de verdade. No "Volume por cliente" eram
    // 700px esticados para 2280: barra larga e texto borrado. Foi o que o
    // Naor fotografou.
    let maxB = 0, maxR = 0;
    const criados = [];
    L.forEach(it => {
      const el = criarWidget(f, it);
      canvas.appendChild(el);
      criados.push([el, it]);
      maxB = Math.max(maxB, (it.y || 0) + (it.h || 240));
      maxR = Math.max(maxR, (it.x || 0) + (it.w || 360));
    });
    criados.forEach(([el, it]) => desenharWidget(f, it, el));
    canvas.style.minHeight = Math.max(maxB + GRID * 4, 380) + 'px';
    // A largura tambem: sem isto o canvas ficava do tamanho da tela e um
    // widget mais largo transbordava sem o canvas saber.
    canvas.style.minWidth = Math.max(maxR + GRID * 2, 0) + 'px';
    canvas.addEventListener('contextmenu', e => {
      if (e.target.closest('.pan-widget')) return;
      e.preventDefault();
      menuCanvas(e.clientX, e.clientY);
    });

    const info = $('pan-info');
    if (info) {
      info.textContent = (state.sheet || '') + ' · ' + L.length + ' widget(s) · ' +
        f.rows.length + ' linhas' +
        (f.rows.length !== total ? ' (de ' + total + ')' : '');
    }
  }

  function criarWidget(f, it) {
    const el = document.createElement('div');
    el.className = 'pan-widget';
    el.dataset.wid = it.id;
    el.style.left = (it.x || 0) + 'px';
    el.style.top = (it.y || 0) + 'px';
    el.style.width = (it.w || 380) + 'px';
    el.style.height = (it.h || 240) + 'px';
    el.innerHTML = '<div class="pan-w-head"><span class="pan-w-tit">' +
      esc(it.config.titulo || tituloAuto(it)) + '</span>' +
      '<span class="pan-w-tag">' + esc(rotuloTipo(it)) + '</span></div>' +
      '<div class="pan-w-body"></div><div class="pan-w-resize" title="Redimensionar"></div>';
    el.addEventListener('contextmenu', e => {
      e.preventDefault(); e.stopPropagation();
      menuWidget(e.clientX, e.clientY, it);
    });
    arrastar(el, it);
    redimensionar(el, it);
    return el;
  }

  // Chamada depois de o widget ja' estar na pagina, para o canvas conseguir
  // se medir.
  function desenharWidget(f, it, el) {
    const body = el.querySelector('.pan-w-body');
    if (!body) return;
    body.innerHTML = '';
    try {
      desenhar(f, it, body);
    } catch (err) {
      body.innerHTML = '<p class="pan-erro">Não foi possível montar este widget.<br><small>' +
        esc(err.message) + '</small></p>';
    }
  }

  const rotuloTipo = it => it.type === 'grafico' ? (it.config.tipo || 'barra')
    : it.type === 'distribuicao' ? 'distribuição' : it.type;

  function tituloAuto(it) {
    const c = it.config;
    const alvo = c.grupo === '__periodo__' ? 'período' : (c.grupo || '—');
    if (it.type === 'dado') return (c.op || 'Soma') + ' de ' + (c.valor || '—');
    if (it.type === 'tabela') return 'Por ' + alvo;
    if (it.type === 'insights') return 'Insights automáticos';
    if (it.type === 'distribuicao') return 'Distribuição de ' + (c.valor || 'resistência');
    return (c.valor || 'Contagem') + ' por ' + alvo;
  }

  // Colunas que servem para dividir/agrupar: texto com poucos valores repetidos.
  function colunasDeTexto(f) {
    const viz = V();
    const out = [];
    f.headers.forEach((h, i) => {
      const amostra = f.rows.slice(0, 200).map(r => r[i]).filter(v => String(v || '').trim());
      if (!amostra.length) return;
      const numericos = amostra.filter(v => !isNaN(viz.num(v))).length;
      if (numericos > amostra.length * 0.5) return;          // e' coluna de numero
      const distintos = new Set(amostra.map(v => String(v))).size;
      // No maximo 12 valores distintos: com mais que isso o empilhado vira um
      // arco-iris ilegivel (foi o que aconteceu na planilha real do Naor).
      if (distintos > 1 && distintos <= 12) out.push({ h: h, n: distintos });
    });
    // menos categorias primeiro: da' o empilhado mais legivel
    return out.sort((a, b) => a.n - b.n).map(x => x.h);
  }

  /* ── desenho por tipo ──────────────────────────── */
  function desenhar(f, it, body) {
    const c = it.config, viz = V();
    if (it.type === 'dado') return desenharDado(f, it, body);
    if (it.type === 'insights') {
      const iD = f.headers.indexOf(c.colData);
      const iV = f.headers.indexOf(c.valor);
      const iC = f.headers.indexOf(c.grupo);
      const ins = viz.gerarInsights ? viz.gerarInsights(f, f.rows, iD, iV, iC) : [];
      body.innerHTML = ins.length
        ? '<div class="ana-ins pan-ins">' + ins.map(i =>
            '<div class="ins-card ' + i.cls + '"><span class="ins-ico">' + i.ico +
            '</span><span>' + i.txt + '</span></div>').join('') + '</div>'
        : '<p class="pan-vazio">Sem insights — defina Data e Valor nas propriedades.</p>';
      return;
    }
    if (it.type === 'distribuicao') return desenharDistribuicao(f, it, body);
    if (it.type === 'tabela') return desenharTabela(f, it, body);

    desenharGrafico(f, it, body);
    // Insights valem para QUALQUER tipo de grafico — antes so' a tabela tinha
    // a opcao, e no empilhado a faixa nem aparecia.
    if (c.insights) anexarInsights(f, it, body);
  }

  // Largura minima por barra para o nome embaixo continuar legivel.
  const PX_POR_GRUPO = 38;

  // Passou do limite? As maiores ficam e o resto vira uma barra "Outros (N)".
  // Esconder a cauda sem dizer que ela existe faria o total do grafico nao
  // bater com o da tabela ao lado.
  function limitarComOutros(dat, limite) {
    if (!limite || dat.length <= limite) return dat;
    const ficam = dat.slice(0, limite - 1);
    const resto = dat.slice(limite - 1);
    const soma = resto.reduce((a, x) => a + (isNaN(x.v) ? 0 : x.v), 0);
    ficam.push({ k: 'Outros (' + resto.length + ')', v: soma,
                 n: resto.reduce((a, x) => a + (x.n || 0), 0) });
    return ficam;
  }
  function esticarParaCaber(canvas, quantos) {
    if (!canvas) return;
    const area = canvas.parentElement;
    const disponivel = (area && area.clientWidth) || 600;
    const preciso = quantos * PX_POR_GRUPO;
    const rola = preciso > disponivel;
    canvas.style.width = rola ? preciso + 'px' : '100%';
    // Diz ao desenho a largura, em vez de deixar ele medir.
    //
    // Medir logo depois de mexer no style devolve o valor ANTIGO - conferi no
    // navegador: mudar para 100% e ler na linha seguinte ainda dava 2280. O
    // desenho saia num bitmap de 588px e o CSS esticava para 2280: barra gorda
    // e texto borrado, que e' a foto que o Naor mandou.
    canvas.dataset.larguraAlvo = String(Math.round(rola ? preciso : disponivel));
  }

  function anexarInsights(f, it, body) {
    const c = it.config, viz = V();
    let dados = [];
    try { dados = agrupar(f, f.rows, c) || []; } catch (e) { dados = []; }
    if (!dados.length) return;
    const faixa = document.createElement('div');
    faixa.className = 'pan-ins-faixa';
    faixa.innerHTML = montarInsightsTabela(dados, viz);
    if (!faixa.innerHTML.trim()) return;
    body.appendChild(faixa);

    // A faixa entra DEPOIS do gráfico, e o corpo do widget tem overflow
    // escondido. Sem devolver ao gráfico a altura que ela ocupa, ela nasce
    // fora da área visível e o usuário vê o gráfico inteiro e nenhum insight —
    // "os insights se escondem embaixo do gráfico".
    const cv = body.querySelector('canvas');
    if (!cv) return;

    // A faixa so' pode ser medida depois que o navegador a colocou na tela, e
    // isso nao acontece nem no mesmo instante nem no quadro seguinte: o widget
    // e' montado solto e so' depois entra no documento. Enquanto esta' solto,
    // offsetHeight devolve 0 — e uma conta feita com esse zero devolvia ao
    // grafico a altura inteira, jogando os insights para fora da area visivel.
    //
    // O observador resolve sem chutar quando medir: ele avisa no momento em
    // que a faixa ganha altura de verdade, seja quando for.
    const ajustar = () => {
      const alturaFaixa = faixa.offsetHeight;
      if (!alturaFaixa || !body.clientHeight) return false;

      // Mede a CAIXA, nao reconstroi a altura a partir de it.h mais uma soma
      // de constantes: bastava um padding mudar no CSS para a conta errar.
      const disponivel = body.clientHeight - alturaFaixa - 8;
      const MIN_GRAFICO = 90;

      // Quando nem o grafico minimo mais a faixa cabem, encolher mais nao
      // resolve — alguma coisa fica de fora de qualquer jeito. Ai' o quadro
      // passa a rolar, para o conteudo ficar alcancavel em vez de sumir calado.
      const cabeTudo = disponivel >= MIN_GRAFICO;
      body.style.overflowY = cabeTudo ? '' : 'auto';
      body.title = cabeTudo ? '' :
        'Role dentro do quadro para ver os insights, ou aumente a altura em Editar propriedades';

      const altura = Math.max(MIN_GRAFICO, disponivel);
      const atual = parseFloat(cv.style.height);
      // Comparacao ao contrario de proposito: na primeira vez o canvas nao tem
      // altura inline, parseFloat('') da' NaN, e "NaN > 4" seria FALSO.
      if (!(Math.abs(atual - altura) <= 4)) {
        cv.style.height = altura + 'px';
        // A altura vai TAMBEM no invólucro. Canvas tem tamanho próprio (os
        // atributos width/height), e em alguns contextos é ele que decide a
        // caixa, ignorando o style — aí a div em volta continuava com a altura
        // antiga e empurrava a faixa para fora. A div obedece sempre.
        if (cv.parentElement) cv.parentElement.style.height = altura + 'px';
        desenharGrafico(f, it, body, cv);
        if (faixa.parentElement === body) body.appendChild(faixa);

        // Segunda passada. A conta acima nao tem como saber de tudo que ocupa
        // espaco — margem da faixa, padding do corpo, a barra de rolagem de
        // 8px que aparece dentro do invólucro quando o grafico e' largo. Em
        // vez de tentar prever cada um, mede a sobra REAL e desconta. Uma
        // passada basta: a segunda medida ja' inclui tudo.
        const sobra = body.scrollHeight - body.clientHeight;
        if (sobra > 2 && cv.parentElement) {
          const corrigida = Math.max(MIN_GRAFICO, altura - sobra);
          cv.style.height = corrigida + 'px';
          cv.parentElement.style.height = corrigida + 'px';
          desenharGrafico(f, it, body, cv);
          if (faixa.parentElement === body) body.appendChild(faixa);
          // se nem assim couber, o quadro rola em vez de cortar calado
          if (body.scrollHeight - body.clientHeight > 2) {
            body.style.overflowY = 'auto';
            body.title = 'Role dentro do quadro para ver os insights, ' +
              'ou aumente a altura em Editar propriedades';
          }
        }
      }
      return true;
    };

    if (!ajustar() && typeof ResizeObserver === 'function') {
      const obs = new ResizeObserver(() => { if (ajustar()) obs.disconnect(); });
      obs.observe(faixa);
      // rede de seguranca: em navegador sem ResizeObserver util, tenta de novo
      setTimeout(() => { if (ajustar()) obs.disconnect(); }, 120);
    }
  }

  function desenharGrafico(f, it, body, canvasExistente) {
    const c = it.config, viz = V();
    if (c.tipo === 'calor') return desenharCalor(f, it, body);
    let canvas = canvasExistente;
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.style.width = '100%';
      canvas.style.height = ((it.h || 240) - HEADER_H - 16) + 'px';
      // O grafico vive dentro de uma area que ROLA de lado. Com muitas
      // categorias ele fica largo em vez de espremer tudo e virar um borrao
      // (era a diferenca que o Naor viu entre o Painel e o mapa de calor).
      const rolagem = document.createElement('div');
      rolagem.className = 'pan-graf-scroll';
      rolagem.appendChild(canvas);
      body.appendChild(rolagem);
    }
    // O TIPO escolhido manda. Antes, um gráfico com séries extras ignorava o
    // tipo (pizza/empilhado) e continuava desenhando o combo — parecia que
    // "editar as propriedades não muda nada".
    if (c.tipo === 'empilhado') {
      // Escolher "Barra empilhada" sem dizer POR QUE dividir nao tem como
      // funcionar. Antes caia num grafico comum, e parecia que a edicao do
      // painel nao fazia efeito nenhum.
      if (c.serieCat) return desenharEmpilhado(f, it, canvas);
      const cand = colunasDeTexto(f).filter(h => h !== c.grupo);
      if (cand.length) {
        c.serieCat = cand[0];
        salvar();
        return desenharEmpilhado(f, it, canvas);
      }
      canvas.remove();
      body.innerHTML = '<p class="pan-vazio">Para empilhar, escolha em ' +
        '<b>Dividir barras por</b> qual coluna separa as fatias ' +
        '(ex.: CLIENTE, REGIÃO).</p>';
      return;
    }
    if ((c.tipo === 'barra' || !c.tipo) && (c.series || []).length) return desenharCombo(f, it, canvas);

    // Ate' 60 barras, deixando a area rolar de lado. Nao funcionava: o desenho
    // saia num bitmap do tamanho da area e o navegador esticava o resto, que e'
    // a barra gorda e borrada que o Naor fotografou. E 60 barras em 590px sao
    // 9px cada, com o nome de pe' - ilegivel mesmo quando desenhava certo.
    //
    // Agora e' o que o Dashboard ja' fazia: mostra as maiores e junta o resto
    // numa barra so'. Cabe na area, nao estica, e da' para ler.
    const dat = limitarComOutros(agrupar(f, f.rows, c), c.topN || 12);
    if (!dat.length) {
      body.innerHTML = '<p class="pan-vazio">Sem dados para os campos escolhidos.</p>';
      return;
    }
    const sufixo = ehPct(c.op) ? '%' : '';
    const fv = v => viz.fmt0(v) + sufixo;
    esticarParaCaber(canvas, dat.length);
    const aoClicar = cliqueDe(c);
    if (c.tipo === 'pizza') {
      canvas.style.width = '100%';          // pizza nao rola: nao tem eixo
      viz.drawDonut(canvas, dat.map(d => d.k), dat.map(d => d.v), aoClicar);
    } else {
      viz.drawBars(canvas, dat.map(d => d.k), dat.map(d => d.v), aoClicar, fv);
    }

  }


  /* ── distribuição (histograma de resistência × fck) ──
   *
   * Este era o único widget que faltava para o Painel dar conta do que o
   * Dashboard dá: o desenho é o MESMO (window.ConcreLab.drawDistribuicao), não
   * uma segunda versão parecida. Dois histogramas independentes acabariam
   * discordando um dia, e quem visse a diferença não saberia em qual acreditar.
   */
  function colunasIrmas(f, col) {
    // Na planilha do laboratório os corpos de prova do mesmo dia ficam em
    // colunas repetidas: "MPA 28", "MPA 28.1", "MPA 28.2". Ler só a escolhida
    // mostraria um terço dos ensaios — e o histograma do Painel não bateria
    // com o do Dashboard, que junta todas.
    const lab = LAB();
    if (!lab.colsFor || !lab.baseName) {
      const i = f.headers.indexOf(col);
      return i >= 0 ? [i] : [];
    }
    return lab.colsFor(f.headers, lab.baseName(col));
  }

  /* Lê uma coluna de ensaio pelas regras do laboratório: junta as colunas
   * irmãs, ignora o zero (ensaio não rompido) e tira o que é impossível para
   * concreto. É a MESMA leitura do histograma — sem isso o cartão "Desvio
   * padrão" mostrava 47,58 MPa logo acima de um histograma dizendo 13,01, na
   * mesma tela. Dois números discordando ali derrubam a confiança nos dois. */
  function lerEnsaio(f, coluna) {
    const lab = LAB();
    if (!lab.poolNums) return { vals: [], fora: [], limite: NaN, cols: [] };
    const cols = colunasIrmas(f, coluna);
    const brutos = lab.poolNums(f.rows, cols, true);
    const sep = lab.separarImpossiveis ? lab.separarImpossiveis(brutos)
      : { bons: brutos, fora: [], limite: NaN };
    return { vals: sep.bons, fora: sep.fora, limite: sep.limite, cols: cols };
  }

  function desenharDistribuicao(f, it, body) {
    const c = it.config, lab = LAB(), viz = V();
    if (!lab.drawDistribuicao) {
      body.innerHTML = '<p class="pan-vazio">Estatística de laboratório indisponível.</p>';
      return;
    }
    if (!c.valor) {
      body.innerHTML = '<p class="pan-vazio">Escolha em <b>Coluna de valor</b> a ' +
        'resistência a analisar (ex.: MPA 28).</p>';
      return;
    }

    // zero não é ruptura fraca, é ensaio que ainda não foi rompido; e o que é
    // grande demais para ser concreto sai do cálculo.
    const sep = lerEnsaio(f, c.valor);
    const cols = sep.cols;
    const vals = sep.vals;

    const numeros = document.createElement('div');
    numeros.className = 'dist-numeros';
    const rolagem = document.createElement('div');
    rolagem.className = 'pan-graf-scroll';
    const canvas = document.createElement('canvas');
    canvas.style.width = '100%';
    canvas.style.height = Math.max(120, (it.h || 360) - HEADER_H - 116) + 'px';
    rolagem.appendChild(canvas);
    const legenda = document.createElement('div');
    legenda.className = 'dist-legenda';
    body.appendChild(numeros); body.appendChild(rolagem); body.appendChild(legenda);

    if (!vals.length) {
      legenda.innerHTML = '<span class="dist-vazio">Sem resultado em ' +
        esc(c.valor) + ' nesta seleção</span>';
      return;
    }

    // fck manual ganha do automático: numa planilha sem PRODUTO/RECEITA o
    // automático não acha nada, e sem limite o gráfico não diz o que reprovou.
    const manual = parseFloat(String(c.fck || '').replace(',', '.'));
    const auto = lab.fckPredominante(f.rows, f.headers);
    const fck = isNaN(manual) ? auto.fck : manual;
    const quantos = isNaN(manual) ? auto.quantos : 1;

    const media = vals.reduce((a, b) => a + b, 0) / vals.length;
    const dp = lab.desvioPadrao(vals, media);
    const cv = (!isNaN(dp) && media > 0) ? (dp / media * 100) : NaN;
    const abaixo = !isNaN(fck) ? vals.filter(v => v < fck).length : 0;

    lab.drawDistribuicao(canvas, vals, fck);

    const numero = (rotulo, valor, obs) =>
      '<div class="dist-num"><b>' + valor + '</b><span>' + rotulo + '</span>' +
      (obs ? '<i>' + obs + '</i>' : '') + '</div>';
    numeros.innerHTML =
      numero('Corpos de prova', vals.length) +
      numero('Média', viz.fmt(media, 1) + ' MPa') +
      numero('Desvio padrão', isNaN(dp) ? '—' : viz.fmt(dp, 2) + ' MPa', 'constância da usina') +
      numero('Coef. de variação', isNaN(cv) ? '—' : viz.fmt(cv, 1) + '%') +
      (!isNaN(fck)
        ? numero('Abaixo do fck', abaixo, viz.fmt(abaixo / vals.length * 100, 1) + '% do total')
        : '');

    const item = (cor, texto) =>
      '<span class="dist-item"><i class="dist-cor" style="background:' + cor + '"></i>' + texto + '</span>';
    let leg = '';
    if (!isNaN(fck)) {
      leg += item('#2a5298', 'Atingiu o fck (' + viz.fmt(fck, 0) + ' MPa)') +
        item('#b33a2a', 'Abaixo do fck') +
        '<span class="dist-item"><i class="dist-tracejado"></i>Limite do projeto</span>';
      if (quantos > 1) {
        leg += '<span class="dist-alerta">Esta seleção tem ' + quantos + ' fck diferentes. ' +
          'A linha marca o mais frequente; para ler a distribuição de um só, filtre por produto.</span>';
      }
    } else {
      leg += item('#2a5298', 'Corpos de prova') +
        '<span class="dist-alerta">Sem fck na coluna de produto ou receita, ' +
        'não dá para marcar o limite do projeto. Informe-o nas propriedades.</span>';
    }
    if (cols.length > 1) {
      leg += '<span class="dist-item">' + cols.length + ' colunas de ' +
        esc(lab.baseName ? lab.baseName(c.valor) : c.valor) + ' somadas</span>';
    }
    if (sep.fora.length) {
      leg += '<span class="dist-alerta">' + sep.fora.length + ' ' +
        (sep.fora.length === 1 ? 'resultado ficou' : 'resultados ficaram') +
        ' de fora do cálculo por passar de ' + viz.fmt(sep.limite, 0) + ' MPa (' +
        sep.fora.map(v => viz.fmt(v, 0)).join(', ') + '). Concreto não chega lá — ' +
        'provavelmente é erro de digitação na planilha.</span>';
    }
    legenda.innerHTML = leg;
  }

  function desenharDado(f, it, body) {
    const c = it.config, viz = V();
    const iV = f.headers.indexOf(c.valor);
    const ens = c.ensaio ? lerEnsaio(f, c.valor) : null;
    const vals = ens ? ens.vals
      : (iV >= 0 ? f.rows.map(r => viz.num(r[iV])) : f.rows.map(() => NaN));
    let valor, pct = false, sub = c.subtitulo || '';
    if (ens && !c.subtitulo) {
      const partes = [];
      if (ens.cols.length > 1) partes.push(ens.cols.length + ' colunas');
      if (ens.fora.length) partes.push(ens.fora.length + ' fora do cálculo');
      if (partes.length) sub = partes.join(' · ');
    }

    if (c.op === 'Crescimento %') {
      const g = agrupar(f, f.rows, {
        grupo: '__periodo__', colData: c.colData, grao: c.grao || 'mes',
        valor: c.valor, op: c.opBase || 'Soma'
      });
      // Comparar o ULTIMO periodo com o ANTERIOR so' faz sentido se eles forem
      // vizinhos. Numa planilha com um registro solto em janeiro e o resto em
      // dezembro, saia "-99,9% (2026-12 vs 2026-01)" — numero sem significado.
      if (g.length >= 2) {
        const ult = g[g.length - 1], ant = g[g.length - 2];
        if (!periodosVizinhos(ant.k, ult.k, c.grao || 'mes')) {
          // Periodos nao vizinhos: o numero continua valendo (o Naor confirmou
          // que fazia sentido na planilha dele), mas a legenda avisa que ha'
          // um buraco no meio — senao parece comparacao de meses seguidos.
          valor = ant.v ? (ult.v - ant.v) / Math.abs(ant.v) * 100 : NaN;
          pct = true;
          sub = ult.k + ' vs ' + ant.k + ' · sem dados no meio';
        } else {
          valor = ant.v ? (ult.v - ant.v) / Math.abs(ant.v) * 100 : NaN;
          pct = true;
          sub = sub || (ult.k + ' vs ' + ant.k);
        }
      } else {
        valor = NaN;
        sub = sub || 'só há um período nos dados';
      }
    } else if (c.op === '% do total' && c.grupo && c.filtroValor) {
      const g = agrupar(f, f.rows, { grupo: c.grupo, valor: c.valor, op: c.opBase || 'Soma' });
      const t = g.reduce((s, x) => s + (isNaN(x.v) ? 0 : Math.abs(x.v)), 0) || 1;
      const alvo = g.filter(x => x.k === c.filtroValor)[0];
      valor = alvo ? Math.abs(alvo.v) / t * 100 : NaN;
      pct = true;
      sub = sub || (c.filtroValor + ' sobre o total');
    } else {
      valor = calc(vals, c.op || 'Soma');
    }

    const cls = isNaN(valor) ? '' : (valor < 0 ? 'ana-down' : (pct && valor > 0 ? 'ana-up' : ''));
    const seta = pct ? (valor > 0 ? '▲ ' : valor < 0 ? '▼ ' : '') : '';
    const txt = isNaN(valor) ? '—'
      : pct ? seta + viz.fmt(Math.abs(valor), 1) + '%'
        : (c.op === 'Contagem' ? viz.fmt(valor, 0)
           : (viz.perfil === 'financeiro' ? 'R$ ' : '') + viz.fmt0(valor));
    body.innerHTML = '<div class="pan-dado"><b class="' + cls + '">' + esc(txt) + '</b>' +
      (sub ? '<span>' + esc(sub) + '</span>' : '') + '</div>';
  }

  function desenharTabela(f, it, body) {
    const c = it.config, viz = V();
    const cols = (c.colunas && c.colunas.length) ? c.colunas : [{ valor: c.valor, op: c.op || 'Soma' }];
    const base = agrupar(f, f.rows, {
      grupo: c.grupo, colData: c.colData, grao: c.grao,
      valor: cols[0].valor, op: cols[0].op, topN: c.topN
    });
    if (!base.length) {
      body.innerHTML = '<p class="pan-vazio">Escolha "Agrupar por" nas propriedades (botão direito).</p>';
      return;
    }
    const series = cols.map(cl => {
      const m = new Map();
      agrupar(f, f.rows, { grupo: c.grupo, colData: c.colData, grao: c.grao, valor: cl.valor, op: cl.op })
        .forEach(x => m.set(x.k, x.v));
      return m;
    });
    const pctCol = cols.map(cl => ehPct(cl.op));
    const linhas = base.slice(0, c.limite || 200);
    const totCols = cols.map((cl, i) => {
      if (pctCol[i]) return NaN;
      const iV = f.headers.indexOf(cl.valor);
      const vals = iV >= 0 ? f.rows.map(r => viz.num(r[iV])) : f.rows.map(() => NaN);
      return calc(vals, cl.op);
    });

    const cabec = '<th>' + esc(c.grupo === '__periodo__' ? 'Período' : (c.grupo || '')) + '</th>' +
      cols.map(cl => '<th>' + esc(cl.titulo || (cl.op + (cl.valor ? ' · ' + cl.valor : ''))) + '</th>').join('');

    const corpo = linhas.map(l => '<tr><td>' + esc(l.k) + '</td>' + cols.map((cl, i) => {
      const v = series[i].get(l.k);
      const neg = (v !== undefined && !isNaN(v) && v < 0) ? ' ana-neg' : '';
      return '<td class="ana-num' + neg + '">' + fmtOp(v, cl.op) + '</td>';
    }).join('') + '</tr>').join('');

    const rodape = c.total === false ? '' :
      '<tfoot><tr><td><b>Total</b></td>' + totCols.map((t, i) =>
        '<td class="ana-num"><b>' + fmtOp(t, cols[i].op) + '</b></td>'
      ).join('') + '</tr></tfoot>';

    body.innerHTML = (c.insights ? montarInsightsTabela(base, viz) : '') +
      '<div class="pan-tab-wrap"><table class="ana-pivot pan-tab"><thead><tr>' + cabec +
      '</tr></thead><tbody>' + corpo + '</tbody>' + rodape + '</table></div>' +
      '<button class="pan-btn-xls" type="button">Baixar Excel</button>';

    body.querySelector('.pan-btn-xls').addEventListener('click', ev => {
      ev.stopPropagation();
      const aoa = [[c.grupo === '__periodo__' ? 'Período' : c.grupo].concat(
        cols.map(cl => cl.titulo || (cl.op + ' ' + (cl.valor || ''))))];
      base.forEach(l => aoa.push([l.k].concat(cols.map((cl, i) => {
        const v = series[i].get(l.k);
        return (v === undefined || isNaN(v)) ? '' : v;
      }))));
      exportarAoa(aoa, String(it.config.titulo || tituloAuto(it)).replace(/[^\w\-]+/g, '_'));
    });
  }

  // Insights da própria tabela (o Naor pediu insights on/off por widget).
  function montarInsightsTabela(base, viz) {
    const vals = (base || []).filter(x => x && !isNaN(x.v));
    if (!vals.length) return '';
    // Maior e menor calculados de verdade. Antes assumia a lista ja' ordenada
    // por valor — num grafico por mes (ordenado por data) saia "Maior: 220" e
    // "Menor: 340", que e' visivelmente errado.
    const tot = vals.reduce((s, x) => s + Math.abs(x.v), 0) || 1;
    let top = vals[0], baixo = vals[0];
    vals.forEach(x => { if (x.v > top.v) top = x; if (x.v < baixo.v) baixo = x; });
    const cards = [{
      cls: 'info', ico: '★',
      txt: 'Maior: ' + top.k + ' (' + viz.fmt0(top.v) + ' · ' + viz.fmt(Math.abs(top.v) / tot * 100, 1) + '%)'
    }];
    if (vals.length > 1 && baixo.k !== top.k) {
      cards.push({ cls: 'down', ico: '▼', txt: 'Menor: ' + baixo.k + ' (' + viz.fmt0(baixo.v) + ')' });
    }
    if (vals.length > 2) {
      const media = vals.reduce((s, x) => s + x.v, 0) / vals.length;
      cards.push({ cls: 'info', ico: '~', txt: 'Média: ' + viz.fmt0(media) + ' por ' + (vals.length) + ' grupos' });
    }
    const conc = Math.abs(top.v) / tot * 100;
    if (conc > 50) cards.push({ cls: 'warn', ico: '!', txt: '"' + top.k + '" concentra ' + viz.fmt(conc, 1) + '% do total' });
    return '<div class="ana-ins pan-ins">' + cards.map(i =>
      '<div class="ins-card ' + i.cls + '"><span class="ins-ico">' + i.ico + '</span><span>' +
      esc(i.txt) + '</span></div>').join('') + '</div>';
  }


  function desenharEmpilhado(f, it, canvas) {
    const c = it.config, viz = V(), num = viz.num;
    const porPeriodo = c.grupo === '__periodo__';
    const iX = porPeriodo ? f.headers.indexOf(c.colData) : f.headers.indexOf(c.grupo);
    const iC = f.headers.indexOf(c.serieCat);
    const iV = f.headers.indexOf(c.valor);
    if (iX < 0 || iC < 0) { viz.drawBars(canvas, [], [], null); return; }
    const xs = [], catTot = new Map(), mapa = new Map();
    f.rows.forEach(r => {
      const k = porPeriodo ? chavePeriodo(r[iX], c.grao || 'mes')
        : (String(r[iX] == null ? '' : r[iX]).trim() || SEM_VALOR);
      if (k === null) return;
      const cat = String(r[iC] == null ? '' : r[iC]).trim() || SEM_VALOR;
      const v = iV >= 0 ? num(r[iV]) : 1;
      if (isNaN(v)) return;
      if (!mapa.has(k)) { mapa.set(k, new Map()); xs.push(k); }
      mapa.get(k).set(cat, (mapa.get(k).get(cat) || 0) + v);
      catTot.set(cat, (catTot.get(cat) || 0) + v);
    });
    xs.sort((a, b) => String(a).localeCompare(String(b)));

    // Sem limite de barras, uma coluna com centenas de valores virava um borrao
    // com os nomes ilegiveis embaixo. Fica o que importa: por periodo, os
    // ultimos N; por categoria, os N maiores.
    // Com a area rolando, da' para mostrar bem mais do que cabia antes.
    const limite = c.topN > 0 ? c.topN : 60;
    let deFora = 0;
    if (xs.length > limite) {
      deFora = xs.length - limite;
      if (porPeriodo) {
        xs.splice(0, deFora);
      } else {
        const totalPorX = new Map();
        xs.forEach(k => {
          let t = 0;
          (mapa.get(k) || new Map()).forEach(v => { t += v; });
          totalPorX.set(k, t);
        });
        const mantidos = xs.slice()
          .sort((a, b) => (totalPorX.get(b) || 0) - (totalPorX.get(a) || 0))
          .slice(0, limite);
        xs.length = 0;
        mantidos.forEach(k => xs.push(k));
      }
    }

    const arr = [];
    catTot.forEach((v, k) => arr.push([k, v]));
    const top = arr.sort((a, b) => b[1] - a[1]).slice(0, 6).map(e => e[0]);
    const series = top.map(cat => ({
      nome: cat, vals: xs.map(k => (mapa.get(k) || new Map()).get(cat) || 0)
    }));
    const outros = {
      nome: 'Outros',
      vals: xs.map(k => {
        let s = 0;
        (mapa.get(k) || new Map()).forEach((v, cat) => { if (top.indexOf(cat) < 0) s += v; });
        return s;
      })
    };
    if (outros.vals.some(v => v > 0)) series.push(outros);
    esticarParaCaber(canvas, xs.length);
    // Num empilhado o clique acerta a fatia, não a barra: quem foi clicado é
    // a categoria que divide as barras, não o eixo X.
    viz.drawStacked(canvas, xs, series, cliqueDe({ grupo: c.serieCat, grao: c.grao }));
    if (deFora > 0) marcarCorte(canvas, deFora, porPeriodo);
  }

  // Avisa, sem atrapalhar, que o grafico esta' mostrando so' uma parte.
  function marcarCorte(canvas, quantos, porPeriodo) {
    const pai = canvas.parentElement;
    if (!pai || pai.querySelector('.pan-nota-corte')) return;
    const p = document.createElement('p');
    p.className = 'pan-nota pan-nota-corte';
    p.textContent = porPeriodo
      ? 'Mostrando os últimos períodos — ' + quantos + ' anteriores ficaram de fora.'
      : 'Mostrando os maiores — outros ' + quantos + ' ficaram de fora (aumente o ' +
        '"Máximo de grupos" nas propriedades para ver mais).';
    pai.appendChild(p);
  }

  /* ── combo: várias séries (barra + linha, 2 eixos) ──
     É o que permite montar "produção e crescimento" como o Naor pediu. */
  function desenharCombo(f, it, canvas) {
    const c = it.config, viz = V();
    const eixoX = agrupar(f, f.rows, {
      grupo: c.grupo, colData: c.colData, grao: c.grao,
      valor: (c.series[0] || {}).valor, op: (c.series[0] || {}).op || 'Soma',
      topN: (!c.topN || c.topN === 12) ? 60 : c.topN
    });
    if (!eixoX.length) { viz.drawBars(canvas, [], [], null); return; }
    const labels = eixoX.map(d => d.k);
    esticarParaCaber(canvas, labels.length);   // area rola quando nao cabe
    const series = c.series.map(s => {
      const m = new Map();
      agrupar(f, f.rows, { grupo: c.grupo, colData: c.colData, grao: c.grao, valor: s.valor, op: s.op })
        .forEach(x => m.set(x.k, x.v));
      const o = {};
      Object.keys(s).forEach(k => { o[k] = s[k]; });
      o.vals = labels.map(k => { const v = m.get(k); return v === undefined ? NaN : v; });
      return o;
    });

    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth || 600, h = canvas.clientHeight || 240;
    canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);

    const temDir = series.some(s => s.eixo === 'dir');
    const left = 56, right = temDir ? 56 : 14, top = 16, bottom = 48;
    const plotW = w - left - right, plotH = h - top - bottom, baseY = top + plotH;

    const junta = arr => arr.filter(v => !isNaN(v) && isFinite(v));
    let esqVals = [], dirVals = [];
    series.forEach(s => { (s.eixo === 'dir' ? dirVals : esqVals).push.apply(s.eixo === 'dir' ? dirVals : esqVals, junta(s.vals)); });
    const eMax = Math.max.apply(null, esqVals.concat([1])), eMin = Math.min.apply(null, esqVals.concat([0]));
    let dMax = Math.max.apply(null, dirVals.concat([1])), dMin = Math.min.apply(null, dirVals.concat([0]));
    if (dMax === dMin) { dMax += 1; dMin -= 1; }

    ctx.font = '11px IBM Plex Mono, monospace';
    for (let i = 0; i <= 4; i++) {
      const y = top + plotH * i / 4;
      ctx.strokeStyle = '#ececea';
      ctx.beginPath(); ctx.moveTo(left, y); ctx.lineTo(w - right, y); ctx.stroke();
      ctx.fillStyle = '#2a5298'; ctx.textAlign = 'right';
      ctx.fillText(viz.fmt0(eMax - (eMax - eMin) * i / 4), left - 6, y + 4);
      if (temDir) {
        ctx.fillStyle = '#2a6640'; ctx.textAlign = 'left';
        ctx.fillText(viz.fmt0(dMax - (dMax - dMin) * i / 4) + '%', w - right + 6, y + 4);
      }
    }
    ctx.textAlign = 'start';

    const yEsq = v => top + plotH * (1 - (v - eMin) / ((eMax - eMin) || 1));
    const yDir = v => top + plotH * (1 - (v - dMin) / ((dMax - dMin) || 1));
    const slot = plotW / Math.max(1, labels.length);
    const barras = series.filter(s => s.tipo !== 'linha');
    const bw = Math.max(4, Math.min(46, slot * 0.7 / Math.max(1, barras.length)));

    barras.forEach((s, si) => {
      ctx.fillStyle = s.cor || '#2a5298';
      s.vals.forEach((v, i) => {
        if (isNaN(v)) return;
        const fy = s.eixo === 'dir' ? yDir : yEsq;
        const yv = fy(v), y0 = fy(0);
        const x = left + slot * i + (slot - bw * barras.length) / 2 + si * bw;
        ctx.fillRect(x, Math.min(yv, y0), bw, Math.max(2, Math.abs(y0 - yv)));
      });
    });
    series.filter(s => s.tipo === 'linha').forEach(s => {
      const fy = s.eixo === 'dir' ? yDir : yEsq;
      ctx.strokeStyle = s.cor || '#2a6640';
      ctx.lineWidth = 2; ctx.beginPath();
      let iniciado = false;
      s.vals.forEach((v, i) => {
        if (isNaN(v)) return;
        const x = left + slot * i + slot / 2, y = fy(v);
        if (!iniciado) { ctx.moveTo(x, y); iniciado = true; } else ctx.lineTo(x, y);
      });
      ctx.stroke(); ctx.lineWidth = 1;
      ctx.fillStyle = s.cor || '#2a6640';
      s.vals.forEach((v, i) => {
        if (isNaN(v)) return;
        ctx.beginPath();
        ctx.arc(left + slot * i + slot / 2, fy(v), 3, 0, Math.PI * 2);
        ctx.fill();
      });
    });

    ctx.fillStyle = '#555'; ctx.font = '10px IBM Plex Mono, monospace'; ctx.textAlign = 'center';
    const passo = slot >= 46 ? 1 : Math.ceil(46 / slot);
    labels.forEach((l, i) => {
      if (i % passo) return;
      ctx.fillText(String(l).slice(0, 12), left + slot * i + slot / 2, baseY + 16);
    });
    let lx = left;
    ctx.textAlign = 'left'; ctx.font = '10px IBM Plex Sans, sans-serif';
    series.forEach(s => {
      ctx.fillStyle = s.cor || '#2a5298';
      ctx.fillRect(lx, baseY + 28, 9, 9);
      ctx.fillStyle = '#5a5852';
      const nome = String(s.titulo || (s.op + ' ' + (s.valor || ''))).slice(0, 26);
      ctx.fillText(nome, lx + 13, baseY + 36);
      lx += ctx.measureText(nome).width + 30;
    });
    ctx.textAlign = 'start';

    // Clicar no mês filtra o painel inteiro por aquele período, como na Análise.
    const aoClicar = cliqueDe(c);
    if (aoClicar) {
      canvas.style.cursor = 'pointer';
      canvas.onclick = ev => {
        const r = canvas.getBoundingClientRect();
        const i = Math.floor((ev.clientX - r.left - left) / slot);
        if (i >= 0 && i < labels.length) aoClicar(labels[i]);
      };
    }
  }

  /* ── mapa de calor (calendário) ────────────────── */
  function desenharCalor(f, it, body) {
    const c = it.config, viz = V(), num = viz.num;
    const iD = f.headers.indexOf(c.colData), iV = f.headers.indexOf(c.valor);
    if (iD < 0) { body.innerHTML = '<p class="pan-vazio">Escolha a coluna de data nas propriedades.</p>'; return; }
    const dias = new Map();
    f.rows.forEach(r => {
      const k = chavePeriodo(r[iD], 'dia');
      if (!k) return;
      const v = iV >= 0 ? num(r[iV]) : 1;
      if (isNaN(v)) return;
      dias.set(k, (dias.get(k) || 0) + v);
    });
    const keys = [];
    dias.forEach((v, k) => keys.push(k));
    keys.sort();
    if (!keys.length) { body.innerHTML = '<p class="pan-vazio">Sem datas válidas.</p>'; return; }
    const parse = k => { const p = k.split('-'); return new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])); };

    // Uma data solta no comeco do ano esticava o mapa por 52 semanas vazias e
    // o que interessa ficava fora da tela. Agora o mapa comeca onde os dados
    // realmente comecam: o trecho mais recente que cobre 98% do movimento.
    let totalMov = 0;
    dias.forEach(v => { totalMov += v; });
    let acumulado = 0, corte = 0;
    for (let i = keys.length - 1; i >= 0; i--) {
      acumulado += dias.get(keys[i]) || 0;
      if (acumulado >= totalMov * 0.98) { corte = i; break; }
    }
    const forasDeFora = corte;                      // quantos dias ficaram de fora
    const d0 = parse(keys[corte]), d1 = parse(keys[keys.length - 1]);
    let maxV = 1;
    dias.forEach(v => { if (v > maxV) maxV = v; });
    const cor = v => v <= 0 ? '#ebedf0'
      : (v / maxV < 0.25 ? '#c6e48b' : v / maxV < 0.5 ? '#7bc96f' : v / maxV < 0.75 ? '#239a3b' : '#196127');
    const cur = new Date(d0);
    cur.setUTCDate(cur.getUTCDate() - ((cur.getUTCDay() + 6) % 7));
    const cols = [];
    let guarda = 0;
    while (guarda++ < 800) {
      const semana = [];
      for (let i = 0; i < 7; i++) {
        const k = cur.toISOString().slice(0, 10);
        semana.push({ k: k, v: dias.get(k) || 0, dentro: cur >= d0 && cur <= d1 });
        cur.setUTCDate(cur.getUTCDate() + 1);
      }
      cols.push(semana);
      if (cur > d1 && ((cur.getUTCDay() + 6) % 7) === 0) break;
    }
    const nota = forasDeFora > 0
      ? '<p class="pan-nota">Mostrando de ' + keys[corte].split('-').reverse().join('/') +
        ' em diante — ' + forasDeFora + ' dia(s) mais antigo(s) e isolado(s) ficaram de fora ' +
        'para o mapa nao virar uma faixa vazia.</p>'
      : '';
    const C = 12, G = 3;
    let svg = '<svg width="' + (cols.length * (C + G) + 46) + '" height="' + (7 * (C + G) + 34) +
      '" style="font-family:IBM Plex Mono,monospace">';
    ['Seg', '', 'Qua', '', 'Sex', '', 'Dom'].forEach((dn, r) => {
      if (dn) svg += '<text x="2" y="' + (30 + r * (C + G) + C - 2) + '" font-size="9" fill="#999">' + dn + '</text>';
    });
    let ultimoMes = '';
    cols.forEach((semana, ci) => {
      const primeiro = semana.filter(d => d.dentro)[0];
      if (primeiro) {
        const mo = primeiro.k.slice(0, 7);
        if (mo !== ultimoMes) {
          ultimoMes = mo;
          svg += '<text x="' + (44 + ci * (C + G)) + '" y="18" font-size="9" fill="#999">' +
            primeiro.k.slice(5, 7) + '/' + primeiro.k.slice(2, 4) + '</text>';
        }
      }
      semana.forEach((cel, r) => {
        if (!cel.dentro) return;
        svg += '<rect x="' + (44 + ci * (C + G)) + '" y="' + (24 + r * (C + G)) + '" width="' + C +
          '" height="' + C + '" rx="2" fill="' + cor(cel.v) + '"><title>' +
          viz.fmt(cel.v, 1) + ' · ' + cel.k.split('-').reverse().join('/') + '</title></rect>';
      });
    });
    svg += '</svg>';
    body.innerHTML = '<div class="pan-calor">' + svg + '</div>' + nota;
  }

  /* ── mover e redimensionar ─────────────────────── */
  function arrastar(el, it) {
    const head = el.querySelector('.pan-w-head');
    head.addEventListener('mousedown', ev => {
      if (ev.button !== 0) return;
      ev.preventDefault();
      const canvas = $('pan-canvas');
      const cr = canvas.getBoundingClientRect();
      const offX = ev.clientX - el.getBoundingClientRect().left;
      const offY = ev.clientY - el.getBoundingClientRect().top;
      el.classList.add('movendo');
      const mover = e => {
        let nl = snap(e.clientX - cr.left - offX);
        let nt = snap(e.clientY - cr.top - offY);
        // Sem limite superior, igual ja' era na vertical. O limite antigo era
        // (largura do canvas - largura do widget): num widget mais largo que a
        // tela isso da' NEGATIVO, o Math.max(0, ...) zerava, e o widget ficava
        // preso no canto esquerdo sem sair do lugar. Reproduzido: widget de
        // 1640px num canvas de 1226px nao andava um pixel.
        nl = Math.max(0, nl);
        nt = Math.max(0, nt);
        el.style.left = nl + 'px';
        el.style.top = nt + 'px';
        // O canvas cresce junto para dar onde pousar (e onde rolar ate').
        const precisaW = snap(nl + el.offsetWidth + GRID * 2);
        if (precisaW > canvas.offsetWidth) canvas.style.minWidth = precisaW + 'px';
        const precisaH = snap(nt + el.offsetHeight + GRID * 2);
        if (precisaH > canvas.offsetHeight) canvas.style.minHeight = precisaH + 'px';
      };
      const soltar = () => {
        document.removeEventListener('mousemove', mover);
        document.removeEventListener('mouseup', soltar);
        el.classList.remove('movendo');
        it.x = parseInt(el.style.left) || 0;
        it.y = parseInt(el.style.top) || 0;
        salvar();
        render();
      };
      document.addEventListener('mousemove', mover);
      document.addEventListener('mouseup', soltar);
    });
  }

  function redimensionar(el, it) {
    const h = el.querySelector('.pan-w-resize');
    h.addEventListener('mousedown', ev => {
      ev.preventDefault(); ev.stopPropagation();
      const canvas = $('pan-canvas');
      const x0 = ev.clientX, y0 = ev.clientY;
      const w0 = el.offsetWidth, h0 = el.offsetHeight;
      const mover = e => {
        el.style.width = Math.max(180, snap(w0 + e.clientX - x0)) + 'px';
        el.style.height = Math.max(110, snap(h0 + e.clientY - y0)) + 'px';
        const precisaW = snap((parseInt(el.style.left) || 0) + el.offsetWidth + GRID * 2);
        if (precisaW > canvas.offsetWidth) canvas.style.minWidth = precisaW + 'px';
        const precisaH = snap((parseInt(el.style.top) || 0) + el.offsetHeight + GRID * 2);
        if (precisaH > canvas.offsetHeight) canvas.style.minHeight = precisaH + 'px';
      };
      const soltar = () => {
        document.removeEventListener('mousemove', mover);
        document.removeEventListener('mouseup', soltar);
        it.w = parseInt(el.style.width);
        it.h = parseInt(el.style.height);
        salvar();
        render();
      };
      document.addEventListener('mousemove', mover);
      document.addEventListener('mouseup', soltar);
    });
  }

  /* ── menus de contexto ─────────────────────────── */
  let _fecharFora = null;
  function fecharMenu() {
    const m = $('pan-ctx');
    if (m) m.remove();
    if (_fecharFora) {
      document.removeEventListener('mousedown', _fecharFora, true);
      _fecharFora = null;
    }
  }
  function abrirMenu(x, y, itens) {
    fecharMenu();
    const m = document.createElement('div');
    m.id = 'pan-ctx';
    m.className = 'context-menu pan-ctx';
    m.style.cssText = 'display:block;left:' + x + 'px;top:' + y + 'px';
    m.innerHTML = itens.map((i, idx) => i.sep
      ? '<div class="pan-ctx-sep"></div>'
      : '<div class="context-item" data-i="' + idx + '">' + esc(i.label) + '</div>').join('');
    document.body.appendChild(m);
    const r = m.getBoundingClientRect();
    if (r.right > window.innerWidth) m.style.left = Math.max(4, window.innerWidth - r.width - 6) + 'px';
    if (r.bottom > window.innerHeight) m.style.top = Math.max(4, window.innerHeight - r.height - 6) + 'px';
    m.querySelectorAll('.context-item').forEach(el => {
      el.addEventListener('click', () => {
        const it = itens[parseInt(el.dataset.i)];
        fecharMenu();
        if (it && it.fn) it.fn();
      });
    });
    // Fecha só quando o clique for FORA do menu. Antes, o mousedown no próprio
    // item removia o menu antes do 'click' disparar — as opções não funcionavam.
    _fecharFora = ev => { if (!ev.target.closest('#pan-ctx')) fecharMenu(); };
    setTimeout(() => document.addEventListener('mousedown', _fecharFora, true), 0);
  }

  function menuCanvas(x, y) {
    const canvas = $('pan-canvas');
    const cr = canvas ? canvas.getBoundingClientRect() : { left: 0, top: 0 };
    const px = snap(Math.max(0, x - cr.left)), py = snap(Math.max(0, y - cr.top));
    abrirMenu(x, y, [
      { label: '+ Dado (KPI)', fn: () => novoWidget('dado', px, py) },
      { label: '+ Tabela', fn: () => novoWidget('tabela', px, py) },
      { label: '+ Gráfico', fn: () => novoWidget('grafico', px, py) },
      { label: '+ Insights', fn: () => novoWidget('insights', px, py) },
      { label: '+ Distribuição (resistência × fck)', fn: () => novoWidget('distribuicao', px, py) },
      { sep: true },
      { label: 'Montar painel automático', fn: painelAutomatico },
      {
        label: 'Limpar painel', fn: () => {
          if (!confirm('Remover todos os widgets deste painel?')) return;
          state.layouts[state.sheet] = [];
          salvar(); render();
        }
      }
    ]);
  }

  function menuWidget(x, y, it) {
    abrirMenu(x, y, [
      { label: 'Editar propriedades', fn: () => editar(it) },
      {
        label: 'Duplicar', fn: () => {
          const n = JSON.parse(JSON.stringify(it));
          n.id = genId(); n.y = (it.y || 0) + (it.h || 240) + GRID;
          layout().push(n); salvar(); render();
        }
      },
      { sep: true },
      {
        label: 'Excluir', fn: () => {
          const L = layout();
          for (let i = 0; i < L.length; i++) {
            if (L[i].id === it.id) { L.splice(i, 1); break; }
          }
          salvar(); render();
        }
      }
    ]);
  }

  /* ── criação e edição ──────────────────────────── */
  function autoMapa(f) {
    return (window.ConcreAutoMap && window.ConcreAutoMap(f.headers, f.rows)) || {};
  }

  // Coluna de ensaio: MPA 28 primeiro (e' o que vale o laudo), depois 7 dias,
  // depois qualquer cabecalho que fale de MPa ou resistencia.
  function colunaDeResistencia(f) {
    const norm = h => String(h || '').trim().toUpperCase();
    const acha = alvo => f.headers.find(h => norm(h).replace(/\.\d+$/, '') === alvo);
    return acha('MPA 28') || acha('MPA 7') ||
      f.headers.find(h => /MPA|RESIST/.test(norm(h))) || '';
  }

  function novoWidget(tipo, x, y) {
    const f = dados();
    if (!f) return;
    const m = autoMapa(f);
    const cfg = {
      valor: m.valor || '', grupo: m.cat || '', colData: m.data || '',
      grao: 'mes', op: 'Soma', insights: false, total: true, topN: 12
    };
    if (tipo === 'grafico') { cfg.tipo = 'barra'; cfg.series = []; }
    if (tipo === 'tabela') cfg.colunas = [{ valor: cfg.valor, op: 'Soma' }, { valor: cfg.valor, op: '% do total' }];
    // A distribuicao nao e' sobre a coluna que mais soma, e' sobre a
    // resistencia. O autodetect escolhe volume (M3) e o widget nasceria
    // desenhando o histograma do tamanho dos caminhoes.
    if (tipo === 'distribuicao') cfg.valor = colunaDeResistencia(f) || cfg.valor;
    const tam = tipo === 'dado' ? { w: 240, h: 130 }
      : tipo === 'insights' ? { w: 460, h: 210 }
        : tipo === 'tabela' ? { w: 460, h: 300 }
          : tipo === 'distribuicao' ? { w: 700, h: 400 } : { w: 520, h: 280 };
    const it = { id: genId(), type: tipo, x: x || 0, y: y || 0, w: tam.w, h: tam.h, config: cfg };
    layout().push(it);
    salvar(); render();
    editar(it);
  }

  function selHtml(id, headers, cur, rotulo) {
    const opts = ['<option value="">—</option>'].concat(headers.map(h =>
      '<option value="' + esc(h) + '"' + (h === cur ? ' selected' : '') + '>' + esc(h) + '</option>'));
    return '<label>' + rotulo + '</label><select id="' + id + '">' + opts.join('') + '</select>';
  }
  const opSel = (id, cur, lista) => '<select id="' + id + '">' + (lista || OPS).map(o =>
    '<option' + (o === cur ? ' selected' : '') + '>' + o + '</option>').join('') + '</select>';

  function editar(it) {
    const f = dados();
    if (!f || !window.openModal) return;
    const c = it.config;
    const H = f.headers;
    const grupoOpts = '<option value="">—</option>' +
      '<option value="__periodo__"' + (c.grupo === '__periodo__' ? ' selected' : '') + '>Período (data)</option>' +
      H.map(h => '<option value="' + esc(h) + '"' + (h === c.grupo ? ' selected' : '') + '>' + esc(h) + '</option>').join('');

    let corpo = '<label>Título</label><input id="pw-tit" value="' + esc(c.titulo || '') +
      '" placeholder="' + esc(tituloAuto(it)) + '">';

    if (it.type === 'grafico') {
      corpo += '<label>Tipo</label><select id="pw-tipo">' + TIPOS.map(t =>
        '<option value="' + t[0] + '"' + (t[0] === (c.tipo || 'barra') ? ' selected' : '') + '>' + t[1] + '</option>').join('') + '</select>';
    }
    if (it.type === 'tabela' || it.type === 'grafico') {
      corpo += '<label>Agrupar por</label><select id="pw-grupo">' + grupoOpts + '</select>';
    }
    // A distribuição não tem eixo de tempo: ela conta quantos ensaios caíram em
    // cada faixa de resistência. Oferecer "agrupar datas por mês" ali só faz o
    // usuário preencher um campo que não muda nada no desenho.
    if (it.type !== 'distribuicao') {
      corpo += selHtml('pw-data', H, c.colData, 'Coluna de data');
      corpo += '<label>Agrupar datas por</label><select id="pw-grao">' +
        [['dia', 'Dia'], ['mes', 'Mês'], ['ano', 'Ano']].map(g =>
          '<option value="' + g[0] + '"' + (g[0] === (c.grao || 'mes') ? ' selected' : '') + '>' + g[1] + '</option>').join('') + '</select>';
    }
    corpo += selHtml('pw-valor', H, c.valor,
      it.type === 'distribuicao' ? 'Coluna do ensaio (ex.: MPA 28)' : 'Coluna de valor');

    if (it.type === 'distribuicao') {
      corpo += '<label>fck do projeto (MPa)</label><input id="pw-fck" value="' +
        esc(c.fck || '') + '" placeholder="deixe vazio para ler do produto/receita">';
      corpo += '<p class="rc-dica">Vazio, o fck sai da coluna PRODUTO ou RECEITA ' +
        '(o valor depois de "FCK"). Preencha quando a planilha não trouxer essa ' +
        'informação, ou para comparar a mesma produção com outro limite.</p>';
    }

    if (it.type === 'dado') {
      corpo += '<label>Operação</label>' + opSel('pw-op', c.op || 'Soma');
      corpo += '<label>Operação base (para % e crescimento)</label>' + opSel('pw-opbase', c.opBase || 'Soma', OPS_BASE);
      corpo += '<label>Categoria (para "% do total")</label><select id="pw-grupo">' + grupoOpts + '</select>';
      corpo += '<label>Valor da categoria</label><input id="pw-fval" value="' + esc(c.filtroValor || '') +
        '" placeholder="ex.: Serviços">';
      corpo += '<label class="pw-check"><input type="checkbox" id="pw-ensaio"' +
        (c.ensaio ? ' checked' : '') + '> Tratar como ensaio de resistência</label>';
      corpo += '<p class="rc-dica">Marcado, o cartão lê a coluna do jeito do ' +
        'laboratório: junta as colunas repetidas (MPA 28 e MPA 28.1), ignora ' +
        'o ensaio ainda não rompido (zero) e descarta valor impossível para ' +
        'concreto — os mesmos números do gráfico de distribuição.</p>';
      corpo += '<label>Legenda</label><input id="pw-sub" value="' + esc(c.subtitulo || '') + '" placeholder="opcional">';
    }
    if (it.type === 'tabela') {
      corpo += '<label>Colunas (cada uma com sua operação)</label><div id="pw-cols" class="pw-cols"></div>' +
        '<button type="button" id="pw-addcol" class="pw-add">+ coluna</button>' +
        '<label class="pw-check"><input type="checkbox" id="pw-ins"' + (c.insights ? ' checked' : '') +
        '> Mostrar insights</label>' +
        '<label class="pw-check"><input type="checkbox" id="pw-tot"' + (c.total !== false ? ' checked' : '') + '> Linha de total</label>' +
        '<label>Máximo de grupos</label><input id="pw-topn" type="number" min="0" max="500" value="' + (c.topN || 12) + '">';
    }
    if (it.type === 'grafico') {
      // Cada tipo de gráfico usa um conjunto diferente de campos. Mostrar todos
      // para todos fazia o usuário preencher "Dividir barras por" numa pizza e
      // achar que o app tinha ignorado — quando na verdade aquele campo nunca
      // teve efeito ali. Os que não servem ficam escondidos, e a lista muda
      // sozinha ao trocar o tipo.
      const tipoAtual = c.tipo || 'barra';
      const usaEmpilhado = tipoAtual === 'barra';
      const usaSeries = tipoAtual === 'barra' || tipoAtual === 'linha';
      const usaTopN = tipoAtual !== 'calor';

      corpo += '<label>Operação</label>' + opSel('pw-op', c.op || 'Soma');
      corpo += '<label class="pw-check"><input type="checkbox" id="pw-ins"' +
        (c.insights ? ' checked' : '') + '> Mostrar insights abaixo do gráfico</label>';
      if (usaEmpilhado) {
        corpo += selHtml('pw-seriecat', H, c.serieCat, 'Dividir barras por (empilhado)');
      }
      if (!usaSeries) {
        corpo += '<p class="rc-dica">Gráfico de ' +
          (tipoAtual === 'pizza' ? 'pizza' : 'mapa de calor') +
          ' mostra uma medida só. Para comparar duas, use barra ou linha.</p>';
      }
      if (usaSeries) {
      corpo += '<label>Séries extras — combo barra + linha</label>';
      corpo += '<p class="rc-dica" id="pw-aviso-series"' +
        ((c.series || []).length ? '' : ' hidden') + '>A primeira série é o gráfico que já estava aqui, ' +
        'trazido para a lista. Enquanto houver séries, são elas que mandam — os campos ' +
        '<b>Coluna de valor</b> e <b>Operação</b> acima ficam de reserva. Apague todas para voltar ao gráfico simples.</p>';
      corpo += '<div id="pw-series" class="pw-cols"></div>' +
        '<button type="button" id="pw-addserie" class="pw-add">+ gráfico (série)</button>';
      }
      if (usaTopN) {
        corpo += '<label>Máximo de grupos</label><input id="pw-topn" type="number" min="0" max="500" value="' + (c.topN || 12) + '">';
      }
    }

    const nomeTipo = it.type === 'dado' ? 'Dado' : it.type === 'tabela' ? 'Tabela'
      : it.type === 'insights' ? 'Insights'
        : it.type === 'distribuicao' ? 'Distribuição' : 'Gráfico';

    window.openModal('Propriedades — ' + nomeTipo, corpo, () => {
      const g = id => { const el = document.getElementById(id); return el ? el.value : undefined; };
      const gc = id => { const el = document.getElementById(id); return el ? el.checked : undefined; };
      c.titulo = g('pw-tit') || '';
      if (g('pw-data') !== undefined) c.colData = g('pw-data');
      if (g('pw-grao') !== undefined) c.grao = g('pw-grao');
      c.valor = g('pw-valor') || '';
      if (g('pw-grupo') !== undefined) c.grupo = g('pw-grupo') || '';
      if (g('pw-tipo') !== undefined) c.tipo = g('pw-tipo');
      if (g('pw-op') !== undefined) c.op = g('pw-op');
      if (g('pw-opbase') !== undefined) c.opBase = g('pw-opbase');
      if (g('pw-fval') !== undefined) c.filtroValor = g('pw-fval');
      if (g('pw-sub') !== undefined) c.subtitulo = g('pw-sub');
      if (g('pw-fck') !== undefined) c.fck = g('pw-fck');
      if (gc('pw-ensaio') !== undefined) c.ensaio = gc('pw-ensaio');
      if (g('pw-seriecat') !== undefined) c.serieCat = g('pw-seriecat') || '';
      if (gc('pw-ins') !== undefined) c.insights = gc('pw-ins');
      if (gc('pw-tot') !== undefined) c.total = gc('pw-tot');
      if (g('pw-topn') !== undefined) c.topN = parseInt(g('pw-topn')) || 0;
      if (it.type === 'tabela') c.colunas = lerColunas();
      // So' regrava as séries se a lista estava na tela. Sem isto, trocar o
      // tipo para pizza (que não mostra séries) apagaria as que estavam
      // salvas, e voltar para barra devolveria um gráfico vazio.
      if (it.type === 'grafico' && document.getElementById('pw-series')) {
        c.series = lerSeries();
      }
      salvar();
      if (window.closeModal) window.closeModal();
      render();
    });

    function linhaColuna(cl) {
      const d = document.createElement('div');
      d.className = 'pw-col-row';
      d.innerHTML = '<select class="pw-c-val"><option value="">— contagem —</option>' +
        H.map(h => '<option value="' + esc(h) + '"' + (h === cl.valor ? ' selected' : '') + '>' + esc(h) + '</option>').join('') +
        '</select><select class="pw-c-op">' + OPS.map(o =>
          '<option' + (o === cl.op ? ' selected' : '') + '>' + o + '</option>').join('') +
        '</select><input class="pw-c-tit" placeholder="título" value="' + esc(cl.titulo || '') + '">' +
        '<button type="button" class="pw-del" title="Remover">×</button>';
      d.querySelector('.pw-del').addEventListener('click', () => d.remove());
      return d;
    }
    function linhaSerie(s) {
      const d = document.createElement('div');
      d.className = 'pw-col-row';
      d.innerHTML = '<select class="pw-s-val"><option value="">— contagem —</option>' +
        H.map(h => '<option value="' + esc(h) + '"' + (h === s.valor ? ' selected' : '') + '>' + esc(h) + '</option>').join('') +
        '</select><select class="pw-s-op">' + OPS.map(o =>
          '<option' + (o === s.op ? ' selected' : '') + '>' + o + '</option>').join('') + '</select>' +
        '<select class="pw-s-tipo"><option value="barra"' + (s.tipo !== 'linha' ? ' selected' : '') + '>barra</option>' +
        '<option value="linha"' + (s.tipo === 'linha' ? ' selected' : '') + '>linha</option></select>' +
        '<select class="pw-s-eixo"><option value="esq"' + (s.eixo !== 'dir' ? ' selected' : '') + '>eixo esq.</option>' +
        '<option value="dir"' + (s.eixo === 'dir' ? ' selected' : '') + '>eixo dir.</option></select>' +
        '<button type="button" class="pw-del" title="Remover">×</button>';
      d.querySelector('.pw-del').addEventListener('click', () => d.remove());
      return d;
    }
    function lerColunas() {
      const out = [];
      document.querySelectorAll('#pw-cols .pw-col-row').forEach(d => {
        out.push({
          valor: d.querySelector('.pw-c-val').value,
          op: d.querySelector('.pw-c-op').value,
          titulo: d.querySelector('.pw-c-tit').value
        });
      });
      return out.filter(x => x.op);
    }
    function lerSeries() {
      const cores = ['#2a5298', '#2a6640', '#e05c3a', '#8a2be2', '#e8a030'];
      const out = [];
      document.querySelectorAll('#pw-series .pw-col-row').forEach((d, i) => {
        out.push({
          valor: d.querySelector('.pw-s-val').value,
          op: d.querySelector('.pw-s-op').value,
          tipo: d.querySelector('.pw-s-tipo').value,
          eixo: d.querySelector('.pw-s-eixo').value,
          cor: cores[i % cores.length]
        });
      });
      return out.filter(x => x.op);
    }
    function atualizarAvisoSeries() {
      const aviso = document.getElementById('pw-aviso-series');
      const sbox = document.getElementById('pw-series');
      if (aviso && sbox) aviso.hidden = !sbox.querySelector('.pw-col-row');
    }

    setTimeout(() => {
      const box = document.getElementById('pw-cols');
      if (box) {
        (c.colunas || []).forEach(cl => box.appendChild(linhaColuna(cl)));
        const b1 = document.getElementById('pw-addcol');
        if (b1) b1.addEventListener('click', () => box.appendChild(linhaColuna({ valor: c.valor, op: 'Soma' })));
      }
      // Trocar o tipo tem que trocar os campos na hora. Se so' mudasse ao
      // reabrir, o usuário escolheria "Pizza" e continuaria vendo "Dividir
      // barras por" logo abaixo.
      const selTipo = document.getElementById('pw-tipo');
      if (selTipo) {
        selTipo.addEventListener('change', () => {
          if (document.getElementById('pw-series')) c.series = lerSeries();
          c.tipo = selTipo.value;
          const g2 = id => { const el = document.getElementById(id); return el ? el.value : undefined; };
          c.titulo = g2('pw-tit') || c.titulo;
          c.grupo = g2('pw-grupo') !== undefined ? g2('pw-grupo') : c.grupo;
          c.valor = g2('pw-valor') !== undefined ? g2('pw-valor') : c.valor;
          c.op = g2('pw-op') !== undefined ? g2('pw-op') : c.op;
          window.closeModal && window.closeModal();
          setTimeout(() => editar(it), 60);
        });
      }

      const sbox = document.getElementById('pw-series');
      if (sbox) {
        (c.series || []).forEach(s => sbox.appendChild(linhaSerie(s)));
        const b2 = document.getElementById('pw-addserie');
        if (b2) b2.addEventListener('click', () => {
          // A PRIMEIRA série extra tem que trazer o gráfico que já estava na
          // tela junto. Antes ela entrava sozinha e os campos de cima paravam
          // de valer — de fora, o desenho original simplesmente sumia e dava
          // lugar ao novo. "Série extra" que apaga o gráfico não é extra.
          // Lê do FORMULÁRIO, não do que estava salvo: o usuário pode ter
          // acabado de trocar a coluna e ainda não ter confirmado. Copiar o
          // valor antigo faria a primeira série nascer diferente do gráfico
          // que ele está vendo na tela.
          const el = id => document.getElementById(id);
          const valorAtual = (el('pw-valor') || {}).value || c.valor || '';
          const opAtual = (el('pw-op') || {}).value || c.op || 'Soma';
          if (!sbox.querySelector('.pw-col-row')) {
            sbox.appendChild(linhaSerie({
              valor: valorAtual, op: opAtual,
              tipo: (c.tipo === 'linha' ? 'linha' : 'barra'), eixo: 'esq'
            }));
          }
          sbox.appendChild(linhaSerie({ valor: valorAtual, op: 'Soma', tipo: 'linha', eixo: 'dir' }));
          atualizarAvisoSeries();
        });
      }
    }, 30);
  }

  /* ── painel automático (um clique monta tudo) ──── */

  // Acha uma coluna pelo nome, ignorando caixa, acento de M³ e o sufixo que o
  // Excel gruda em cabeçalho repetido (".1", ".2").
  function acharCol(f, nomes) {
    const norm = h => String(h || '').trim().toUpperCase().replace(/\.\d+$/, '');
    for (const n of nomes) {
      const achou = f.headers.find(h => norm(h) === n);
      if (achou) return achou;
    }
    return '';
  }

  /* O Naor quer que o Painel substitua o DASHBOARD. Para isso, um clique tem de
   * entregar o painel do laboratório pronto — os mesmos números e os mesmos
   * gráficos que ele já aprovou lá. Montar barra genérica e deixar o resto por
   * conta do usuário não substitui nada: só transfere o trabalho para ele.  */
  function planoLaboratorio(f) {
    const mpa = colunaDeResistencia(f);
    const vol = acharCol(f, ['M³', 'M3', 'VOLUME']);
    const cli = acharCol(f, ['CLIENTE']);
    const prod = acharCol(f, ['PRODUTO', 'RECEITA']);
    const data = acharCol(f, ['DATA']) || (autoMapa(f).data || '');
    // Sem ensaio nem volume não é planilha de usina; cai no painel genérico.
    if (!mpa && !vol) return null;
    return { mpa, vol, cli, prod, data };
  }

  function montarLaboratorio(f, lb) {
    const L = [];
    const add = (type, x, y, w, h, cfg) => L.push({
      id: genId(), type: type, x: x, y: y, w: w, h: h, config: cfg
    });
    const base = () => ({ colData: lb.data, grao: 'mes', topN: 12 });
    const com = extra => Object.assign(base(), extra);

    let y = 0;
    add('dado', 0, y, 240, 120, com({ valor: '', op: 'Contagem', titulo: 'Registros' }));
    if (lb.vol) add('dado', 250, y, 240, 120, com({ valor: lb.vol, op: 'Soma', titulo: 'Volume total (m³)' }));
    if (lb.mpa) add('dado', 500, y, 240, 120,
      com({ valor: lb.mpa, op: 'Média', titulo: 'Média ' + lb.mpa, ensaio: true }));
    if (lb.mpa) add('dado', 750, y, 240, 120,
      com({ valor: lb.mpa, op: 'Desvio padrão', titulo: 'Desvio padrão', ensaio: true }));
    y += 130;

    if (lb.data && lb.vol) {
      add('grafico', 0, y, 740, 300, com({
        tipo: 'barra', grupo: '__periodo__', valor: lb.vol, op: 'Soma',
        titulo: 'Produção e crescimento',
        series: [
          { valor: lb.vol, op: 'Soma', tipo: 'barra', eixo: 'esq', cor: '#2a5298', titulo: 'Produção (m³)' },
          { valor: lb.vol, op: 'Crescimento %', tipo: 'linha', eixo: 'dir', cor: '#2a6640', titulo: 'Crescimento %' }
        ]
      }));
      add('grafico', 750, y, 480, 300, com({
        tipo: 'calor', valor: lb.vol, titulo: 'Mapa de calor — volume por dia'
      }));
      y += 310;
    }

    if (lb.cli && lb.vol) {
      add('grafico', 0, y, 610, 300, com({
        tipo: 'barra', grupo: lb.cli, valor: lb.vol, op: 'Soma', titulo: 'Volume por cliente (m³)'
      }));
    }
    if (lb.prod && lb.vol) {
      add('grafico', 620, y, 610, 300, com({
        tipo: 'barra', grupo: lb.prod, valor: lb.vol, op: 'Soma', titulo: 'Volume por produto (m³)'
      }));
    }
    if ((lb.cli || lb.prod) && lb.vol) y += 310;

    if (lb.mpa) {
      add('distribuicao', 0, y, 740, 400, com({
        valor: lb.mpa, titulo: 'Distribuição da resistência (' + lb.mpa + ')'
      }));
      add('insights', 750, y, 480, 400, com({ valor: lb.vol || lb.mpa, grupo: lb.prod || lb.cli }));
    }
    return L;
  }

  function montarGenerico(f, m) {
    const base = { valor: m.valor || '', grupo: m.cat || '', colData: m.data || '', grao: 'mes', topN: 12 };
    const L = [];
    const add = (type, x, y, w, h, cfg) => {
      const c = {};
      Object.keys(base).forEach(k => { c[k] = base[k]; });
      Object.keys(cfg).forEach(k => { c[k] = cfg[k]; });
      L.push({ id: genId(), type: type, x: x, y: y, w: w, h: h, config: c });
    };

    add('dado', 0, 0, 240, 120, { op: 'Soma', titulo: 'Total' });
    add('dado', 250, 0, 240, 120, { op: 'Média', titulo: 'Média' });
    add('dado', 500, 0, 240, 120, { op: 'Contagem', titulo: 'Registros' });
    if (m.data) add('dado', 750, 0, 240, 120, { op: 'Crescimento %', opBase: 'Soma', titulo: 'Crescimento' });
    add('insights', 0, 130, 740, 200, {});
    if (m.data) {
      add('grafico', 750, 130, 480, 200, { tipo: 'calor', titulo: 'Mapa de calor' });
      add('grafico', 0, 340, 740, 300, {
        tipo: 'barra', grupo: '__periodo__', op: 'Soma', titulo: 'Produção e crescimento',
        series: [
          { valor: m.valor, op: 'Soma', tipo: 'barra', eixo: 'esq', cor: '#2a5298' },
          { valor: m.valor, op: 'Crescimento %', tipo: 'linha', eixo: 'dir', cor: '#2a6640' }
        ]
      });
    }
    if (m.cat) {
      add('grafico', 750, 340, 480, 300, { tipo: 'pizza', op: 'Soma', titulo: 'Distribuição' });
      add('tabela', 0, 650, 740, 320, {
        insights: true, total: true,
        colunas: [
          { valor: m.valor, op: 'Soma' },
          { valor: m.valor, op: '% do total' },
          { valor: m.valor, op: 'Média' }
        ]
      });
    }
    return L;
  }

  function painelAutomatico() {
    const f = dados();
    if (!f) return;
    const lb = planoLaboratorio(f);
    let L, aviso;
    if (lb) {
      L = montarLaboratorio(f, lb);
      aviso = 'Painel do laboratório montado';
    } else {
      const m = autoMapa(f);
      if (!m.valor && !m.cat) {
        if (window.showToast) window.showToast('Não consegui detectar as colunas — adicione widgets manualmente', 'error');
        return;
      }
      L = montarGenerico(f, m);
      aviso = 'Painel montado automaticamente';
    }
    limparFoco();
    state.layouts[state.sheet] = L;
    salvar(); render();
    if (window.showToast) window.showToast(aviso, 'success');
  }

  /* ── init ──────────────────────────────────────── */
  function init() {
    const b = $('pan-auto');
    if (b) b.addEventListener('click', painelAutomatico);
    const r = $('pan-refresh');
    if (r) r.addEventListener('click', render);
    const p = $('pan-present');
    if (p) p.addEventListener('click', () => {
      const m = $('module-painel');
      m.classList.add('ana-presenting');
      (m.requestFullscreen ? m.requestFullscreen() : Promise.reject())
        .catch(() => m.classList.remove('ana-presenting'));
    });
    document.addEventListener('fullscreenchange', () => {
      const m = $('module-painel');
      if (m && !document.fullscreenElement) m.classList.remove('ana-presenting');
    });
    window.addEventListener('concrestats:datachanged', () => {
      const el = $('module-painel');
      if (el && el.style.display !== 'none') setTimeout(render, 60);
    });
    carregar();
  }

  window.PainelModule = {
    onModuleEnter: () => {
      if (!state.carregado) carregar().then(render);
      else render();
    }
  };
  document.addEventListener('DOMContentLoaded', init);
})();
