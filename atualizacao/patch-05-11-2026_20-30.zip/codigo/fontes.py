# -*- coding: utf-8 -*-
"""Fonte avancada: traz dados de uma API ou de um banco, sem passar por planilha.

So' leitura. O programa nunca escreve no sistema do cliente: consulta que nao for
SELECT e' recusada aqui, antes de chegar no banco. Senha nao fica guardada: quem
grava a fonte nas preferencias e' a tela, e ela tira o PWD da conexao antes.
"""
import io
import json
import os
import re
import sqlite3
import urllib.request

import pandas as pd

LIMITE_LINHAS = 200000
LIMITE_BYTES = 80 * 1024 * 1024


def so_leitura(sql):
    limpo = re.sub(r"/\*.*?\*/|--[^\n]*", " ", str(sql or ""), flags=re.S).strip().rstrip(";").strip()
    if not limpo:
        raise ValueError("escreva a consulta")
    if ";" in limpo:
        raise ValueError("uma consulta por vez")
    if not re.match(r"(?i)^(select|with)\b", limpo):
        raise ValueError("só consultas SELECT: o programa não altera o banco")
    if re.search(r"(?i)\b(insert|update|delete|drop|alter|create|truncate|merge|exec|execute|attach|pragma)\b", limpo):
        raise ValueError("só consultas SELECT: o programa não altera o banco")
    return limpo


def _tabela(colunas, linhas):
    nomes, vistos = [], {}
    for i, c in enumerate(colunas):
        c = str(c).strip() or "Coluna %d" % (i + 1)
        n = vistos.get(c, 0)
        vistos[c] = n + 1
        nomes.append(c if not n else "%s.%d" % (c, n))
    return pd.DataFrame(linhas, columns=nomes, dtype=object)


def _de_json(dados):
    """Lista de objetos, ou um objeto com a lista dentro ({"data": [...]})."""
    if isinstance(dados, dict):
        listas = [v for v in dados.values() if isinstance(v, list) and v and isinstance(v[0], dict)]
        if not listas:
            raise ValueError("a resposta não tem uma lista de registros")
        dados = max(listas, key=len)
    if not isinstance(dados, list) or not dados or not isinstance(dados[0], dict):
        raise ValueError("a resposta não tem uma lista de registros")
    colunas = []
    for r in dados[:500]:
        colunas += [k for k in r if k not in colunas]
    return _tabela(colunas, [[r.get(c) for c in colunas] for r in dados[:LIMITE_LINHAS]])


def de_api(url, chave=""):
    if not str(url).lower().startswith(("http://", "https://")):
        raise ValueError("o endereço precisa começar com http:// ou https://")
    pedido = urllib.request.Request(url, headers={"User-Agent": "Concrestats", "Accept": "application/json, text/csv"})
    if chave:
        pedido.add_header("Authorization", "Bearer " + chave)
    with urllib.request.urlopen(pedido, timeout=30) as r:
        bruto = r.read(LIMITE_BYTES + 1)
        tipo = r.headers.get("Content-Type", "")
    if len(bruto) > LIMITE_BYTES:
        raise ValueError("a resposta passou de 80 MB: filtre na própria API")
    if "csv" in tipo or str(url).lower().split("?")[0].endswith(".csv"):
        return pd.read_csv(io.BytesIO(bruto), sep=None, engine="python", dtype=object)
    return _de_json(json.loads(bruto.decode("utf-8-sig")))


def de_sqlite(arquivo, sql):
    if not os.path.exists(arquivo):
        raise ValueError("arquivo não encontrado")
    uri = "file:" + arquivo.replace("\\", "/") + "?mode=ro"
    con = sqlite3.connect(uri, uri=True, timeout=10)
    try:
        cur = con.execute(so_leitura(sql))
        return _tabela([d[0] for d in cur.description], [list(x) for x in cur.fetchmany(LIMITE_LINHAS)])
    finally:
        con.close()


def de_odbc(conexao, sql):
    """SQL Server, MySQL, Postgres, Firebird: o que tiver driver ODBC no Windows.
    Vai pelo .NET que o pywebview ja' carrega: o exe nao traz biblioteca de banco."""
    import clr
    clr.AddReference("System.Data")
    from System import DateTime
    from System.Data.Odbc import OdbcCommand, OdbcConnection
    con = OdbcConnection(str(conexao))
    con.Open()
    try:
        rd = OdbcCommand(so_leitura(sql), con).ExecuteReader()
        colunas = [rd.GetName(i) for i in range(rd.FieldCount)]
        linhas = []
        while rd.Read() and len(linhas) < LIMITE_LINHAS:
            linha = []
            for i in range(rd.FieldCount):
                if rd.IsDBNull(i):
                    linha.append(None)
                    continue
                v = rd.GetValue(i)
                linha.append(v.ToString("yyyy-MM-dd") if isinstance(v, DateTime) else str(v))
            linhas.append(linha)
        return _tabela(colunas, linhas)
    finally:
        con.Close()


def carregar(cfg):
    tipo = cfg.get("tipo")
    if tipo == "api":
        return de_api(cfg.get("url", ""), cfg.get("chave", ""))
    if tipo == "sqlite":
        return de_sqlite(cfg.get("arquivo", ""), cfg.get("consulta", ""))
    if tipo == "odbc":
        return de_odbc(cfg.get("conexao", ""), cfg.get("consulta", ""))
    raise ValueError("escolha o tipo de fonte")
