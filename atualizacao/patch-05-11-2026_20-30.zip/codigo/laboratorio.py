# -*- coding: utf-8 -*-
"""O que laboratorio acreditado cobra do programa.

Tres coisas que andam juntas: quem mudou qual valor e quando (historico), quem
pode liberar relatorio (acessos) e como provar que um laudo nao foi alterado
depois de emitido (emissoes).

Fica em %LOCALAPPDATA%, nao ao lado do exe: o Naor guarda varias versoes lado a
lado dentro do OneDrive, e registro de auditoria nao pode sumir junto com uma
pasta antiga nem ficar se regravando em pasta sincronizada.
"""
import getpass
import hashlib
import hmac
import json
import os
import secrets
import threading
import time
from collections import Counter

LIMITE_POR_GRAVACAO = 300
_trava = threading.Lock()
_atual = {"nome": None, "funcao": None}


def pasta():
    p = os.environ.get("CONCRE_LAB_DIR")
    if not p:
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
        p = os.path.join(base, "Concrestats", "laboratorio")
    os.makedirs(p, exist_ok=True)
    return p


def _agora():
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def quem():
    """Nome de quem esta' usando: o do login, ou o usuario do Windows."""
    if _atual["nome"]:
        return _atual["nome"]
    try:
        return getpass.getuser()
    except Exception:  # noqa: BLE001 -- sem nome nao e' motivo para perder o registro
        return "?"


# -- historico ---------------------------------------------------------------
def _txt(v):
    return "" if v is None else str(v)


def _coluna_de_id(headers):
    for i, h in enumerate(headers):
        n = str(h).strip().upper()
        if n == "CP" or n.startswith("CORPO DE PROVA") or n == "AMOSTRA":
            return i
    return 0 if headers else -1


def diferencas(h0, d0, h1, d1):
    """O que mudou entre duas fotos da aba, em linhas de historico.

    Vem do servidor de proposito: toda alteracao passa pelo save_data, seja
    celula, colar, excluir, desfazer ou localizar e substituir. Marcar na tela
    deixaria sempre um caminho de fora, e historico com buraco nao serve para
    quem audita.
    """
    h0, h1 = [str(h) for h in h0 or []], [str(h) for h in h1 or []]
    saida = []
    for nome in h0:
        if nome not in h1:
            saida.append({"tipo": "coluna", "col": nome, "antes": nome, "depois": ""})
    for nome in h1:
        if nome not in h0:
            saida.append({"tipo": "coluna", "col": nome, "antes": "", "depois": nome})
    comuns = [h for h in h1 if h in h0]
    if not comuns:
        return saida
    i0, i1 = [h0.index(h) for h in comuns], [h1.index(h) for h in comuns]

    def foto(linhas, idx):
        return [tuple(_txt(x[i]) if i < len(x) else "" for i in idx) for x in linhas or []]

    a, b = foto(d0, i0), foto(d1, i1)
    if a == b:
        return saida
    ca, cb = Counter(a), Counter(b)
    if ca == cb:
        saida.append({"tipo": "ordem"})
        return saida
    sobra, saiu = Counter(cb), []
    for i, x in enumerate(a):
        if sobra[x] > 0:
            sobra[x] -= 1
        else:
            saiu.append(i)
    sobra, entrou = Counter(ca), []
    for i, x in enumerate(b):
        if sobra[x] > 0:
            sobra[x] -= 1
        else:
            entrou.append(i)

    ic = _coluna_de_id(comuns)

    def ident(linha, n):
        v = linha[ic] if ic >= 0 else ""
        return ("%s %s" % (comuns[ic], v)) if v else "linha %d" % (n + 1)

    livres = list(entrou)
    for i in saiu:
        par = None
        for j in livres:
            iguais = sum(1 for p, q in zip(a[i], b[j]) if p == q)
            if iguais * 2 >= len(comuns):
                par = j
                break
        if par is None:
            saida.append({"tipo": "linha-", "id": ident(a[i], i), "linha": i + 1,
                          "antes": " | ".join(a[i])[:200], "depois": ""})
            continue
        livres.remove(par)
        for c, (p, q) in enumerate(zip(a[i], b[par])):
            if p != q:
                saida.append({"tipo": "celula", "id": ident(b[par], par), "linha": par + 1,
                              "col": comuns[c], "antes": p, "depois": q})
    for j in livres:
        saida.append({"tipo": "linha+", "id": ident(b[j], j), "linha": j + 1,
                      "antes": "", "depois": " | ".join(b[j])[:200]})
    return saida


def _arquivo_do_historico(caminho):
    marca = hashlib.sha1(os.path.normcase(caminho or "sem_arquivo").encode("utf-8")).hexdigest()[:12]
    return os.path.join(pasta(), "historico-%s.jsonl" % marca)


def _hash(anterior, entrada):
    corpo = json.dumps({k: v for k, v in entrada.items() if k != "h"}, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256((anterior + corpo).encode("utf-8")).hexdigest()[:24]


def _ultimo_hash(arq):
    try:
        with open(arq, "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 8192))
            fim = f.read().decode("utf-8", "ignore").strip().split("\n")[-1]
        return json.loads(fim).get("h", "")
    except (OSError, ValueError, IndexError):
        return ""


def registrar(caminho, aba, mudancas):
    """Acrescenta ao historico, encadeado: cada linha carrega o hash da anterior,
    e apagar ou trocar uma linha do arquivo quebra a corrente."""
    if not mudancas:
        return 0
    arq = _arquivo_do_historico(caminho)
    fora = max(0, len(mudancas) - LIMITE_POR_GRAVACAO)
    lista = mudancas[:LIMITE_POR_GRAVACAO]
    if fora:
        lista = lista + [{"tipo": "resumo", "depois": "e mais %d alterações nesta gravação" % fora}]
    with _trava:
        ant = _ultimo_hash(arq)
        with open(arq, "a", encoding="utf-8") as f:
            for m in lista:
                e = dict(m, t=_agora(), quem=quem(), aba=aba, arq=os.path.basename(caminho or ""))
                e["h"] = ant = _hash(ant, e)
                f.write(json.dumps(e, ensure_ascii=False) + "\n")
    return len(lista)


def ler(caminho, limite=500, busca=""):
    arq = _arquivo_do_historico(caminho)
    linhas, integro, ant = [], True, ""
    try:
        with open(arq, encoding="utf-8") as f:
            for bruto in f:
                try:
                    e = json.loads(bruto)
                except ValueError:
                    integro = False
                    continue
                if _hash(ant, e) != e.get("h"):
                    integro = False
                ant = e.get("h", "")
                linhas.append(e)
    except OSError:
        return {"itens": [], "total": 0, "integro": True}
    if busca:
        b = busca.lower()
        linhas = [e for e in linhas if b in json.dumps(e, ensure_ascii=False).lower()]
    return {"itens": linhas[::-1][:limite], "total": len(linhas), "integro": integro}


# -- acessos -----------------------------------------------------------------
FUNCOES = ("responsavel", "operador")


def _arq_acessos():
    return os.path.join(pasta(), "acessos.json")


def _ler_acessos():
    try:
        with open(_arq_acessos(), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _gravar_acessos(d):
    tmp = _arq_acessos() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)
    os.replace(tmp, _arq_acessos())


def _hash_pin(pin, sal):
    return hashlib.pbkdf2_hmac("sha256", str(pin).encode("utf-8"), bytes.fromhex(sal), 120000).hex()


def acessos():
    d = _ler_acessos()
    return {"ligado": bool(d.get("ligado")),
            "usuarios": [{"nome": u["nome"], "funcao": u["funcao"]} for u in d.get("usuarios", [])],
            "atual": dict(_atual) if _atual["nome"] else None}


def entrar(nome, pin):
    d = _ler_acessos()
    for u in d.get("usuarios", []):
        if u["nome"] == nome and hmac.compare_digest(_hash_pin(pin, u["sal"]), u["pin"]):
            _atual.update(nome=u["nome"], funcao=u["funcao"])
            return True
    return False


def sair():
    _atual.update(nome=None, funcao=None)


def pode_liberar():
    """Sem o controle ligado, todo mundo libera, como sempre foi."""
    return not _ler_acessos().get("ligado") or _atual["funcao"] == "responsavel"


def pode_gerir(d=None):
    d = d if d is not None else _ler_acessos()
    return not d.get("ligado") or _atual["funcao"] == "responsavel"


def salvar_usuario(nome, funcao, pin):
    if funcao not in FUNCOES or not str(nome).strip() or len(str(pin)) < 4:
        return "nome, função e PIN de 4 dígitos ou mais"
    d = _ler_acessos()
    if not pode_gerir(d):
        return "só o responsável mexe nos acessos"
    nome = str(nome).strip()
    usuarios = [u for u in d.get("usuarios", []) if u["nome"] != nome]
    sal = secrets.token_hex(16)
    usuarios.append({"nome": nome, "funcao": funcao, "sal": sal, "pin": _hash_pin(pin, sal)})
    d["usuarios"] = usuarios
    _gravar_acessos(d)
    return ""


def apagar_usuario(nome):
    d = _ler_acessos()
    if not pode_gerir(d):
        return "só o responsável mexe nos acessos"
    resto = [u for u in d.get("usuarios", []) if u["nome"] != nome]
    if d.get("ligado") and not any(u["funcao"] == "responsavel" for u in resto):
        return "precisa sobrar um responsável"
    d["usuarios"] = resto
    _gravar_acessos(d)
    return ""


def ligar_acessos(ligado):
    d = _ler_acessos()
    if not pode_gerir(d):
        return "só o responsável mexe nos acessos"
    if ligado and not any(u["funcao"] == "responsavel" for u in d.get("usuarios", [])):
        return "cadastre um responsável antes de ligar"
    d["ligado"] = bool(ligado)
    _gravar_acessos(d)
    return ""


# -- emissoes ----------------------------------------------------------------
def _segredo():
    arq = os.path.join(pasta(), "emissao.key")
    with _trava:
        try:
            with open(arq, encoding="ascii") as f:
                s = f.read().strip()
            if s:
                return s
        except OSError:
            pass
        s = secrets.token_hex(32)
        with open(arq, "w", encoding="ascii") as f:
            f.write(s)
    return s


def _arq_emissoes():
    return os.path.join(pasta(), "emissoes.jsonl")


def _emissoes():
    itens = []
    try:
        with open(_arq_emissoes(), encoding="utf-8") as f:
            for bruto in f:
                try:
                    itens.append(json.loads(bruto))
                except ValueError:
                    continue
    except OSError:
        pass
    return itens


def _codigo(texto):
    """Oito letras faceis de ditar por telefone: sem 0, O, 1, I."""
    d = hmac.new(_segredo().encode("ascii"), texto.encode("utf-8"), hashlib.sha256).digest()
    letras = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    s = "".join(letras[b % 32] for b in d[:8])
    return s[:4] + "-" + s[4:]


def emitir(titulo, resumo):
    """Registra o relatorio e devolve o texto que vai no QR.

    O QR leva o proprio resumo em texto. Quem recebe o laudo aponta o celular e
    le os numeros sem instalar nada e sem internet: se o PDF foi editado, os
    numeros do papel nao batem com os do QR. O codigo so' o laboratorio consegue
    gerar, e e' ele que confere no botao Conferir relatorio.
    """
    if not pode_liberar():
        return None
    resumo = {str(k): _txt(v)[:120] for k, v in (resumo or {}).items()}
    # Imprimir duas vezes o mesmo relatorio nao emite dois laudos.
    igual = json.dumps({"titulo": titulo, "resumo": resumo}, sort_keys=True, ensure_ascii=False)
    for e in _emissoes():
        if e.get("igual") == igual and e.get("quem") == quem():
            return dict(e, texto_qr=_texto_do_qr(e))
    ano = time.strftime("%Y")
    n = sum(1 for e in _emissoes() if "codigo" in e and str(e.get("id", "")).startswith(ano)) + 1
    ident = "%s-%05d" % (ano, n)
    corpo = json.dumps({"id": ident, "titulo": titulo, "resumo": resumo}, sort_keys=True, ensure_ascii=False)
    e = {"id": ident, "t": _agora(), "quem": quem(), "titulo": str(titulo)[:120], "resumo": resumo,
         "codigo": _codigo(corpo), "igual": igual}
    with _trava:
        with open(_arq_emissoes(), "a", encoding="utf-8") as f:
            f.write(json.dumps(e, ensure_ascii=False) + "\n")
    e["texto_qr"] = _texto_do_qr(e)
    return e


def _texto_do_qr(e):
    linhas = ["Concrestats - relatório %s" % e["id"], e["titulo"]]
    linhas += ["%s: %s" % (k, v) for k, v in e["resumo"].items() if v]
    linhas += ["Emitido por %s em %s" % (e["quem"], e["t"][:10]), "Código %s" % e["codigo"]]
    return "\n".join(linhas)


def anexar_arquivo(ident, caminho):
    """Guarda o hash do PDF pronto. E' ele que pega qualquer alteracao."""
    with open(caminho, "rb") as f:
        h = hashlib.sha256(f.read()).hexdigest()
    with _trava:
        with open(_arq_emissoes(), "a", encoding="utf-8") as f:
            f.write(json.dumps({"id": ident, "sha256": h, "t": _agora(), "evento": "pdf"}, ensure_ascii=False) + "\n")
    return h


def _publico(e):
    return {k: e.get(k) for k in ("id", "t", "quem", "titulo", "resumo", "codigo")} if e else None


def conferir(codigo="", conteudo=None):
    """Por codigo devolve o que foi emitido; por arquivo diz se e' igual ao emitido."""
    itens = _emissoes()
    base = {e["id"]: e for e in itens if "codigo" in e}
    if conteudo is not None:
        h = hashlib.sha256(conteudo).hexdigest()
        achado = next((e for e in itens if e.get("sha256") == h), None)
        if achado:
            return {"ok": True, "emissao": _publico(base.get(achado["id"]))}
        return {"ok": False, "motivo": "este arquivo não é igual a nenhum relatório emitido aqui: foi alterado ou veio de outro lugar"}
    alvo = str(codigo).strip().upper()
    achado = next((e for e in base.values() if e["codigo"] == alvo or e["id"].upper() == alvo), None)
    if achado:
        return {"ok": True, "emissao": _publico(achado)}
    return {"ok": False, "motivo": "código não encontrado neste computador"}


def ultimas_emissoes(limite=100):
    return [_publico(e) for e in _emissoes() if "codigo" in e][::-1][:limite]


# -- PDF ---------------------------------------------------------------------
_fontes = {}


def fonte_do_pdf(token):
    return _fontes.get(token)


def _pdf_webview(url, caminho):
    """Imprime por uma janela escondida do proprio WebView2: e' o unico navegador
    que o programa tem certeza de ter, e assim o PDF sai igual ao da impressao."""
    import webview
    from System import Action
    from System.Threading.Tasks import TaskStatus  # noqa: F401 -- carrega o tipo no pythonnet
    w = webview.create_window("Concrestats PDF", url=url, hidden=True)
    try:
        if not w.events.loaded.wait(40):
            raise RuntimeError("a pagina do relatorio nao carregou")
        try:
            w.evaluate_js("window.__ajustar && window.__ajustar()")
        except Exception:  # noqa: BLE001 -- sem ajuste, imprime igual
            pass
        wv, res, pronto = w.native.webview, {}, threading.Event()

        def na_tela():
            core = wv.CoreWebView2
            cfg = core.Environment.CreatePrintSettings()
            cfg.ShouldPrintBackgrounds = True
            cfg.ShouldPrintHeaderAndFooter = False
            cfg.PageWidth, cfg.PageHeight = 11.69, 8.27          # A4 deitado
            cfg.MarginTop = cfg.MarginBottom = cfg.MarginLeft = cfg.MarginRight = 0
            res["tarefa"] = core.PrintToPdfAsync(caminho, cfg)
            pronto.set()

        wv.Invoke(Action(na_tela))
        pronto.wait(15)
        tarefa, fim = res["tarefa"], time.time() + 180
        while not tarefa.IsCompleted and time.time() < fim:
            time.sleep(0.1)
        if not tarefa.IsCompleted or not tarefa.Result:
            raise RuntimeError("o WebView2 nao conseguiu gerar o PDF")
    finally:
        w.destroy()


def _pdf_edge(url, caminho):
    """Sem janela aberta (servidor de teste): Edge sem tela, que todo Windows traz."""
    import subprocess
    base = [os.environ.get("ProgramFiles(x86)", ""), os.environ.get("ProgramFiles", "")]
    edge = next((p for p in (os.path.join(b, "Microsoft", "Edge", "Application", "msedge.exe") for b in base)
                 if os.path.exists(p)), None)
    if not edge:
        raise RuntimeError("não achei o Edge para gerar o PDF")
    perfil = os.path.join(pasta(), "perfil_pdf")
    subprocess.run([edge, "--headless=new", "--disable-gpu", "--no-pdf-header-footer", "--user-data-dir=" + perfil,
                    "--print-to-pdf=" + caminho, url], timeout=180, creationflags=0x08000000,
                   stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    if not os.path.exists(caminho):
        raise RuntimeError("o Edge não gerou o PDF")


def gerar_pdf(html, caminho, base_url):
    token = secrets.token_urlsafe(16)
    _fontes[token] = html
    url = base_url.rstrip("/") + "/api/pdf_fonte/" + token
    try:
        try:
            import webview
            comjanela = bool(webview.windows)
        except ImportError:
            comjanela = False
        (_pdf_webview if comjanela else _pdf_edge)(url, caminho)
    finally:
        _fontes.pop(token, None)
    return caminho


def pasta_de_relatorios():
    p = os.environ.get("CONCRE_RELATORIOS") or os.path.join(os.path.expanduser("~"), "Documents", "Concrestats", "Relatorios")
    os.makedirs(p, exist_ok=True)
    return p
