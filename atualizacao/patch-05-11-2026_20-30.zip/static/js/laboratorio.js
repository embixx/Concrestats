/*
 * laboratorio.js - historico de alteracoes, acesso por funcao e conferencia de
 * relatorio. O servidor (laboratorio.py) guarda; aqui ficam as telas.
 * Tudo so' aparece com a previa: botoes ficam com data-previa no index.html.
 */
(function () {
  'use strict';

  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const aviso = (m, t) => { if (typeof toast === 'function') toast(m, t || ''); };
  const postar = (url, corpo) => fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(corpo || {}) }).then(r => r.json());
  const fecharModal = () => { if (window.closeModal) window.closeModal(); };
  const NOME_DA_FUNCAO = { responsavel: 'Responsável', operador: 'Operador' };
  // Janela que so' mostra: um botao Fechar basta, Cancelar ali nao cancela nada.
  const soFechar = () => {
    const ok = $('modal-confirm');
    if (ok) ok.textContent = 'Fechar';
    document.querySelectorAll('#modal-content .modal-footer .secondary-btn').forEach(b => { b.style.display = 'none'; });
  };

  let acesso = { ligado: false, usuarios: [], atual: null };

  /* -- historico ---------------------------------------------------------- */
  const ACAO = { celula: 'Alterou', 'linha+': 'Incluiu linha', 'linha-': 'Apagou linha', coluna: 'Coluna', ordem: 'Reordenou', resumo: '' };
  const quando = t => {
    const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(t || '');
    return m ? m[3] + '/' + m[2] + '/' + m[1] + ' ' + m[4] + ':' + m[5] : '';
  };

  async function lerHistorico(busca) {
    const sid = typeof SESSION_ID !== 'undefined' ? SESSION_ID : 'default';
    const q = '/api/historico?limite=1000&session_id=' + encodeURIComponent(sid) + '&busca=' + encodeURIComponent(busca || '');
    return fetch(q).then(r => r.json());
  }

  function tabelaDoHistorico(r) {
    if (!r.itens.length) return '<p class="rc-dica">Nenhuma alteração registrada para esta planilha.</p>';
    const linhas = r.itens.map(e => '<tr><td>' + esc(quando(e.t)) + '</td><td>' + esc(e.quem) + '</td><td>' + esc(e.aba) + '</td>' +
      '<td>' + esc(ACAO[e.tipo] != null ? ACAO[e.tipo] : e.tipo) + '</td><td>' + esc(e.id || '') + (e.col ? ' · ' + esc(e.col) : '') + '</td>' +
      '<td class="lab-antes">' + esc(e.antes) + '</td><td class="lab-depois">' + esc(e.depois) + '</td></tr>').join('');
    return (r.integro ? '' : '<p class="lab-alerta">O arquivo do histórico foi mexido fora do programa: a sequência de registros não confere.</p>') +
      '<p class="rc-dica">' + r.total.toLocaleString('pt-BR') + ' registro(s)' + (r.total > r.itens.length ? ', mostrando os ' + r.itens.length + ' mais recentes' : '') + '.</p>' +
      '<div class="lab-tabela"><table><thead><tr><th>Quando</th><th>Quem</th><th>Aba</th><th>O quê</th><th>Onde</th><th>Antes</th><th>Depois</th></tr></thead><tbody>' +
      linhas + '</tbody></table></div>';
  }

  async function abrirHistorico() {
    if (!window.openModal) return;
    window.openModal('Histórico de alterações',
      '<div class="lab-barra"><input id="lab-busca" class="rec-search-input" placeholder="Buscar CP, coluna, valor ou pessoa...">' +
      '<button type="button" class="secondary-btn" id="lab-hist-excel">Exportar para Excel</button></div><div id="lab-hist"></div>',
      fecharModal, 'modal-laboratorio');
    soFechar();
    let ultimo = null;
    const mostrar = async () => {
      ultimo = await lerHistorico(($('lab-busca') || {}).value || '');
      const caixa = $('lab-hist');
      if (caixa) caixa.innerHTML = tabelaDoHistorico(ultimo);
    };
    let espera = null;
    $('lab-busca').addEventListener('input', () => { clearTimeout(espera); espera = setTimeout(mostrar, 250); });
    $('lab-hist-excel').addEventListener('click', async () => {
      const aoa = [['Quando', 'Quem', 'Aba', 'O quê', 'Onde', 'Coluna', 'Antes', 'Depois']];
      (ultimo ? ultimo.itens : []).forEach(e => aoa.push([quando(e.t), e.quem, e.aba, ACAO[e.tipo] || '', e.id || '', e.col || '', e.antes || '', e.depois || '']));
      exportar(aoa, 'historico_de_alteracoes', 'Histórico');
    });
    await mostrar();
  }

  async function exportar(aoa, base, aba) {
    try {
      let caminho = null;
      if (window.pywebview && window.pywebview.api && window.pywebview.api.save_file_dialog) {
        caminho = await window.pywebview.api.save_file_dialog(base + '.xlsx');
        if (!caminho) return;
      }
      const r = await fetch('/api/export_aoa', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ aoa, path: caminho, sheet_name: aba, base_name: base }) });
      if ((r.headers.get('content-type') || '').includes('json')) {
        const j = await r.json();
        aviso(j.success ? 'Exportado' : (j.error || 'Não consegui exportar'), j.success ? 'success' : 'error');
        return;
      }
      const a = document.createElement('a');
      a.href = URL.createObjectURL(await r.blob());
      a.download = base + '.xlsx'; a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    } catch (e) { aviso('Não consegui exportar', 'error'); }
  }

  /* -- acesso por funcao -------------------------------------------------- */
  function aplicarFuncao() {
    const a = acesso.ligado ? acesso.atual : null;
    document.documentElement.dataset.funcao = a ? a.funcao : '';
    let chip = $('lab-usuario');
    if (!a) { if (chip) chip.remove(); return; }
    if (!chip) {
      chip = document.createElement('div');
      chip.id = 'lab-usuario';
      document.body.appendChild(chip);
    }
    chip.innerHTML = '<span>' + esc(a.nome) + ' · ' + esc(NOME_DA_FUNCAO[a.funcao] || '') + '</span><button type="button" id="lab-sair">Sair</button>';
    $('lab-sair').addEventListener('click', async () => {
      await postar('/api/acessos/sair');
      acesso.atual = null;
      aplicarFuncao();
      mostrarLogin();
    });
  }

  function mostrarLogin() {
    if ($('lab-login')) return;
    const o = document.createElement('div');
    o.id = 'lab-login';
    let escolhido = acesso.usuarios[0] ? acesso.usuarios[0].nome : '';
    o.innerHTML = '<div class="lab-login-caixa"><h2>Quem está usando?</h2><div class="lab-pessoas">' +
      acesso.usuarios.map(u => '<button type="button" data-nome="' + esc(u.nome) + '"><b>' + esc(u.nome) + '</b><small>' +
        esc(NOME_DA_FUNCAO[u.funcao] || '') + '</small></button>').join('') + '</div>' +
      '<input type="password" id="lab-pin" inputmode="numeric" autocomplete="off" placeholder="PIN" aria-label="PIN">' +
      '<button type="button" class="primary-btn" id="lab-entrar">Entrar</button><p id="lab-erro" role="alert"></p></div>';
    document.body.appendChild(o);
    const marcar = () => o.querySelectorAll('.lab-pessoas button').forEach(b => b.classList.toggle('ativo', b.dataset.nome === escolhido));
    o.querySelectorAll('.lab-pessoas button').forEach(b => b.addEventListener('click', () => {
      escolhido = b.dataset.nome; marcar(); $('lab-pin').focus();
    }));
    marcar();
    const entrar = async () => {
      const r = await postar('/api/acessos/entrar', { nome: escolhido, pin: $('lab-pin').value });
      if (!r.success) { $('lab-erro').textContent = r.error || 'Não deu certo'; $('lab-pin').select(); return; }
      acesso.atual = r.atual;
      o.remove();
      aplicarFuncao();
    };
    $('lab-entrar').addEventListener('click', entrar);
    $('lab-pin').addEventListener('keydown', e => { if (e.key === 'Enter') entrar(); });
    $('lab-pin').focus();
  }

  async function carregarAcessos() {
    try {
      acesso = await fetch('/api/acessos').then(r => r.json());
    } catch (e) { return; }
    if (acesso.ligado && !acesso.atual) mostrarLogin();
    aplicarFuncao();
  }

  function caixaDeUsuarios() {
    const lista = acesso.usuarios.length
      ? acesso.usuarios.map(u => '<li><b>' + esc(u.nome) + '</b> <span>' + esc(NOME_DA_FUNCAO[u.funcao] || '') + '</span>' +
          '<button type="button" class="secondary-btn lab-tirar" data-nome="' + esc(u.nome) + '">Tirar</button></li>').join('')
      : '<li class="rc-dica">Nenhuma pessoa cadastrada.</li>';
    return '<ul class="lab-usuarios">' + lista + '</ul>';
  }

  function abrirAcessos() {
    if (!window.openModal) return;
    window.openModal('Acesso por função',
      '<p class="col-intro">O operador lança os resultados; só o responsável libera o relatório (imprimir, PDF, Excel e mandar para o cliente) e mexe nos acessos. ' +
      'Esqueceu o PIN de todos os responsáveis? Apague o arquivo acessos.json da pasta Concrestats, em AppData, Local, laboratorio.</p>' +
      '<label class="pw-check"><input type="checkbox" id="lab-ligado"' + (acesso.ligado ? ' checked' : '') + '> Pedir login ao abrir o programa</label>' +
      '<div id="lab-lista">' + caixaDeUsuarios() + '</div>' +
      '<div class="lab-novo"><input id="lab-nome" placeholder="Nome"><select id="lab-funcao"><option value="responsavel">Responsável</option>' +
      '<option value="operador">Operador</option></select><input id="lab-novo-pin" type="password" inputmode="numeric" placeholder="PIN (4 ou mais)">' +
      '<button type="button" class="secondary-btn" id="lab-add">Adicionar</button></div><p id="lab-msg" class="rc-dica"></p>',
      fecharModal, 'modal-laboratorio');
    soFechar();
    const ligarTirar = () => document.querySelectorAll('.lab-tirar').forEach(b => b.addEventListener('click', async () => {
      atualizar(await postar('/api/acessos/apagar', { nome: b.dataset.nome }));
    }));
    const atualizar = async r => {
      if (r && !r.success) { $('lab-msg').textContent = r.error || 'Não deu certo'; return; }
      $('lab-msg').textContent = '';
      acesso = await fetch('/api/acessos').then(x => x.json());
      $('lab-lista').innerHTML = caixaDeUsuarios();
      ligarTirar();
      aplicarFuncao();
    };
    ligarTirar();
    $('lab-add').addEventListener('click', async () => {
      const r = await postar('/api/acessos/usuario', { nome: $('lab-nome').value, funcao: $('lab-funcao').value, pin: $('lab-novo-pin').value });
      if (r.success) { $('lab-nome').value = ''; $('lab-novo-pin').value = ''; }
      atualizar(r);
    });
    $('lab-ligado').addEventListener('change', async e => {
      const r = await postar('/api/acessos/ligar', { ligado: e.target.checked });
      if (!r.success) e.target.checked = !e.target.checked;
      atualizar(r);
    });
  }

  const podeLiberar = () => !acesso.ligado || !!(acesso.atual && acesso.atual.funcao === 'responsavel');

  /* -- conferir relatorio ------------------------------------------------- */
  function resultadoDaConferencia(r) {
    if (!r.ok) return '<p class="lab-nao">Não confere: ' + esc(r.motivo) + '.</p>';
    const e = r.emissao, resumo = Object.keys(e.resumo || {}).map(k => '<li>' + esc(k) + ': <b>' + esc(e.resumo[k]) + '</b></li>').join('');
    return '<p class="lab-sim">Confere: relatório ' + esc(e.id) + ', emitido por ' + esc(e.quem) + ' em ' + esc(quando(e.t)) + '.</p>' +
      '<p class="rc-dica">' + esc(e.titulo) + '</p><ul class="lab-resumo">' + resumo + '</ul>';
  }

  function conferirRelatorio() {
    if (!window.openModal) return;
    window.openModal('Conferir relatório',
      '<p class="col-intro">Com o PDF, o programa diz se o arquivo é exatamente o que foi emitido aqui. Só com o código impresso, mostra os números daquela emissão para comparar com o papel.</p>' +
      '<label for="cf-arq">Arquivo PDF</label><input type="file" id="cf-arq" accept=".pdf">' +
      '<label for="cf-cod">ou código do relatório</label><input id="cf-cod" placeholder="ABCD-EFGH ou 2026-00001">' +
      '<div id="cf-res"></div>', async () => {
        const arq = $('cf-arq').files[0], cod = $('cf-cod').value.trim();
        if (!arq && !cod) { $('cf-res').innerHTML = '<p class="lab-nao">Escolha um PDF ou digite o código.</p>'; return; }
        let r;
        if (arq) {
          const f = new FormData(); f.append('arquivo', arq);
          r = await fetch('/api/emissao/conferir', { method: 'POST', body: f }).then(x => x.json());
        } else r = await postar('/api/emissao/conferir', { codigo: cod });
        $('cf-res').innerHTML = resultadoDaConferencia(r);
      }, 'modal-laboratorio');
    const ok = $('modal-confirm'); if (ok) ok.textContent = 'Conferir';
  }

  window.ConcreLaboratorio = { abrirHistorico, abrirAcessos, conferirRelatorio, podeLiberar, postar, exportar,
                               usuario: () => acesso.atual, carregarAcessos };

  function iniciar() {
    if (!window.ConcrePrevia) return;
    window.ConcrePrevia.then(ligada => {
      if (!ligada) return;
      carregarAcessos();
      const b = $('btn-historico');
      if (b) b.addEventListener('click', abrirHistorico);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
  else iniciar();
})();
