/*
 * guia.js - primeira abertura guiada (item 5 da lista do Naor).
 *
 * Empresa nova abre a planilha, confirma as colunas, preenche os dados e ja' tira
 * o primeiro relatorio. Nao e' tour de setinhas: e' uma lista no canto que se marca
 * sozinha conforme a pessoa faz, e nao impede de usar o programa por baixo.
 */
(function () {
  'use strict';

  const CHAVE = 'concre_guia';
  const $ = id => document.getElementById(id);
  const ler = () => { try { return JSON.parse(localStorage.getItem(CHAVE) || '{}'); } catch (e) { return {}; } };
  const gravar = g => {
    try { localStorage.setItem(CHAVE, JSON.stringify(g)); } catch (e) { /* so' nesta abertura */ }
    fetch('/api/prefs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ guia: g }) }).catch(() => {});
  };
  const temPlanilha = () => {
    const d = window.getConcrestatsData ? window.getConcrestatsData({ filtered: false }) : null;
    return !!(d && d.headers && d.headers.length);
  };
  const temEmpresa = async () => {
    const R = window.RelatorioModule;
    if (!R || !R._marcaDaEmpresa) return false;
    return !!(await R._marcaDaEmpresa()).nome;
  };

  const PASSOS = [
    { id: 'planilha', nome: 'Abra a sua planilha de rompimentos', botao: 'Abrir',
      acao: () => { const b = $('btn-upload'); if (b) b.click(); }, feito: async () => temPlanilha() },
    { id: 'colunas', nome: 'Confira se o programa entendeu as colunas', botao: 'Conferir',
      acao: g => { if (window.ConcreColunas) window.ConcreColunas.abrir(); g.colunas = true; gravar(g); }, feito: async g => !!g.colunas },
    { id: 'empresa', nome: 'Preencha os dados da empresa', botao: 'Preencher',
      acao: () => { window.ConcrestatsOpenModule('relatorio'); setTimeout(() => { const b = $('rep-fixos'); if (b) b.click(); }, 300); }, feito: temEmpresa },
    { id: 'relatorio', nome: 'Tire o primeiro relatório', botao: 'Ver relatório',
      acao: () => window.ConcrestatsOpenModule('relatorio'), feito: async g => !!g.relatorio },
  ];

  async function desenhar() {
    const caixa = $('guia');
    if (!caixa) return;
    const g = ler();
    const feitos = await Promise.all(PASSOS.map(p => p.feito(g)));
    const proximo = feitos.indexOf(false);
    caixa.innerHTML = '<div class="guia-topo"><b>Primeiros passos</b><span>' + feitos.filter(Boolean).length + ' de ' + PASSOS.length + '</span>' +
      '<button type="button" id="guia-fechar" aria-label="Fechar" title="Fechar">×</button></div><ol>' +
      PASSOS.map((p, i) => '<li class="' + (feitos[i] ? 'feito' : i === proximo ? 'agora' : '') + '"><span>' + p.nome + '</span>' +
        (feitos[i] ? '' : '<button type="button" class="secondary-btn" data-passo="' + i + '">' + p.botao + '</button>') + '</li>').join('') + '</ol>' +
      (proximo < 0 ? '<p>Pronto. Para abrir esta lista de novo: engrenagem, Primeiros passos.</p>' : '');
    $('guia-fechar').addEventListener('click', () => fechar(true));
    caixa.querySelectorAll('[data-passo]').forEach(b => b.addEventListener('click', () => {
      PASSOS[+b.dataset.passo].acao(ler());
      setTimeout(desenhar, 400);
    }));
  }

  function abrir() {
    if (!$('guia')) {
      const c = document.createElement('aside');
      c.id = 'guia';
      c.setAttribute('aria-label', 'Primeiros passos');
      document.body.appendChild(c);
    }
    desenhar();
  }

  function fechar(marcar) {
    const c = $('guia');
    if (c) c.remove();
    if (marcar) { const g = ler(); g.fim = true; gravar(g); }
  }

  function iniciar() {
    if (!window.ConcrePrevia) return;
    window.ConcrePrevia.then(async ligada => {
      if (!ligada) return;
      window.addEventListener('concrestats:datachanged', desenhar);
      ['rep-imprimir', 'rep-export-xlsx', 'rep-export-html'].forEach(id => {
        const b = $(id);
        if (b) b.addEventListener('click', () => { const g = ler(); g.relatorio = true; gravar(g); desenhar(); });
      });
      const g = ler();
      if (g.fim) return;
      // Quem ja' usa o programa nao precisa disso na cara: so' aparece sozinho em
      // instalacao nova. A engrenagem abre para todo mundo.
      const p = window.prefsGet ? await window.prefsGet().catch(() => null) : null;
      if (p && p.guia && p.guia.fim) return;
      if (temPlanilha() || (p && ((p.recentes || []).length || p.ensaio_fixos))) return;
      abrir();
    });
  }

  function marcarRelatorio() { const g = ler(); g.relatorio = true; gravar(g); desenhar(); }

  window.ConcreGuia = { abrir, fechar, PASSOS, marcarRelatorio };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
  else iniciar();
})();
