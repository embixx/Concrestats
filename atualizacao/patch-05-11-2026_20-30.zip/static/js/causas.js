/*
 * causas.js - "Por que deu baixo" (item 16 da lista do Naor).
 *
 * Duas perguntas, nessa ordem:
 *  1. Cada ensaio que nao chegou no fck: o que os dados dizem sobre ele? O 7 dias
 *     ja' vinha fraco, os dois CPs brigam entre si, a semana inteira foi ruim, a
 *     versao nao tem folga. Sao sinais que a planilha ja' traz.
 *  2. O que anda junto com resultado baixo na planilha inteira? Abatimento,
 *     temperatura, tempo de viagem, quando existem; volume da carga, dia da
 *     moldagem e idade real do rompimento sempre que der.
 *
 * Tudo em cima do RESIDUO (ensaio menos a media da propria versao). Sem isso, a
 * coluna "mais forte" seria sempre a que separa fck 20 de fck 40.
 * Correlacao nao prova causa, e a tela diz isso.
 */
(function () {
  'use strict';

  const MIN_AMOSTRA = 30, MIN_GRUPO = 8;
  const DIAS = ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'];
  // Nome de coluna que vale a pena destacar. O resto entra pelo tipo do conteudo.
  const PAPEIS = [
    [/abat|slump/i, 'abatimento'],
    [/temp(?!o)|°c/i, 'temperatura'],
    [/viagem|transporte|percurso|tempo|dist[aâ]ncia|km\b/i, 'tempo de viagem'],
    [/[aá]gua|a\/c|umidade/i, 'água'],
  ];
  const SINAIS = {
    desde7: { nome: 'Fraco desde os 7 dias', dica: 'o concreto já saiu abaixo do normal da versão: olhe traço, materiais e água da carga' },
    cps: { nome: 'CPs irmãos brigando', dica: 'os dois corpos de prova diferem demais: olhe moldagem, capeamento e prensa, não o traço' },
    semana: { nome: 'Semana ruim', dica: 'outros ensaios da mesma versão na mesma semana também caíram: olhe o lote de cimento ou de agregado' },
    semFolga: { nome: 'Versão sem folga', dica: 'a média da versão fica perto demais do fck: qualquer variação normal já reprova' },
    idade: { nome: 'Idade fora dos 28 dias', dica: 'o rompimento não aconteceu perto dos 28 dias: confira as datas' },
    isolado: { nome: 'Caso isolado', dica: 'nada mais nos dados acompanha este resultado: olhe a moldagem e a cura deste corpo de prova' },
  };

  const num = v => {
    if (typeof v === 'number') return v;
    const t = String(v == null ? '' : v).trim().replace(/\s/g, '');
    if (!t) return NaN;
    const n = Number(/,\d*$/.test(t) ? t.replace(/\./g, '').replace(',', '.') : t);
    return isFinite(n) ? n : NaN;
  };
  const media = a => a.reduce((s, v) => s + v, 0) / a.length;
  const desvio = a => {
    if (a.length < 2) return NaN;
    const m = media(a);
    return Math.sqrt(a.reduce((s, v) => s + (v - m) * (v - m), 0) / (a.length - 1));
  };
  const dataDe = v => {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(v == null ? '' : v));
    if (m) return new Date(+m[1], +m[2] - 1, +m[3]);
    const b = /^(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(String(v == null ? '' : v));
    return b ? new Date(+b[3], +b[2] - 1, +b[1]) : null;
  };
  const dias = (a, b) => Math.round((b - a) / 86400000);

  function amostra(analisadas) {
    const lista = [];
    analisadas.forEach(a => {
      const boas = (a.serie || []).filter(e => !e.impossivel);
      if (boas.length < 5) return;
      const m = media(boas.map(e => e.v));
      const d7 = boas.map(e => e.d7).filter(v => isFinite(v) && v > 0);
      const m7 = d7.length >= 5 ? media(d7) : NaN, s7 = d7.length >= 5 ? desvio(d7) : NaN;
      boas.forEach(e => lista.push({ e, a, r: e.v - m, m7, s7, quando: dataDe(e.data) }));
    });
    return lista;
  }

  function pearson(xs, ys) {
    const mx = media(xs), my = media(ys);
    let sxy = 0, sxx = 0, syy = 0;
    for (let i = 0; i < xs.length; i++) {
      const dx = xs[i] - mx, dy = ys[i] - my;
      sxy += dx * dy; sxx += dx * dx; syy += dy * dy;
    }
    if (!sxx || !syy) return { r: 0, inclinacao: 0 };
    return { r: sxy / Math.sqrt(sxx * syy), inclinacao: sxy / sxx };
  }

  function fatorNumerico(nome, pares, papel) {
    if (pares.length < MIN_AMOSTRA) return null;
    const { r, inclinacao } = pearson(pares.map(p => p[0]), pares.map(p => p[1]));
    if (Math.abs(r) < Math.max(0.12, 2 / Math.sqrt(pares.length))) return null;
    return { tipo: 'numero', nome, papel, n: pares.length, forca: Math.abs(r), r, inclinacao };
  }

  function fatorCategoria(nome, pares) {
    const grupos = new Map();
    pares.forEach(([k, r]) => { if (!grupos.has(k)) grupos.set(k, []); grupos.get(k).push(r); });
    const validos = [...grupos.entries()].filter(([, v]) => v.length >= MIN_GRUPO);
    if (validos.length < 2 || validos.length > 40) return null;
    const todos = validos.flatMap(([, v]) => v), mg = media(todos);
    let entre = 0, dentro = 0;
    validos.forEach(([, v]) => {
      const m = media(v);
      entre += v.length * (m - mg) * (m - mg);
      dentro += v.reduce((s, x) => s + (x - m) * (x - m), 0);
    });
    const gl1 = validos.length - 1, gl2 = todos.length - validos.length;
    if (gl2 <= 0 || !dentro) return null;
    const F = (entre / gl1) / (dentro / gl2), eta = entre / (entre + dentro);
    if (F < 3 || eta < 0.02) return null;
    const pior = validos.map(([k, v]) => ({ k, n: v.length, d: media(v) - mg })).sort((x, y) => x.d - y.d)[0];
    return { tipo: 'categoria', nome, n: todos.length, forca: Math.sqrt(eta), pior };
  }

  /* Colunas que nao sao o resultado nem o nome da versao. */
  function fatores(lista, sd, usados) {
    const achados = [], H = sd.headers;
    const residuos = lista.map(x => x.r);
    H.forEach((h, c) => {
      if (usados.includes(c)) return;
      const nome = String(h);
      const papel = (PAPEIS.find(([re]) => re.test(nome)) || [])[1] || '';
      const vals = lista.map(x => x.e.linha ? x.e.linha[c] : null);
      const cheias = vals.filter(v => v != null && String(v).trim() !== '');
      if (cheias.length < MIN_AMOSTRA) return;
      if (cheias.filter(v => dataDe(v)).length > cheias.length * 0.5) return;
      const numericas = cheias.filter(v => isFinite(num(v))).length;
      if (numericas >= cheias.length * 0.8) {
        const distintos = new Set(cheias.map(String)).size;
        if (distintos > cheias.length * 0.9 && !papel) return;          // codigo, nota fiscal
        const pares = [];
        vals.forEach((v, i) => { const n = num(v); if (isFinite(n)) pares.push([n, residuos[i]]); });
        const f = fatorNumerico(nome, pares, papel);
        if (f) achados.push(f);
      } else {
        const pares = [];
        vals.forEach((v, i) => { if (v != null && String(v).trim()) pares.push([String(v).trim(), residuos[i]]); });
        const f = fatorCategoria(nome, pares);
        if (f) achados.push(f);
      }
    });
    const comData = lista.filter(x => x.quando);
    const f = fatorCategoria('Dia da moldagem', comData.map(x => [DIAS[x.quando.getDay()], x.r]));
    if (f) achados.push(f);
    return achados.sort((x, y) => y.forca - x.forca);
  }

  function sinaisDoEnsaio(x, vizinhos, iData28) {
    const { e, a, m7, s7 } = x, sinais = [];
    if (isFinite(e.d7) && e.d7 > 0 && isFinite(m7) && s7 > 0 && e.d7 < m7 - s7) sinais.push(['desde7', 'aos 7 dias deu ' + fmt(e.d7) + ' MPa, e o normal da versão é ' + fmt(m7)]);
    if (e.cps && e.cps.length === 2) {
      const dif = Math.abs(e.cps[0] - e.cps[1]) / Math.max(e.cps[0], e.cps[1]);
      if (dif > 0.15) sinais.push(['cps', 'um CP deu ' + fmt(e.cps[0]) + ' e o outro ' + fmt(e.cps[1]) + ' MPa']);
    }
    if (x.quando && iData28 >= 0 && e.linha) {
      const d28 = dataDe(e.linha[iData28]);
      const idade = d28 ? dias(x.quando, d28) : NaN;
      if (isFinite(idade) && (idade < 26 || idade > 31)) sinais.push(['idade', 'rompeu com ' + idade + ' dias']);
    }
    if (vizinhos.length >= 3) {
      const baixos = vizinhos.filter(v => v.r < 0).length;
      if (baixos / vizinhos.length >= 0.7 && media(vizinhos.map(v => v.r)) < -1) {
        sinais.push(['semana', baixos + ' de ' + vizinhos.length + ' ensaios da versão na mesma semana vieram abaixo da média']);
      }
    }
    const folga = isFinite(a.media) && isFinite(e.fck) ? a.media - e.fck : NaN;
    if (isFinite(folga) && isFinite(a.desvio) && folga < a.desvio) {
      sinais.push(['semFolga', 'a média da versão fica só ' + fmt(folga) + ' MPa acima do fck']);
    }
    if (!sinais.length) sinais.push(['isolado', 'nenhum outro sinal nos dados']);
    return sinais;
  }

  const fmt = (v, c) => Number(v).toLocaleString('pt-BR', { minimumFractionDigits: c === undefined ? 1 : c, maximumFractionDigits: c === undefined ? 1 : c });

  function analisar(analisadas, sd, cols) {
    const lista = amostra(analisadas);
    const usados = [cols.r, cols.d7, cols.d28, cols.d28b, cols.cp, cols.fck, cols.produto, cols.data]
      .filter(i => Number.isInteger(i) && i >= 0);
    // Coluna derivada do resultado nao explica nada: e' a mesma conta (TNF e' a
    // carga que virou o MPa, AREA e' constante).
    const iguais = /^(tnf|carga|kn|kgf|tf|mpa|fc|fcj|area|área|data)\b/i;
    sd.headers.forEach((h, i) => { if (iguais.test(String(h).trim()) && !usados.includes(i)) usados.push(i); });
    const iData28 = sd.headers.findIndex(h => /data\s*28/i.test(String(h)));
    const porVersao = new Map();
    lista.forEach(x => {
      if (!porVersao.has(x.a)) porVersao.set(x.a, []);
      porVersao.get(x.a).push(x);
    });
    const baixos = lista.filter(x => isFinite(x.e.fck) && x.e.v < x.e.fck).map(x => {
      const irmaos = x.quando ? porVersao.get(x.a).filter(o => o !== x && o.quando && Math.abs(dias(o.quando, x.quando)) <= 3) : [];
      const sinais = sinaisDoEnsaio(x, irmaos, iData28);
      return { e: x.e, versao: x.a.nome, falta: x.e.fck - x.e.v, sinais, principal: sinais[0][0] };
    }).sort((p, q) => q.falta - p.falta);
    const contagem = {};
    Object.keys(SINAIS).forEach(k => { contagem[k] = 0; });
    baixos.forEach(b => { contagem[b.principal]++; });
    const encontrados = sd.headers.filter(h => PAPEIS.some(([re]) => re.test(String(h))));
    // Versao com menos de 5 ensaios nao tem normal para comparar: fica de fora, e a tela diz.
    const semBase = analisadas.reduce((s, a) => s + ((a.serie || []).filter(e => !e.impossivel).length < 5
      ? (a.serie || []).filter(e => !e.impossivel && isFinite(e.fck) && e.v < e.fck).length : 0), 0);
    return { amostra: lista.length, baixos, contagem, semBase, fatores: fatores(lista, sd, usados), comPapel: encontrados };
  }

  function textoDoFator(f) {
    if (f.tipo === 'numero') {
      const sobe = f.inclinacao > 0 ? 'sobe' : 'cai';
      return 'Quando ' + f.nome + ' sobe 1, a resistência ' + sobe + ' ' + fmt(Math.abs(f.inclinacao), 2) + ' MPa em relação à média da versão';
    }
    return f.nome + ': "' + f.pior.k + '" fica ' + fmt(Math.abs(f.pior.d)) + ' MPa abaixo do esperado (' + f.pior.n + ' ensaios)';
  }

  window.ConcreCausas = { analisar, textoDoFator, SINAIS };
})();
