/* aparencia.js - Aparência e configurações.
 *
 * Três itens da lista que o Naor aprovou em 12/10/2026:
 *   21. modo escuro;
 *   23. letra maior ou menor, e o espaçamento da planilha;
 *   13. levar para outro computador os dados da empresa, as colunas e os
 *       modelos - "a aparência do relatório precisa de um arquivo próprio,
 *       então uma pasta de arquivos talvez", nas palavras dele.
 *
 * Fica num botão de engrenagem no canto de cima de todas as telas. Por
 * enquanto só na cópia em prévia (a do testador).
 */
(function () {
  'use strict';

  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const toast = (m, t, a) => { if (window.showToast) window.showToast(m, t, a); };

  const PADRAO = { tema: 'claro', escala: 1, densidade: 'normal', abrirUltima: true };
  const ESCALAS = [[0.9, '90%'], [1, '100%'], [1.1, '110%'], [1.25, '125%'], [1.4, '140%']];
  const DENSIDADES = [['compacto', 'Compacto', '24px'], ['normal', 'Normal', '28px'], ['confortavel', 'Confortável', '34px']];
  const TEMAS = [['claro', 'Claro'], ['escuro', 'Escuro'], ['sistema', 'Como o Windows']];

  let ap = Object.assign({}, PADRAO);
  let previa = false;
  try { Object.assign(ap, JSON.parse(localStorage.getItem('concre_aparencia') || '{}')); } catch (e) { /* padrão */ }

  /* -- aplicar --------------------------------------------------------- */
  const midiaEscura = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  function escuro() {
    return ap.tema === 'escuro' || (ap.tema === 'sistema' && !!(midiaEscura && midiaEscura.matches));
  }
  function aplicar() {
    const html = document.documentElement;
    if (!previa) {
      delete html.dataset.tema;
      html.style.removeProperty('--cell-h');
      return;
    }
    html.dataset.tema = escuro() ? 'escuro' : 'claro';
    aplicarEmpresa();
    html.dataset.abasAntigas = ap.abasAntigas ? '1' : '';
    const d = DENSIDADES.find(x => x[0] === ap.densidade) || DENSIDADES[1];
    html.style.setProperty('--cell-h', d[2]);
    if (window.ConcrestatsRemedirGrade) window.ConcrestatsRemedirGrade();
    aplicarZoom();
    window.dispatchEvent(new CustomEvent('concrestats:aparencia', { detail: Object.assign({}, ap) }));
  }
  /* A cara da empresa (item 25): logo e cor no programa todo, sem apagar a
   * identidade. O nome Concrestats fica na barra, ao lado do logo dela. */
  const clareza = cor => {
    const n = parseInt(String(cor).slice(1), 16);
    return (0.299 * (n >> 16 & 255) + 0.587 * (n >> 8 & 255) + 0.114 * (n & 255)) / 255;
  };
  const escurecer = (cor, f) => '#' + [16, 8, 0].map(s => Math.round((parseInt(cor.slice(1), 16) >> s & 255) * f)
    .toString(16).padStart(2, '0')).join('');
  function aplicarEmpresa() {
    const html = document.documentElement, e = ap.empresa || {};
    const ligada = previa && !!e.ligada;
    html.dataset.empresa = ligada ? '1' : '';
    const vars = ['--empresa-cor', '--empresa-texto', '--accent', '--accent-2'];
    if (ligada && /^#[0-9a-f]{6}$/i.test(e.cor || '')) {
      html.style.setProperty('--empresa-cor', e.cor);
      html.style.setProperty('--empresa-texto', clareza(e.cor) > 0.6 ? '#1c1b18' : '#ffffff');
      html.style.setProperty('--accent', e.cor);
      html.style.setProperty('--accent-2', escurecer(e.cor, 0.75));
    } else vars.forEach(v => html.style.removeProperty(v));
    document.querySelectorAll('.logo').forEach(l => {
      let i = l.querySelector('.logo-empresa');
      if (ligada && e.logo) {
        if (!i) { i = new Image(); i.className = 'logo-empresa'; i.alt = e.nome || 'Logotipo da empresa'; l.prepend(i); }
        i.src = e.logo;
      } else if (i) i.remove();
    });
  }

  if (midiaEscura && midiaEscura.addEventListener) {
    midiaEscura.addEventListener('change', () => { if (ap.tema === 'sistema') aplicar(); });
  }

  // O zoom de verdade é o do WebView2 (app.py, definir_zoom). No navegador
  // comum, usado só no desenvolvimento, cai no zoom de CSS.
  let zoomAplicado = null;
  function aplicarZoom() {
    const f = Number(ap.escala) || 1;
    if (zoomAplicado === f) return;
    const api = window.pywebview && window.pywebview.api;
    if (api && typeof api.definir_zoom === 'function') {
      zoomAplicado = f;
      // Deu certo o nativo: tira o de CSS que possa ter entrado antes de o
      // pywebview ficar pronto - senão os dois somam (1,25 x 1,25 = 1,56).
      Promise.resolve(api.definir_zoom(f)).then(ok => zoomCss(ok ? 1 : f)).catch(() => zoomCss(f));
    } else if (!window.pywebview) {
      zoomAplicado = f;
      zoomCss(f);
    }
    // com pywebview ainda subindo, o 'pywebviewready' chama de novo
  }
  function zoomCss(f) { document.documentElement.style.zoom = f === 1 ? '' : String(f); }
  window.addEventListener('pywebviewready', () => { zoomAplicado = null; if (previa) aplicarZoom(); });
  // O 'pywebviewready' pode ter disparado antes deste arquivo carregar. Sem
  // isto a letra maior só valeria depois de mexer de novo na opção.
  function esperarPywebview(tentativas) {
    if (!previa || zoomAplicado !== null || !window.pywebview || tentativas <= 0) return;
    if (window.pywebview.api && typeof window.pywebview.api.definir_zoom === 'function') { aplicarZoom(); return; }
    setTimeout(() => esperarPywebview(tentativas - 1), 300);
  }

  function gravar() {
    try { localStorage.setItem('concre_aparencia', JSON.stringify(ap)); } catch (e) { /* só nesta abertura */ }
    try {
      fetch('/api/prefs', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ aparencia: ap }) }).catch(() => {});
    } catch (e) { /* idem */ }
  }

  /* -- o painel -------------------------------------------------------- */
  function grupo(nome, opcoes, atual) {
    return '<div class="ap-opcoes" role="group" data-grupo="' + nome + '">' + opcoes.map(o =>
      '<button type="button" data-v="' + esc(o[0]) + '" class="' + (String(o[0]) === String(atual) ? 'ativo' : '') +
      '" aria-pressed="' + (String(o[0]) === String(atual)) + '">' + esc(o[1]) + '</button>').join('') + '</div>';
  }
  function abrir() {
    if (!window.openModal) return;
    const corpo =
      '<div class="ap-secao">Aparência</div>' +
      '<div class="ap-linha"><span class="ap-rotulo">Tema</span>' + grupo('tema', TEMAS, ap.tema) + '</div>' +
      '<div class="ap-linha"><span class="ap-rotulo">Tamanho da letra</span>' + grupo('escala', ESCALAS, ap.escala) + '</div>' +
      '<div class="ap-linha"><span class="ap-rotulo">Espaçamento da planilha</span>' +
        grupo('densidade', DENSIDADES.map(d => [d[0], d[1]]), ap.densidade) + '</div>' +
      '<p class="ap-nota">Muda na hora, e fica guardado neste computador. O relatório impresso não muda: ele é sempre a folha branca.</p>' +
      '<div class="ap-secao">Ao abrir o programa</div>' +
      '<label class="ap-check"><input type="checkbox" id="ap-abrir-ultima"' + (ap.abrirUltima ? ' checked' : '') +
        '> Abrir a última planilha usada - a tela de Início já mostra os rompimentos do dia</label>' +
      '<label class="ap-check"><input type="checkbox" id="ap-abas"' + (ap.abasAntigas ? ' checked' : '') +
        '> Mostrar Análise e Dashboard como abas separadas, fora do Painel</label>' +
      '<div class="ap-secao">Levar para outro computador</div>' +
      '<p class="ap-nota">Grava numa pasta os dados da empresa e dos clientes, o visual do relatório (com o logotipo como imagem), ' +
        'as colunas escolhidas, os modelos de gráfico e de painel, a agenda e esta aparência - um arquivo para cada assunto. ' +
        'No outro computador, <b>Importar</b> e escolher a pasta.</p>' +
      '<div class="ap-acoes"><button type="button" class="secondary-btn" id="ap-exportar">Exportar para uma pasta…</button>' +
        '<button type="button" class="secondary-btn" id="ap-importar">Importar de uma pasta…</button></div>' +
      '<div class="ap-secao">O programa com a cara da empresa</div>' +
      '<label class="ap-check"><input type="checkbox" id="ap-empresa"' + ((ap.empresa || {}).ligada ? ' checked' : '') +
        '> Usar o logo e a cor da empresa em todas as telas</label>' +
      '<div class="ap-acoes"><input type="color" id="ap-empresa-cor" value="' + esc((ap.empresa || {}).cor || '#2a5298') + '" aria-label="Cor da empresa">' +
        '<input type="file" id="ap-empresa-logo" accept="image/*" aria-label="Logotipo da empresa">' +
        '<button type="button" class="secondary-btn" id="ap-empresa-puxar">Puxar do relatório</button></div>' +
      '<div class="ap-secao">Acesso por função</div>' +
      '<p class="ap-nota">O operador lança os resultados e só o responsável libera o relatório.</p>' +
      '<div class="ap-acoes"><button type="button" class="secondary-btn" id="ap-acessos">Pessoas e PIN…</button>' +
        '<button type="button" class="secondary-btn" id="ap-guia">Primeiros passos</button></div>';
    window.openModal('Aparência e configurações', corpo, () => { if (window.closeModal) window.closeModal(); }, 'modal-aparencia');
    const ok = $('modal-confirm');
    if (ok) ok.textContent = 'Fechar';
    document.querySelectorAll('#modal-content .modal-footer .secondary-btn').forEach(b => { b.style.display = 'none'; });

    document.querySelectorAll('#modal-content .ap-opcoes').forEach(g => g.addEventListener('click', e => {
      const b = e.target.closest('button[data-v]');
      if (!b) return;
      const nome = g.dataset.grupo;
      ap[nome] = nome === 'escala' ? Number(b.dataset.v) : b.dataset.v;
      g.querySelectorAll('button').forEach(x => {
        x.classList.toggle('ativo', x === b);
        x.setAttribute('aria-pressed', String(x === b));
      });
      gravar(); aplicar();
    }));
    $('ap-abrir-ultima')?.addEventListener('change', e => { ap.abrirUltima = !!e.target.checked; gravar(); });
    $('ap-abas')?.addEventListener('change', e => { ap.abasAntigas = !!e.target.checked; gravar(); aplicar(); });
    $('ap-exportar')?.addEventListener('click', exportar);
    $('ap-importar')?.addEventListener('click', importar);
    const empresa = () => (ap.empresa = ap.empresa || {});
    const salva = () => { gravar(); aplicar(); };
    $('ap-empresa')?.addEventListener('change', e => { empresa().ligada = !!e.target.checked; salva(); });
    $('ap-empresa-cor')?.addEventListener('input', e => { empresa().cor = e.target.value; salva(); });
    $('ap-empresa-logo')?.addEventListener('change', async e => {
      const logo = await logoReduzido(e.target.files[0]);
      if (logo) { empresa().logo = logo; salva(); }
    });
    $('ap-empresa-puxar')?.addEventListener('click', async () => {
      const m = window.RelatorioModule && window.RelatorioModule._marcaDaEmpresa ? await window.RelatorioModule._marcaDaEmpresa() : null;
      if (!m || (!m.logo && !m.nome)) { toast('Preencha o logotipo em Relatório, Campos fixos', 'error'); return; }
      Object.assign(empresa(), { logo: m.logo || empresa().logo, nome: m.nome, ligada: true });
      if (/^#[0-9a-f]{6}$/i.test(m.cor || '')) { empresa().cor = m.cor; if ($('ap-empresa-cor')) $('ap-empresa-cor').value = m.cor; }
      if ($('ap-empresa')) $('ap-empresa').checked = true;
      salva();
    });
    $('ap-acessos')?.addEventListener('click', () => window.ConcreLaboratorio?.abrirAcessos());
    $('ap-guia')?.addEventListener('click', () => { if (window.closeModal) window.closeModal(); window.ConcreGuia?.abrir(); });
  }

  // Logo vai para as preferencias: reduz para a altura da barra, senao uma foto de
  // 3 MB entraria em toda gravacao.
  function logoReduzido(arq) {
    return new Promise(resolve => {
      if (!arq) { resolve(null); return; }
      const img = new Image(), url = URL.createObjectURL(arq);
      img.onload = () => {
        const f = Math.min(1, 96 / img.height), c = document.createElement('canvas');
        c.width = Math.round(img.width * f); c.height = Math.round(img.height * f);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        resolve(c.toDataURL('image/png'));
      };
      img.onerror = () => { URL.revokeObjectURL(url); toast('Não consegui ler essa imagem', 'error'); resolve(null); };
      img.src = url;
    });
  }

  /* -- levar para outro computador ------------------------------------- */
  // Cada arquivo diz o que é e de qual versão; as chaves são as mesmas das
  // preferências, para importar ser só devolvê-las.
  const ARQUIVOS = [
    { arq: 'empresa.json', rotulo: 'Dados da empresa (Campos fixos do relatório)', chaves: ['ensaio_fixos'] },
    { arq: 'relatorio-aparencia.json', rotulo: 'Visual do relatório e logotipo', chaves: [] },
    { arq: 'clientes.json', rotulo: 'Dados de cada cliente', chaves: ['ensaio_por_cliente'] },
    { arq: 'colunas.json', rotulo: 'Colunas escolhidas em cada formato de planilha', chaves: ['colunas_por_formato', 'previsao_colunas', 'analise_maps'] },
    { arq: 'graficos.json', rotulo: 'Modelos e layouts de gráfico', chaves: ['graf_layouts', 'graf_templates'] },
    { arq: 'painel.json', rotulo: 'Painéis montados', chaves: ['painel_layouts'] },
    { arq: 'planilha.json', rotulo: 'Regras de cor, colunas congeladas e larguras', chaves: ['grid'] },
    { arq: 'previsao.json', rotulo: 'Ajustes da Previsão', chaves: ['previsao_fator', 'previsao_dois_cps'] },
    { arq: 'agenda.json', rotulo: 'Agenda de rompimento', chaves: ['agenda'] },
    { arq: 'programa.json', rotulo: 'Aparência do programa', chaves: ['aparencia'] },
  ];
  const VISUAL = ['identidade', 'cor'];

  function embalar(chaves) {
    return JSON.stringify({ concrestats: 'configuracoes', versao: 1,
      gerado: new Date().toISOString(), chaves }, null, 2);
  }

  async function escolherPasta() {
    const api = window.pywebview && window.pywebview.api;
    if (!api || typeof api.escolher_pasta !== 'function') {
      toast('Escolher pasta só funciona no programa instalado', 'error');
      return null;
    }
    try {
      return await api.escolher_pasta();
    } catch (e) {
      toast('Não consegui abrir a escolha de pasta do Windows', 'error');
      return null;
    }
  }

  // Monta o conteúdo da pasta a partir das preferências. Separado do gravar
  // para o Modo Teste conferir sem abrir diálogo.
  function montarArquivos(p) {
    const arquivos = {};
    const logo = p.ensaio_fixos && typeof p.ensaio_fixos.logo === 'string' ? p.ensaio_fixos.logo : '';
    const nomeLogo = /^data:image\/jpe?g/i.test(logo) ? 'relatorio-logotipo.jpg' : 'relatorio-logotipo.png';
    ARQUIVOS.forEach(a => {
      if (a.arq === 'relatorio-aparencia.json') {
        const fx = p.ensaio_fixos || {};
        const visual = {};
        VISUAL.forEach(k => { if (fx[k] != null) visual[k] = fx[k]; });
        if (logo) visual.logotipo = nomeLogo;
        arquivos[a.arq] = embalar({ relatorio_visual: visual });
        return;
      }
      const chaves = {};
      a.chaves.forEach(k => {
        if (p[k] === undefined) return;
        if (k === 'ensaio_fixos') {
          const fx = Object.assign({}, p[k]);
          delete fx.logo; VISUAL.forEach(v => delete fx[v]);    // vão no arquivo do visual
          chaves[k] = fx;
        } else chaves[k] = p[k];
      });
      if (Object.keys(chaves).length) arquivos[a.arq] = embalar(chaves);
    });
    if (logo) arquivos[nomeLogo] = logo;
    arquivos['LEIA-ME.txt'] = [
      'Configurações do Concrestats',
      '',
      'Para usar em outro computador: no Concrestats, engrenagem no canto de cima >',
      'Aparência e configurações > Importar de uma pasta, e escolha esta pasta.',
      '',
      'Um arquivo para cada assunto. Pode apagar o que não quiser levar.',
      '',
      ...ARQUIVOS.filter(a => arquivos[a.arq]).map(a => '  ' + a.arq.padEnd(26) + a.rotulo),
      logo ? '  ' + nomeLogo.padEnd(26) + 'o logotipo do relatório (pode trocar por outra imagem)' : '',
      '',
      'Gerado em ' + new Date().toLocaleString('pt-BR'),
    ].join('\r\n');
    return arquivos;
  }

  async function exportar() {
    const pasta = await escolherPasta();
    if (!pasta) return;
    const p = (await window.prefsGet(true)) || {};
    const arquivos = montarArquivos(p);
    try {
      const j = await fetch('/api/configuracoes/exportar', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pasta, arquivos }) }).then(r => r.json());
      if (!j.success) { toast('Não consegui gravar: ' + (j.error || ''), 'error'); return; }
      toast('Configurações gravadas em "' + String(j.pasta).split(/[\\/]/).pop() + '" (' + j.arquivos.length + ' arquivos)', 'success');
    } catch (e) {
      toast('Não consegui gravar as configurações', 'error');
    }
  }

  // De volta: o que veio da pasta vira preferências. O visual do relatório e
  // os dados da empresa moram na mesma chave (ensaio_fixos), mas chegam em
  // arquivos separados - cada um só mexe na sua parte.
  function montarImportacao(achados, marcados, p) {
    const logo = achados['relatorio-logotipo.png'] || achados['relatorio-logotipo.jpg'] || '';
    const novo = {};
    ARQUIVOS.forEach(a => {
      const x = achados[a.arq];
      if (!marcados.has(a.arq) || !x || !x.chaves) return;
      const ch = x.chaves;
      if (a.arq === 'relatorio-aparencia.json') {
        const vis = ch.relatorio_visual || {};
        const fx = Object.assign({}, novo.ensaio_fixos || p.ensaio_fixos || {});
        VISUAL.forEach(k => { if (vis[k] != null) fx[k] = vis[k]; else delete fx[k]; });
        if (logo) fx.logo = logo;
        novo.ensaio_fixos = fx;
        return;
      }
      a.chaves.forEach(k => {
        if (ch[k] === undefined) return;
        if (k === 'ensaio_fixos') {
          const antes = novo.ensaio_fixos || p.ensaio_fixos || {};
          const fx = Object.assign({}, ch[k]);
          VISUAL.concat('logo').forEach(v => { if (antes[v] != null) fx[v] = antes[v]; });
          novo.ensaio_fixos = fx;
        } else novo[k] = ch[k];
      });
    });
    return novo;
  }

  async function importar() {
    const pasta = await escolherPasta();
    if (!pasta) return;
    let j;
    try {
      j = await fetch('/api/configuracoes/ler', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pasta }) }).then(r => r.json());
    } catch (e) { j = null; }
    if (!j || !j.success) { toast('Não consegui ler a pasta', 'error'); return; }
    const achados = j.arquivos || {};
    const temLogo = !!(achados['relatorio-logotipo.png'] || achados['relatorio-logotipo.jpg']);
    const valido = x => x && x.concrestats === 'configuracoes' && x.chaves && typeof x.chaves === 'object';
    const itens = ARQUIVOS.filter(a => valido(achados[a.arq]));
    if (!itens.length) {
      toast('Esta pasta não tem configurações do Concrestats', 'error');
      return;
    }
    const corpo = '<p class="col-intro">O que estiver marcado <b>substitui</b> o que este computador tem hoje. ' +
      'O resto fica como está.</p><div class="ap-importar">' + itens.map(a =>
        '<label class="ap-check"><input type="checkbox" class="ap-imp" data-arq="' + esc(a.arq) + '" checked> ' +
        esc(a.rotulo) + (a.arq === 'relatorio-aparencia.json' && temLogo ? ' <small>(com o logotipo)</small>' : '') +
        ' <small class="ap-arq">' + esc(a.arq) + '</small></label>').join('') + '</div>' +
      ((j.problemas || []).length ? '<p class="ap-nota ap-erro">Não consegui ler: ' + esc(j.problemas.join(', ')) + '</p>' : '');
    window.openModal('Importar configurações', corpo, async () => {
      const marcados = new Set([...document.querySelectorAll('.ap-imp:checked')].map(i => i.dataset.arq));
      if (!marcados.size) { if (window.closeModal) window.closeModal(); return; }
      const p = (await window.prefsGet(true)) || {};
      const novo = montarImportacao(achados, marcados, p);
      try {
        const r = await fetch('/api/prefs', { method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(novo) }).then(x => x.json());
        if (!r || r.success === false) throw new Error((r && r.error) || 'recusado');
      } catch (e) {
        toast('Não consegui importar: ' + e.message, 'error');
        return;
      }
      // As telas guardam cópia das preferências; recarregar é o jeito de
      // todas verem o que chegou. A planilha aberta volta sozinha.
      try {
        if (novo.ensaio_fixos) localStorage.setItem('concrestats_ensaio_fixos', JSON.stringify(novo.ensaio_fixos));
        if (novo.ensaio_por_cliente) localStorage.setItem('concrestats_ensaio_por_cliente', JSON.stringify(novo.ensaio_por_cliente));
        if (novo.aparencia) localStorage.setItem('concre_aparencia', JSON.stringify(novo.aparencia));
      } catch (e) { /* o servidor já tem */ }
      if (window.closeModal) window.closeModal();
      const sujo = document.getElementById('btn-save-file')?.classList.contains('dirty');
      if (sujo && window.perguntar && !(await window.perguntar('Recarregar o programa',
        'As configurações foram importadas. Para valerem em todas as telas o programa recarrega - ' +
        'e há alterações na planilha ainda não salvas. Recarregar assim mesmo?', 'Recarregar'))) {
        toast('Importado. Salve a planilha e feche e abra o programa para ver tudo.', 'success');
        return;
      }
      try { if (window.__concreSourcePath) sessionStorage.setItem('concre_reabrir', window.__concreSourcePath); } catch (e) { /* sem reabrir */ }
      location.reload();
    }, 'modal-aparencia');
    const ok = $('modal-confirm');
    if (ok) ok.textContent = 'Importar';
  }

  /* -- o botão --------------------------------------------------------- */
  const ENGRENAGEM = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M8 5.6a2.4 2.4 0 100 4.8 2.4 2.4 0 000-4.8z" fill="none" stroke="currentColor" stroke-width="1.2"/>' +
    '<path d="M6.9 1.5h2.2l.4 1.7 1.2.5 1.5-.9 1.6 1.6-.9 1.5.5 1.2 1.7.4v2.2l-1.7.4-.5 1.2.9 1.5-1.6 1.6-1.5-.9-1.2.5-.4 1.7H6.9l-.4-1.7-1.2-.5-1.5.9-1.6-1.6.9-1.5-.5-1.2-1.7-.4V6.9l1.7-.4.5-1.2-.9-1.5 1.6-1.6 1.5.9 1.2-.5z" fill="none" stroke="currentColor" stroke-width="1.1" stroke-linejoin="round"/></svg>';
  function botoes() {
    document.querySelectorAll('.topbar-right').forEach(tr => {
      if (tr.querySelector('.tb-config')) return;
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'tb-config';
      b.setAttribute('data-previa', '');
      b.title = 'Aparência e configurações';
      b.setAttribute('aria-label', 'Aparência e configurações');
      b.innerHTML = ENGRENAGEM;
      b.addEventListener('click', abrir);
      tr.appendChild(b);
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    botoes();
    (window.ConcrePrevia || Promise.resolve(false)).then(sim => {
      previa = !!sim;
      aplicar();
      esperarPywebview(20);
      if (!previa || typeof window.prefsGet !== 'function') return;
      // O que está no servidor vale mais que a cópia do navegador (pode ter
      // chegado por importação, ou o perfil do WebView2 ter sido limpo).
      window.prefsGet().then(p => {
        if (p && p.aparencia && typeof p.aparencia === 'object') {
          ap = Object.assign({}, PADRAO, p.aparencia);
          try { localStorage.setItem('concre_aparencia', JSON.stringify(ap)); } catch (e) { /* ok */ }
          aplicar();
        }
      }).catch(() => {});
    });
  });

  window.ConcreAparencia = {
    abrir,
    abrirUltima: () => previa && ap.abrirUltima !== false,
    // para o Modo Teste
    _estado: () => Object.assign({}, ap),
    _montarArquivos: montarArquivos,
    _montarImportacao: montarImportacao,
  };
})();
