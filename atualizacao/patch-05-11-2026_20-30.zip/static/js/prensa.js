/*
 * prensa.js - ler direto da prensa (item 14 da lista do Naor).
 *
 * Importa o arquivo que a prensa gera, sem digitar. Cada software exporta de um
 * jeito, entao nada aqui assume formato: acha as colunas pelo nome e pelo conteudo,
 * mostra o que entendeu e so' grava depois que a pessoa confirma. Valor que ja'
 * existe na planilha nao e' trocado sem marcar a caixa.
 */
(function () {
  'use strict';

  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const num = v => {
    if (typeof v === 'number') return v;
    const t = String(v == null ? '' : v).trim().replace(/\s/g, '');
    if (!t) return NaN;
    const n = Number(/,\d*$/.test(t) ? t.replace(/\./g, '').replace(',', '.') : t);
    return isFinite(n) ? n : NaN;
  };
  const semZeros = v => String(v == null ? '' : v).trim().replace(/^0+(?=.)/, '').toLowerCase();
  const norm = s => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

  // Carga para MPa: forca sobre a area. A area sai do diametro do corpo de prova.
  const AREA_MM2 = d => Math.PI * d * d / 4;
  const PARA_NEWTON = { kn: 1000, tf: 9806.65, kgf: 9.80665, n: 1 };

  function acharColunas(headers) {
    const achar = re => headers.findIndex(h => re.test(norm(h)));
    const iMpa = achar(/mpa|resistencia|tensao|fc\b/);
    const unidade = () => {
      for (const [re, u] of [[/kn/, 'kn'], [/tnf|tf\b|tonelada/, 'tf'], [/kgf/, 'kgf']]) {
        const i = achar(re);
        if (i >= 0) return { i, u };
      }
      const i = achar(/carga|forca|ruptura/);
      return i >= 0 ? { i, u: 'kn' } : { i: -1, u: 'kn' };
    };
    return { cp: achar(/^cp\b|corpo|amostra|identifica|^id\b|codigo/), mpa: iMpa, carga: unidade(), idade: achar(/idade|dias/) };
  }

  function resultadoDaLinha(r, col, diametro) {
    if (col.mpa >= 0) {
      const v = num(r[col.mpa]);
      if (v > 0 && v < 150) return v;
    }
    if (col.carga.i >= 0) {
      const f = num(r[col.carga.i]);
      if (f > 0) return f * PARA_NEWTON[col.carga.u] / AREA_MM2(diametro);
    }
    return NaN;
  }

  // Para onde vai cada resultado. Sem idade no arquivo, cai na primeira coluna
  // vazia daquele CP, na ordem 7 dias, 28 dias, segundo CP de 28.
  function plano(prensa, col, diametro, trocar) {
    const d = window.getConcrestatsData({ filtered: false }), H = d.headers, C = window.ConcreColunas;
    const iCp = C.indice(H, 'cp'), i7 = C.indice(H, 'mpa7'), i28 = C.indice(H, 'mpa28'), i28b = C.indice(H, 'mpa28b');
    const r = { itens: [], ignoradas: 0, semPar: 0, jaTinha: 0, semColuna: iCp < 0 };
    if (iCp < 0 || col.cp < 0) return r;
    const porCp = new Map();
    d.data.forEach((l, i) => { const k = semZeros(l[iCp]); if (k && !porCp.has(k)) porCp.set(k, i); });
    const usadas = new Set();
    const livre = (i, c) => c >= 0 && !usadas.has(i + ':' + c) && !String(d.data[i][c] == null ? '' : d.data[i][c]).trim();
    prensa.data.forEach(l => {
      const cp = semZeros(l[col.cp]), v = resultadoDaLinha(l, col, diametro);
      if (!cp || !isFinite(v)) { r.ignoradas++; return; }
      const i = porCp.get(cp);
      if (i === undefined) { r.semPar++; return; }
      const idade = col.idade >= 0 ? num(l[col.idade]) : NaN;
      const opcoes = isFinite(idade) ? (idade <= 14 ? [i7] : [i28, i28b]) : [i7, i28, i28b];
      let c = opcoes.find(x => livre(i, x));
      if (c === undefined) {
        if (!trocar) { r.jaTinha++; return; }
        c = opcoes.find(x => x >= 0 && !usadas.has(i + ':' + x));
        if (c === undefined) { r.jaTinha++; return; }
      }
      usadas.add(i + ':' + c);
      r.itens.push({ linha: i, col: c, valor: v.toFixed(2), cp: d.data[i][iCp], nomeCol: H[c], antes: d.data[i][c] });
    });
    return r;
  }

  function selColuna(id, rotulo, headers, atual) {
    return '<div class="fx-campo"><label for="' + id + '">' + rotulo + '</label><select id="' + id + '"><option value="-1">não tem</option>' +
      headers.map((h, i) => '<option value="' + i + '"' + (i === atual ? ' selected' : '') + '>' + esc(h) + '</option>').join('') + '</select></div>';
  }

  function abrir() {
    if (!window.openModal) return;
    const d = window.getConcrestatsData ? window.getConcrestatsData({ filtered: false }) : null;
    if (!d || !d.headers.length) { if (typeof toast === 'function') toast('Abra a planilha de rompimentos primeiro', 'error'); return; }
    let prensa = null, atual = null;
    window.openModal('Importar da prensa',
      '<p class="col-intro">Escolha o arquivo que a prensa gerou (CSV, TXT ou Excel). Cada resultado entra na linha do CP com o mesmo número. Nada é gravado antes de Aplicar, e dá para desfazer.</p>' +
      '<input type="file" id="pr-arq" accept=".csv,.txt,.dat,.log,.xlsx,.xls"><div id="pr-cols"></div><div id="pr-res"></div>',
      () => {
        if (!atual || !atual.itens.length) return;
        window.ConcrestatsAplicarCelulas(atual.itens);
        if (window.closeModal) window.closeModal();
        if (typeof toast === 'function') toast(atual.itens.length + ' resultado(s) da prensa na planilha', 'success');
      }, 'modal-laboratorio');
    const ok = $('modal-confirm'); if (ok) ok.textContent = 'Aplicar';
    const refazer = () => {
      const col = { cp: +$('pr-cp').value, mpa: +$('pr-mpa').value, idade: +$('pr-idade').value,
                    carga: { i: +$('pr-carga').value, u: $('pr-un').value } };
      atual = plano(prensa, col, +$('pr-diam').value, $('pr-trocar').checked);
      const linhas = atual.itens.slice(0, 8).map(x => '<tr><td>' + esc(x.cp) + '</td><td>' + esc(x.nomeCol) + '</td><td>' + esc(x.antes) +
        '</td><td class="lab-depois">' + esc(x.valor.replace('.', ',')) + '</td></tr>').join('');
      $('pr-res').innerHTML = '<p class="rc-dica"><b>' + atual.itens.length + '</b> resultado(s) para gravar' +
        (atual.semPar ? ', ' + atual.semPar + ' sem CP igual na planilha' : '') + (atual.jaTinha ? ', ' + atual.jaTinha + ' já tinham valor' : '') +
        (atual.ignoradas ? ', ' + atual.ignoradas + ' linha(s) sem CP ou sem resultado' : '') + '.</p>' +
        (atual.semColuna ? '<p class="lab-alerta">A planilha aberta não tem a coluna de CP: confira em Colunas.</p>' : '') +
        (linhas ? '<div class="lab-tabela"><table><thead><tr><th>CP</th><th>Coluna</th><th>Antes</th><th>Prensa</th></tr></thead><tbody>' + linhas + '</tbody></table></div>' : '');
    };
    $('pr-arq').addEventListener('change', async e => {
      const arq = e.target.files[0];
      if (!arq) return;
      const f = new FormData(); f.append('arquivo', arq);
      const j = await fetch('/api/prensa/ler', { method: 'POST', body: f }).then(r => r.json()).catch(() => null);
      if (!j || !j.success) { $('pr-res').innerHTML = '<p class="lab-nao">Não consegui ler: ' + esc((j && j.error) || 'sem resposta') + '</p>'; return; }
      prensa = j;
      const col = acharColunas(j.headers);
      $('pr-cols').innerHTML = '<div class="fx-grade">' + selColuna('pr-cp', 'Identificação do CP', j.headers, col.cp) +
        selColuna('pr-mpa', 'Resultado em MPa', j.headers, col.mpa) + selColuna('pr-carga', 'Carga de ruptura', j.headers, col.carga.i) +
        '<div class="fx-campo"><label for="pr-un">Unidade da carga</label><select id="pr-un">' + [['kn', 'kN'], ['tf', 'tf'], ['kgf', 'kgf']].map(u =>
          '<option value="' + u[0] + '"' + (u[0] === col.carga.u ? ' selected' : '') + '>' + u[1] + '</option>').join('') + '</select></div>' +
        selColuna('pr-idade', 'Idade (dias)', j.headers, col.idade) +
        '<div class="fx-campo"><label for="pr-diam">Diâmetro do CP</label><select id="pr-diam"><option value="100">10 cm</option><option value="150">15 cm</option></select></div></div>' +
        '<label class="pw-check"><input type="checkbox" id="pr-trocar"> Trocar valor que já existe</label>';
      ['pr-cp', 'pr-mpa', 'pr-carga', 'pr-un', 'pr-idade', 'pr-diam', 'pr-trocar'].forEach(id => $(id).addEventListener('change', refazer));
      refazer();
    });
  }

  window.ConcrePrensa = { abrir, acharColunas, plano };
  document.addEventListener('DOMContentLoaded', () => { const b = $('btn-prensa'); if (b) b.addEventListener('click', abrir); });
})();
