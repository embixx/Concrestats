/**
 * painel.js - Painel livre (canvas) do Concrestats
 *
 * Implementa a ideia do Naor: a página inteira é um canvas. Botão direito no
 * vazio ADICIONA um widget; botão direito no widget EDITA/duplica/exclui.
 * Os widgets cobrem as três "qualidades" que ele descreveu: valor filtrado,
 * agrupado por X, e proporção do total.
 *
 * Tipos: dado (KPI) · tabela · gráfico (barra/linha/pizza/empilhado/mapa de calor) · insights
 * Layout persistido por planilha em /api/prefs (chave painel_layouts).
 * Os dados respeitam SEMPRE os filtros globais da aba Planilhas.
 */
(function () {
  'use strict';

  const $ = id => document.getElementById(id);
  const V = () => window.ConcreViz || {};
  const LAB = () => window.ConcreLab || {};
  const esc = s => String(s ?? '').replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const GRID = 10;
  const snap = v => Math.round(v / GRID) * GRID;
  const HEADER_H = 30;

  // Linha sem valor na coluna de agrupamento vira uma categoria propria - nao
  // da' para somar no que nao existe. Na planilha do laboratorio sao 826
  // linhas sem PRODUTO, 17,5% do volume: aparecia como a maior fatia nomeada,
  // chamada "-". Um traco nao diz que aquilo e' dado faltando; diz que alguem
  // batizou uma categoria de traco.
  const SEM_VALOR = '(em branco)';

  // Operações. As três derivadas usam período anterior / total - é a base do
  // "criar suas próprias fórmulas" pedido pelo Naor.
  const OPS = ['Soma', 'Média', 'Contagem', 'Mínimo', 'Máximo', 'Mediana',
    'Desvio padrão', '% do total', 'Crescimento %', 'Acumulado'];
  const OPS_BASE = ['Soma', 'Média', 'Contagem', 'Mínimo', 'Máximo', 'Mediana', 'Desvio padrão'];
  const TIPOS = [['barra', 'Barra'], ['pizza', 'Pizza'],
    ['empilhado', 'Barra empilhada'], ['calor', 'Mapa de calor']];
  // O que so' a copia de teste oferece por enquanto.
  const FORMULA = 'Fórmula';
  const tiposDaTela = () => (previaLigada
    ? [TIPOS[0], ['barraH', 'Barra deitada'], ['linha', 'Linha']].concat(TIPOS.slice(1)) : TIPOS);
  const opsDaTela = () => (previaLigada ? OPS.concat(FORMULA) : OPS);

  const state = { sheet: null, layouts: {}, carregado: false };
  let previaLigada = false;          // recursos em prévia (edição do testador)
  if (window.ConcrePrevia) window.ConcrePrevia.then(s => {
    previaLigada = !!s;
    // O primeiro desenho pode sair antes da resposta, e sem repetir o grafico
    // ficava com o jeito antigo ate' o proximo clique.
    const el = $('module-painel');
    if (previaLigada && state.carregado && el && el.style.display !== 'none') render();
  });

  /* -- dados (sempre com o filtro global aplicado) -- */
  function dados() {
    const d = window.getConcrestatsData ? window.getConcrestatsData({ filtered: true }) : null;
    if (!d || !d.headers || !d.headers.length) return null;
    return { headers: d.headers, rows: d.data || [], todas: d.fullData || d.data || [], sheet: d.activeSheet };
  }
  const layout = () => (state.layouts[state.sheet] = state.layouts[state.sheet] || []);
  const genId = () => 'w' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36);

  // O try/catch só pegava exceção síncrona, que praticamente nunca acontece.
  // Uma falha de gravação de verdade virava rejeição de promessa sem
  // tratamento: invisível na tela e no console. O usuário montava o painel
  // inteiro e só descobria que nada tinha sido salvo na próxima vez que
  // abrisse o programa, com o layout de volta ao que era antes.
  let avisouFalhaAoSalvar = false;
  function salvar() {
    fetch('/api/prefs', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ painel_layouts: state.layouts })
    })
      .then(r => r.json())
      .then(j => {
        if (j && j.success === false) throw new Error(j.error || 'recusado');
        avisouFalhaAoSalvar = false;
      })
      .catch(() => {
        // Uma vez por sequência de falhas: arrastar um widget dispara vários
        // salvamentos seguidos, e um aviso por arrasto viraria uma parede.
        if (avisouFalhaAoSalvar) return;
        avisouFalhaAoSalvar = true;
        if (window.showToast) {
          window.showToast('Não consegui salvar o painel - ele volta ao estado ' +
                           'anterior quando você fechar o programa', 'error');
        }
      });
  }
  function carregar() {
    return window.prefsGet().then(p => {
      if (p && p.painel_layouts && typeof p.painel_layouts === 'object') state.layouts = p.painel_layouts;
      state.carregado = true;
    }).catch(() => { state.carregado = true; });
  }

  /* -- agregação ----------------------------------- */
  function calc(vals, op) {
    const ns = vals.filter(v => !isNaN(v));
    if (op === 'Contagem') return vals.length;
    if (!ns.length) return NaN;
    const soma = ns.reduce((a, b) => a + b, 0);
    switch (op) {
      case 'Soma': case '% do total': case 'Crescimento %': case 'Acumulado': case FORMULA: return soma;
      case 'Média': return soma / ns.length;
      case 'Mínimo': return Math.min.apply(null, ns);
      case 'Máximo': return Math.max.apply(null, ns);
      case 'Mediana': {
        const b = ns.slice().sort((x, y) => x - y), m = b.length >> 1;
        return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2;
      }
      case 'Desvio padrão': {
        if (ns.length < 2) return 0;
        const md = soma / ns.length;
        return Math.sqrt(ns.reduce((s, v) => s + (v - md) * (v - md), 0) / (ns.length - 1));
      }
      default: return soma;
    }
  }

  // Chave de período no grão pedido (dia/mês/ano). Aceita ISO e data BR.
  function chavePeriodo(v, grao) {
    const s = String(v || '');
    let a, m, d;
    const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (iso) { a = iso[1]; m = iso[2]; d = iso[3]; }
    else {
      const br = s.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/);
      if (!br) return null;
      d = String(br[1]).padStart(2, '0');
      m = String(br[2]).padStart(2, '0');
      a = br[3];
    }
    return grao === 'ano' ? a : grao === 'dia' ? (a + '-' + m + '-' + d) : (a + '-' + m);
  }

  // Agrupa por coluna (ou por período) e aplica a operação escolhida.
  function agrupar(f, rows, cfg) {
    const num = V().num;
    const porPeriodo = cfg.grupo === '__periodo__';
    const iG = porPeriodo ? f.headers.indexOf(cfg.colData) : f.headers.indexOf(cfg.grupo);
    const iV = f.headers.indexOf(cfg.valor);
    if (iG < 0) return [];
    const g = new Map();
    rows.forEach(r => {
      const k = porPeriodo ? chavePeriodo(r[iG], cfg.grao || 'mes')
        : (String(r[iG] == null ? '' : r[iG]).trim() || SEM_VALOR);
      if (k === null) return;
      if (!g.has(k)) g.set(k, []);
      g.get(k).push(iV >= 0 ? num(r[iV]) : NaN);
    });
    let saida = [];
    // Formula sem coluna de valor: "atual" e' quantas linhas o grupo tem.
    const opBase = cfg.op === FORMULA && iV < 0 ? 'Contagem' : (cfg.op || 'Soma');
    g.forEach((vals, k) => saida.push({ k: k, v: calc(vals, opBase), n: vals.length }));
    if (porPeriodo) saida.sort((a, b) => String(a.k).localeCompare(String(b.k)));
    else saida.sort((a, b) => (isNaN(b.v) ? -Infinity : b.v) - (isNaN(a.v) ? -Infinity : a.v));

    const op = cfg.op || 'Soma';
    if (op === '% do total') {
      const t = saida.reduce((s, x) => s + (isNaN(x.v) ? 0 : Math.abs(x.v)), 0) || 1;
      saida = saida.map(x => ({ k: x.k, n: x.n, v: Math.abs(x.v) / t * 100 }));
    } else if (op === 'Crescimento %') {
      const orig = saida.slice();
      saida = saida.map((x, i) => ({
        k: x.k, n: x.n,
        v: (i === 0 || !orig[i - 1].v) ? NaN : (x.v - orig[i - 1].v) / Math.abs(orig[i - 1].v) * 100
      }));
    } else if (op === 'Acumulado') {
      let acc = 0;
      saida = saida.map(x => { acc += isNaN(x.v) ? 0 : x.v; return { k: x.k, n: x.n, v: acc }; });
    } else if (op === FORMULA) {
      saida = aplicarFormula(saida, cfg);
    }
    if (cfg.topN > 0 && !porPeriodo) saida = saida.slice(0, cfg.topN);
    return saida;
  }

  /* -- formula propria -----------------------------
   * O Mudancas.md do Naor: "um botao para criar suas proprias formulas, talvez
   * estilo Latex, opcoes uteis com valor atual, valor anterior, media, formula A".
   * Conta por grupo, sobre o valor que a coluna ja' agrupou. Parser proprio, sem
   * eval: o texto vem do usuario e fica salvo no painel.
   */
  const VARS_FORMULA = ['atual', 'anterior', 'media', 'total', 'maior', 'menor', 'n'];
  const FUNCOES_FORMULA = { raiz: 1, abs: 1, arred: 1, min: 2, max: 2 };
  const semAcento = s => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

  // letras: quais colunas existem aqui ('A', 'B'...). Sem ela, nao confere.
  function lerFormula(texto, letras) {
    const fonte = String(texto || '').trim().replace(/valor\s+(atual|anterior)/gi, '$1');
    if (!fonte) return { erro: 'Escreva a fórmula.' };
    const t = fonte.match(/\d+(?:[.,]\d+)?|[A-Za-zÀ-ÿ_]+|\S/g) || [];
    let i = 0;
    const erro = m => { throw new Error(m); };
    function soma() {
      let a = produto();
      while (t[i] === '+' || t[i] === '-' || t[i] === '−') {
        const op = t[i++] === '+' ? '+' : '-';
        a = { t: 'b', op: op, a: a, b: produto() };
      }
      return a;
    }
    function produto() {
      let a = sinal();
      while (t[i] === '*' || t[i] === '/' || t[i] === '×' || t[i] === '÷') {
        const op = (t[i] === '*' || t[i] === '×') ? '*' : '/';
        i++;
        a = { t: 'b', op: op, a: a, b: sinal() };
      }
      return a;
    }
    function sinal() {
      if (t[i] === '-' || t[i] === '−') { i++; return { t: 'm', a: sinal() }; }
      if (t[i] === '+') { i++; return sinal(); }
      const base = valor();
      if (t[i] !== '^') return base;
      i++;
      return { t: 'b', op: '^', a: base, b: sinal() };
    }
    function funcao(nome) {
      i++;                                   // o parentese
      const args = [soma()];
      while (t[i] === ';') { i++; args.push(soma()); }
      if (t[i] !== ')') erro('Falta fechar um parêntese.');
      i++;
      if (args.length < FUNCOES_FORMULA[nome]) erro(nome + ' precisa de dois valores, separados por ponto e vírgula.');
      return { t: 'f', nome: nome, args: args };
    }
    function valor() {
      const x = t[i];
      if (x === undefined) erro('A fórmula acabou no meio: falta um valor no fim.');
      if (x === '(') {
        i++;
        const a = soma();
        if (t[i] !== ')') erro('Falta fechar um parêntese.');
        i++;
        return { t: 'p', a: a };
      }
      if (x === '√') { i++; return { t: 'f', nome: 'raiz', args: [valor()] }; }
      if (/^\d/.test(x)) { i++; return { t: 'n', v: Number(x.replace(',', '.')), txt: x }; }
      if (/^[A-Za-zÀ-ÿ_]/.test(x)) {
        i++;
        const nome = semAcento(x);
        if (t[i] === '(' && FUNCOES_FORMULA[nome]) return funcao(nome);
        if (VARS_FORMULA.indexOf(nome) >= 0) return { t: 'v', nome: nome };
        if (x.length === 1) {
          const L = x.toUpperCase();
          if (letras && letras.indexOf(L) < 0) erro('Não existe a coluna ' + L + ' aqui.');
          return { t: 'c', nome: L };
        }
        erro('Não conheço "' + x + '".');
      }
      erro('Não entendi "' + x + '".');
    }
    try {
      const arvore = soma();
      if (i < t.length) erro(t[i] === ')' ? 'Tem um parêntese fechando sem ter aberto.' : 'Não entendi "' + t[i] + '".');
      return { arvore: arvore };
    } catch (e) {
      return { erro: e.message };
    }
  }

  function calcularFormula(no, v) {
    const c = x => calcularFormula(x, v);
    switch (no.t) {
      case 'n': return no.v;
      case 'v': case 'c': { const x = v[no.nome]; return x === undefined ? NaN : x; }
      case 'p': return c(no.a);
      case 'm': return -c(no.a);
      case 'f': {
        const a = no.args.map(c);
        if (no.nome === 'raiz') return Math.sqrt(a[0]);
        if (no.nome === 'abs') return Math.abs(a[0]);
        if (no.nome === 'arred') return Math.round(a[0] * Math.pow(10, a[1] || 0)) / Math.pow(10, a[1] || 0);
        return no.nome === 'min' ? Math.min.apply(null, a) : Math.max.apply(null, a);
      }
      default: {
        const a = c(no.a), b = c(no.b);
        if (no.op === '+') return a + b;
        if (no.op === '-') return a - b;
        if (no.op === '*') return a * b;
        if (no.op === '/') return a / b;
        return Math.pow(a, b);
      }
    }
  }

  // A mesma conta, escrita como se escreve no papel: fracao em cima da outra,
  // expoente pequeno, raiz com traco.
  function formulaHtml(no) {
    const h = formulaHtml;
    switch (no.t) {
      case 'n': return esc(no.txt);
      case 'v': return '<i>' + esc(no.nome === 'media' ? 'média' : no.nome) + '</i>';
      case 'c': return '<b>' + esc(no.nome) + '</b>';
      case 'p': return no.a.t === 'b' && no.a.op === '/' ? h(no.a) : '(' + h(no.a) + ')';
      case 'm': return '−' + h(no.a);
      case 'f':
        if (no.nome === 'raiz') return '√<span class="fx-raiz">' + h(no.args[0]) + '</span>';
        return esc(no.nome) + '(' + no.args.map(h).join('; ') + ')';
      default:
        if (no.op === '/') return '<span class="fx-frac"><span>' + h(no.a) + '</span><span>' + h(no.b) + '</span></span>';
        if (no.op === '^') return h(no.a) + '<sup>' + h(no.b) + '</sup>';
        return h(no.a) + (no.op === '*' ? ' · ' : no.op === '+' ? ' + ' : ' − ') + h(no.b);
    }
  }

  function aplicarFormula(saida, cfg) {
    const fx = lerFormula(cfg.formula);
    if (fx.erro) return saida.map(x => ({ k: x.k, n: x.n, v: NaN }));
    const vals = saida.map(x => x.v).filter(v => !isNaN(v));
    const total = vals.reduce((a, b) => a + b, 0);
    const base = {
      total: total, media: vals.length ? total / vals.length : NaN,
      maior: vals.length ? Math.max.apply(null, vals) : NaN,
      menor: vals.length ? Math.min.apply(null, vals) : NaN
    };
    return saida.map((x, i) => {
      const v = Object.assign({}, base, { atual: x.v, anterior: i ? saida[i - 1].v : NaN, n: x.n });
      Object.keys(cfg.letras || {}).forEach(L => { v[L] = cfg.letras[L].get(x.k); });
      const r = calcularFormula(fx.arvore, v);
      return { k: x.k, n: x.n, v: isFinite(r) ? r : NaN };
    });
  }

  // Valores de cada coluna (ou serie) por grupo. A formula usa as outras pela
  // letra, A e' a primeira: primeiro as que nao dependem de ninguem, depois as
  // formulas, da esquerda para a direita.
  function valoresPorGrupo(f, c, lista) {
    const le = (s, letras) => {
      const m = new Map();
      agrupar(f, f.rows, { grupo: c.grupo, colData: c.colData, grao: c.grao, valor: s.valor,
        op: s.op, formula: s.formula, letras: letras }).forEach(x => m.set(x.k, x.v));
      return m;
    };
    const saida = [], letras = {};
    const letra = i => String.fromCharCode(65 + i);
    lista.forEach((s, i) => { if (s.op !== FORMULA) { saida[i] = le(s); letras[letra(i)] = saida[i]; } });
    lista.forEach((s, i) => { if (s.op === FORMULA) { saida[i] = le(s, letras); letras[letra(i)] = saida[i]; } });
    return saida;
  }

  // Dois periodos sao vizinhos? (evita comparar dezembro com janeiro do mesmo
  // ano e chamar isso de "crescimento")
  function periodosVizinhos(a, b, grao) {
    if (!a || !b) return false;
    if (grao === 'ano') return (+b - +a) === 1;
    if (grao === 'dia') {
      const d = (k) => { const p = k.split('-'); return Date.UTC(+p[0], +p[1] - 1, +p[2]); };
      return Math.round((d(b) - d(a)) / 86400000) === 1;
    }
    const meses = k => { const p = k.split('-'); return (+p[0]) * 12 + (+p[1] - 1); };
    return (meses(b) - meses(a)) === 1;
  }

  // Mes isolado e' data solta, longe do periodo de verdade da planilha: na da
  // usina, uma linha em jan/2025 e outra em dez/2026 em volta de set/2025 a
  // jan/2026. Conta o mes a 3 meses ou mais do bloco continuo com mais linhas
  // e com menos de 1% das linhas. Recebe a planilha inteira, nao a selecao: com
  // a selecao, um filtro mudava o que e' solto e o mes sumia e voltava.
  function mesesIsolados(rows, iD) {
    if (iD < 0) return [];
    const porMes = new Map();
    let total = 0;
    rows.forEach(r => {
      const k = chavePeriodo(r[iD], 'mes');
      if (!k) return;
      total++;
      porMes.set(k, (porMes.get(k) || 0) + 1);
    });
    const meses = [...porMes.keys()].sort();
    const pos = k => { const p = k.split('-'); return (+p[0]) * 12 + (+p[1] - 1); };
    const blocos = [];
    meses.forEach(k => {
      const b = blocos[blocos.length - 1], i = pos(k);
      if (b && i - b.fim === 1) { b.fim = i; b.n += porMes.get(k); }
      else blocos.push({ ini: i, fim: i, n: porMes.get(k) });
    });
    if (blocos.length < 2) return [];
    const bloco = blocos.reduce((a, b) => (b.n > a.n ? b : a));
    return meses.filter(k => {
      const i = pos(k);
      const longe = i < bloco.ini ? bloco.ini - i : i - bloco.fim;
      return longe >= 3 && porMes.get(k) < total * 0.01;
    });
  }

  const ehPct = op => op === '% do total' || op === 'Crescimento %';
  // Contagem é inteira; % ganha sufixo; demais usam o formato padrão.
  function fmtOp(v, op) {
    const viz = V();
    if (isNaN(v) || v === undefined) return '—';
    if (op === 'Contagem') return viz.fmt(v, 0);
    return viz.fmt0(v) + (ehPct(op) ? '%' : '');
  }

  /* -- export via backend (funciona no PC da empresa) -- */
  async function exportarAoa(aoa, baseName) {
    try {
      let path = null;
      if (window.pywebview && window.pywebview.api && window.pywebview.api.save_file_dialog) {
        path = await window.pywebview.api.save_file_dialog(baseName + '.xlsx');
        if (!path) return;
      }
      const r = await fetch('/api/export_aoa', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ aoa: aoa, path: path, sheet_name: 'Dados', base_name: baseName })
      });
      const ct = r.headers.get('content-type') || '';
      if (ct.indexOf('json') >= 0) {
        const j = await r.json();
        if (window.showToast) window.showToast(j.success ? 'Planilha salva' : ('Erro: ' + (j.error || '')), j.success ? 'success' : 'error');
        return;
      }
      const blob = await r.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = baseName + '.xlsx';
      a.click();
      URL.revokeObjectURL(a.href);
    } catch (_) {
      if (window.showToast) window.showToast('Falha ao exportar', 'error');
    }
  }


  /* -- foco: clicar num gráfico filtra o painel inteiro --
   * É o que a Análise já fazia. Não é salvo em disco de propósito: filtro é
   * pergunta do momento, e reabrir mostrando um cliente só pareceria que a
   * planilha encolheu. */
  const foco = { tipo: null, col: null, grao: 'mes', vals: [] };

  function limparFoco() { foco.tipo = null; foco.col = null; foco.vals = []; }

  const chaveDe = (r, i, tipo, grao) => tipo === 'periodo' ? chavePeriodo(r[i], grao)
    : (String(r[i] == null ? '' : r[i]).trim() || SEM_VALOR);

  function focar(cfg, rotulo) {
    const porPeriodo = cfg.grupo === '__periodo__';
    const col = porPeriodo ? cfg.colData : cfg.grupo;
    const tipo = porPeriodo ? 'periodo' : 'coluna';
    const grao = cfg.grao || 'mes';
    if (!col || rotulo == null) return;
    // "Outros" e' o balde que o desenho criou, nao um valor da planilha. Filtrar
    // por ele nao acha linha nenhuma: o painel inteiro zerava e cada quadro
    // dizia que nao tinha dados.
    const f = dados(), iC = f ? f.headers.indexOf(col) : -1;
    if (iC >= 0 && !f.rows.some(r => chaveDe(r, iC, tipo, grao) === rotulo)) {
      if (window.showToast) window.showToast('"' + rotulo + '" junta vários grupos - clique numa barra com nome para filtrar');
      return;
    }
    // Trocar de coluna zera a seleção. Empilhar "CLIENTE = A" com "PRODUTO = B"
    // dá interseção, e quase sempre vazia - o painel esvaziaria e pareceria bug.
    // Trocar de grão também: um mês na seleção de um gráfico por dia nunca casa,
    // e o clique não fazia nada.
    if (foco.col !== col || foco.tipo !== tipo || (porPeriodo && foco.grao !== grao)) {
      foco.tipo = tipo; foco.col = col; foco.grao = grao; foco.vals = [];
    }
    const i = foco.vals.indexOf(rotulo);
    if (i >= 0) foco.vals.splice(i, 1); else foco.vals.push(rotulo);
    if (!foco.vals.length) limparFoco();
    render();
  }

  function aplicarFoco(f) {
    if (!foco.tipo || !foco.vals.length) return f;
    const i = f.headers.indexOf(foco.col);
    if (i < 0) return f;                       // coluna sumiu: mostra tudo
    const rows = f.rows.filter(r => foco.vals.indexOf(chaveDe(r, i, foco.tipo, foco.grao)) >= 0);
    return { headers: f.headers, rows: rows, todas: f.todas, sheet: f.sheet,
             focoPeriodo: foco.tipo === 'periodo' ? { col: foco.col, base: f } : null };
  }

  // Só devolve a função de clique quando há mesmo por onde filtrar; senão o
  // cursor vira mãozinha num gráfico que não reage.
  function cliqueDe(cfg) {
    const col = cfg.grupo === '__periodo__' ? cfg.colData : cfg.grupo;
    return col ? (rotulo => focar(cfg, rotulo)) : null;
  }

  function barraDeFoco(host) {
    if (!foco.vals.length) return;
    const nome = foco.tipo === 'periodo' ? 'período' : foco.col;
    const barra = document.createElement('div');
    barra.className = 'pan-foco';
    barra.innerHTML = '<span class="pan-foco-tit">Filtrando por ' + esc(nome) + ':</span>' +
      foco.vals.map((v, i) => '<button type="button" class="pan-foco-chip" data-i="' + i + '">' +
        esc(v) + ' <i>✕</i></button>').join('') +
      '<button type="button" class="pan-foco-limpar">limpar</button>';
    barra.querySelectorAll('.pan-foco-chip').forEach(b => {
      b.addEventListener('click', () => {
        foco.vals.splice(parseInt(b.dataset.i), 1);
        if (!foco.vals.length) limparFoco();
        render();
      });
    });
    barra.querySelector('.pan-foco-limpar').addEventListener('click', () => { limparFoco(); render(); });
    host.appendChild(barra);
  }

  /* -- render do canvas ---------------------------- */
  function render() {
    const host = $('pan-body');
    if (!host) return;
    // A dica do grafico e' uma so' para todos. Com o canvas trocado debaixo do
    // mouse o "saiu de cima" nunca chega, e ela ficava parada na tela.
    if (V().esconderDica) V().esconderDica();
    let f = dados();
    if (!f) {
      host.innerHTML = '<div class="graf-empty-state"><div class="empty-icon">◈</div>' +
        '<p>Abra uma planilha para montar seu painel</p>' +
        '<p class="empty-sub">Depois clique com o botão direito no espaço vazio para adicionar gráficos e tabelas</p></div>';
      const i0 = $('pan-info');
      if (i0) i0.textContent = 'Sem planilha ativa';
      return;
    }
    // Planilha nova, pergunta nova: um filtro de CLIENTE herdado de outra
    // planilha esconderia quase tudo sem explicação.
    const outraPlanilha = f.sheet !== state.sheet;
    if (outraPlanilha) { state.sheet = f.sheet; limparFoco(); }
    const L = layout();
    const total = f.rows.length;
    f = aplicarFoco(f);
    // Esvaziar o corpo zera a rolagem: clicar num grafico la' embaixo, ou
    // confirmar as propriedades dele, jogava a tela para o topo.
    const rolX = outraPlanilha ? 0 : host.scrollLeft, rolY = outraPlanilha ? 0 : host.scrollTop;
    host.innerHTML = '';
    barraDeFoco(host);
    const div = document.createElement('div');
    div.id = 'pan-canvas'; div.className = 'pan-canvas';
    host.appendChild(div);
    const canvas = $('pan-canvas');

    if (!L.length) {
      canvas.innerHTML = '<div class="pan-hint"><b>Painel vazio</b>' +
        '<span>Clique com o botão direito no fundo para adicionar um widget</span>' +
        '<button class="primary-btn" id="pan-add-first" type="button">Montar painel automático</button></div>';
      const bt = $('pan-add-first');
      if (bt) bt.addEventListener('click', ev => { ev.stopPropagation(); painelAutomatico(); });
    }

    // Duas passadas, e nao uma: PRIMEIRO todos os widgets entram na tela,
    // DEPOIS eles se desenham.
    //
    // Desenhando junto com a criacao, o canvas ainda estava fora da pagina e
    // medir a largura dele dava zero - caia no tamanho de reserva (700px) e o
    // CSS esticava para o tamanho de verdade. No "Volume por cliente" eram
    // 700px esticados para 2280: barra larga e texto borrado. Foi o que o
    // Naor fotografou.
    let maxB = 0, maxR = 0;
    const criados = [];
    L.forEach(it => {
      const el = criarWidget(f, it);
      canvas.appendChild(el);
      criados.push([el, it]);
      maxB = Math.max(maxB, (it.y || 0) + (it.h || 240));
      maxR = Math.max(maxR, (it.x || 0) + (it.w || 360));
    });
    criados.forEach(([el, it]) => desenharWidget(f, it, el));
    canvas.style.minHeight = Math.max(maxB + GRID * 4, 380) + 'px';
    // A largura tambem: sem isto o canvas ficava do tamanho da tela e um
    // widget mais largo transbordava sem o canvas saber.
    canvas.style.minWidth = Math.max(maxR + GRID * 2, 0) + 'px';
    host.scrollLeft = rolX;
    host.scrollTop = rolY;
    canvas.addEventListener('contextmenu', e => {
      if (e.target.closest('.pan-widget')) return;
      e.preventDefault();
      menuCanvas(e.clientX, e.clientY);
    });

    const info = $('pan-info');
    if (info) {
      info.textContent = (state.sheet || '') + ' · ' + L.length + ' widget(s) · ' +
        f.rows.length.toLocaleString('pt-BR') + ' linhas' +
        (f.rows.length !== total ? ' (de ' + total + ')' : '');
    }
  }

  function criarWidget(f, it) {
    const el = document.createElement('div');
    el.className = 'pan-widget';
    el.dataset.wid = it.id;
    el.style.left = (it.x || 0) + 'px';
    el.style.top = (it.y || 0) + 'px';
    el.style.width = (it.w || 380) + 'px';
    el.style.height = (it.h || 240) + 'px';
    el.innerHTML = '<div class="pan-w-head"><span class="pan-w-tit">' +
      esc(it.config.titulo || tituloAuto(it)) + '</span>' +
      '<span class="pan-w-tag">' + esc(rotuloTipo(it)) + '</span></div>' +
      '<div class="pan-w-body"></div><div class="pan-w-resize" title="Redimensionar"></div>';
    el.addEventListener('contextmenu', e => {
      e.preventDefault(); e.stopPropagation();
      menuWidget(e.clientX, e.clientY, it);
    });
    arrastar(el, it);
    redimensionar(el, it);
    return el;
  }

  // Chamada depois de o widget ja' estar na pagina, para o canvas conseguir
  // se medir.
  function desenharWidget(f, it, el) {
    const body = el.querySelector('.pan-w-body');
    if (!body) return;
    body.innerHTML = '';
    try {
      desenhar(f, it, body);
    } catch (err) {
      body.innerHTML = '<p class="pan-erro">Não foi possível montar este widget.<br><small>' +
        esc(err.message) + '</small></p>';
    }
  }

  const rotuloTipo = it => it.type === 'grafico' ? (it.config.tipo === 'barraH' ? 'barra deitada' : it.config.tipo || 'barra')
    : it.type === 'distribuicao' ? 'distribuição'
      : it.type === 'comparar' ? 'comparação' : it.type === 'falhas' ? 'ranking' : it.type;

  function tituloAuto(it) {
    const c = it.config;
    const alvo = c.grupo === '__periodo__' ? 'período' : (c.grupo || '—');
    if (it.type === 'dado') return (c.op || 'Soma') + ' de ' + (c.valor || '—');
    if (it.type === 'tabela') return 'Por ' + alvo;
    if (it.type === 'insights') return 'Insights automáticos';
    if (it.type === 'distribuicao') return 'Distribuição de ' + (c.valor || 'resistência');
    if (it.type === 'comparar') return (c.grao && c.grao !== 'mes' ? 'Comparar períodos' : 'Comparar meses') + (c.grupo ? ' por ' + c.grupo : '');
    if (it.type === 'falhas') return 'Falhas por ' + (c.grupo || 'receita');
    return (c.valor || 'Contagem') + ' por ' + alvo;
  }

  // Colunas que servem para dividir/agrupar: texto com poucos valores repetidos.
  function colunasDeTexto(f) {
    const viz = V();
    const out = [];
    f.headers.forEach((h, i) => {
      const amostra = f.rows.slice(0, 200).map(r => r[i]).filter(v => String(v || '').trim());
      if (!amostra.length) return;
      const numericos = amostra.filter(v => !isNaN(viz.num(v))).length;
      if (numericos > amostra.length * 0.5) return;          // e' coluna de numero
      const distintos = new Set(amostra.map(v => String(v))).size;
      // No maximo 12 valores distintos: com mais que isso o empilhado vira um
      // arco-iris ilegivel (foi o que aconteceu na planilha real do Naor).
      if (distintos > 1 && distintos <= 12) out.push({ h: h, n: distintos });
    });
    // menos categorias primeiro: da' o empilhado mais legivel
    return out.sort((a, b) => a.n - b.n).map(x => x.h);
  }

  /* -- desenho por tipo ---------------------------- */
  function desenhar(f, it, body) {
    const c = it.config, viz = V();
    if (it.type === 'dado') return desenharDado(f, it, body);
    if (it.type === 'insights') {
      const iD = f.headers.indexOf(c.colData);
      const iV = f.headers.indexOf(c.valor);
      const iC = f.headers.indexOf(c.grupo);
      const ins = viz.gerarInsights ? viz.gerarInsights(f, f.rows, iD, iV, iC) : [];
      body.innerHTML = ins.length
        ? '<div class="ana-ins pan-ins">' + ins.map(i =>
            '<div class="ins-card ' + i.cls + '"><span class="ins-ico">' + i.ico +
            '</span><span>' + i.txt + '</span></div>').join('') + '</div>'
        : '<p class="pan-vazio">Sem insights - defina Data e Valor nas propriedades.</p>';
      return;
    }
    if (it.type === 'distribuicao') return desenharDistribuicao(f, it, body);
    if (it.type === 'comparar') return desenharComparacao(f, it, body);
    if (it.type === 'falhas') return desenharFalhas(f, it, body);
    if (it.type === 'tabela') return desenharTabela(f, it, body);

    const eixo = recorteDoEixo(f, it);
    if (eixo.fora) avisarForaDoEixo(body, eixo.fora, it.config.colData);    // antes: o grafico reserva a altura dele
    desenharGrafico(eixo.f, it, body);
    // Insights valem para QUALQUER tipo de grafico - antes so' a tabela tinha
    // a opcao, e no empilhado a faixa nem aparecia.
    if (c.insights) anexarInsights(eixo.f, it, body);
  }

  // Grafico por data deixa mes isolado fora do eixo. Por mes, por dia ou por
  // ano, para os numeros baterem entre os graficos. O mapa
  // de calor tem o corte dele, e a tabela nao tem eixo: mostra tudo.
  function recorteDoEixo(f, it) {
    const c = it.config, igual = { f: f, fora: null };
    if (it.type !== 'grafico' || c.tipo === 'calor' ||
        c.grupo !== '__periodo__' || c.mostrarIsolados) return igual;
    const corte = tirarMesesSoltos(f.todas || f.rows, f.rows, f.headers.indexOf(c.colData));
    if (!corte.fora) return igual;
    return { f: Object.assign({}, f, { rows: corte.rows }), fora: corte.fora };
  }

  // Os meses soltos saem contados da planilha inteira, mas o corte e' sobre as
  // linhas da tela. Dashboard e Analise usam o mesmo, para os graficos baterem.
  function tirarMesesSoltos(todas, rows, iD) {
    const igual = { rows: rows, fora: null };
    const soltos = mesesIsolados(todas, iD);
    if (!soltos.length) return igual;
    const fora = new Map();
    let ficam = 0;
    const resto = rows.filter(r => {
      const k = chavePeriodo(r[iD], 'mes');
      if (k && soltos.indexOf(k) >= 0) { fora.set(k, (fora.get(k) || 0) + 1); return false; }
      if (k) ficam++;
      return true;
    });
    // Filtro que deixou so' o mes solto: quem filtrou quer ver aquele mes.
    if (!fora.size || !ficam) return igual;
    return { rows: resto, fora: fora };
  }

  // Leva para a planilha so' com as linhas dos meses soltos: e' la' que a data se
  // corrige, e sem isto a pessoa teria de caca-las entre milhares.
  function botaoVerLinhas(coluna) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'nota-ver';
    b.textContent = 'Ver essas linhas';
    b.addEventListener('click', ev => {
      ev.stopPropagation();
      const d = window.getConcrestatsData({ filtered: false });
      const iD = d.headers.indexOf(coluna);
      const soltos = mesesIsolados(d.data, iD);
      const valores = new Set();
      d.data.forEach(r => { if (soltos.indexOf(chavePeriodo(r[iD], 'mes')) >= 0) valores.add(String(r[iD])); });
      if (valores.size && window.ConcrestatsFiltrarValores) window.ConcrestatsFiltrarValores(coluna, [...valores]);
    });
    return b;
  }

  function textoForaDoEixo(fora) {
    const nomes = [...fora.keys()].sort().map(rotuloMes);
    let linhas = 0;
    fora.forEach(n => { linhas += n; });
    const lista = nomes.length > 6 ? nomes.slice(0, 6).join(', ') + ' e mais ' + (nomes.length - 6) : nomes.join(', ');
    return 'Fora do gráfico: ' + lista + ' (' + linhas + (linhas === 1 ? ' linha' : ' linhas') +
      ') - data solta, longe do período da planilha.';
  }

  // Fica dentro do quadro e embaixo do grafico, nunca sem dizer quais e quantas.
  function avisarForaDoEixo(body, fora, coluna) {
    const p = document.createElement('p');
    p.className = 'pan-nota pan-nota-fora';
    p.textContent = textoForaDoEixo(fora) + ' Para ver no gráfico, marque "Mostrar meses isolados" nas propriedades. ';
    p.appendChild(botaoVerLinhas(coluna));
    body.appendChild(p);
  }

  // Largura minima por barra para o nome embaixo continuar legivel.
  const PX_POR_GRUPO = 38;

  // Passou do limite? As maiores ficam e o resto vira uma barra "Outros (N)".
  // Esconder a cauda sem dizer que ela existe faria o total do grafico nao
  // bater com o da tabela ao lado.
  function limitarComOutros(dat, limite) {
    if (!limite || dat.length <= limite) return dat;
    const ficam = dat.slice(0, limite - 1);
    const resto = dat.slice(limite - 1);
    const soma = resto.reduce((a, x) => a + (isNaN(x.v) ? 0 : x.v), 0);
    ficam.push({ k: 'Outros (' + resto.length + ')', v: soma,
                 n: resto.reduce((a, x) => a + (x.n || 0), 0) });
    return ficam;
  }
  function esticarParaCaber(canvas, quantos) {
    if (!canvas) return;
    const area = canvas.parentElement;
    const disponivel = (area && area.clientWidth) || 600;
    const preciso = quantos * PX_POR_GRUPO;
    const rola = preciso > disponivel;
    canvas.style.width = rola ? preciso + 'px' : '100%';
    // Diz ao desenho a largura, em vez de deixar ele medir.
    //
    // Medir logo depois de mexer no style devolve o valor ANTIGO - conferi no
    // navegador: mudar para 100% e ler na linha seguinte ainda dava 2280. O
    // desenho saia num bitmap de 588px e o CSS esticava para 2280: barra gorda
    // e texto borrado, que e' a foto que o Naor mandou.
    canvas.dataset.larguraAlvo = String(Math.round(rola ? preciso : disponivel));
  }

  function anexarInsights(f, it, body) {
    const c = it.config, viz = V();
    let dados = [];
    try { dados = agrupar(f, f.rows, c) || []; } catch (e) { dados = []; }
    if (!dados.length) return;
    const faixa = document.createElement('div');
    faixa.className = 'pan-ins-faixa';
    faixa.innerHTML = montarInsightsTabela(dados, viz);
    if (!faixa.innerHTML.trim()) return;
    body.appendChild(faixa);

    // A faixa entra DEPOIS do gráfico, e o corpo do widget tem overflow
    // escondido. Sem devolver ao gráfico a altura que ela ocupa, ela nasce
    // fora da área visível e o usuário vê o gráfico inteiro e nenhum insight -
    // "os insights se escondem embaixo do gráfico".
    const cv = body.querySelector('canvas');
    if (!cv) return;

    // A faixa so' pode ser medida depois que o navegador a colocou na tela, e
    // isso nao acontece nem no mesmo instante nem no quadro seguinte: o widget
    // e' montado solto e so' depois entra no documento. Enquanto esta' solto,
    // offsetHeight devolve 0 - e uma conta feita com esse zero devolvia ao
    // grafico a altura inteira, jogando os insights para fora da area visivel.
    //
    // O observador resolve sem chutar quando medir: ele avisa no momento em
    // que a faixa ganha altura de verdade, seja quando for.
    const ajustar = () => {
      const alturaFaixa = faixa.offsetHeight;
      if (!alturaFaixa || !body.clientHeight) return false;

      // Mede a CAIXA, nao reconstroi a altura a partir de it.h mais uma soma
      // de constantes: bastava um padding mudar no CSS para a conta errar.
      const nota = body.querySelector('.pan-nota-fora');
      const disponivel = body.clientHeight - alturaFaixa - (nota ? nota.offsetHeight + 6 : 0) - 8;
      const MIN_GRAFICO = 90;

      // Quando nem o grafico minimo mais a faixa cabem, encolher mais nao
      // resolve - alguma coisa fica de fora de qualquer jeito. Ai' o quadro
      // passa a rolar, para o conteudo ficar alcancavel em vez de sumir calado.
      const cabeTudo = disponivel >= MIN_GRAFICO;
      body.style.overflowY = cabeTudo ? '' : 'auto';
      body.title = cabeTudo ? '' :
        'Role dentro do quadro para ver os insights, ou aumente a altura em Editar propriedades';

      const altura = Math.max(MIN_GRAFICO, disponivel);
      const atual = parseFloat(cv.style.height);
      // Comparacao ao contrario de proposito: na primeira vez o canvas nao tem
      // altura inline, parseFloat('') da' NaN, e "NaN > 4" seria FALSO.
      if (!(Math.abs(atual - altura) <= 4)) {
        cv.style.height = altura + 'px';
        // A altura vai TAMBEM no invólucro. Canvas tem tamanho próprio (os
        // atributos width/height), e em alguns contextos é ele que decide a
        // caixa, ignorando o style - aí a div em volta continuava com a altura
        // antiga e empurrava a faixa para fora. A div obedece sempre.
        if (cv.parentElement) cv.parentElement.style.height = altura + 'px';
        desenharGrafico(f, it, body, cv);
        if (faixa.parentElement === body) body.appendChild(faixa);

        // Segunda passada. A conta acima nao tem como saber de tudo que ocupa
        // espaco - margem da faixa, padding do corpo, a barra de rolagem de
        // 8px que aparece dentro do invólucro quando o grafico e' largo. Em
        // vez de tentar prever cada um, mede a sobra REAL e desconta. Uma
        // passada basta: a segunda medida ja' inclui tudo.
        const sobra = body.scrollHeight - body.clientHeight;
        if (sobra > 2 && cv.parentElement) {
          const corrigida = Math.max(MIN_GRAFICO, altura - sobra);
          cv.style.height = corrigida + 'px';
          cv.parentElement.style.height = corrigida + 'px';
          desenharGrafico(f, it, body, cv);
          if (faixa.parentElement === body) body.appendChild(faixa);
          // se nem assim couber, o quadro rola em vez de cortar calado
          if (body.scrollHeight - body.clientHeight > 2) {
            body.style.overflowY = 'auto';
            body.title = 'Role dentro do quadro para ver os insights, ' +
              'ou aumente a altura em Editar propriedades';
          }
        }
      }
      return true;
    };

    if (!ajustar() && typeof ResizeObserver === 'function') {
      const obs = new ResizeObserver(() => { if (ajustar()) obs.disconnect(); });
      obs.observe(faixa);
      // rede de seguranca: em navegador sem ResizeObserver util, tenta de novo
      setTimeout(() => { if (ajustar()) obs.disconnect(); }, 120);
    }
  }

  function desenharGrafico(f, it, body, canvasExistente) {
    const c = it.config, viz = V();
    if (c.tipo === 'calor') return desenharCalor(f, it, body);
    let canvas = canvasExistente;
    if (!canvas) {
      // O aviso de meses fora ja' esta' no quadro: o grafico entra acima dele e
      // cede a altura, senao o aviso nasce cortado pelo overflow do corpo.
      const nota = body.querySelector('.pan-nota-fora');
      canvas = document.createElement('canvas');
      canvas.style.width = '100%';
      canvas.style.height = Math.max(90, (it.h || 240) - HEADER_H - 16 - (nota ? nota.offsetHeight + 6 : 0)) + 'px';
      // O grafico vive dentro de uma area que ROLA de lado. Com muitas
      // categorias ele fica largo em vez de espremer tudo e virar um borrao
      // (era a diferenca que o Naor viu entre o Painel e o mapa de calor).
      const rolagem = document.createElement('div');
      rolagem.className = 'pan-graf-scroll';
      rolagem.appendChild(canvas);
      body.insertBefore(rolagem, nota);
    }
    // O TIPO escolhido manda. Antes, um gráfico com séries extras ignorava o
    // tipo (pizza/empilhado) e continuava desenhando o combo - parecia que
    // "editar as propriedades não muda nada".
    if (c.tipo === 'empilhado') {
      // Escolher "Barra empilhada" sem dizer POR QUE dividir nao tem como
      // funcionar. Antes caia num grafico comum, e parecia que a edicao do
      // painel nao fazia efeito nenhum.
      if (c.serieCat) return desenharEmpilhado(f, it, canvas);
      const cand = colunasDeTexto(f).filter(h => h !== c.grupo);
      if (cand.length) {
        c.serieCat = cand[0];
        salvar();
        return desenharEmpilhado(f, it, canvas);
      }
      canvas.remove();
      body.innerHTML = '<p class="pan-vazio">Para empilhar, escolha em ' +
        '<b>Dividir barras por</b> qual coluna separa as fatias ' +
        '(ex.: CLIENTE, REGIÃO).</p>';
      return;
    }
    if ((c.tipo === 'barra' || !c.tipo) && (c.series || []).length) return desenharCombo(f, it, canvas);
    if (c.tipo === 'linha') {
      const series = (c.series || []).length ? c.series : [{ valor: c.valor, op: c.op || 'Soma',
        formula: c.formula, tipo: 'linha', eixo: 'esq', cor: '#2a5298', titulo: c.titulo }];
      return desenharCombo(f, { config: Object.assign({}, c, { series: series }) }, canvas);
    }

    // Ate' 60 barras, deixando a area rolar de lado. Nao funcionava: o desenho
    // saia num bitmap do tamanho da area e o navegador esticava o resto, que e'
    // a barra gorda e borrada que o Naor fotografou. E 60 barras em 590px sao
    // 9px cada, com o nome de pe' - ilegivel mesmo quando desenhava certo.
    //
    // Agora e' o que o Dashboard ja' fazia: mostra as maiores e junta o resto
    // numa barra so'. Cabe na area, nao estica, e da' para ler.
    const dat = limitarComOutros(agrupar(f, f.rows, c), c.topN || 12);
    if (!dat.length) {
      body.innerHTML = '<p class="pan-vazio">Sem dados para os campos escolhidos.</p>';
      return;
    }
    const sufixo = ehPct(c.op) ? '%' : '';
    const fv = v => viz.fmt0(v) + sufixo;
    esticarParaCaber(canvas, dat.length);
    const aoClicar = cliqueDe(c);
    // A lista vazia no fim: quem marca barra selecionada e' a Analise. Sem ela,
    // o clique dado la' pintava de laranja a barra de mesmo nome aqui.
    if (c.tipo === 'barraH') {
      canvas.style.width = '100%';          // deitada cresce para baixo, nao rola de lado
      canvas.dataset.larguraAlvo = String((canvas.parentElement && canvas.parentElement.clientWidth) || 600);
      viz.drawBarsH(canvas, dat.map(d => d.k), dat.map(d => d.v), aoClicar, fv, []);
    } else if (c.tipo === 'pizza') {
      canvas.style.width = '100%';          // pizza nao rola: nao tem eixo
      // ...e a largura pedida para rolar nao vale: num quadro estreito o desenho
      // saia largo e o CSS amassava a pizza.
      canvas.dataset.larguraAlvo = String((canvas.parentElement && canvas.parentElement.clientWidth) || 600);
      viz.drawDonut(canvas, dat.map(d => d.k), dat.map(d => d.v), aoClicar, []);
    } else {
      viz.drawBars(canvas, dat.map(d => d.k), dat.map(d => d.v), aoClicar, fv, []);
    }

  }


  /* -- distribuição (histograma de resistência x fck) --
   *
   * Este era o único widget que faltava para o Painel dar conta do que o
   * Dashboard dá: o desenho é o MESMO (window.ConcreLab.drawDistribuicao), não
   * uma segunda versão parecida. Dois histogramas independentes acabariam
   * discordando um dia, e quem visse a diferença não saberia em qual acreditar.
   */
  function colunasIrmas(f, col) {
    // Na planilha do laboratório os corpos de prova do mesmo dia ficam em
    // colunas repetidas: "MPA 28", "MPA 28.1", "MPA 28.2". Ler só a escolhida
    // mostraria um terço dos ensaios - e o histograma do Painel não bateria
    // com o do Dashboard, que junta todas.
    const lab = LAB();
    if (!lab.colsFor || !lab.baseName) {
      const i = f.headers.indexOf(col);
      return i >= 0 ? [i] : [];
    }
    return lab.colsFor(f.headers, lab.baseName(col));
  }

  /* Lê uma coluna de ensaio pelas regras do laboratório: junta as colunas
   * irmãs, ignora o zero (ensaio não rompido) e tira o que é impossível para
   * concreto. É a MESMA leitura do histograma - sem isso o cartão "Desvio
   * padrão" mostrava 47,58 MPa logo acima de um histograma dizendo 13,01, na
   * mesma tela. Dois números discordando ali derrubam a confiança nos dois. */
  function lerEnsaio(f, coluna) {
    const lab = LAB();
    if (!lab.poolNums) return { vals: [], fora: [], limite: NaN, cols: [] };
    const cols = colunasIrmas(f, coluna);
    const brutos = lab.poolNums(f.rows, cols, true);
    const sep = lab.separarImpossiveis ? lab.separarImpossiveis(brutos)
      : { bons: brutos, fora: [], limite: NaN };
    return { vals: sep.bons, fora: sep.fora, limite: sep.limite, cols: cols };
  }

  function desenharDistribuicao(f, it, body) {
    const c = it.config, lab = LAB(), viz = V();
    if (!lab.drawDistribuicao) {
      body.innerHTML = '<p class="pan-vazio">Estatística de laboratório indisponível.</p>';
      return;
    }
    if (!c.valor) {
      body.innerHTML = '<p class="pan-vazio">Escolha em <b>Coluna de valor</b> a ' +
        'resistência a analisar (ex.: MPA 28).</p>';
      return;
    }

    // zero não é ruptura fraca, é ensaio que ainda não foi rompido; e o que é
    // grande demais para ser concreto sai do cálculo.
    const sep = lerEnsaio(f, c.valor);
    const cols = sep.cols;
    const vals = sep.vals;

    const numeros = document.createElement('div');
    numeros.className = 'dist-numeros';
    const rolagem = document.createElement('div');
    rolagem.className = 'pan-graf-scroll';
    const canvas = document.createElement('canvas');
    canvas.style.width = '100%';
    canvas.style.height = Math.max(120, (it.h || 360) - HEADER_H - 116) + 'px';
    rolagem.appendChild(canvas);
    const legenda = document.createElement('div');
    legenda.className = 'dist-legenda';
    body.appendChild(numeros); body.appendChild(rolagem); body.appendChild(legenda);

    if (!vals.length) {
      legenda.innerHTML = '<span class="dist-vazio">Sem resultado em ' +
        esc(c.valor) + ' nesta seleção</span>';
      return;
    }

    // fck manual ganha do automático: numa planilha sem PRODUTO/RECEITA o
    // automático não acha nada, e sem limite o gráfico não diz o que reprovou.
    const manual = parseFloat(String(c.fck || '').replace(',', '.'));
    const auto = lab.fckPredominante(f.rows, f.headers);
    const fck = isNaN(manual) ? auto.fck : manual;
    const quantos = isNaN(manual) ? auto.quantos : 1;

    const media = vals.reduce((a, b) => a + b, 0) / vals.length;
    const dp = lab.desvioPadrao(vals, media);
    const cv = (!isNaN(dp) && media > 0) ? (dp / media * 100) : NaN;
    const abaixo = !isNaN(fck) ? vals.filter(v => v < fck).length : 0;

    lab.drawDistribuicao(canvas, vals, fck);

    const numero = (rotulo, valor, obs) =>
      '<div class="dist-num"><b>' + valor + '</b><span>' + rotulo + '</span>' +
      (obs ? '<i>' + obs + '</i>' : '') + '</div>';
    numeros.innerHTML =
      numero('Corpos de prova', vals.length) +
      numero('Média', viz.fmt(media, 1) + ' MPa') +
      numero('Desvio padrão', isNaN(dp) ? '—' : viz.fmt(dp, 2) + ' MPa', 'constância da usina') +
      numero('Coef. de variação', isNaN(cv) ? '—' : viz.fmt(cv, 1) + '%') +
      (!isNaN(fck)
        ? numero('Abaixo do fck', abaixo, viz.fmt(abaixo / vals.length * 100, 1) + '% do total')
        : '');

    const item = (cor, texto) =>
      '<span class="dist-item"><i class="dist-cor" style="background:' + cor + '"></i>' + texto + '</span>';
    let leg = '';
    if (!isNaN(fck)) {
      leg += item('#2a5298', 'Atingiu o fck (' + viz.fmt(fck, 0) + ' MPa)') +
        item('#b33a2a', 'Abaixo do fck') +
        '<span class="dist-item"><i class="dist-tracejado"></i>Limite do projeto</span>';
      if (quantos > 1) {
        leg += '<span class="dist-alerta">Esta seleção tem ' + quantos + ' fck diferentes. ' +
          'A linha marca o mais frequente; para ler a distribuição de um só, filtre por produto.</span>';
      }
    } else {
      leg += item('#2a5298', 'Corpos de prova') +
        '<span class="dist-alerta">Sem fck na coluna de produto ou receita, ' +
        'não dá para marcar o limite do projeto. Informe-o nas propriedades.</span>';
    }
    if (cols.length > 1) {
      leg += '<span class="dist-item">' + cols.length + ' colunas de ' +
        esc(lab.baseName ? lab.baseName(c.valor) : c.valor) + ' somadas</span>';
    }
    if (sep.fora.length) {
      leg += '<span class="dist-alerta">' + sep.fora.length + ' ' +
        (sep.fora.length === 1 ? 'resultado ficou' : 'resultados ficaram') +
        ' de fora do cálculo por passar de ' + viz.fmt(sep.limite, 0) + ' MPa (' +
        sep.fora.map(v => viz.fmt(v, 0)).join(', ') + '). Concreto não chega lá - ' +
        'provavelmente é erro de digitação na planilha.</span>';
    }
    legenda.innerHTML = leg;
  }

  /* Comparar meses (item 17 da lista; o Naor: "isso já está meio caminho
   * andado"). O Painel já agrupava por mês; faltava pôr dois meses lado a
   * lado, por receita ou obra, nas medidas que dizem se a usina melhorou: a
   * média do exemplar aos 28 dias, o desvio e quantos ficaram abaixo do fck.
   * Exemplar = o maior dos dois CPs, como no relatório e na Previsão. */
  const rotuloMes = k => {
    const p = String(k || '').split('-');
    const nomes = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
    const nome = p.length === 2 ? nomes[(+p[1]) - 1] : '';
    return nome ? nome + '/' + p[0] : String(k || '');
  };
  // Comparar nao e' so' mes com mes: "2025 x 2026" e "este trimestre x o anterior"
  // usam a mesma conta. A chave sai sempre do mes da linha.
  function chaveCmp(v, grao) {
    const m = chavePeriodo(v, 'mes');
    if (!m) return '';
    if (grao === 'ano') return m.slice(0, 4);
    if (grao === 'trimestre') return m.slice(0, 4) + '-T' + (Math.floor((+m.slice(5, 7) - 1) / 3) + 1);
    return m;
  }
  const rotuloCmp = k => (/^\d{4}$/.test(k) ? k : /-T\d$/.test(k) ? k.slice(6) + 'º tri/' + k.slice(0, 4) : rotuloMes(k));
  function mesesDa(f, colData, grao) {
    const iD = f.headers.indexOf(colData);
    if (iD < 0) return [];
    const s = new Set();
    f.rows.forEach(r => { const k = chaveCmp(r[iD], grao || 'mes'); if (k) s.add(k); });
    return [...s].sort();
  }
  function compararMeses(f, c) {
    const H = f.headers, cc = window.ConcreColunas, lab = LAB();
    const iD = H.indexOf(c.colData), iG = c.grupo ? H.indexOf(c.grupo) : -1;
    const grao = c.grao || 'mes';
    const meses = mesesDa(f, c.colData, grao);
    if (iD < 0 || meses.length < 2) return { meses };
    // Automático: os dois últimos meses do período de verdade. Mês no futuro e
    // mês isolado são data digitada errada (na planilha da usina, uma linha em
    // dez/2026), e compará-los daria "1.091 ensaios -> 1". Olhar só o calendário
    // não bastava: passado dezembro, a mesma linha virava o último mês.
    const agora = new Date();
    const mesAtual = chaveCmp(agora.getFullYear() + '-' + String(agora.getMonth() + 1).padStart(2, '0') + '-15', grao);
    const soltos = mesesIsolados(f.todas || f.rows, iD);
    const passados = meses.filter(m => m <= mesAtual);
    // Por ano ou trimestre o mes solto sai das linhas, la' embaixo: o ano dele
    // pode ter meses de verdade.
    const comDados = new Set();
    if (grao !== 'mes') {
      f.rows.forEach(r => { const m = chavePeriodo(r[iD], 'mes'); if (m && soltos.indexOf(m) < 0) comDados.add(chaveCmp(m + '-15', grao)); });
    }
    const bons = passados.filter(m => (grao === 'mes' ? soltos.indexOf(m) < 0 : comDados.has(m)));
    const base = bons.length >= 2 ? bons : passados.length >= 2 ? passados : meses;
    const B = meses.includes(c.mesB) ? c.mesB : base[base.length - 1];
    const antesDeB = lista => lista.filter(m => m < B).pop();
    // O último recurso nunca é o próprio B: mês comparado com ele mesmo dava
    // uma tabela inteira de "=" que parecia resultado.
    const A = meses.includes(c.mesA) && c.mesA !== B ? c.mesA
      : (antesDeB(base) || antesDeB(meses) || meses.find(m => m !== B));
    // O mês escolhido pode não existir nesta seleção (filtro, outra coluna de
    // data). Trocar por outro sem dizer era o "às vezes funciona": a tabela
    // mudava de meses e continuava parecendo certa.
    const avisos = [];
    const sumiram = [...new Set([c.mesA, c.mesB])].filter(m => m && !meses.includes(m));
    if (sumiram.length) {
      avisos.push(sumiram.map(rotuloCmp).join(' e ') + ' sem dados nesta seleção - comparando ' +
        rotuloCmp(A) + ' com ' + rotuloCmp(B) + '.');
    }
    if (c.mesA && c.mesA === B) avisos.push('Período de antes igual ao de depois - usando ' + rotuloCmp(A) + '.');
    if (A > B) avisos.push(rotuloCmp(A) + ' vem depois de ' + rotuloCmp(B) + ': as setas contam nessa ordem.');
    const i28 = cc ? cc.indice(H, 'mpa28') : -1, i28b = cc ? cc.indice(H, 'mpa28b') : -1;
    const iVol = cc ? cc.indice(H, 'volume') : -1;
    const num = V().num;
    const grupos = new Map();
    const novo = () => ({ n: 0, vol: 0, ex: [], abaixo: 0, comFck: 0 });
    const acc = (k, mes, r) => {
      if (!grupos.has(k)) grupos.set(k, { [A]: novo(), [B]: novo() });
      const g = grupos.get(k)[mes];
      g.n++;
      const v = iVol >= 0 ? num(r[iVol]) : NaN;
      if (!isNaN(v) && v > 0) g.vol += v;
      const a = i28 >= 0 ? num(r[i28]) : NaN, b = i28b >= 0 ? num(r[i28b]) : NaN;
      const va = a > 0 && a < 150, vb = b > 0 && b < 150;
      if (!va && !vb) return;
      const ex = va && vb ? Math.max(a, b) : va ? a : b;
      g.ex.push(ex);
      const fck = lab.fckFrom ? lab.fckFrom(r, H) : NaN;
      if (fck > 0) { g.comFck++; if (ex < fck) g.abaixo++; }
    };
    f.rows.forEach(r => {
      const mes = chaveCmp(r[iD], grao);
      if (mes !== A && mes !== B) return;
      if (grao !== 'mes' && soltos.indexOf(chavePeriodo(r[iD], 'mes')) >= 0) return;
      const k = iG >= 0 ? (String(r[iG] == null ? '' : r[iG]).trim() || SEM_VALOR) : 'Toda a seleção';
      acc(k, mes, r);
      if (iG >= 0) acc('\u0000total', mes, r);
    });
    const resumo = g => {
      const m = g.ex.length ? g.ex.reduce((s, v) => s + v, 0) / g.ex.length : NaN;
      const dp = g.ex.length > 1 ? Math.sqrt(g.ex.reduce((s, v) => s + (v - m) * (v - m), 0) / (g.ex.length - 1)) : NaN;
      return { n: g.n, vol: g.vol, rompidos: g.ex.length, media: m, desvio: dp,
        pctAbaixo: g.comFck ? g.abaixo / g.comFck * 100 : NaN, abaixo: g.abaixo };
    };
    const linhas = [];
    let total = null;
    grupos.forEach((v, k) => {
      const l = { k, a: resumo(v[A]), b: resumo(v[B]) };
      if (k === '\u0000total') total = l; else linhas.push(l);
    });
    linhas.sort((x, y) => (y.a.n + y.b.n) - (x.a.n + x.b.n));
    return { meses, A, B, linhas, total, avisos, temResistencia: i28 >= 0 };
  }
  function desenharComparacao(f, it, body) {
    const c = it.config, viz = V();
    if (!c.colData) {
      body.innerHTML = '<p class="pan-vazio">Escolha a coluna de data nas propriedades (botão direito).</p>';
      return;
    }
    if (f.headers.indexOf(c.colData) < 0) {
      body.innerHTML = '<p class="pan-vazio">A coluna de data <b>' + esc(c.colData) +
        '</b> não está nesta planilha. Escolha outra nas propriedades (botão direito).</p>';
      return;
    }
    // Comparar precisa de dois meses, e o clique num mês de outro gráfico deixa
    // um só na seleção: o quadro sumia até alguém limpar o filtro. O filtro de
    // período na própria coluna de data não vale aqui; os outros filtros valem.
    const p = f.focoPeriodo, semFoco = !!p && p.col === c.colData;
    const r = compararMeses(semFoco ? p.base : f, c);
    if (r.meses.length < 2) {
      body.innerHTML = '<p class="pan-vazio">Esta seleção tem ' + (r.meses.length ? 'um mês só' : 'nenhuma data') +
        ' - não há o que comparar. Confira o filtro ou a coluna de data.</p>';
      return;
    }
    const lim = c.topN > 0 ? c.topN : 15;
    const mostrar = r.linhas.slice(0, lim);
    const fmt = (v, casas) => isNaN(v) ? '—' : viz.fmt(v, casas);
    const fmtPct = v => fmt(v, 1) + (isNaN(v) ? '' : '%');
    // Seta pelo que é bom: média subir é bom; desvio e reprovação subirem, ruim.
    const delta = (a, b, casas, bomSobe, sufixo) => {
      if (isNaN(a) || isNaN(b)) return '<td class="ana-num cmp-d">—</td>';
      const d = b - a;
      if (Math.abs(d) < Math.pow(10, -casas) / 2) return '<td class="ana-num cmp-d">=</td>';
      const bom = bomSobe ? d > 0 : d < 0;
      return '<td class="ana-num cmp-d ' + (bom ? 'cmp-bom' : 'cmp-ruim') + '">' + (d > 0 ? '▲ ' : '▼ ') +
        viz.fmt(Math.abs(d), casas) + (sufixo || '') + '</td>';
    };
    const linha = (l, classe) => '<tr' + (classe ? ' class="' + classe + '"' : '') + '><td class="cmp-k" title="' + esc(l.k) + '">' +
      esc(classe ? 'Total' : l.k) + '</td>' +
      '<td class="ana-num">' + l.a.n + ' → ' + l.b.n + '</td>' +
      (r.temResistencia
        ? '<td class="ana-num">' + fmt(l.a.media, 1) + '</td><td class="ana-num">' + fmt(l.b.media, 1) + '</td>' + delta(l.a.media, l.b.media, 1, true) +
          '<td class="ana-num">' + fmt(l.a.desvio, 2) + '</td><td class="ana-num">' + fmt(l.b.desvio, 2) + '</td>' + delta(l.a.desvio, l.b.desvio, 2, false) +
          '<td class="ana-num">' + fmtPct(l.a.pctAbaixo) + '</td><td class="ana-num">' + fmtPct(l.b.pctAbaixo) + '</td>' + delta(l.a.pctAbaixo, l.b.pctAbaixo, 1, false, ' p.p.')
        : '<td class="ana-num">' + fmt(l.a.vol, 1) + '</td><td class="ana-num">' + fmt(l.b.vol, 1) + '</td>' + delta(l.a.vol, l.b.vol, 1, true)) +
      '</tr>';
    const mA = rotuloCmp(r.A), mB = rotuloCmp(r.B);
    const cab = '<tr><th rowspan="2">' + esc(c.grupo || '') + '</th><th rowspan="2">Ensaios</th>' +
      (r.temResistencia
        ? '<th colspan="3">Média 28 dias (MPa)</th><th colspan="3">Desvio padrão (MPa)</th><th colspan="3">Abaixo do fck</th></tr><tr>' +
          [0, 1, 2].map(() => '<th>' + mA + '</th><th>' + mB + '</th><th>Δ</th>').join('')
        : '<th colspan="3">Volume (m³)</th></tr><tr><th>' + mA + '</th><th>' + mB + '</th><th>Δ</th>') + '</tr>';
    const avisos = (semFoco ? ['O filtro de período não vale neste quadro: ele compara meses.'] : []).concat(r.avisos);
    const geral = r.total || r.linhas[0];
    const cartao = (nome, a, b, casas, bom, suf) => '<div class="cmp-cartao"><span>' + nome + '</span><b>' + fmt(a, casas) + (suf || '') +
      ' → ' + fmt(b, casas) + (suf || '') + '</b><table><tr>' + delta(a, b, casas, bom, suf) + '</tr></table></div>';
    const cartoes = !previaLigada || !geral ? '' : '<div class="cmp-cartoes">' + cartao('Ensaios', geral.a.n, geral.b.n, 0, true) +
      (r.temResistencia ? cartao('Média 28 dias', geral.a.media, geral.b.media, 1, true, ' MPa') +
        cartao('Abaixo do fck', geral.a.pctAbaixo, geral.b.pctAbaixo, 1, false, '%') : cartao('Volume', geral.a.vol, geral.b.vol, 1, true, ' m³')) + '</div>';
    body.innerHTML = '<div class="cmp-corpo"><p class="cmp-sub"><b>' + mA + '</b> comparado a <b>' + mB + '</b>' +
      (r.linhas.length > lim ? ' · ' + lim + ' de ' + r.linhas.length + ' grupos, os de mais ensaios' : '') + '</p>' +
      avisos.map(a => '<p class="cmp-aviso">' + esc(a) + '</p>').join('') + cartoes +
      '<div class="pan-tab-wrap"><table class="ana-pivot pan-tab cmp-tab"><thead>' + cab + '</thead><tbody>' +
      mostrar.map(l => linha(l)).join('') + '</tbody>' + (r.total ? '<tfoot>' + linha(r.total, 'cmp-total') + '</tfoot>' : '') +
      '</table></div><button class="pan-btn-xls" type="button">Baixar Excel</button></div>';
    body.querySelector('.pan-btn-xls').addEventListener('click', ev => {
      ev.stopPropagation();
      const cabX = r.temResistencia
        ? ['Ensaios ' + mA, 'Ensaios ' + mB, 'Média ' + mA, 'Média ' + mB, 'Desvio ' + mA, 'Desvio ' + mB, '% abaixo do fck ' + mA, '% abaixo do fck ' + mB]
        : ['Ensaios ' + mA, 'Ensaios ' + mB, 'Volume ' + mA, 'Volume ' + mB];
      const val = v => (isNaN(v) ? '' : Math.round(v * 100) / 100);
      const aoa = [[c.grupo || 'Grupo'].concat(cabX)];
      r.linhas.concat(r.total ? [Object.assign({}, r.total, { k: 'Total' })] : []).forEach(l => aoa.push([l.k].concat(r.temResistencia
        ? [l.a.n, l.b.n, val(l.a.media), val(l.b.media), val(l.a.desvio), val(l.b.desvio), val(l.a.pctAbaixo), val(l.b.pctAbaixo)]
        : [l.a.n, l.b.n, val(l.a.vol), val(l.b.vol)])));
      exportarAoa(aoa, ('Comparar ' + mA + ' ' + mB).replace(/[^\w\-]+/g, '_'));
    });
  }

  function editarComparacao(it) {
    const f = dados();
    if (!f || !window.openModal) return;
    const c = it.config, H = f.headers;
    const opcoesMes = (meses, cur) => '<option value="">automático</option>' +
      meses.map(m => '<option value="' + esc(m) + '"' + (m === cur ? ' selected' : '') + '>' + esc(rotuloCmp(m)) + '</option>').join('');
    const opMes = (id, cur, rotulo) => '<label>' + rotulo + '</label><select id="' + id + '">' +
      opcoesMes(mesesDa(f, c.colData, c.grao), cur) + '</select>';
    const corpo = '<label>Título</label><input id="pw-tit" value="' + esc(c.titulo || '') + '" placeholder="' + esc(tituloAuto(it)) + '">' +
      selHtml('pw-data', H, c.colData, 'Coluna de data (moldagem)') +
      selHtml('pw-grupo', H, c.grupo, 'Comparar por (receita, obra, cliente…)') +
      (previaLigada ? '<label>Comparar</label><select id="pw-grao-cmp">' + [['mes', 'Mês com mês'], ['trimestre', 'Trimestre com trimestre'], ['ano', 'Ano com ano']]
        .map(o => '<option value="' + o[0] + '"' + ((c.grao || 'mes') === o[0] ? ' selected' : '') + '>' + o[1] + '</option>').join('') + '</select>' : '') +
      opMes('pw-mesa', c.mesA, 'Período de antes') + opMes('pw-mesb', c.mesB, 'Período de depois') +
      '<p class="rc-dica">Automático compara o último mês da seleção com o anterior, sem contar mês no futuro ' +
      'nem mês isolado. As medidas usam o exemplar (o maior dos dois CPs) aos 28 dias; o fck vem da coluna ' +
      'própria ou do nome do produto.</p>' +
      '<label>Máximo de grupos</label><input id="pw-topn" type="number" min="1" max="200" value="' + (c.topN || 15) + '">';
    window.openModal('Propriedades - Comparar meses', corpo, () => {
      const g = id => { const el = document.getElementById(id); return el ? el.value : ''; };
      c.titulo = g('pw-tit'); c.colData = g('pw-data'); c.grupo = g('pw-grupo');
      c.mesA = g('pw-mesa'); c.mesB = g('pw-mesb');
      if (document.getElementById('pw-grao-cmp')) c.grao = g('pw-grao-cmp');
      c.topN = parseInt(g('pw-topn')) || 15;
      salvar();
      if (window.closeModal) window.closeModal();
      render();
    }, 'modal-props');
    // Os meses são os da coluna de data: trocar a coluna com a lista antiga na
    // tela deixava escolher mês que não existe, e o quadro caía no automático.
    const selData = document.getElementById('pw-data'), selGrao = document.getElementById('pw-grao-cmp');
    const trocarPeriodos = () => {
      const meses = mesesDa(f, selData.value, selGrao ? selGrao.value : c.grao);
      ['pw-mesa', 'pw-mesb'].forEach(id => {
        const s = document.getElementById(id);
        if (s) s.innerHTML = opcoesMes(meses, s.value);
      });
    };
    if (selData) selData.addEventListener('change', trocarPeriodos);
    if (selGrao) selGrao.addEventListener('change', trocarPeriodos);
  }

  /* -- falhas por receita --------------------------
   * Item 11 da lista: a pior receita e' a que mais falha em proporcao, nao em
   * numero. Conta o exemplar (o maior dos dois CPs) aos 28 dias contra o fck, com
   * a mesma regra do Comparar meses. Receita com poucos ensaios sai do ranking e
   * e' contada: 1 de 1 daria 100% e iria para o topo sem dizer nada.
   */
  function falhasPorGrupo(f, c) {
    const cc = window.ConcreColunas, lab = window.ConcreLab || {}, H = f.headers, num = V().num;
    const iG = H.indexOf(c.grupo);
    const i28 = cc ? cc.indice(H, 'mpa28') : -1, i28b = cc ? cc.indice(H, 'mpa28b') : -1;
    const grupos = new Map();
    let semFck = 0;
    f.rows.forEach(r => {
      const a = i28 >= 0 ? num(r[i28]) : NaN, b = i28b >= 0 ? num(r[i28b]) : NaN;
      const va = a > 0 && a < 150, vb = b > 0 && b < 150;
      if (!va && !vb) return;
      const ex = va && vb ? Math.max(a, b) : va ? a : b;
      const fck = lab.fckFrom ? lab.fckFrom(r, H) : NaN;
      if (!(fck > 0)) { semFck++; return; }
      const k = String(r[iG] == null ? '' : r[iG]).trim() || SEM_VALOR;
      if (!grupos.has(k)) grupos.set(k, { k: k, n: 0, abaixo: 0, folga: 0 });
      const g = grupos.get(k);
      g.n++;
      g.folga += ex - fck;
      if (ex < fck) g.abaixo++;
    });
    const minimo = c.minimo > 0 ? c.minimo : 5;
    const todos = [...grupos.values()].map(g => Object.assign(g, { pct: g.abaixo / g.n * 100, folga: g.folga / g.n }));
    const lista = todos.filter(g => g.n >= minimo)
      .sort((x, y) => y.pct - x.pct || y.abaixo - x.abaixo || x.folga - y.folga);
    return { lista: lista, poucos: todos.length - lista.length, minimo: minimo, semFck: semFck, temResistencia: i28 >= 0 };
  }
  function desenharFalhas(f, it, body) {
    const c = it.config, viz = V();
    const r = falhasPorGrupo(f, c);
    if (!r.temResistencia) {
      body.innerHTML = '<p class="pan-vazio">Não achei a coluna do rompimento de 28 dias nesta planilha.</p>';
      return;
    }
    if (!r.lista.length) {
      body.innerHTML = '<p class="pan-vazio">Nenhum grupo com ' + r.minimo + ' ensaios ou mais e fck conhecido.</p>';
      return;
    }
    const mostrar = r.lista.slice(0, c.topN || 15);
    const maior = Math.max(mostrar[0].pct, 1);
    const linhas = mostrar.map(g => '<tr><td title="' + esc(g.k) + '">' + esc(g.k) + '</td>' +
      '<td class="ana-num">' + viz.fmt(g.n, 0) + '</td><td class="ana-num">' + viz.fmt(g.abaixo, 0) + '</td>' +
      '<td class="pan-falha"><span class="pan-falha-barra" style="width:' + (g.pct / maior * 100).toFixed(1) + '%"></span>' +
      '<b>' + viz.fmt(g.pct, 1) + '%</b></td>' +
      '<td class="ana-num' + (g.folga < 0 ? ' ana-neg' : '') + '">' + (g.folga > 0 ? '+' : '') + viz.fmt(g.folga, 1) + '</td></tr>').join('');
    const fora = [];
    if (r.lista.length > mostrar.length) fora.push('Mostrando ' + mostrar.length + ' de ' + r.lista.length + '.');
    if (r.poucos) fora.push(r.poucos + ' com menos de ' + r.minimo + ' ensaios ficaram de fora.');
    if (r.semFck) fora.push(viz.fmt(r.semFck, 0) + ' ensaios sem fck conhecido.');
    body.innerHTML = '<div class="pan-tab-wrap"><table class="ana-pivot pan-tab"><thead><tr><th>' + esc(c.grupo || '') + '</th>' +
      '<th>Ensaios</th><th>Abaixo</th><th>Falhas</th><th title="Média do exemplar menos o fck, em MPa">Folga</th></tr></thead>' +
      '<tbody>' + linhas + '</tbody></table></div>' +
      (fora.length ? '<p class="pan-nota">' + esc(fora.join(' ')) + '</p>' : '') +
      '<button class="pan-btn-xls" type="button">Baixar Excel</button>';
    body.querySelector('.pan-btn-xls').addEventListener('click', ev => {
      ev.stopPropagation();
      const redondo = v => Math.round(v * 100) / 100;
      const aoa = [[c.grupo || 'Grupo', 'Ensaios', 'Abaixo do fck', '% de falhas', 'Folga média (MPa)']];
      r.lista.forEach(g => aoa.push([g.k, g.n, g.abaixo, redondo(g.pct), redondo(g.folga)]));
      exportarAoa(aoa, 'Falhas por receita');
    });
  }
  function editarFalhas(it) {
    const f = dados();
    if (!f || !window.openModal) return;
    const c = it.config;
    const corpo = '<label>Título</label><input id="pw-tit" value="' + esc(c.titulo || '') + '" placeholder="' + esc(tituloAuto(it)) + '">' +
      selHtml('pw-grupo', f.headers, c.grupo, 'Agrupar por (receita, versão, cliente…)') +
      '<label>Mínimo de ensaios para entrar no ranking</label><input id="pw-minimo" type="number" min="1" max="500" value="' + (c.minimo || 5) + '">' +
      '<label>Máximo de grupos</label><input id="pw-topn" type="number" min="1" max="200" value="' + (c.topN || 15) + '">' +
      '<p class="rc-dica">Conta o exemplar (o maior dos dois CPs) aos 28 dias contra o fck, que vem da coluna própria ou do nome do produto.</p>';
    window.openModal('Propriedades - Falhas por receita', corpo, () => {
      const g = id => { const el = document.getElementById(id); return el ? el.value : ''; };
      c.titulo = g('pw-tit'); c.grupo = g('pw-grupo');
      c.minimo = parseInt(g('pw-minimo')) || 5;
      c.topN = parseInt(g('pw-topn')) || 15;
      salvar();
      if (window.closeModal) window.closeModal();
      render();
    }, 'modal-props');
  }

  function desenharDado(f, it, body) {
    const c = it.config, viz = V();
    const iV = f.headers.indexOf(c.valor);
    const ens = c.ensaio ? lerEnsaio(f, c.valor) : null;
    const vals = ens ? ens.vals
      : (iV >= 0 ? f.rows.map(r => viz.num(r[iV])) : f.rows.map(() => NaN));
    let valor, pct = false, sub = c.subtitulo || '';
    if (ens && !c.subtitulo) {
      const partes = [];
      if (ens.cols.length > 1) partes.push(ens.cols.length + ' colunas');
      if (ens.fora.length) partes.push(ens.fora.length + ' fora do cálculo');
      if (partes.length) sub = partes.join(' · ');
    }

    if (c.op === 'Crescimento %') {
      const g = agrupar(f, f.rows, {
        grupo: '__periodo__', colData: c.colData, grao: c.grao || 'mes',
        valor: c.valor, op: c.opBase || 'Soma'
      });
      // Comparar o ULTIMO periodo com o ANTERIOR so' faz sentido se eles forem
      // vizinhos. Numa planilha com um registro solto em janeiro e o resto em
      // dezembro, saia "-99,9% (2026-12 vs 2026-01)" - numero sem significado.
      if (g.length >= 2) {
        const ult = g[g.length - 1], ant = g[g.length - 2];
        if (!periodosVizinhos(ant.k, ult.k, c.grao || 'mes')) {
          // Periodos nao vizinhos: o numero continua valendo (o Naor confirmou
          // que fazia sentido na planilha dele), mas a legenda avisa que ha'
          // um buraco no meio - senao parece comparacao de meses seguidos.
          valor = ant.v ? (ult.v - ant.v) / Math.abs(ant.v) * 100 : NaN;
          pct = true;
          sub = ult.k + ' vs ' + ant.k + ' · sem dados no meio';
        } else {
          valor = ant.v ? (ult.v - ant.v) / Math.abs(ant.v) * 100 : NaN;
          pct = true;
          sub = sub || (ult.k + ' vs ' + ant.k);
        }
      } else {
        valor = NaN;
        sub = sub || 'só há um período nos dados';
      }
    } else if (c.op === '% do total' && c.grupo && c.filtroValor) {
      const g = agrupar(f, f.rows, { grupo: c.grupo, valor: c.valor, op: c.opBase || 'Soma' });
      const t = g.reduce((s, x) => s + (isNaN(x.v) ? 0 : Math.abs(x.v)), 0) || 1;
      const alvo = g.filter(x => x.k === c.filtroValor)[0];
      valor = alvo ? Math.abs(alvo.v) / t * 100 : NaN;
      pct = true;
      sub = sub || (c.filtroValor + ' sobre o total');
    } else {
      valor = calc(vals, c.op || 'Soma');
    }

    const cls = isNaN(valor) ? '' : (valor < 0 ? 'ana-down' : (pct && valor > 0 ? 'ana-up' : ''));
    const seta = pct ? (valor > 0 ? '▲ ' : valor < 0 ? '▼ ' : '') : '';
    const txt = isNaN(valor) ? '—'
      : pct ? seta + viz.fmt(Math.abs(valor), 1) + '%'
        : (c.op === 'Contagem' ? viz.fmt(valor, 0)
           : (viz.perfil === 'financeiro' ? 'R$ ' : '') + viz.fmt0(valor));
    body.innerHTML = '<div class="pan-dado"><b class="' + cls + '">' + esc(txt) + '</b>' +
      (sub ? '<span>' + esc(sub) + '</span>' : '') + '</div>';
  }

  function desenharTabela(f, it, body) {
    const c = it.config, viz = V();
    const cols = (c.colunas && c.colunas.length) ? c.colunas : [{ valor: c.valor, op: c.op || 'Soma' }];
    const base = agrupar(f, f.rows, {
      grupo: c.grupo, colData: c.colData, grao: c.grao,
      valor: cols[0].valor, op: cols[0].op, formula: cols[0].formula, topN: c.topN
    });
    if (!base.length) {
      body.innerHTML = '<p class="pan-vazio">Escolha "Agrupar por" nas propriedades (botão direito).</p>';
      return;
    }
    const series = valoresPorGrupo(f, c, cols);
    const pctCol = cols.map(cl => ehPct(cl.op) || cl.op === FORMULA);   // nao somam no rodape
    const linhas = base.slice(0, c.limite || 200);
    const totCols = cols.map((cl, i) => {
      if (pctCol[i]) return NaN;
      const iV = f.headers.indexOf(cl.valor);
      const vals = iV >= 0 ? f.rows.map(r => viz.num(r[iV])) : f.rows.map(() => NaN);
      return calc(vals, cl.op);
    });

    const cabec = '<th>' + esc(c.grupo === '__periodo__' ? 'Período' : (c.grupo || '')) + '</th>' +
      cols.map(cl => '<th>' + esc(cl.titulo || (cl.op + (cl.valor ? ' · ' + cl.valor : ''))) + '</th>').join('');

    const corpo = linhas.map(l => '<tr><td>' + esc(l.k) + '</td>' + cols.map((cl, i) => {
      const v = series[i].get(l.k);
      const neg = (v !== undefined && !isNaN(v) && v < 0) ? ' ana-neg' : '';
      return '<td class="ana-num' + neg + '">' + fmtOp(v, cl.op) + '</td>';
    }).join('') + '</tr>').join('');

    const rodape = c.total === false ? '' :
      '<tfoot><tr><td><b>Total</b></td>' + totCols.map((t, i) =>
        '<td class="ana-num"><b>' + fmtOp(t, cols[i].op) + '</b></td>'
      ).join('') + '</tr></tfoot>';

    body.innerHTML = (c.insights ? montarInsightsTabela(base, viz) : '') +
      '<div class="pan-tab-wrap"><table class="ana-pivot pan-tab"><thead><tr>' + cabec +
      '</tr></thead><tbody>' + corpo + '</tbody>' + rodape + '</table></div>' +
      '<button class="pan-btn-xls" type="button">Baixar Excel</button>';

    body.querySelector('.pan-btn-xls').addEventListener('click', ev => {
      ev.stopPropagation();
      const aoa = [[c.grupo === '__periodo__' ? 'Período' : c.grupo].concat(
        cols.map(cl => cl.titulo || (cl.op + ' ' + (cl.valor || ''))))];
      base.forEach(l => aoa.push([l.k].concat(cols.map((cl, i) => {
        const v = series[i].get(l.k);
        return (v === undefined || isNaN(v)) ? '' : v;
      }))));
      exportarAoa(aoa, String(it.config.titulo || tituloAuto(it)).replace(/[^\w\-]+/g, '_'));
    });
  }

  // Insights da própria tabela (o Naor pediu insights on/off por widget).
  function montarInsightsTabela(base, viz) {
    const vals = (base || []).filter(x => x && !isNaN(x.v));
    if (!vals.length) return '';
    // Maior e menor calculados de verdade. Antes assumia a lista ja' ordenada
    // por valor - num grafico por mes (ordenado por data) saia "Maior: 220" e
    // "Menor: 340", que e' visivelmente errado.
    const tot = vals.reduce((s, x) => s + Math.abs(x.v), 0) || 1;
    let top = vals[0], baixo = vals[0];
    vals.forEach(x => { if (x.v > top.v) top = x; if (x.v < baixo.v) baixo = x; });
    const cards = [{
      cls: 'info', ico: '★',
      txt: 'Maior: ' + top.k + ' (' + viz.fmt0(top.v) + ' · ' + viz.fmt(Math.abs(top.v) / tot * 100, 1) + '%)'
    }];
    if (vals.length > 1 && baixo.k !== top.k) {
      cards.push({ cls: 'down', ico: '▼', txt: 'Menor: ' + baixo.k + ' (' + viz.fmt0(baixo.v) + ')' });
    }
    if (vals.length > 2) {
      const media = vals.reduce((s, x) => s + x.v, 0) / vals.length;
      cards.push({ cls: 'info', ico: '~', txt: 'Média: ' + viz.fmt0(media) + ' por ' + (vals.length) + ' grupos' });
    }
    const conc = Math.abs(top.v) / tot * 100;
    if (conc > 50) cards.push({ cls: 'warn', ico: '!', txt: '"' + top.k + '" concentra ' + viz.fmt(conc, 1) + '% do total' });
    return '<div class="ana-ins pan-ins">' + cards.map(i =>
      '<div class="ins-card ' + i.cls + '"><span class="ins-ico">' + i.ico + '</span><span>' +
      esc(i.txt) + '</span></div>').join('') + '</div>';
  }


  function desenharEmpilhado(f, it, canvas) {
    const c = it.config, viz = V(), num = viz.num;
    const porPeriodo = c.grupo === '__periodo__';
    const iX = porPeriodo ? f.headers.indexOf(c.colData) : f.headers.indexOf(c.grupo);
    const iC = f.headers.indexOf(c.serieCat);
    const iV = f.headers.indexOf(c.valor);
    if (iX < 0 || iC < 0) { viz.drawBars(canvas, [], [], null); return; }
    const xs = [], catTot = new Map(), mapa = new Map();
    f.rows.forEach(r => {
      const k = porPeriodo ? chavePeriodo(r[iX], c.grao || 'mes')
        : (String(r[iX] == null ? '' : r[iX]).trim() || SEM_VALOR);
      if (k === null) return;
      const cat = String(r[iC] == null ? '' : r[iC]).trim() || SEM_VALOR;
      const v = iV >= 0 ? num(r[iV]) : 1;
      if (isNaN(v)) return;
      if (!mapa.has(k)) { mapa.set(k, new Map()); xs.push(k); }
      mapa.get(k).set(cat, (mapa.get(k).get(cat) || 0) + v);
      catTot.set(cat, (catTot.get(cat) || 0) + v);
    });
    xs.sort((a, b) => String(a).localeCompare(String(b)));

    // Sem limite de barras, uma coluna com centenas de valores virava um borrao
    // com os nomes ilegiveis embaixo. Fica o que importa: por periodo, os
    // ultimos N; por categoria, os N maiores.
    // Com a area rolando, da' para mostrar bem mais do que cabia antes.
    const limite = c.topN > 0 ? c.topN : 60;
    let deFora = 0;
    if (xs.length > limite) {
      deFora = xs.length - limite;
      if (porPeriodo) {
        xs.splice(0, deFora);
      } else {
        const totalPorX = new Map();
        xs.forEach(k => {
          let t = 0;
          (mapa.get(k) || new Map()).forEach(v => { t += v; });
          totalPorX.set(k, t);
        });
        const mantidos = xs.slice()
          .sort((a, b) => (totalPorX.get(b) || 0) - (totalPorX.get(a) || 0))
          .slice(0, limite);
        xs.length = 0;
        mantidos.forEach(k => xs.push(k));
      }
    }

    const arr = [];
    catTot.forEach((v, k) => arr.push([k, v]));
    const top = arr.sort((a, b) => b[1] - a[1]).slice(0, 6).map(e => e[0]);
    const series = top.map(cat => ({
      nome: cat, vals: xs.map(k => (mapa.get(k) || new Map()).get(cat) || 0)
    }));
    const outros = {
      nome: 'Outros',
      vals: xs.map(k => {
        let s = 0;
        (mapa.get(k) || new Map()).forEach((v, cat) => { if (top.indexOf(cat) < 0) s += v; });
        return s;
      })
    };
    if (outros.vals.some(v => v > 0)) series.push(outros);
    esticarParaCaber(canvas, xs.length);
    // Num empilhado o clique acerta a fatia, não a barra: quem foi clicado é
    // a categoria que divide as barras, não o eixo X.
    viz.drawStacked(canvas, xs, series, cliqueDe({ grupo: c.serieCat, grao: c.grao }));
    if (deFora > 0) marcarCorte(canvas, deFora, porPeriodo);
  }

  // Avisa, sem atrapalhar, que o grafico esta' mostrando so' uma parte.
  function marcarCorte(canvas, quantos, porPeriodo) {
    const pai = canvas.parentElement;
    if (!pai || pai.querySelector('.pan-nota-corte')) return;
    const p = document.createElement('p');
    p.className = 'pan-nota pan-nota-corte';
    p.textContent = porPeriodo
      ? 'Mostrando os últimos períodos - ' + quantos + ' anteriores ficaram de fora.'
      : 'Mostrando os maiores - outros ' + quantos + ' ficaram de fora (aumente o ' +
        '"Máximo de grupos" nas propriedades para ver mais).';
    pai.appendChild(p);
  }

  /* -- combo: várias séries (barra + linha, 2 eixos) --
     É o que permite montar "produção e crescimento" como o Naor pediu. */
  function desenharCombo(f, it, canvas) {
    const c = it.config, viz = V();
    const eixoX = agrupar(f, f.rows, {
      grupo: c.grupo, colData: c.colData, grao: c.grao,
      valor: (c.series[0] || {}).valor, op: (c.series[0] || {}).op || 'Soma',
      formula: (c.series[0] || {}).formula,
      topN: (!c.topN || c.topN === 12) ? 60 : c.topN
    });
    if (!eixoX.length) { viz.drawBars(canvas, [], [], null); return; }
    const labels = eixoX.map(d => d.k);
    esticarParaCaber(canvas, labels.length);   // area rola quando nao cabe
    const mapas = valoresPorGrupo(f, c, c.series);
    const series = c.series.map((s, i) => {
      const m = mapas[i];
      const o = {};
      Object.keys(s).forEach(k => { o[k] = s[k]; });
      o.vals = labels.map(k => { const v = m.get(k); return v === undefined ? NaN : v; });
      return o;
    });

    const dpr = window.devicePixelRatio || 1;
    const w = canvas.clientWidth || 600, h = canvas.clientHeight || 240;
    canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr);
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);

    const temDir = series.some(s => s.eixo === 'dir');
    const left = 56, right = temDir ? 56 : 14, top = 16, bottom = 48;
    const plotW = w - left - right, plotH = h - top - bottom, baseY = top + plotH;

    const junta = arr => arr.filter(v => !isNaN(v) && isFinite(v));
    let esqVals = [], dirVals = [];
    series.forEach(s => { (s.eixo === 'dir' ? dirVals : esqVals).push.apply(s.eixo === 'dir' ? dirVals : esqVals, junta(s.vals)); });
    const eMax = Math.max.apply(null, esqVals.concat([1])), eMin = Math.min.apply(null, esqVals.concat([0]));
    let dMax = Math.max.apply(null, dirVals.concat([1])), dMin = Math.min.apply(null, dirVals.concat([0]));
    if (dMax === dMin) { dMax += 1; dMin -= 1; }
    // Porcentagem so' quando o eixo direito e' de porcentagem. A contagem de CP
    // la' saia como "1.091%".
    const sufixoDir = series.filter(s => s.eixo === 'dir').every(s => ehPct(s.op)) ? '%' : '';

    const yEsq = v => top + plotH * (1 - (v - eMin) / ((eMax - eMin) || 1));
    const yDir = v => top + plotH * (1 - (v - dMin) / ((dMax - dMin) || 1));

    // Numero redondo nos dois eixos, como nos outros graficos. A grade segue o
    // da esquerda; o da direita so' escreve as marcas dele.
    const marcas = (min, max) => {
      const { passo, casas } = viz.passoDoEixo(max - min);
      const lista = [];
      const fim = Math.floor(max / passo + 1e-9);
      for (let k = Math.ceil(min / passo - 1e-9); k <= fim; k++) lista.push(k * passo || 0);
      return { lista, casas };
    };
    ctx.font = '11px IBM Plex Mono, monospace';
    ctx.strokeStyle = '#ececea';
    ctx.beginPath(); ctx.moveTo(left, top + plotH); ctx.lineTo(w - right, top + plotH); ctx.stroke();
    const me = marcas(eMin, eMax);
    ctx.fillStyle = '#2a5298'; ctx.textAlign = 'right';
    me.lista.forEach(v => {
      const y = yEsq(v);
      ctx.beginPath(); ctx.moveTo(left, y); ctx.lineTo(w - right, y); ctx.stroke();
      ctx.fillText(viz.fmt(v, me.casas), left - 6, y + 4);
    });
    if (temDir) {
      const md = marcas(dMin, dMax);
      ctx.fillStyle = '#2a6640'; ctx.textAlign = 'left';
      md.lista.forEach(v => ctx.fillText(viz.fmt(v, md.casas) + sufixoDir, w - right + 6, yDir(v) + 4));
    }
    ctx.textAlign = 'start';
    const slot = plotW / Math.max(1, labels.length);
    const barras = series.filter(s => s.tipo !== 'linha');
    const bw = Math.max(4, Math.min(46, slot * 0.7 / Math.max(1, barras.length)));

    barras.forEach((s, si) => {
      ctx.fillStyle = s.cor || '#2a5298';
      s.vals.forEach((v, i) => {
        if (isNaN(v)) return;
        const fy = s.eixo === 'dir' ? yDir : yEsq;
        const yv = fy(v), y0 = fy(0);
        const x = left + slot * i + (slot - bw * barras.length) / 2 + si * bw;
        ctx.fillRect(x, Math.min(yv, y0), bw, Math.max(2, Math.abs(y0 - yv)));
      });
    });
    series.filter(s => s.tipo === 'linha').forEach(s => {
      const fy = s.eixo === 'dir' ? yDir : yEsq;
      ctx.strokeStyle = s.cor || '#2a6640';
      ctx.lineWidth = 2; ctx.beginPath();
      let iniciado = false;
      s.vals.forEach((v, i) => {
        if (isNaN(v)) return;
        const x = left + slot * i + slot / 2, y = fy(v);
        if (!iniciado) { ctx.moveTo(x, y); iniciado = true; } else ctx.lineTo(x, y);
      });
      ctx.stroke(); ctx.lineWidth = 1;
      ctx.fillStyle = s.cor || '#2a6640';
      s.vals.forEach((v, i) => {
        if (isNaN(v)) return;
        ctx.beginPath();
        ctx.arc(left + slot * i + slot / 2, fy(v), 3, 0, Math.PI * 2);
        ctx.fill();
      });
    });

    ctx.fillStyle = '#555'; ctx.font = '10px IBM Plex Mono, monospace'; ctx.textAlign = 'center';
    const passo = slot >= 46 ? 1 : Math.ceil(46 / slot);
    labels.forEach((l, i) => {
      if (i % passo) return;
      ctx.fillText(String(l).slice(0, 12), left + slot * i + slot / 2, baseY + 16);
    });
    let lx = left;
    ctx.textAlign = 'left'; ctx.font = '10px IBM Plex Sans, sans-serif';
    series.forEach(s => {
      ctx.fillStyle = s.cor || '#2a5298';
      ctx.fillRect(lx, baseY + 28, 9, 9);
      ctx.fillStyle = '#5a5852';
      const nome = String(s.titulo || (s.op + ' ' + (s.valor || ''))).slice(0, 26);
      ctx.fillText(nome, lx + 13, baseY + 36);
      lx += ctx.measureText(nome).width + 30;
    });
    ctx.textAlign = 'start';

    // Clicar no mês filtra o painel inteiro por aquele período, como na Análise.
    const aoClicar = cliqueDe(c);
    if (aoClicar) {
      canvas.style.cursor = 'pointer';
      canvas.onclick = ev => {
        const r = canvas.getBoundingClientRect();
        const i = Math.floor((ev.clientX - r.left - left) / slot);
        if (i >= 0 && i < labels.length) aoClicar(labels[i]);
      };
    }
  }

  /* -- mapa de calor (calendário) ------------------ */
  function desenharCalor(f, it, body) {
    const c = it.config, viz = V(), num = viz.num;
    const iD = f.headers.indexOf(c.colData), iV = f.headers.indexOf(c.valor);
    if (iD < 0) { body.innerHTML = '<p class="pan-vazio">Escolha a coluna de data nas propriedades.</p>'; return; }
    const dias = new Map();
    f.rows.forEach(r => {
      const k = chavePeriodo(r[iD], 'dia');
      if (!k) return;
      const v = iV >= 0 ? num(r[iV]) : 1;
      if (isNaN(v)) return;
      dias.set(k, (dias.get(k) || 0) + v);
    });
    const keys = [];
    dias.forEach((v, k) => keys.push(k));
    keys.sort();
    if (!keys.length) { body.innerHTML = '<p class="pan-vazio">Sem datas válidas.</p>'; return; }
    const parse = k => { const p = k.split('-'); return new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])); };

    // Uma data solta no comeco do ano esticava o mapa por 52 semanas vazias e
    // o que interessa ficava fora da tela. Agora o mapa comeca onde os dados
    // realmente comecam: o trecho mais recente que cobre 98% do movimento.
    let totalMov = 0;
    dias.forEach(v => { totalMov += v; });
    let acumulado = 0, corte = 0;
    for (let i = keys.length - 1; i >= 0; i--) {
      acumulado += dias.get(keys[i]) || 0;
      if (acumulado >= totalMov * 0.98) { corte = i; break; }
    }
    const forasDeFora = corte;                      // quantos dias ficaram de fora
    const d0 = parse(keys[corte]), d1 = parse(keys[keys.length - 1]);
    let maxV = 1;
    dias.forEach(v => { if (v > maxV) maxV = v; });
    const cor = v => v <= 0 ? '#ebedf0'
      : (v / maxV < 0.25 ? '#c6e48b' : v / maxV < 0.5 ? '#7bc96f' : v / maxV < 0.75 ? '#239a3b' : '#196127');
    const cur = new Date(d0);
    cur.setUTCDate(cur.getUTCDate() - ((cur.getUTCDay() + 6) % 7));
    const cols = [];
    let guarda = 0;
    while (guarda++ < 800) {
      const semana = [];
      for (let i = 0; i < 7; i++) {
        const k = cur.toISOString().slice(0, 10);
        semana.push({ k: k, v: dias.get(k) || 0, dentro: cur >= d0 && cur <= d1 });
        cur.setUTCDate(cur.getUTCDate() + 1);
      }
      cols.push(semana);
      if (cur > d1 && ((cur.getUTCDay() + 6) % 7) === 0) break;
    }
    const nota = forasDeFora > 0
      ? '<p class="pan-nota">Mostrando de ' + keys[corte].split('-').reverse().join('/') +
        ' em diante - ' + forasDeFora + ' dia(s) mais antigo(s) e isolado(s) ficaram de fora ' +
        'para o mapa nao virar uma faixa vazia.</p>'
      : '';
    const C = 12, G = 3;
    let svg = '<svg width="' + (cols.length * (C + G) + 46) + '" height="' + (7 * (C + G) + 34) +
      '" style="font-family:IBM Plex Mono,monospace">';
    ['Seg', '', 'Qua', '', 'Sex', '', 'Dom'].forEach((dn, r) => {
      if (dn) svg += '<text x="2" y="' + (30 + r * (C + G) + C - 2) + '" font-size="9" fill="#999">' + dn + '</text>';
    });
    let ultimoMes = '';
    cols.forEach((semana, ci) => {
      const primeiro = semana.filter(d => d.dentro)[0];
      if (primeiro) {
        const mo = primeiro.k.slice(0, 7);
        if (mo !== ultimoMes) {
          ultimoMes = mo;
          svg += '<text x="' + (44 + ci * (C + G)) + '" y="18" font-size="9" fill="#999">' +
            primeiro.k.slice(5, 7) + '/' + primeiro.k.slice(2, 4) + '</text>';
        }
      }
      semana.forEach((cel, r) => {
        if (!cel.dentro) return;
        svg += '<rect x="' + (44 + ci * (C + G)) + '" y="' + (24 + r * (C + G)) + '" width="' + C +
          '" height="' + C + '" rx="2" fill="' + cor(cel.v) + '"><title>' +
          viz.fmt(cel.v, 1) + ' · ' + cel.k.split('-').reverse().join('/') + '</title></rect>';
      });
    });
    svg += '</svg>';
    body.innerHTML = '<div class="pan-calor">' + svg + '</div>' + nota;
  }

  /* -- mover e redimensionar ----------------------- */
  function arrastar(el, it) {
    const head = el.querySelector('.pan-w-head');
    head.addEventListener('mousedown', ev => {
      if (ev.button !== 0) return;
      ev.preventDefault();
      const canvas = $('pan-canvas');
      const cr = canvas.getBoundingClientRect();
      const offX = ev.clientX - el.getBoundingClientRect().left;
      const offY = ev.clientY - el.getBoundingClientRect().top;
      el.classList.add('movendo');
      const mover = e => {
        let nl = snap(e.clientX - cr.left - offX);
        let nt = snap(e.clientY - cr.top - offY);
        // Sem limite superior, igual ja' era na vertical. O limite antigo era
        // (largura do canvas - largura do widget): num widget mais largo que a
        // tela isso da' NEGATIVO, o Math.max(0, ...) zerava, e o widget ficava
        // preso no canto esquerdo sem sair do lugar. Reproduzido: widget de
        // 1640px num canvas de 1226px nao andava um pixel.
        nl = Math.max(0, nl);
        nt = Math.max(0, nt);
        el.style.left = nl + 'px';
        el.style.top = nt + 'px';
        // O canvas cresce junto para dar onde pousar (e onde rolar ate').
        const precisaW = snap(nl + el.offsetWidth + GRID * 2);
        if (precisaW > canvas.offsetWidth) canvas.style.minWidth = precisaW + 'px';
        const precisaH = snap(nt + el.offsetHeight + GRID * 2);
        if (precisaH > canvas.offsetHeight) canvas.style.minHeight = precisaH + 'px';
      };
      const soltar = () => {
        document.removeEventListener('mousemove', mover);
        document.removeEventListener('mouseup', soltar);
        el.classList.remove('movendo');
        it.x = parseInt(el.style.left) || 0;
        it.y = parseInt(el.style.top) || 0;
        salvar();
        render();
      };
      document.addEventListener('mousemove', mover);
      document.addEventListener('mouseup', soltar);
    });
  }

  function redimensionar(el, it) {
    const h = el.querySelector('.pan-w-resize');
    h.addEventListener('mousedown', ev => {
      ev.preventDefault(); ev.stopPropagation();
      const canvas = $('pan-canvas');
      const x0 = ev.clientX, y0 = ev.clientY;
      const w0 = el.offsetWidth, h0 = el.offsetHeight;
      const mover = e => {
        el.style.width = Math.max(180, snap(w0 + e.clientX - x0)) + 'px';
        el.style.height = Math.max(110, snap(h0 + e.clientY - y0)) + 'px';
        const precisaW = snap((parseInt(el.style.left) || 0) + el.offsetWidth + GRID * 2);
        if (precisaW > canvas.offsetWidth) canvas.style.minWidth = precisaW + 'px';
        const precisaH = snap((parseInt(el.style.top) || 0) + el.offsetHeight + GRID * 2);
        if (precisaH > canvas.offsetHeight) canvas.style.minHeight = precisaH + 'px';
      };
      const soltar = () => {
        document.removeEventListener('mousemove', mover);
        document.removeEventListener('mouseup', soltar);
        it.w = parseInt(el.style.width);
        it.h = parseInt(el.style.height);
        salvar();
        render();
      };
      document.addEventListener('mousemove', mover);
      document.addEventListener('mouseup', soltar);
    });
  }

  /* -- menus de contexto --------------------------- */
  let _fecharFora = null;
  function fecharMenu() {
    const m = $('pan-ctx');
    if (m) m.remove();
    if (_fecharFora) {
      document.removeEventListener('mousedown', _fecharFora, true);
      _fecharFora = null;
    }
  }
  function abrirMenu(x, y, itens) {
    fecharMenu();
    const m = document.createElement('div');
    m.id = 'pan-ctx';
    m.className = 'context-menu pan-ctx';
    m.style.cssText = 'display:block;left:' + x + 'px;top:' + y + 'px';
    m.innerHTML = itens.map((i, idx) => i.sep
      ? '<div class="pan-ctx-sep"></div>'
      : '<div class="context-item" data-i="' + idx + '">' + esc(i.label) + '</div>').join('');
    document.body.appendChild(m);
    const r = m.getBoundingClientRect();
    if (r.right > window.innerWidth) m.style.left = Math.max(4, window.innerWidth - r.width - 6) + 'px';
    if (r.bottom > window.innerHeight) m.style.top = Math.max(4, window.innerHeight - r.height - 6) + 'px';
    m.querySelectorAll('.context-item').forEach(el => {
      el.addEventListener('click', () => {
        const it = itens[parseInt(el.dataset.i)];
        fecharMenu();
        if (it && it.fn) it.fn();
      });
    });
    // Fecha só quando o clique for FORA do menu. Antes, o mousedown no próprio
    // item removia o menu antes do 'click' disparar - as opções não funcionavam.
    _fecharFora = ev => { if (!ev.target.closest('#pan-ctx')) fecharMenu(); };
    setTimeout(() => document.addEventListener('mousedown', _fecharFora, true), 0);
  }

  function menuCanvas(x, y) {
    const canvas = $('pan-canvas');
    const cr = canvas ? canvas.getBoundingClientRect() : { left: 0, top: 0 };
    const px = snap(Math.max(0, x - cr.left)), py = snap(Math.max(0, y - cr.top));
    abrirMenu(x, y, [
      { label: '+ Dado (KPI)', fn: () => novoWidget('dado', px, py) },
      { label: '+ Tabela', fn: () => novoWidget('tabela', px, py) },
      { label: '+ Gráfico', fn: () => novoWidget('grafico', px, py) },
      { label: '+ Insights', fn: () => novoWidget('insights', px, py) },
      { label: '+ Distribuição (resistência × fck)', fn: () => novoWidget('distribuicao', px, py) }
    ].concat(previaLigada ? [{ label: '+ Comparar períodos', fn: () => novoWidget('comparar', px, py) },
      { label: '+ Falhas por receita', fn: () => novoWidget('falhas', px, py) }] : []).concat([
      { sep: true },
      { label: 'Montar painel automático', fn: painelAutomatico },
      {
        label: 'Limpar painel', fn: async () => {
          if (!(await perguntar('Limpar painel', 'Remover todos os widgets deste painel?', 'Limpar'))) return;
          state.layouts[state.sheet] = [];
          salvar(); render();
        }
      }
    ]));
  }

  function menuWidget(x, y, it) {
    abrirMenu(x, y, [
      { label: 'Editar propriedades', fn: () => editar(it) },
      {
        label: 'Duplicar', fn: () => {
          const n = JSON.parse(JSON.stringify(it));
          n.id = genId(); n.y = (it.y || 0) + (it.h || 240) + GRID;
          layout().push(n); salvar(); render();
        }
      },
      { sep: true },
      {
        label: 'Excluir', fn: () => {
          const L = layout();
          for (let i = 0; i < L.length; i++) {
            if (L[i].id === it.id) { L.splice(i, 1); break; }
          }
          salvar(); render();
        }
      }
    ]);
  }

  /* -- criação e edição ---------------------------- */
  function autoMapa(f) {
    return (window.ConcreAutoMap && window.ConcreAutoMap(f.headers, f.rows)) || {};
  }

  // Coluna de ensaio: 28 dias primeiro (e' o que vale o laudo), depois 7 dias,
  // depois qualquer cabecalho que fale de MPa ou resistencia. As duas idades
  // vêm da escolha de colunas comum a todas as telas (colunas.js).
  function colunaDeResistencia(f) {
    const norm = h => String(h || '').trim().toUpperCase();
    const c = window.ConcreColunas;
    const acha = alvo => f.headers.find(h => norm(h).replace(/\.\d+$/, '') === alvo);
    const d28 = c ? c.nome(f.headers, 'mpa28') : acha('MPA 28');
    const d7 = c ? c.nome(f.headers, 'mpa7') : acha('MPA 7');
    return d28 || d7 || f.headers.find(h => /MPA|RESIST/.test(norm(h))) || '';
  }

  function novoWidget(tipo, x, y) {
    const f = dados();
    if (!f) return;
    const m = autoMapa(f);
    const cfg = {
      valor: m.valor || '', grupo: m.cat || '', colData: m.data || '',
      grao: 'mes', op: 'Soma', insights: false, total: true, topN: 12
    };
    if (tipo === 'grafico') { cfg.tipo = 'barra'; cfg.series = []; }
    if (tipo === 'tabela') cfg.colunas = [{ valor: cfg.valor, op: 'Soma' }, { valor: cfg.valor, op: '% do total' }];
    // A distribuicao nao e' sobre a coluna que mais soma, e' sobre a
    // resistencia. O autodetect escolhe volume (M3) e o widget nasceria
    // desenhando o histograma do tamanho dos caminhoes.
    if (tipo === 'distribuicao') cfg.valor = colunaDeResistencia(f) || cfg.valor;
    if (tipo === 'comparar') {
      const cc = window.ConcreColunas;
      cfg.colData = (cc && cc.nome(f.headers, 'data')) || cfg.colData;
      cfg.grupo = (cc && (cc.nome(f.headers, 'receita') || cc.nome(f.headers, 'produto'))) || '';
      cfg.mesA = ''; cfg.mesB = ''; cfg.topN = 15;
    }
    if (tipo === 'falhas') {
      const cc = window.ConcreColunas;
      cfg.grupo = (cc && (cc.nome(f.headers, 'produto') || cc.nome(f.headers, 'receita'))) || cfg.grupo;
      cfg.topN = 15; cfg.minimo = 5;
    }
    const tam = tipo === 'dado' ? { w: 240, h: 130 }
      : tipo === 'falhas' ? { w: 640, h: 400 }
      : tipo === 'comparar' ? { w: 980, h: 400 }
      : tipo === 'insights' ? { w: 460, h: 210 }
        : tipo === 'tabela' ? { w: 460, h: 300 }
          : tipo === 'distribuicao' ? { w: 700, h: 400 } : { w: 520, h: 280 };
    // A comparação é o maior quadro do painel. Solta onde se clicou, cobria os
    // gráficos em volta e parecia que eles tinham quebrado.
    const py = tipo === 'comparar' ? abaixoDoQueOcupa(layout(), x || 0, y || 0, tam.w, tam.h) : (y || 0);
    const it = { id: genId(), type: tipo, x: x || 0, y: py, w: tam.w, h: tam.h, config: cfg };
    layout().push(it);
    salvar(); render();
    if (tipo === 'comparar') {
      const el = document.querySelector('.pan-widget[data-wid="' + it.id + '"]');
      if (el) el.scrollIntoView({ block: 'nearest' });
    }
    editar(it);
  }

  // Desce até achar uma faixa onde o quadro não caia em cima de outro.
  function abaixoDoQueOcupa(L, x, y, w, h) {
    for (let guarda = 0; guarda <= L.length; guarda++) {
      const bate = L.find(o => x < (o.x || 0) + (o.w || 380) && x + w > (o.x || 0) &&
                               y < (o.y || 0) + (o.h || 240) && y + h > (o.y || 0));
      if (!bate) break;
      y = (bate.y || 0) + (bate.h || 240) + GRID;
    }
    return y;
  }

  function selHtml(id, headers, cur, rotulo) {
    const opts = ['<option value="">—</option>'].concat(headers.map(h =>
      '<option value="' + esc(h) + '"' + (h === cur ? ' selected' : '') + '>' + esc(h) + '</option>'));
    return '<label>' + rotulo + '</label><select id="' + id + '">' + opts.join('') + '</select>';
  }
  // Editor da formula: escreve, ou clica nos botoes, e ve a conta montada embaixo.
  const CHIPS_FORMULA = [['atual', 'valor atual'], ['anterior', 'valor anterior'], ['média', 'média'],
    ['total', 'total'], ['maior', 'maior'], ['menor', 'menor'], ['n', 'nº de linhas']];
  const CHIPS_CONTA = ['+', '−', '×', '÷', '^', '(', ')', '√'];
  const editorDeFormula = (texto, op) => '<div class="pw-fx"' + (op === FORMULA ? '' : ' hidden') + '>' +
    '<input class="pw-fx-txt" spellcheck="false" placeholder="(atual - anterior) / anterior * 100" value="' + esc(texto || '') + '">' +
    '<div class="pw-fx-chips">' + CHIPS_FORMULA.map(x => '<button type="button" data-fx="' + x[0] + '">' + x[1] + '</button>').join('') +
    '<span class="pw-fx-letras"></span>' +
    CHIPS_CONTA.map(x => '<button type="button" class="pw-fx-op" data-fx="' + x + '">' + x + '</button>').join('') +
    '</div><div class="pw-fx-previa"></div></div>';

  function atualizarFormula(fx) {
    const lista = fx.closest('.pw-cols');
    const qtos = lista ? lista.querySelectorAll('.pw-col-row').length : 0;
    const letras = [];
    for (let i = 0; i < qtos; i++) letras.push(String.fromCharCode(65 + i));
    fx.querySelector('.pw-fx-letras').innerHTML = letras.map(L =>
      '<button type="button" class="pw-fx-letra" data-fx="' + L + '" title="Valor da coluna ' + L + '">' + L + '</button>').join('');
    const r = lerFormula(fx.querySelector('.pw-fx-txt').value, letras);
    const previa = fx.querySelector('.pw-fx-previa');
    previa.classList.toggle('erro', !!r.erro);
    previa.innerHTML = r.erro ? esc(r.erro) : formulaHtml(r.arvore);
  }

  function ligarFormulas(raiz) {
    const todas = () => raiz.querySelectorAll('.pw-fx').forEach(atualizarFormula);
    raiz.addEventListener('input', e => {
      if (e.target.classList.contains('pw-fx-txt')) atualizarFormula(e.target.closest('.pw-fx'));
    });
    raiz.addEventListener('change', e => {
      if (!e.target.matches('.pw-c-op, .pw-s-op, #pw-op')) return;
      const fx = (e.target.closest('.pw-col-row') || e.target.parentElement).querySelector('.pw-fx');
      if (fx) { fx.hidden = e.target.value !== FORMULA; atualizarFormula(fx); }
    });
    raiz.addEventListener('click', e => {
      if (e.target.matches('.pw-del, #pw-addcol, #pw-addfx, #pw-addserie')) setTimeout(todas, 0);
      const b = e.target.closest('[data-fx]');
      if (!b) return;
      const inp = b.closest('.pw-fx').querySelector('.pw-fx-txt');
      const a = inp.selectionStart === null ? inp.value.length : inp.selectionStart;
      const z = inp.selectionEnd === null ? a : inp.selectionEnd;
      const ch = b.dataset.fx;
      const t = ch === '√' ? '√(' : /^[+−×÷^]$/.test(ch) ? ' ' + ch + ' ' : ch;
      inp.value = inp.value.slice(0, a) + t + inp.value.slice(z);
      inp.focus();
      inp.setSelectionRange(a + t.length, a + t.length);
      atualizarFormula(inp.closest('.pw-fx'));
    });
    todas();
  }

  const opSel = (id, cur, lista) => '<select id="' + id + '">' + (lista || opsDaTela()).map(o =>
    '<option' + (o === cur ? ' selected' : '') + '>' + o + '</option>').join('') + '</select>';

  function editar(it) {
    if (it.type === 'comparar') return editarComparacao(it);
    if (it.type === 'falhas') return editarFalhas(it);
    const f = dados();
    if (!f || !window.openModal) return;
    const c = it.config;
    const H = f.headers;
    const grupoOpts = '<option value="">—</option>' +
      '<option value="__periodo__"' + (c.grupo === '__periodo__' ? ' selected' : '') + '>Período (data)</option>' +
      H.map(h => '<option value="' + esc(h) + '"' + (h === c.grupo ? ' selected' : '') + '>' + esc(h) + '</option>').join('');
    const selGrao = '<label>Agrupar datas por</label><select id="pw-grao">' +
      [['dia', 'Dia'], ['mes', 'Mês'], ['ano', 'Ano']].map(g =>
        '<option value="' + g[0] + '"' + (g[0] === (c.grao || 'mes') ? ' selected' : '') + '>' + g[1] + '</option>').join('') + '</select>';

    const campoIsolados = '<label class="pw-check"><input type="checkbox" id="pw-isolados"' + (c.mostrarIsolados ? ' checked' : '') +
      '> Mostrar meses isolados</label><p class="rc-dica">Mês isolado é data solta: a 3 meses ou mais do período ' +
      'principal e com menos de 1% das linhas. Desmarcado, ele fica fora do gráfico e o quadro avisa quais ficaram.</p>';

    // Com a prévia, o formulário segue a ordem de quem preenche de cima para
    // baixo e cada campo surge logo abaixo do controle que o revela. Todos já
    // vêm na janela: trocar o tipo ou o interruptor só mostra e esconde (ver
    // ajustarCampos), sem fechar e reabrir.
    const emOrdem = previaLigada && (it.type === 'grafico' || it.type === 'tabela');
    const bloco = (id, html) => '<div class="pw-bloco" id="' + id + '">' + html + '</div>';

    let corpo = '<label>Título</label><input id="pw-tit" value="' + esc(c.titulo || '') +
      '" placeholder="' + esc(tituloAuto(it)) + '">';

    if (it.type === 'grafico') {
      corpo += '<label>Tipo</label><select id="pw-tipo">' + tiposDaTela().map(t =>
        '<option value="' + t[0] + '"' + (t[0] === (c.tipo || 'barra') ? ' selected' : '') + '>' + t[1] + '</option>').join('') + '</select>';
      if (emOrdem) corpo += bloco('pw-b-seriecat', selHtml('pw-seriecat', H, c.serieCat, 'Dividir barras por'));
    }
    if (emOrdem) {
      // O interruptor troca o "Período (data)" que ficava no meio da lista de
      // colunas. Config salva abre igual: c.grupo === '__periodo__' é ligado.
      const porData = c.grupo === '__periodo__';
      const auto = autoMapa(f), cc = window.ConcreColunas;
      const colData = c.colData || (cc && cc.nome(H, 'data')) || auto.data || '';
      const categoria = (!porData && c.grupo) || c.grupoCat || auto.cat || '';
      corpo += bloco('pw-b-pordata', '<label class="pw-check pw-interruptor"><input type="checkbox" id="pw-pordata"' +
          (porData ? ' checked' : '') + '> Agrupar por data</label>') +
        bloco('pw-b-data', selHtml('pw-data', H, colData, 'Coluna de data')) +
        bloco('pw-b-grao', selGrao + (it.type === 'grafico' ? campoIsolados : '')) +
        bloco('pw-b-cat', selHtml('pw-grupo', H, categoria, 'Agrupar por'));
    } else {
      if (it.type === 'tabela' || it.type === 'grafico') {
        corpo += '<label>Agrupar por</label><select id="pw-grupo">' + grupoOpts + '</select>';
      }
      // A distribuição não tem eixo de tempo: ela conta quantos ensaios caíram em
      // cada faixa de resistência. Oferecer "agrupar datas por mês" ali só faz o
      // usuário preencher um campo que não muda nada no desenho.
      if (it.type !== 'distribuicao') {
        corpo += selHtml('pw-data', H, c.colData, 'Coluna de data');
        corpo += selGrao;
        if (it.type === 'grafico') corpo += campoIsolados;
      }
    }
    corpo += selHtml('pw-valor', H, c.valor,
      it.type === 'distribuicao' ? 'Coluna do ensaio (ex.: MPA 28)' : 'Coluna de valor');

    if (it.type === 'distribuicao') {
      corpo += '<label>fck do projeto (MPa)</label><input id="pw-fck" value="' +
        esc(c.fck || '') + '" placeholder="deixe vazio para ler do produto/receita">';
      corpo += '<p class="rc-dica">Vazio, o fck sai da coluna PRODUTO ou RECEITA ' +
        '(o valor depois de "FCK"). Preencha quando a planilha não trouxer essa ' +
        'informação, ou para comparar a mesma produção com outro limite.</p>';
    }

    if (it.type === 'dado') {
      corpo += '<label>Operação</label>' + opSel('pw-op', c.op || 'Soma', OPS);
      corpo += '<label>Operação base (para % e crescimento)</label>' + opSel('pw-opbase', c.opBase || 'Soma', OPS_BASE);
      corpo += '<label>Categoria (para "% do total")</label><select id="pw-grupo">' + grupoOpts + '</select>';
      corpo += '<label>Valor da categoria</label><input id="pw-fval" value="' + esc(c.filtroValor || '') +
        '" placeholder="ex.: Serviços">';
      corpo += '<label class="pw-check"><input type="checkbox" id="pw-ensaio"' +
        (c.ensaio ? ' checked' : '') + '> Tratar como ensaio de resistência</label>';
      corpo += '<p class="rc-dica">Marcado, o cartão lê a coluna do jeito do ' +
        'laboratório: junta as colunas repetidas (MPA 28 e MPA 28.1), ignora ' +
        'o ensaio ainda não rompido (zero) e descarta valor impossível para ' +
        'concreto - os mesmos números do gráfico de distribuição.</p>';
      corpo += '<label>Legenda</label><input id="pw-sub" value="' + esc(c.subtitulo || '') + '" placeholder="opcional">';
    }
    if (it.type === 'tabela') {
      corpo += '<label>Colunas (cada uma com sua operação)</label><div id="pw-cols" class="pw-cols"></div>' +
        '<button type="button" id="pw-addcol" class="pw-add">+ coluna</button>' +
        (previaLigada ? '<button type="button" id="pw-addfx" class="pw-add">+ fórmula</button>' : '') +
        '<label class="pw-check"><input type="checkbox" id="pw-ins"' + (c.insights ? ' checked' : '') +
        '> Mostrar insights</label>' +
        '<label class="pw-check"><input type="checkbox" id="pw-tot"' + (c.total !== false ? ' checked' : '') + '> Linha de total</label>' +
        '<label>Máximo de grupos</label><input id="pw-topn" type="number" min="0" max="500" value="' + (c.topN || 12) + '">';
    }
    if (it.type === 'grafico') {
      // Cada tipo de gráfico usa um conjunto diferente de campos. Mostrar todos
      // para todos fazia o usuário preencher "Dividir barras por" numa pizza e
      // achar que o app tinha ignorado - quando na verdade aquele campo nunca
      // teve efeito ali. Os que não servem ficam escondidos, e a lista muda
      // sozinha ao trocar o tipo.
      const tipoAtual = c.tipo || 'barra';
      // Era "barra": o campo aparecia onde não tem efeito e faltava justo na
      // barra empilhada, que manda escolher nele.
      const usaEmpilhado = tipoAtual === 'empilhado';
      const usaSeries = tipoAtual === 'barra' || tipoAtual === 'linha';
      const usaTopN = tipoAtual !== 'calor';
      const avisoSeries = '<p class="rc-dica" id="pw-aviso-series"' +
        ((c.series || []).length ? '' : ' hidden') + '>A primeira série é o gráfico que já estava aqui, ' +
        'trazido para a lista. Enquanto houver séries, são elas que mandam - os campos ' +
        '<b>Coluna de valor</b> e <b>Operação</b> acima ficam de reserva. Apague todas para voltar ao gráfico simples.</p>';
      const campoTopN = '<label>Máximo de grupos</label><input id="pw-topn" type="number" min="0" max="500" value="' + (c.topN || 12) + '">';
      const campoIns = '<label class="pw-check"><input type="checkbox" id="pw-ins"' +
        (c.insights ? ' checked' : '') + '> Mostrar insights abaixo do gráfico</label>';

      if (emOrdem) {
        // Botão em cima da lista: a série nova nasce logo abaixo de onde se
        // clicou. Com o botão no fim, ela entrava acima dele e o botão fugia.
        corpo += bloco('pw-b-op', '<label>Operação</label>' + opSel('pw-op', c.op || 'Soma') + editorDeFormula(c.formula, c.op)) +
          bloco('pw-b-series', '<label>Séries extras - combo barra + linha</label>' +
            '<button type="button" id="pw-addserie" class="pw-add">+ gráfico (série)</button>' +
            '<div id="pw-series" class="pw-cols"></div>' + avisoSeries) +
          bloco('pw-b-umamedida', '<p class="rc-dica" id="pw-umamedida"></p>') +
          bloco('pw-b-topn', campoTopN) + campoIns;
      } else {
        corpo += '<label>Operação</label>' + opSel('pw-op', c.op || 'Soma');
        corpo += campoIns;
        if (usaEmpilhado) {
          corpo += selHtml('pw-seriecat', H, c.serieCat, 'Dividir barras por (empilhado)');
        }
        if (!usaSeries) {
          corpo += '<p class="rc-dica">Gráfico de ' +
            (tipoAtual === 'pizza' ? 'pizza' : tipoAtual === 'empilhado' ? 'barra empilhada' : 'mapa de calor') +
            ' mostra uma medida só. Para comparar duas, use barra ou linha.</p>';
        }
        if (usaSeries) {
          corpo += '<label>Séries extras - combo barra + linha</label>' + avisoSeries +
            '<div id="pw-series" class="pw-cols"></div>' +
            '<button type="button" id="pw-addserie" class="pw-add">+ gráfico (série)</button>';
        }
        if (usaTopN) corpo += campoTopN;
      }
    }

    const nomeTipo = it.type === 'dado' ? 'Dado' : it.type === 'tabela' ? 'Tabela'
      : it.type === 'insights' ? 'Insights'
        : it.type === 'distribuicao' ? 'Distribuição' : 'Gráfico';

    window.openModal('Propriedades - ' + nomeTipo, corpo, () => {
      const g = id => { const el = document.getElementById(id); return el ? el.value : undefined; };
      const gc = id => { const el = document.getElementById(id); return el ? el.checked : undefined; };
      c.titulo = g('pw-tit') || '';
      if (g('pw-data') !== undefined) c.colData = g('pw-data');
      if (g('pw-grao') !== undefined) c.grao = g('pw-grao');
      c.valor = g('pw-valor') || '';
      if (g('pw-grupo') !== undefined) c.grupo = g('pw-grupo') || '';
      // O interruptor manda; a categoria fica guardada para quando ele desligar.
      if (gc('pw-pordata')) { if (c.grupo) c.grupoCat = c.grupo; c.grupo = '__periodo__'; }
      if (gc('pw-isolados') !== undefined) c.mostrarIsolados = gc('pw-isolados');
      if (g('pw-tipo') !== undefined) c.tipo = g('pw-tipo');
      if (g('pw-op') !== undefined) c.op = g('pw-op');
      const fxGrafico = document.querySelector('#pw-b-op .pw-fx-txt');
      if (fxGrafico) c.formula = fxGrafico.value;
      if (g('pw-opbase') !== undefined) c.opBase = g('pw-opbase');
      if (g('pw-fval') !== undefined) c.filtroValor = g('pw-fval');
      if (g('pw-sub') !== undefined) c.subtitulo = g('pw-sub');
      if (g('pw-fck') !== undefined) c.fck = g('pw-fck');
      if (gc('pw-ensaio') !== undefined) c.ensaio = gc('pw-ensaio');
      if (g('pw-seriecat') !== undefined) c.serieCat = g('pw-seriecat') || '';
      if (gc('pw-ins') !== undefined) c.insights = gc('pw-ins');
      if (gc('pw-tot') !== undefined) c.total = gc('pw-tot');
      if (g('pw-topn') !== undefined) c.topN = parseInt(g('pw-topn')) || 0;
      if (it.type === 'tabela') c.colunas = lerColunas();
      // So' regrava as séries se a lista estava na tela. Sem isto, trocar o
      // tipo para pizza (que não mostra séries) apagaria as que estavam
      // salvas, e voltar para barra devolveria um gráfico vazio.
      if (it.type === 'grafico' && document.getElementById('pw-series')) {
        c.series = lerSeries();
      }
      salvar();
      if (window.closeModal) window.closeModal();
      render();
    }, 'modal-props' + (emOrdem ? ' modal-props-topo' : ''));

    // Agora, e não no timeout lá embaixo: esperar faria os campos dos outros
    // tipos piscarem na janela antes de sumir.
    if (emOrdem) {
      ['pw-tipo', 'pw-pordata'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('change', ajustarCampos);
      });
      ajustarCampos();
    }

    function ajustarCampos() {
      const el = id => document.getElementById(id);
      const mostra = (id, sim) => { const b = el(id); if (b) b.hidden = !sim; };
      const tipo = el('pw-tipo') ? el('pw-tipo').value : '';     // a tabela não tem tipo
      const calor = tipo === 'calor';
      const porData = el('pw-pordata').checked;
      mostra('pw-b-seriecat', tipo === 'empilhado');
      // O mapa de calor é sempre por dia: só precisa saber de qual coluna.
      mostra('pw-b-pordata', !calor);
      mostra('pw-b-data', calor || porData);
      mostra('pw-b-grao', porData && !calor);
      mostra('pw-b-cat', !porData && !calor);
      mostra('pw-b-op', !calor);
      mostra('pw-b-series', tipo === 'barra' || tipo === 'linha');
      mostra('pw-b-topn', !calor);
      mostra('pw-b-umamedida', tipo === 'pizza' || tipo === 'barraH' || calor);
      const dica = el('pw-umamedida');
      if (dica) {
        dica.textContent = 'Gráfico de ' + (calor ? 'mapa de calor' : tipo === 'barraH' ? 'barra deitada' : 'pizza') +
          ' mostra uma medida só. Para comparar duas, use barra.';
      }
    }

    function linhaColuna(cl) {
      const d = document.createElement('div');
      d.className = 'pw-col-row';
      d.innerHTML = '<select class="pw-c-val"><option value="">— contagem —</option>' +
        H.map(h => '<option value="' + esc(h) + '"' + (h === cl.valor ? ' selected' : '') + '>' + esc(h) + '</option>').join('') +
        '</select><select class="pw-c-op">' + opsDaTela().map(o =>
          '<option' + (o === cl.op ? ' selected' : '') + '>' + o + '</option>').join('') +
        '</select><input class="pw-c-tit" placeholder="título" value="' + esc(cl.titulo || '') + '">' +
        '<button type="button" class="pw-del" title="Remover">×</button>' +
        (previaLigada ? editorDeFormula(cl.formula, cl.op) : '');
      d.querySelector('.pw-del').addEventListener('click', () => d.remove());
      return d;
    }
    function linhaSerie(s) {
      const d = document.createElement('div');
      d.className = 'pw-col-row';
      d.innerHTML = '<select class="pw-s-val"><option value="">— contagem —</option>' +
        H.map(h => '<option value="' + esc(h) + '"' + (h === s.valor ? ' selected' : '') + '>' + esc(h) + '</option>').join('') +
        '</select><select class="pw-s-op">' + opsDaTela().map(o =>
          '<option' + (o === s.op ? ' selected' : '') + '>' + o + '</option>').join('') + '</select>' +
        '<select class="pw-s-tipo"><option value="barra"' + (s.tipo !== 'linha' ? ' selected' : '') + '>barra</option>' +
        '<option value="linha"' + (s.tipo === 'linha' ? ' selected' : '') + '>linha</option></select>' +
        '<select class="pw-s-eixo"><option value="esq"' + (s.eixo !== 'dir' ? ' selected' : '') + '>eixo esq.</option>' +
        '<option value="dir"' + (s.eixo === 'dir' ? ' selected' : '') + '>eixo dir.</option></select>' +
        '<button type="button" class="pw-del" title="Remover">×</button>' +
        (previaLigada ? editorDeFormula(s.formula, s.op) : '');
      d.querySelector('.pw-del').addEventListener('click', () => { d.remove(); atualizarAvisoSeries(); });
      return d;
    }
    function lerColunas() {
      const out = [];
      document.querySelectorAll('#pw-cols .pw-col-row').forEach(d => {
        out.push({
          valor: d.querySelector('.pw-c-val').value,
          op: d.querySelector('.pw-c-op').value,
          formula: (d.querySelector('.pw-fx-txt') || {}).value,
          titulo: d.querySelector('.pw-c-tit').value
        });
      });
      return out.filter(x => x.op);
    }
    function lerSeries() {
      const cores = ['#2a5298', '#2a6640', '#e05c3a', '#8a2be2', '#e8a030'];
      const out = [];
      document.querySelectorAll('#pw-series .pw-col-row').forEach((d, i) => {
        out.push({
          valor: d.querySelector('.pw-s-val').value,
          op: d.querySelector('.pw-s-op').value,
          formula: (d.querySelector('.pw-fx-txt') || {}).value,
          tipo: d.querySelector('.pw-s-tipo').value,
          eixo: d.querySelector('.pw-s-eixo').value,
          cor: cores[i % cores.length]
        });
      });
      return out.filter(x => x.op);
    }
    function atualizarAvisoSeries() {
      const aviso = document.getElementById('pw-aviso-series');
      const sbox = document.getElementById('pw-series');
      if (aviso && sbox) aviso.hidden = !sbox.querySelector('.pw-col-row');
    }

    setTimeout(() => {
      const box = document.getElementById('pw-cols');
      if (box) {
        (c.colunas || []).forEach(cl => box.appendChild(linhaColuna(cl)));
        const b1 = document.getElementById('pw-addcol');
        if (b1) b1.addEventListener('click', () => box.appendChild(linhaColuna({ valor: c.valor, op: 'Soma' })));
        const bFx = document.getElementById('pw-addfx');
        if (bFx) bFx.addEventListener('click', () => box.appendChild(linhaColuna({ valor: c.valor, op: FORMULA })));
      }
      // Trocar o tipo tem que trocar os campos na hora. Se so' mudasse ao
      // reabrir, o usuário escolheria "Pizza" e continuaria vendo "Dividir
      // barras por" logo abaixo.
      const selTipo = document.getElementById('pw-tipo');
      if (selTipo && !emOrdem) {
        selTipo.addEventListener('change', () => {
          if (document.getElementById('pw-series')) c.series = lerSeries();
          c.tipo = selTipo.value;
          const g2 = id => { const el = document.getElementById(id); return el ? el.value : undefined; };
          c.titulo = g2('pw-tit') || c.titulo;
          c.grupo = g2('pw-grupo') !== undefined ? g2('pw-grupo') : c.grupo;
          c.valor = g2('pw-valor') !== undefined ? g2('pw-valor') : c.valor;
          c.op = g2('pw-op') !== undefined ? g2('pw-op') : c.op;
          window.closeModal && window.closeModal();
          setTimeout(() => editar(it), 60);
        });
      }

      const sbox = document.getElementById('pw-series');
      if (sbox) {
        (c.series || []).forEach(s => sbox.appendChild(linhaSerie(s)));
        const b2 = document.getElementById('pw-addserie');
        if (b2) b2.addEventListener('click', () => {
          // A PRIMEIRA série extra tem que trazer o gráfico que já estava na
          // tela junto. Antes ela entrava sozinha e os campos de cima paravam
          // de valer - de fora, o desenho original simplesmente sumia e dava
          // lugar ao novo. "Série extra" que apaga o gráfico não é extra.
          // Lê do FORMULÁRIO, não do que estava salvo: o usuário pode ter
          // acabado de trocar a coluna e ainda não ter confirmado. Copiar o
          // valor antigo faria a primeira série nascer diferente do gráfico
          // que ele está vendo na tela.
          const el = id => document.getElementById(id);
          const valorAtual = (el('pw-valor') || {}).value || c.valor || '';
          const opAtual = (el('pw-op') || {}).value || c.op || 'Soma';
          if (!sbox.querySelector('.pw-col-row')) {
            sbox.appendChild(linhaSerie({
              valor: valorAtual, op: opAtual,
              formula: (document.querySelector('#pw-b-op .pw-fx-txt') || {}).value,
              tipo: (c.tipo === 'linha' ? 'linha' : 'barra'), eixo: 'esq'
            }));
          }
          sbox.appendChild(linhaSerie({ valor: valorAtual, op: 'Soma', tipo: 'linha', eixo: 'dir' }));
          atualizarAvisoSeries();
          if (emOrdem) sbox.lastElementChild.scrollIntoView({ block: 'nearest' });
        });
      }
      const corpoDaCaixa = document.querySelector('#modal-content .modal-body');
      if (previaLigada && corpoDaCaixa) ligarFormulas(corpoDaCaixa);
    }, 30);
  }

  /* -- painel automático (um clique monta tudo) ---- */

  // Acha uma coluna pelo nome, ignorando caixa, acento de M³ e o sufixo que o
  // Excel gruda em cabeçalho repetido (".1", ".2").
  function acharCol(f, nomes) {
    const norm = h => String(h || '').trim().toUpperCase().replace(/\.\d+$/, '');
    for (const n of nomes) {
      const achou = f.headers.find(h => norm(h) === n);
      if (achou) return achou;
    }
    return '';
  }

  /* O Naor quer que o Painel substitua o DASHBOARD. Para isso, um clique tem de
   * entregar o painel do laboratório pronto - os mesmos números e os mesmos
   * gráficos que ele já aprovou lá. Montar barra genérica e deixar o resto por
   * conta do usuário não substitui nada: só transfere o trabalho para ele.  */
  // A coluna de cada papel vem da escolha comum (colunas.js) - a mesma que o
  // Dashboard, o Relatório e a Previsão usam. Uma planilha com "Volume (m³)"
  // e "Contratante" montava o painel sem os gráficos de volume e de cliente.
  function colunaDoPapel(f, papel, reserva) {
    const c = window.ConcreColunas;
    return c ? c.nome(f.headers, papel) : acharCol(f, reserva);
  }

  function planoLaboratorio(f) {
    const mpa = colunaDeResistencia(f);
    const vol = colunaDoPapel(f, 'volume', ['M³', 'M3', 'VOLUME']);
    const cli = colunaDoPapel(f, 'cliente', ['CLIENTE']);
    const prod = colunaDoPapel(f, 'produto', ['PRODUTO']) || colunaDoPapel(f, 'receita', ['RECEITA']);
    const data = colunaDoPapel(f, 'data', ['DATA']) || (autoMapa(f).data || '');
    // Sem ensaio nem volume não é planilha de usina; cai no painel genérico.
    if (!mpa && !vol) return null;
    return { mpa, vol, cli, prod, data };
  }

  function montarLaboratorio(f, lb) {
    const L = [];
    const add = (type, x, y, w, h, cfg) => L.push({
      id: genId(), type: type, x: x, y: y, w: w, h: h, config: cfg
    });
    const base = () => ({ colData: lb.data, grao: 'mes', topN: 12 });
    const com = extra => Object.assign(base(), extra);

    let y = 0;
    add('dado', 0, y, 240, 120, com({ valor: '', op: 'Contagem', titulo: 'Registros' }));
    if (lb.vol) add('dado', 250, y, 240, 120, com({ valor: lb.vol, op: 'Soma', titulo: 'Volume total (m³)' }));
    if (lb.mpa) add('dado', 500, y, 240, 120,
      com({ valor: lb.mpa, op: 'Média', titulo: 'Média ' + lb.mpa, ensaio: true }));
    if (lb.mpa) add('dado', 750, y, 240, 120,
      com({ valor: lb.mpa, op: 'Desvio padrão', titulo: 'Desvio padrão', ensaio: true }));
    y += 130;

    if (lb.data && lb.vol) {
      add('grafico', 0, y, 740, 300, com({
        tipo: 'barra', grupo: '__periodo__', valor: lb.vol, op: 'Soma',
        titulo: 'Produção e crescimento',
        series: [
          { valor: lb.vol, op: 'Soma', tipo: 'barra', eixo: 'esq', cor: '#2a5298', titulo: 'Produção (m³)' },
          { valor: lb.vol, op: 'Crescimento %', tipo: 'linha', eixo: 'dir', cor: '#2a6640', titulo: 'Crescimento %' }
        ]
      }));
      add('grafico', 750, y, 480, 300, com({
        tipo: 'calor', valor: lb.vol, titulo: 'Mapa de calor - volume por dia'
      }));
      y += 310;
    }

    if (lb.cli && lb.vol) {
      add('grafico', 0, y, 610, 300, com({
        tipo: 'barra', grupo: lb.cli, valor: lb.vol, op: 'Soma', titulo: 'Volume por cliente (m³)'
      }));
    }
    if (lb.prod && lb.vol) {
      add('grafico', 620, y, 610, 300, com({
        tipo: 'barra', grupo: lb.prod, valor: lb.vol, op: 'Soma', titulo: 'Volume por produto (m³)'
      }));
    }
    if ((lb.cli || lb.prod) && lb.vol) y += 310;

    if (lb.mpa) {
      add('distribuicao', 0, y, 740, 400, com({
        valor: lb.mpa, titulo: 'Distribuição da resistência (' + lb.mpa + ')'
      }));
      add('insights', 750, y, 480, 400, com({ valor: lb.vol || lb.mpa, grupo: lb.prod || lb.cli }));
    }
    return L;
  }

  function montarGenerico(f, m) {
    const base = { valor: m.valor || '', grupo: m.cat || '', colData: m.data || '', grao: 'mes', topN: 12 };
    const L = [];
    const add = (type, x, y, w, h, cfg) => {
      const c = {};
      Object.keys(base).forEach(k => { c[k] = base[k]; });
      Object.keys(cfg).forEach(k => { c[k] = cfg[k]; });
      L.push({ id: genId(), type: type, x: x, y: y, w: w, h: h, config: c });
    };

    add('dado', 0, 0, 240, 120, { op: 'Soma', titulo: 'Total' });
    add('dado', 250, 0, 240, 120, { op: 'Média', titulo: 'Média' });
    add('dado', 500, 0, 240, 120, { op: 'Contagem', titulo: 'Registros' });
    if (m.data) add('dado', 750, 0, 240, 120, { op: 'Crescimento %', opBase: 'Soma', titulo: 'Crescimento' });
    add('insights', 0, 130, 740, 200, {});
    if (m.data) {
      add('grafico', 750, 130, 480, 200, { tipo: 'calor', titulo: 'Mapa de calor' });
      add('grafico', 0, 340, 740, 300, {
        tipo: 'barra', grupo: '__periodo__', op: 'Soma', titulo: 'Produção e crescimento',
        series: [
          { valor: m.valor, op: 'Soma', tipo: 'barra', eixo: 'esq', cor: '#2a5298' },
          { valor: m.valor, op: 'Crescimento %', tipo: 'linha', eixo: 'dir', cor: '#2a6640' }
        ]
      });
    }
    if (m.cat) {
      add('grafico', 750, 340, 480, 300, { tipo: 'pizza', op: 'Soma', titulo: 'Distribuição' });
      add('tabela', 0, 650, 740, 320, {
        insights: true, total: true,
        colunas: [
          { valor: m.valor, op: 'Soma' },
          { valor: m.valor, op: '% do total' },
          { valor: m.valor, op: 'Média' }
        ]
      });
    }
    return L;
  }

  function painelAutomatico() {
    const f = dados();
    if (!f) return;
    const lb = planoLaboratorio(f);
    let L, aviso;
    if (lb) {
      L = montarLaboratorio(f, lb);
      aviso = 'Painel do laboratório montado';
    } else {
      const m = autoMapa(f);
      if (!m.valor && !m.cat) {
        if (window.showToast) window.showToast('Não consegui detectar as colunas - adicione widgets manualmente', 'error');
        return;
      }
      L = montarGenerico(f, m);
      aviso = 'Painel montado automaticamente';
    }
    limparFoco();
    state.layouts[state.sheet] = L;
    salvar(); render();
    if (window.showToast) window.showToast(aviso, 'success');
  }

  /* -- init ---------------------------------------- */
  function init() {
    const b = $('pan-auto');
    if (b) b.addEventListener('click', painelAutomatico);
    const r = $('pan-refresh');
    if (r) r.addEventListener('click', render);
    const p = $('pan-present');
    if (p) p.addEventListener('click', () => {
      const m = $('module-painel');
      m.classList.add('ana-presenting');
      (m.requestFullscreen ? m.requestFullscreen() : Promise.reject())
        .catch(() => m.classList.remove('ana-presenting'));
    });
    document.addEventListener('fullscreenchange', () => {
      const m = $('module-painel');
      if (m && !document.fullscreenElement) m.classList.remove('ana-presenting');
    });
    window.addEventListener('concrestats:datachanged', () => {
      const el = $('module-painel');
      if (el && el.style.display !== 'none') setTimeout(render, 60);
    });
    carregar();
  }

  window.PainelModule = {
    onModuleEnter: () => {
      if (!state.carregado) carregar().then(render);
      else render();
    },
    // para o Modo Teste: as colunas que o painel automático usaria agora
    _planoLaboratorio: () => { const f = dados(); return f ? planoLaboratorio(f) : null; },
    _compararMeses: (cfg, fTeste) => { const f = fTeste || dados(); return f ? compararMeses(f, cfg || {}) : null; },
    _desenharComparacao: desenharComparacao,
    _mesesIsolados: mesesIsolados,
    _formula: { ler: lerFormula, calcular: calcularFormula, html: formulaHtml, agrupar: agrupar },
    _tirarMesesSoltos: tirarMesesSoltos,
    _textoForaDoEixo: textoForaDoEixo,
    _botaoVerLinhas: botaoVerLinhas,
    _falhas: falhasPorGrupo,
    _recorteDoEixo: recorteDoEixo,
    _focar: focar,
    _editar: editar,
  };
  document.addEventListener('DOMContentLoaded', init);
})();
