/*
 * fontes.js - fonte avancada: API, SQLite ou ODBC. O dado cai na grade como uma
 * planilha e todas as telas funcionam igual; o Recarregar busca de novo.
 */
(function () {
  'use strict';

  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  // Senha nao fica nas preferencias: nem chave de API, nem o PWD da conexao.
  const semSegredo = c => ({ tipo: c.tipo, url: c.url, arquivo: c.arquivo, consulta: c.consulta,
                             conexao: String(c.conexao || '').replace(/(pwd|password)\s*=[^;]*;?/ig, '') });

  function campos(tipo, c) {
    if (tipo === 'api') {
      return '<label for="ft-url">Endereço (JSON ou CSV)</label><input id="ft-url" value="' + esc(c.url) + '" placeholder="https://servidor/api/ensaios">' +
        '<label for="ft-chave">Chave de acesso, se houver</label><input id="ft-chave" type="password" autocomplete="off">';
    }
    const base = tipo === 'sqlite'
      ? '<label for="ft-arq">Caminho do arquivo .db</label><input id="ft-arq" value="' + esc(c.arquivo) + '">'
      : '<label for="ft-con">Conexão ODBC</label><input id="ft-con" value="' + esc(c.conexao) + '" placeholder="Driver={SQL Server};Server=servidor;Database=lab;UID=usuario;PWD=senha">';
    return base + '<label for="ft-sql">Consulta (só SELECT)</label><textarea id="ft-sql" rows="4">' + esc(c.consulta) + '</textarea>';
  }

  async function abrir() {
    if (!window.openModal) return;
    const p = window.prefsGet ? await window.prefsGet().catch(() => null) : null;
    const salva = (p && p.fonte) || { tipo: 'api' };
    window.openModal('Banco de dados ou API',
      '<p class="col-intro">Traz os dados para a grade como se fossem uma planilha. O programa só lê: nada é gravado no banco, e a senha não fica guardada.</p>' +
      '<label for="ft-tipo">De onde</label><select id="ft-tipo"><option value="api">API (internet ou rede)</option>' +
      '<option value="sqlite">Arquivo SQLite</option><option value="odbc">Banco por ODBC (SQL Server, MySQL, Postgres...)</option></select>' +
      '<div id="ft-campos"></div><p id="ft-msg" class="rc-dica"></p>', carregar, 'modal-laboratorio');
    const ok = $('modal-confirm'); if (ok) ok.textContent = 'Trazer os dados';
    $('ft-tipo').value = salva.tipo || 'api';
    const trocar = () => { $('ft-campos').innerHTML = campos($('ft-tipo').value, salva); };
    $('ft-tipo').addEventListener('change', trocar);
    trocar();
  }

  async function carregar() {
    const v = id => ($(id) ? $(id).value.trim() : '');
    const cfg = { tipo: $('ft-tipo').value, url: v('ft-url'), chave: v('ft-chave'), arquivo: v('ft-arq'), conexao: v('ft-con'), consulta: v('ft-sql') };
    $('ft-msg').textContent = 'Buscando...';
    const r = await fetch('/api/fonte/carregar', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.assign({ session_id: SESSION_ID }, cfg)) }).then(x => x.json()).catch(() => null);
    if (!r || !r.success) { $('ft-msg').textContent = 'Não deu: ' + ((r && r.error) || 'sem resposta'); return; }
    fetch('/api/prefs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fonte: semSegredo(cfg) }) }).catch(() => {});
    window.closeModal();
    loadSheetData(r);
    if (typeof markSaved === 'function') markSaved();
    if (typeof toast === 'function') toast((r.data.data || []).length.toLocaleString('pt-BR') + ' linhas trazidas da fonte', 'success');
  }

  window.ConcreFontes = { abrir, semSegredo };
})();
