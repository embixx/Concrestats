/**
 * previsao.js — Previsão do rompimento de 28 dias e alerta de receita fora da faixa
 *
 * Pedido do Naor: "fazer previsão de resultados de receita, e identificar na
 * tabela que receitas estão saindo da faixa de resistência desejada".
 *
 * Por que isto NÃO é um modelo de linguagem
 * -----------------------------------------
 * Num laboratório o número precisa ser defensável na frente do cliente: de onde
 * saiu, com quantos ensaios, com que erro. Um palpite que ninguém consegue
 * rastrear não serve para nada aqui — e ainda exigiria embutir chave de API num
 * programa que é distribuído, que é justamente o que estamos evitando.
 *
 * Então é estatística, com a conta à mostra. E com uma regra: quando o histórico
 * não sustenta a previsão, esta tela DIZ isso em vez de inventar um número.
 *
 * O que foi medido antes de escrever (4.809 ensaios reais da Usinop, treinando
 * na metade antiga de cada receita e testando na metade nova):
 *
 *     palpite burro ("essa receita costuma dar X")   6,33 MPa de erro
 *     razão 28/7 da própria receita                  5,30 MPa
 *     reta ajustada na própria receita               4,73 MPa   <- é o que usamos
 *
 * Ganha do palpite burro por cerca de 25%. É real, e é pouco: por isso a margem
 * aparece SEMPRE junto do número.
 */
(function () {
  'use strict';

  // Mínimo para a reta valer alguma coisa. Abaixo disso a reta acompanha o
  // ruído e erra com confiança, que é pior do que não responder.
  const MINIMO_DE_ENSAIOS = 12;
  // Acima deste erro a própria receita é irregular demais para ser prevista.
  const ERRO_INACEITAVEL = 8;
  // Para o alerta de faixa basta menos histórico: a conta é média e desvio.
  const MINIMO_PARA_FAIXA = 6;

  const est = { receita: null, cadastro: [], aba: 'resumo', ultimo: null,
                // qual coluna e' o que, quando o palpite automatico erra.
                // Guardado por FORMATO de planilha, nao por arquivo: quem usa
                // o mesmo modelo toda semana responde uma vez so'.
                colunas: {}, colunasEmUso: null, trocando: false,
                // usar o MAIOR dos dois corpos de prova de 28 dias (MPA 28 e
                // MPA 28.1). LIGADO desde 24/09/2026, quando o laboratorio
                // confirmou o que e' a segunda coluna — ver blocoDoisCPs().
                doisCPs: true,
                fator: { kgPorMPa: null, reaisPorKg: null } };

  /* O fator que transforma margem em dinheiro.
   *
   * Quantos quilos de cimento valem 1 MPa aos 28 dias muda com o traço, o
   * agregado, o cimento e a idade — não existe número universal, e inventar um
   * aqui seria o tipo de conta que ninguém consegue defender na frente do
   * cliente. Quem tem esse número é o laboratório da usina, que já fez a curva
   * de dosagem. Então a tela PERGUNTA, e só mostra o valor em reais depois que
   * alguém responde.
   *
   * Fica guardado nas preferências: é característica da usina, não da sessão. */
  function carregarFator() {
    try {
      if (typeof window.prefsGet !== 'function') return;
      window.prefsGet().then(p => {
        if (!p || !p.previsao_fator) return;
        const f = p.previsao_fator;
        est.fator.kgPorMPa = numBR(f.kgPorMPa);
        est.fator.reaisPorKg = numBR(f.reaisPorKg);
        if (est.aba === 'resumo') render();
      }).catch(() => {});
    } catch (e) { /* sem prefs, segue sem o valor em reais */ }
  }
  function salvarFator() {
    try {
      fetch('/api/prefs', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ previsao_fator: {
          kgPorMPa: est.fator.kgPorMPa, reaisPorKg: est.fator.reaisPorKg } }),
      }).catch(() => {});
    } catch (e) { /* idem */ }
  }
  function temFator() {
    return isFinite(est.fator.kgPorMPa) && est.fator.kgPorMPa > 0;
  }

  function carregarColunas() {
    try {
      if (typeof window.prefsGet !== 'function') return;
      window.prefsGet().then(p => {
        if (!p) return;
        let mudou = false;
        if (p.previsao_colunas) { est.colunas = p.previsao_colunas || {}; mudou = true; }
        if (typeof p.previsao_dois_cps === 'boolean' && p.previsao_dois_cps !== est.doisCPs) {
          est.doisCPs = p.previsao_dois_cps; mudou = true;
        }
        if (mudou) render();
      }).catch(() => {});
    } catch (e) { /* sem prefs, o palpite automatico segue valendo */ }
  }
  function salvarDoisCPs() {
    try {
      fetch('/api/prefs', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ previsao_dois_cps: !!est.doisCPs }),
      }).catch(() => {});
    } catch (e) { /* sem prefs, vale so' nesta abertura */ }
  }
  function salvarColunas() {
    try {
      fetch('/api/prefs', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ previsao_colunas: est.colunas }),
      }).catch(() => {});
    } catch (e) { /* idem */ }
  }

  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function br(v, casas) {
    const n = Number(v);
    if (!isFinite(n)) return '—';
    return n.toFixed(casas === undefined ? 1 : casas).replace('.', ',');
  }
  function numBR(v) {
    if (v === null || v === undefined) return NaN;
    if (typeof v === 'number') return isFinite(v) ? v : NaN;
    let s = String(v).trim().replace(/\s| /g, '');
    if (!s) return NaN;
    s = s.replace(/[^0-9,.\-]/g, '');
    if (!s || s === '-' || s === ',' || s === '.') return NaN;
    if (s.includes(',') && s.includes('.')) {
      s = s.lastIndexOf(',') > s.lastIndexOf('.')
        ? s.replace(/\./g, '').replace(',', '.')
        : s.replace(/,/g, '');
    } else if (s.includes(',')) s = s.replace(',', '.');
    const n = Number(s);
    return isFinite(n) ? n : NaN;
  }

  /* ── o que o concreto não faz ─────────────────────────────────────────
   * Na planilha da Usinop, 12% das linhas com 7 e 28 dias eram fisicamente
   * impossíveis — e mandavam no resultado. Antes de limpar, a correlação
   * entre 7 e 28 dias dava 0,23 e uma receita aparecia com média 214 MPa e
   * desvio 723. Depois de limpar, vira um problema tratável.
   */
  function possivel(p) {
    if (!isFinite(p.d7) || !isFinite(p.d28)) return false;
    if (p.d7 <= 0 || p.d28 <= 0) return false;
    if (p.d7 > 120 || p.d28 > 120) return false;       // não existe nessa usina
    if (p.d28 < p.d7 * 0.7) return false;              // cair assim é digitação
    if (p.d28 > p.d7 * 4) return false;                // subir assim também
    return true;
  }

  /* ── achar a coluna certa ─────────────────────────────────────────────
   * Comparar cabecalho com === e maiusculas so' funciona na planilha para a
   * qual a lista foi escrita. Na primeira planilha de fora que testei, a
   * coluna MPA 28 estava la', mas a receita chamava-se OBRA: a tela morria
   * dizendo "nao achei as colunas certas" sem dizer o que TINHA achado e sem
   * deixar ninguem corrigir. As duas coisas sao tratadas aqui e em
   * escolherColunas(): o nome e' comparado sem acento, sem pontuacao e sem
   * espaco sobrando — inteiro, depois por palavra, depois por pedaco — e
   * quando ainda assim nao da', quem sabe e' quem abriu a planilha.
   */
  function normaliza(s) {
    return String(s == null ? '' : s)
      .replace(/³/g, '3').replace(/²/g, '2')
      .normalize('NFD').replace(/[̀-ͯ]/g, '')
      .toUpperCase().replace(/[^A-Z0-9]+/g, ' ').trim();
  }

  function coluna(headers, nomes) {
    const hs = headers.map(normaliza);
    const alvos = nomes.map(normaliza).filter(Boolean);
    for (const a of alvos) {             // 1. igual
      const i = hs.indexOf(a);
      if (i >= 0) return i;
    }
    for (const a of alvos) {             // 2. palavra inteira na ponta
      const i = hs.findIndex(h => h.startsWith(a + ' ') || h.endsWith(' ' + a));
      if (i >= 0) return i;
    }
    for (const a of alvos) {             // 3. pedaco — so' para nome longo,
      if (a.length < 4) continue;        //    senao "M3" casa dentro de tudo
      const i = hs.findIndex(h => h.indexOf(a) >= 0);
      if (i >= 0) return i;
    }
    return -1;
  }

  /* O formato da planilha, nao o arquivo: mesma sequencia de cabecalhos, mesma
   * resposta. Trocar o mes do arquivo nao faz perguntar de novo. */
  function formatoDaPlanilha(headers) {
    return headers.map(normaliza).join('|').slice(0, 400);
  }

  /* ── fck pedido: o cadastro manda, o nome é o segundo melhor ───────── */
  function chaveNome(s) {
    return String(s || '').trim().toUpperCase().replace(/\s+/g, ' ');
  }
  function fckDoCadastro(nome) {
    const k = chaveNome(nome);
    const rec = (est.cadastro || []).find(r => chaveNome(r.nome) === k);
    if (!rec || !Array.isArray(rec.versoes) || !rec.versoes.length) return NaN;
    const v = rec.versoes.find(x => x.id === rec.versaoAtiva) || rec.versoes[0];
    const direto = numBR(v && v.fck);
    if (!isNaN(direto) && direto > 0) return direto;
    const p = ((v && v.propriedades) || []).find(x => /fck|resist/i.test(x.nome || ''));
    const pv = p ? numBR(p.consumo) : NaN;
    return (!isNaN(pv) && pv > 0) ? pv : NaN;
  }
  function fckDoNome(nome) {
    const m = String(nome || '').toUpperCase().match(/FCK\s*[-:_]*\s*(\d+(?:[.,]\d+)?)/);
    return m ? numBR(m[1]) : NaN;
  }
  /* ── relação água/cimento ───────────────────────────────────────────
   * A lei de Abrams diz que a resistência do concreto cai com a relação
   * água/cimento — é o parâmetro mais determinante do traço.
   *
   * O que NÃO fiz, de propósito: usar a a/c para prever. Medir se ela melhora
   * a previsão exige receitas com cimento e água cadastrados, e hoje o
   * cadastro desta instalação tem UMA receita e NENHUMA com os dois campos
   * preenchidos. Sem dado para validar, entrar na conta seria fé, não
   * estatística — e esta tela existe justamente para não fazer isso.
   *
   * Então ela entra como DIAGNÓSTICO: quando a receita está cadastrada, a a/c
   * aparece ao lado dos números e entra na frase. No dia em que houver
   * receitas suficientes cadastradas, a medição de se ela ajuda a prever é
   * uma tarde de trabalho — e está anotada no PREVISAO_BACKLOG.md.
   */
  function relacaoAC(nome) {
    const rec = (est.cadastro || []).find(r => chaveNome(r.nome) === chaveNome(nome));
    if (!rec || !Array.isArray(rec.versoes) || !rec.versoes.length) return NaN;
    const v = rec.versoes.find(x => x.id === rec.versaoAtiva) || rec.versoes[0];
    const props = (v && v.propriedades) || [];
    const achar = re => {
      const p = props.find(x => re.test(x.nome || '') || re.test(x.tipo || ''));
      return p ? numBR(p.consumo) : NaN;
    };
    // Uma propriedade chamada "Relação a/c" ganha de qualquer conta nossa.
    const direta = props.find(x => /rela[çc][ãa]o\s*a\s*\/?\s*c|^a\/c$/i.test(x.nome || ''));
    const dv = direta ? numBR(direta.consumo) : NaN;
    if (!isNaN(dv) && dv > 0 && dv < 2) return dv;
    const agua = achar(/^[áa]gua/i);
    const cim = achar(/cimento|aglomerante|^cp\s/i);
    if (!isFinite(agua) || !isFinite(cim) || cim <= 0) return NaN;
    const r = agua / cim;
    return (r > 0.2 && r < 1.5) ? r : NaN;     // fora disso é erro de cadastro
  }

  /* Tres origens, nesta ordem de confianca: o cadastro de receitas (valor
   * oficial, digitado uma vez), a coluna de fck da propria planilha (o que o
   * laboratorio anotou naquele ensaio) e, por ultimo, o nome do produto — que
   * so' funciona quando alguem escreveu "FCK 30" no nome. A terceira era a
   * unica que existia, e por isso planilha com coluna FCK e nome sem fck
   * ficava sem conformidade nenhuma, mostrando "0 abaixo do fck" como se
   * estivesse tudo bem. */
  function fckPedido(nome, daPlanilha) {
    const c = fckDoCadastro(nome);
    if (!isNaN(c)) return { valor: c, origem: 'cadastro' };
    if (isFinite(daPlanilha) && daPlanilha > 0) {
      return { valor: daPlanilha, origem: 'planilha' };
    }
    const n = fckDoNome(nome);
    return { valor: n, origem: isNaN(n) ? null : 'nome' };
  }

  /* ── junta os ensaios por receita ─────────────────────────────────── */
  function porReceita(opcoes) {
    const usarDois = opcoes && typeof opcoes.doisCPs === 'boolean' ? opcoes.doisCPs : est.doisCPs;
    const sd = window.getConcrestatsData ? window.getConcrestatsData({ filtered: true }) : null;
    if (!sd || !sd.headers || !sd.headers.length) return null;
    const h = sd.headers;
    // A escolha manual, quando existe, manda: ela foi feita olhando a planilha.
    const esc0 = est.colunas[formatoDaPlanilha(h)] || null;
    const posta = (k, nomes) => {
      const v = esc0 && Number.isInteger(esc0[k]) ? esc0[k] : -1;
      if (v >= 0 && v < h.length) return v;
      return coluna(h, nomes);
    };
    // Cada usina chama a receita de um jeito. Ordem importa: PRODUTO e RECEITA
    // sao o nome tecnico; OBRA e CLIENTE ficam por ultimo porque agrupam por
    // quem comprou, nao pelo traco — serve, mas e' o pior dos casos.
    const iR = posta('r', ['PRODUTO', 'RECEITA', 'TRACO', 'TRAÇO', 'DOSAGEM',
                           'DESCRICAO', 'DESCRIÇÃO', 'MATERIAL', 'NOME',
                           'SERVICO', 'SERVIÇO', 'APLICACAO', 'PECA', 'OBRA']);
    // NAO entram aqui: FCK e RESISTENCIA sozinhos. Numa planilha de usina eles
    // costumam ser o que foi PEDIDO, nao o que o corpo de prova deu — usar um
    // pelo outro faria a tela dizer que esta' tudo perfeito.
    const i7 = posta('d7', ['MPA 7', 'MPA7', 'MPA 7D', 'FC 7', 'FCJ 7',
                            'RESISTENCIA 7', '7 DIAS', 'RUPTURA 7']);
    const i28 = posta('d28', ['MPA 28', 'MPA28', 'MPA 28D', 'FC 28', 'FCJ 28',
                              'RESISTENCIA 28', '28 DIAS', 'RUPTURA 28']);
    // Sem saber QUAL corpo de prova, apontar um ensaio suspeito é inútil:
    // ninguém vai atrás de "um ensaio qualquer da receita 248".
    const iCP = coluna(h, ['CP', 'CORPO DE PROVA', 'AMOSTRA']);
    const iDt = coluna(h, ['DATA', 'DATA 28', 'DATA DE MOLDAGEM']);
    // O volume é o que transforma "3,2 MPa de margem" em quilos de cimento.
    // Vem da própria planilha; não é estimativa nossa.
    const iM3 = coluna(h, ['M³', 'M3', 'VOLUME', 'MC']);
    // O fck PEDIDO, quando a planilha o traz numa coluna propria. Nunca pode
    // ser a mesma coluna do rompimento: seria comparar o ensaio com ele mesmo
    // e dar conformidade perfeita para qualquer coisa.
    let iFck = coluna(h, ['FCK', 'FCK PEDIDO', 'FCK MPA', 'FCK PROJETO',
                          'RESISTENCIA PEDIDA', 'RESISTENCIA CARACTERISTICA']);
    if (iFck === i28 || iFck === i7) iFck = -1;
    // O SEGUNDO corpo de prova de 28 dias do mesmo exemplar. A planilha da
    // Usinop traz MPA 28 e MPA 28.1 (e TNF 28 / TNF 28.1, as cargas). A conta
    // usava so' a primeira — 3.266 ensaios da segunda ficavam de fora.
    let i28b = coluna(h, ['MPA 28 1', 'MPA28 1', 'MPA 28 2', 'MPA 28 CP2', 'MPA 28 B',
                          'FC 28 2', 'CP2 28', 'CP 2 28']);
    if (i28b === i28 || i28b === i7 || i28b === iFck) i28b = -1;
    est.colunasEmUso = { r: iR, d7: i7, d28: i28, d28b: i28b, cp: iCP, data: iDt, m3: iM3,
                         fck: iFck, headers: h, manual: !!esc0,
                         doisCPs: usarDois && i28b >= 0 };
    if (iR < 0 || i28 < 0 || est.trocando) {
      return { erro: 'faltaColuna', headers: h, iR, i7, i28,
               soTrocando: iR >= 0 && i28 >= 0 };
    }

    const mapa = new Map();
    let descartados = 0, comParDeEnsaios = 0;
    sd.data.forEach(linha => {
      const nome = String(linha[iR] || '').trim();
      if (!nome) return;
      let d28 = numBR(linha[i28]);
      if (usarDois && i28b >= 0) {
        // NBR 12655: o valor do exemplar e' o MAIOR dos dois corpos de prova.
        // Se so' um dos dois e' valido, vale ele.
        const b = numBR(linha[i28b]);
        const okA = isFinite(d28) && d28 > 0 && d28 <= 120;
        const okB = isFinite(b) && b > 0 && b <= 120;
        if (okA && okB) d28 = Math.max(d28, b);
        else if (!okA && okB) d28 = b;
      }
      if (!isFinite(d28) || d28 <= 0 || d28 > 120) { if (isFinite(d28)) descartados++; return; }
      const d7 = i7 >= 0 ? numBR(linha[i7]) : NaN;
      if (!mapa.has(nome)) mapa.set(nome, { nome, todos: [], serie: [], pares: [], m3: 0, fcks: [] });
      const r = mapa.get(nome);
      if (iFck >= 0) {
        const f = numBR(linha[iFck]);
        if (isFinite(f) && f > 0 && f < 120) r.fcks.push(f);
      }
      r.todos.push(d28);
      r.serie.push({ v: d28, data: iDt >= 0 ? linha[iDt] : null,
                     cp: iCP >= 0 ? linha[iCP] : null });
      if (iM3 >= 0) {
        const v = numBR(linha[iM3]);
        if (isFinite(v) && v > 0 && v < 1000) r.m3 += v;
      }
      if (isFinite(d7)) {
        comParDeEnsaios++;
        const p = { d7, d28,
                    cp: iCP >= 0 ? linha[iCP] : null,
                    data: iDt >= 0 ? linha[iDt] : null };
        if (possivel(p)) r.pares.push(p);
        else descartados++;
      }
    });
    return { receitas: [...mapa.values()], descartados, comParDeEnsaios, semColuna7: i7 < 0 };
  }

  function media(a) { return a.reduce((s, v) => s + v, 0) / a.length; }
  function desvio(a) {
    if (a.length < 2) return 0;
    const m = media(a);
    return Math.sqrt(a.reduce((s, v) => s + (v - m) * (v - m), 0) / (a.length - 1));
  }

  /* ── a reta desta receita, e o erro que ela comete nos próprios dados ─ */
  function reta(pares) {
    const n = pares.length;
    if (n < 2) return null;
    const mx = media(pares.map(p => p.d7));
    const my = media(pares.map(p => p.d28));
    let num = 0, den = 0;
    pares.forEach(p => { num += (p.d7 - mx) * (p.d28 - my); den += (p.d7 - mx) * (p.d7 - mx); });
    if (!den) return null;
    const a = num / den;
    const b = my - a * mx;
    const erros = pares.map(p => Math.abs(a * p.d7 + b - p.d28));
    return { a, b, erro: media(erros), n };
  }

  /* ── a receita esta' caindo? ────────────────────────────────────────
   * Compara os ultimos 10 ensaios contra os 10 anteriores. O limiar nao e' um
   * numero chutado: e' o erro padrao da diferenca entre duas medias de 10
   * amostras da PROPRIA receita — uma receita baguncada precisa cair mais
   * para a queda significar alguma coisa.
   *
   * A regua de 2x foi escolhida MEDINDO. Embaralhando a ordem dos ensaios (o
   * que destroi qualquer tendencia real) e contando quantas "quedas"
   * apareciam so' por acaso, na planilha da Usinop:
   *
   *     regua   quedas reais   falsas (media de 30 embaralhadas)
   *      1,0x        10              4,40
   *      1,5x         7              2,27
   *      2,0x         6              0,53   <- esta
   *      2,5x         2              0,07
   *
   * Em 1,0x quase metade do que ele veria seria mentira. Em 2,0x sobra menos
   * de um falso por leitura inteira. So' QUEDA e' apontada: subir nao e'
   * problema de ninguem.
   */
  const ENSAIOS_POR_METADE = 10;
  const REGUA_DA_QUEDA = 2;

  function tendencia(vals) {
    const n = ENSAIOS_POR_METADE;
    if (!vals || vals.length < n * 2) return null;
    const dif = media(vals.slice(-n)) - media(vals.slice(-n * 2, -n));
    const limiar = desvio(vals) * Math.sqrt(2 / n) * REGUA_DA_QUEDA;
    return { dif: dif, limiar: limiar, caiu: dif < -limiar };
  }

  /* ── condição de preparo (NBR 12655) ────────────────────────────────
   * A norma não trata o desvio como número solto: ela o amarra a COMO o
   * concreto é preparado. Condição A é cimento e agregados medidos em massa,
   * com umidade corrigida; B admite agregado miúdo em massa e graúdo em
   * volume; C é a mais frouxa, e só vale até fck 20.
   *
   * Dizer "seu desvio é 9,6" não move ninguém. Dizer "seu desvio é pior que a
   * condição C, a mais frouxa que a norma admite" é a frase que faz o
   * laboratório olhar para a balança da usina.
   */
  const CONDICOES = [['A', 4.0], ['B', 5.5], ['C', 7.0]];
  function condicaoDePreparo(sd) {
    if (!isFinite(sd) || sd <= 0) return null;
    for (const [nome, limite] of CONDICOES) if (sd <= limite) return nome;
    return 'pior que C';
  }
  /* A referência é a condição B, não "a próxima classe melhor".
   *
   * Mirar a próxima classe dava ganhos triviais para quem já está bem: uma
   * receita com desvio 4,5 aparecia prometendo 0,8 MPa, e a lista inchava de
   * 23 para 33 receitas com a média caindo de 3,2 para 1,7 MPa — o número
   * importante afogado em ruído.
   *
   * B é o alvo realista de uma usina de concreto: agregado miúdo em massa,
   * graúdo em volume. A condição A exige corrigir a umidade do agregado
   * continuamente, que poucas centrais fazem. Quem já está em A ou B não
   * aparece: não há o que cobrar. */
  const CONDICAO_ALVO = ['B', 5.5];
  function alvoDeRegularidade(sd) {
    return sd > CONDICAO_ALVO[1] ? CONDICAO_ALVO : null;
  }

  /* Qual desvio faria esta receita passar SEM mexer no traço?
   * fck,est = média − 1,65·σ ≥ fck  ⟹  σ ≤ (média − fck) / 1,65
   * Quando a média já está abaixo do fck, nenhuma regularidade salva: o
   * problema é o traço, e a tela tem de dizer isso em vez de sugerir o
   * impossível. */
  function desvioQuePrecisaria(m, alvo) {
    if (!isFinite(m) || !isFinite(alvo)) return NaN;
    return (m - alvo) / 1.65;
  }

  /* Margem de média desperdiçada por irregularidade: quanto a receita poderia
   * baixar a média — e portanto o consumo — se alcançasse a próxima condição
   * de preparo. É onde a irregularidade vira dinheiro. */
  function margemDesperdicada(m, sd, alvo) {
    if (!isFinite(m) || !isFinite(sd) || !isFinite(alvo)) return NaN;
    const melhor = alvoDeRegularidade(sd);
    if (!melhor) return NaN;
    const precisaHoje = alvo + 1.65 * sd;
    const precisaDepois = alvo + 1.65 * melhor[1];
    const ganho = precisaHoje - precisaDepois;
    return ganho > 0 ? { ganho, condicao: melhor[0], sigma: melhor[1] } : NaN;
  }

  /* ── quando a receita mudou de patamar ──────────────────────────────
   * "Está caindo" não move ninguém: cair devagar não tem culpado. Já "em 12
   * de novembro esta receita perdeu 8,9 MPa de uma vez" tem data, e com data o
   * laboratório vai atrás do que aconteceu naquele dia — lote de cimento,
   * agregado novo, chuva, operador.
   *
   * Procura o corte que mais separa as duas metades da série e mede o quanto
   * isso é forte, comparado com a variação da própria receita.
   *
   * O limiar saiu de medição, e é o resultado mais limpo deste projeto.
   * Embaralhando a ordem dos ensaios — o que destrói qualquer patamar real — e
   * repetindo a mesma busca:
   *
   *     limiar   patamares reais   encontrados no embaralhado
   *      t=3,0         15                    0
   *      t=3,5         13                    0
   *      t=4,0         12                    0
   *      t=4,5         10                    0
   *
   * Zero falsos em qualquer régua. Fico em 3,5 por folga.
   *
   * (Por contraste: dar mais peso aos ensaios recentes na PREVISÃO foi medido
   * e PIORA — 4,53 MPa de erro sem peso contra 4,73 com meia-vida de 6. A
   * relação entre 7 e 28 dias é propriedade da mistura e é estável; o que
   * anda é o patamar. Por isso esta função existe e aquela não.)
   */
  const LIMIAR_PATAMAR = 3.5;
  const MINIMO_POR_LADO = 8;
  // Significativo não é o mesmo que importante. A receita 285 (argamassa) é tão
  // regular que uma queda de 0,34 MPa dá t=6,2 — forte estatisticamente e
  // irrelevante na obra. Um alerta desses gasta a atenção de quem lê e ensina a
  // ignorar os próximos. Abaixo de 1,5 MPa não vale acordar ninguém.
  const MUDANCA_QUE_IMPORTA = 1.5;

  function mudancaDePatamar(serie) {
    const n = serie.length;
    if (n < MINIMO_POR_LADO * 2) return null;
    const v = serie.map(x => x.v);
    const sd = desvio(v);
    if (!sd) return null;
    let melhor = null;
    for (let i = MINIMO_POR_LADO; i < n - MINIMO_POR_LADO; i++) {
      const antes = media(v.slice(0, i));
      const depois = media(v.slice(i));
      const dif = depois - antes;
      const t = Math.abs(dif) / (sd * Math.sqrt(1 / i + 1 / (n - i)));
      if (!melhor || t > melhor.t) melhor = { t, i, dif, antes, depois };
    }
    if (!melhor || melhor.t < LIMIAR_PATAMAR) return null;
    if (Math.abs(melhor.dif) < MUDANCA_QUE_IMPORTA) return null;
    const ponto = serie[melhor.i] || {};
    return { ...melhor, data: ponto.data, cp: ponto.cp, ensaio: melhor.i + 1, de: n };
  }

  /* O fck de uma receita nao varia; o que varia e' a digitacao. Entao vale a
   * MODA, e nao a media: uma linha com 3 no lugar de 30 nao pode arrastar o
   * alvo da receita inteira. */
  function fckMaisComum(lista) {
    if (!Array.isArray(lista) || !lista.length) return NaN;
    const conta = new Map();
    lista.forEach(v => conta.set(v, (conta.get(v) || 0) + 1));
    let melhor = NaN, vezes = 0;
    conta.forEach((q, v) => { if (q > vezes) { vezes = q; melhor = v; } });
    return melhor;
  }

  function analisar(r) {
    const alvo = fckPedido(r.nome, fckMaisComum(r.fcks));
    const vals = r.todos;
    const m = vals.length ? media(vals) : NaN;
    const sd = desvio(vals);
    // NBR 12655: a resistência característica estimada é média − 1,65 · desvio.
    // É por ela que a receita passa ou não, e não pela média — que é onde quase
    // toda receita desta usina parece bem e mesmo assim reprova.
    const fckEst = vals.length >= MINIMO_PARA_FAIXA ? m - 1.65 * sd : NaN;
    const folga = (isFinite(fckEst) && isFinite(alvo.valor)) ? fckEst - alvo.valor : NaN;
    return { ...r, alvo, n: vals.length, media: m, desvio: sd, fckEst, folga,
             reta: reta(r.pares), tend: tendencia(vals),
             condicao: condicaoDePreparo(sd),
             sdNecessario: desvioQuePrecisaria(m, alvo.valor),
             desperdicio: margemDesperdicada(m, sd, alvo.valor),
             ac: relacaoAC(r.nome), m3: r.m3 || 0,
             patamar: mudancaDePatamar(r.serie || []) };
  }

  /* ── PREVISÃO ──────────────────────────────────────────────────────── */
  function prever(a, mpa7) {
    if (!a || !a.reta) {
      return { ok: false, msg: 'Esta receita não tem ensaios de 7 dias suficientes para prever.' };
    }
    if (a.reta.n < MINIMO_DE_ENSAIOS) {
      return { ok: false, msg: 'Só ' + a.reta.n + ' ensaios com 7 e 28 dias. Abaixo de ' +
                              MINIMO_DE_ENSAIOS + ' a conta segue o acaso, não a receita.' };
    }
    if (a.reta.erro > ERRO_INACEITAVEL) {
      return { ok: false, msg: 'O histórico desta receita varia demais (erro típico de ' +
                              br(a.reta.erro) + ' MPa). Prever aqui seria inventar um número.' };
    }
    const v = a.reta.a * mpa7 + a.reta.b;
    if (!isFinite(v)) return { ok: false, msg: 'Não consegui calcular.' };
    return { ok: true, valor: v, erro: a.reta.erro, n: a.reta.n,
             minimo: v - a.reta.erro, maximo: v + a.reta.erro };
  }

  /* ── ensaios que decepcionaram ──────────────────────────────────────
   * A tabela de receitas mostra o problema do mês. Isto mostra o problema do
   * DIA: um corpo de prova que, pelo próprio 7 dias dele, deveria ter dado X
   * aos 28 e veio bem abaixo. É o que permite ir atrás enquanto a betoneira
   * daquele traço ainda está fresca na memória de alguém.
   *
   * O limiar é o erro típico da própria receita, dobrado. Com o erro simples
   * um terço dos ensaios apareceria — lista longa demais para alguém olhar, e
   * a maioria seria a variação normal do ensaio.
   */
  function ensaiosSuspeitos(todas) {
    const achados = [];
    todas.forEach(a => {
      if (!a.reta || a.reta.n < MINIMO_DE_ENSAIOS || a.reta.erro > ERRO_INACEITAVEL) return;
      const limite = a.reta.erro * 2;
      a.pares.forEach(p => {
        const esperado = a.reta.a * p.d7 + a.reta.b;
        const dif = p.d28 - esperado;
        if (dif < -limite) {
          achados.push({ receita: a.nome, cp: p.cp, data: p.data,
                         d7: p.d7, d28: p.d28, esperado, dif });
        }
      });
    });
    return achados.sort((x, y) => x.dif - y.dif);
  }

  function blocoSuspeitos(todas) {
    const lista = ensaiosSuspeitos(todas);
    if (!lista.length) {
      return secao('Ensaios que decepcionaram',
        '<p class="prev-nota">Nenhum ensaio ficou tão abaixo do que a própria receita ' +
        'previa. Isso é bom sinal: a variação que existe é a normal do ensaio.</p>');
    }
    const linhas = lista.slice(0, 25).map(e =>
      '<tr>' +
      '<td class="prev-nome" title="' + esc(e.receita) + '">' + esc(e.receita) + '</td>' +
      '<td>' + esc(e.cp == null || e.cp === '' ? '—' : e.cp) + '</td>' +
      '<td>' + esc(fmtData(e.data)) + '</td>' +
      '<td>' + br(e.d7) + '</td>' +
      '<td>' + br(e.esperado) + '</td>' +
      '<td><b>' + br(e.d28) + '</b></td>' +
      '<td class="prev-neg">' + br(e.dif) + '</td>' +
      '</tr>').join('');
    const sobra = lista.length > 25
      ? '<p class="prev-nota">Mostrando os 25 piores de ' + lista.length + '.</p>' : '';
    return secao('Ensaios que decepcionaram',
      '<div class="prev-tabela-wrap"><table class="prev-tabela">' +
      '<thead><tr><th>Receita</th><th>CP</th><th>Data</th><th>7 dias</th>' +
      '<th>Esperado aos 28</th><th>Deu</th><th>Diferença</th></tr></thead>' +
      '<tbody>' + linhas + '</tbody></table></div>' + sobra +
      '<p class="prev-nota">Pelo resultado de 7 dias, a própria receita previa o valor da ' +
      'coluna "Esperado". Estes vieram mais de duas vezes o erro típico abaixo disso — ' +
      'não é a variação normal do ensaio. Vale conferir cura, adensamento e a carga ' +
      'daquele dia enquanto alguém ainda lembra.</p>');
  }

  function fmtData(v) {
    if (v == null || v === '') return '—';
    const m = String(v).match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (m) return m[3] + '/' + m[2] + '/' + m[1];
    return String(v).slice(0, 10);
  }

  /* ── o que a irregularidade custa ───────────────────────────────────
   * A usina compensa desvio com cimento: para o fck,est passar, a média tem
   * de ficar 1,65 desvios acima do fck. Desvio maior, média maior, cimento
   * maior — e o cliente paga por uma resistência que ele não pediu.
   *
   * Mostro a margem em MPa, não em quilos nem em reais. A conversão de MPa
   * para consumo de cimento muda com o traço, o agregado e o cimento de cada
   * usina; inventar um fator aqui seria justamente o número indefensável que
   * esta tela existe para evitar. Quem tem o fator é o laboratório.
   */
  function blocoDesperdicio(todas) {
    // Mesmo piso da tabela de faixa. Desvio calculado sobre 2 ou 3 ensaios nao
    // e' desvio, e' acaso — e apareceria aqui inflando a conta. Sem este
    // filtro a lista saltava de 23 para 38 receitas e a media caia de 3,2
    // para 1,5 MPa, diluida por receitas que nao deviam estar ali.
    const lista = todas.filter(a => a.desperdicio && isFinite(a.desperdicio.ganho)
                                 && a.n >= MINIMO_PARA_FAIXA && isFinite(a.alvo.valor))
      .sort((x, y) => y.desperdicio.ganho - x.desperdicio.ganho);
    if (!lista.length) {
      return secao('O que a irregularidade custa',
        '<p class="prev-nota">Nenhuma receita tem desvio acima da condição A da norma. ' +
        'Não há margem sendo gasta com irregularidade.</p>');
    }
    const total = lista.reduce((s, a) => s + a.desperdicio.ganho, 0) / lista.length;
    const linhas = lista.slice(0, 12).map(a =>
      '<tr>' +
      '<td class="prev-nome" title="' + esc(a.nome) + '">' + esc(a.nome) + '</td>' +
      '<td>' + br(a.desvio, 2) + '</td>' +
      '<td>' + esc(a.condicao || '—') + '</td>' +
      '<td>' + br(a.desperdicio.sigma, 1) + ' (' + esc(a.desperdicio.condicao) + ')</td>' +
      '<td class="prev-neg"><b>' + br(a.desperdicio.ganho) + '</b></td>' +
      '</tr>').join('');
    return secao('O que a irregularidade custa',
      '<div class="prev-tabela-wrap"><table class="prev-tabela">' +
      '<thead><tr><th>Receita</th><th>Desvio hoje</th><th>Condição</th>' +
      '<th>Se chegasse a</th><th>Média que sobraria</th></tr></thead>' +
      '<tbody>' + linhas + '</tbody></table></div>' +
      '<p class="prev-nota"><b>Como se lê:</b> para o fck estimado passar, a média precisa ' +
      'ficar 1,65 desvios acima do fck. Desvio maior obriga média maior, e média maior é ' +
      'cimento a mais — que o cliente paga sem ter pedido. A última coluna é quanto de média ' +
      'esta receita poderia baixar se alcançasse a condição de preparo ao lado, sem perder ' +
      'nada em aprovação. São ' + lista.length + ' receitas, com média de ' + br(total) +
      ' MPa de margem gasta com irregularidade.</p>' +
      '<p class="prev-nota">Deixo em MPa de propósito. Converter para quilos de cimento ' +
      'depende do traço, do agregado e do cimento desta usina — o fator é do laboratório, ' +
      'não meu. Com ele em mãos, a conta de quanto isso vale por mês sai direto daqui.</p>');
  }

  /* ── TELA ──────────────────────────────────────────────────────────────
   * Quatro painéis em vez de uma rolagem única.
   *
   * A primeira versão empilhava tudo numa página só, e ela cresceu até ficar
   * inútil: quem abria caía numa tabela de 36 linhas, e as três seções abaixo
   * — que respondem perguntas diferentes — só existiam para quem rolasse até
   * lá. Separado por pergunta:
   *
   *   Resumo    quanto isto custa, e quais são os piores casos
   *   Receitas  a tabela inteira, e a carta de controle de cada uma
   *   Ensaios   os corpos de prova que decepcionaram
   *   Prever    o formulário do 28 dias
   */
  const ESTILO_RELATORIO = 'body{font:12px/1.55 -apple-system,Segoe UI,Roboto,sans-serif;color:#25231d;margin:26px 30px;max-width:1000px}h1{font-size:19px;margin:0 0 3px}h2{font-size:13px;margin:22px 0 8px;text-transform:uppercase;letter-spacing:.06em;color:#555;border-bottom:1px solid #ddd;padding-bottom:4px}.sub{color:#666;font-size:11px;margin-bottom:16px}.cartoes{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:6px}.cartao{border:1px solid #ddd;border-radius:5px;padding:9px 14px;min-width:120px}.cartao b{display:block;font-size:20px}.cartao.ruim{border-color:#c0392b}.cartao.ruim b{color:#c0392b}table{border-collapse:collapse;width:100%;font-size:11px;margin-top:4px}th{background:#f2f0ea;text-align:right;padding:5px 7px;border-bottom:1px solid #ccc;font-size:10px;text-transform:uppercase;letter-spacing:.04em;color:#555}td{text-align:right;padding:4px 7px;border-bottom:1px solid #eee}th:first-child,td:first-child{text-align:left}.nome{max-width:330px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}tr.ruim td{background:#fdf3f2}.ruim{color:#c0392b;font-weight:600}.obs{font-size:10.5px;color:#666;margin-top:7px;line-height:1.6}@media print{body{margin:0}h2{page-break-after:avoid}tr{page-break-inside:avoid}}';

  const ABAS = [
    ['resumo',   'Resumo'],
    ['receitas', 'Receitas'],
    ['ensaios',  'Ensaios'],
    ['dados',    'Dados'],
    ['prever',   'Prever'],
  ];

  function render() {
    const corpo = $('prev-corpo');
    if (!corpo) return;
    const dados = porReceita();

    if (!dados) {
      corpo.innerHTML = vazio('Abra uma planilha de rompimentos',
        'Preciso de uma coluna de produto/receita e de uma coluna MPA 28.');
      return;
    }
    if (dados.erro === 'faltaColuna') {
      corpo.innerHTML = escolherColunas(dados);
      ligarEscolhaDeColunas(dados);
      return;
    }

    const analisadas = dados.receitas.map(analisar);
    const comFaixa = analisadas.filter(a => isFinite(a.folga))
      .sort((x, y) => x.folga - y.folga);
    const fora = comFaixa.filter(a => a.folga < 0);
    est.ultimo = { analisadas, comFaixa, fora, dados };

    const nav = '<div class="prev-abas">' + ABAS.map(([id, rotulo]) => {
      const n = contadorDaAba(id, est.ultimo);
      return '<button class="prev-aba' + (est.aba === id ? ' ativa' : '') +
             '" data-aba="' + id + '">' + esc(rotulo) +
             (n ? '<span class="prev-aba-n">' + n + '</span>' : '') + '</button>';
    }).join('') + '</div>';

    let painel = '';
    if (est.aba === 'resumo')        painel = painelResumo(est.ultimo);
    else if (est.aba === 'receitas') painel = blocoFaixa(comFaixa) +
                                              '<div id="prev-carta"></div>' +
                                              blocoDesperdicio(analisadas);
    else if (est.aba === 'ensaios')  painel = blocoSuspeitos(analisadas);
    else if (est.aba === 'dados')    painel = painelDados();
    else                             painel = blocoPrevisao(analisadas);

    corpo.innerHTML = nav + '<div class="prev-painel">' + painel + '</div>';

    corpo.querySelectorAll('.prev-aba').forEach(b => {
      b.addEventListener('click', () => { est.aba = b.dataset.aba; render(); });
    });

    if (est.aba === 'prever')   ligarPrevisao(analisadas);
    if (est.aba === 'receitas') { ligarMarcacao(fora); ligarExport(comFaixa); ligarCarta(comFaixa); }
    if (est.aba === 'resumo')   { ligarFator(est.ultimo); ligarRelatorio(est.ultimo); }
    if (est.aba === 'dados') {
      const bt = $('prev-trocar-colunas');
      if (bt) bt.addEventListener('click', () => { est.trocando = true; render(); });
      const dois = $('prev-dois-cps');
      if (dois) dois.addEventListener('change', () => {
        est.doisCPs = !!dois.checked;
        salvarDoisCPs();
        render();
      });
    }
  }

  function contadorDaAba(id, d) {
    if (id === 'receitas') return d.fora.length || '';
    if (id === 'ensaios')  return ensaiosSuspeitos(d.analisadas).length || '';
    if (id === 'dados') {
      const sa = saudeDosDados();
      return sa && sa.comProblema ? sa.comProblema : '';
    }
    return '';
  }

  /* ── relatório de conformidade ──────────────────────────────────────
   * O documento que o laboratório manda ao cliente dele. Enquanto o app for só
   * ferramenta interna, ele é cancelável; quando faz parte da entrega comercial
   * da usina, sair dele passa a ter preço.
   *
   * Abre numa janela própria e chama a impressão: quem quiser PDF escolhe
   * "Salvar como PDF" no diálogo do Windows, sem biblioteca nenhuma embarcada.
   */
  /* O relatorio abria com window.open('', '_blank'). Num NAVEGADOR isso
   * funciona, e foi onde eu testei — erro meu. DENTRO do programa, que e' uma
   * janela do WebView2, 'about:blank' nao e' pagina: o Windows tenta entregar
   * o endereco a um aplicativo e responde "We can't open this 'about' link".
   * O botao nunca funcionou para quem usa o programa de verdade.
   *
   * Agora o documento e' montado num quadro escondido DENTRO da propria
   * pagina e a impressao sai dele. Nao abre janela, nao depende do sistema, e
   * o "Salvar como PDF" do dialogo do Windows continua sendo o caminho para o
   * arquivo que a usina manda ao cliente. */
  function imprimirDocumento(html, comoChamar) {
    const antigo = $('prev-quadro-impressao');
    if (antigo) antigo.remove();

    const q = document.createElement('iframe');
    q.id = 'prev-quadro-impressao';
    q.setAttribute('aria-hidden', 'true');
    // Fora da vista, mas COM tamanho: quadro de 0x0 imprime folha em branco.
    q.style.cssText = 'position:fixed; right:0; bottom:0; width:820px; height:1100px;' +
                      'opacity:0; pointer-events:none; border:0; z-index:-1;';
    document.body.appendChild(q);

    let saiu = false;
    const imprimir = () => {
      if (saiu) return;
      saiu = true;
      try {
        q.contentWindow.focus();
        q.contentWindow.print();
        setTimeout(() => { try { q.remove(); } catch (e) { /* ja' foi */ } }, 1500);
      } catch (e) {
        try { q.remove(); } catch (e2) { /* ja' foi */ }
        avisar('Não consegui abrir a impressão do ' + comoChamar, 'error');
      }
    };

    q.addEventListener('load', () => setTimeout(imprimir, 250));
    // srcdoc e' o caminho que nao passa por endereco nenhum — nem about:blank.
    q.srcdoc = html;
    // Rede de seguranca: se o load nao disparar, imprime assim mesmo.
    setTimeout(imprimir, 2500);
  }

  function ligarRelatorio(d) {
    const bt = $('prev-relatorio');
    if (!bt) return;
    bt.addEventListener('click', () => {
      imprimirDocumento(montarRelatorio(d), 'relatório');
    });
  }

  function montarRelatorio(d) {
    const comFaixa = d.comFaixa, fora = d.fora, analisadas = d.analisadas;
    const hoje = new Date().toLocaleDateString('pt-BR');
    const patamares = analisadas.filter(a => a.patamar)
                                .sort((x, y) => y.patamar.t - x.patamar.t);
    const caindo = analisadas.filter(a => a.tend && a.tend.caiu);
    const sa = saudeDosDados();

    const linha = a =>
      '<tr class="' + (a.folga < 0 ? 'ruim' : '') + '">' +
      '<td class="nome">' + esc(a.nome) + '</td>' +
      '<td>' + a.n + '</td>' +
      '<td>' + br(a.alvo.valor, 0) + '</td>' +
      '<td>' + br(a.media) + '</td>' +
      '<td>' + br(a.desvio, 2) + '</td>' +
      '<td>' + esc(a.condicao || '\u2014') + '</td>' +
      '<td><b>' + br(a.fckEst) + '</b></td>' +
      '<td>' + (a.folga >= 0 ? '+' : '') + br(a.folga) + '</td></tr>';

    const secaoPatamar = patamares.length
      ? '<h2>Mudanças de patamar no período</h2>' +
        '<table><thead><tr><th>Receita</th><th>Data</th><th>Variação</th>' +
        '<th>Antes</th><th>Depois</th></tr></thead><tbody>' +
        patamares.map(a =>
          '<tr><td class="nome">' + esc(a.nome) + '</td>' +
          '<td>' + esc(a.patamar.data ? fmtData(a.patamar.data) : '\u2014') + '</td>' +
          '<td class="' + (a.patamar.dif < 0 ? 'ruim' : '') + '">' +
            (a.patamar.dif > 0 ? '+' : '') + br(a.patamar.dif) + ' MPa</td>' +
          '<td>' + br(a.patamar.antes) + '</td>' +
          '<td>' + br(a.patamar.depois) + '</td></tr>').join('') +
        '</tbody></table>' +
        '<p class="obs">Estas datas marcam o ponto em que a resistência mudou de nível de ' +
        'forma que não se explica pela variação normal do ensaio.</p>'
      : '';

    const secaoDados = sa
      ? '<h2>Base de dados</h2><p class="obs">Foram considerados ' +
        (sa.total - sa.comProblema) + ' de ' + sa.total + ' registros. Ficaram de fora ' +
        sa.comProblema + ' linhas com inconsistência física ou sem identificação de ' +
        'produto — resistência fora da faixa possível, ou resultado de 28 dias ' +
        'incompatível com o de 7 dias. A lista detalhada está no sistema.</p>'
      : '';

    return '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">' +
      '<title>Relatório de conformidade — ' + hoje + '</title>' +
      '<style>' + ESTILO_RELATORIO + '</style></head><body>' +
      '<h1>Relatório de conformidade</h1>' +
      '<div class="sub">Critério: ABNT NBR 12655 — resistência característica estimada ' +
      '(fck,est = média − 1,65 × desvio-padrão). ' +
      // o documento vai ao cliente: tem de dizer qual valor de cada exemplar entrou
      (est.colunasEmUso && est.colunasEmUso.doisCPs
        ? 'Valor de cada exemplar: o maior dos dois corpos de prova de 28 dias. '
        : '') +
      'Emitido em ' + hoje + '.</div>' +
      '<div class="cartoes">' +
        '<div class="cartao"><b>' + comFaixa.length + '</b>receitas avaliadas</div>' +
        '<div class="cartao' + (fora.length ? ' ruim' : '') + '"><b>' + fora.length +
          '</b>abaixo do fck</div>' +
        '<div class="cartao' + (caindo.length ? ' ruim' : '') + '"><b>' + caindo.length +
          '</b>em queda</div>' +
        '<div class="cartao' + (patamares.length ? ' ruim' : '') + '"><b>' + patamares.length +
          '</b>mudaram de patamar</div>' +
      '</div>' +
      '<h2>Receitas avaliadas</h2>' +
      '<table><thead><tr><th>Receita</th><th>Ensaios</th><th>fck</th><th>Média</th>' +
      '<th>Desvio</th><th>Condição</th><th>fck,est</th><th>Folga</th></tr></thead><tbody>' +
      comFaixa.map(linha).join('') + '</tbody></table>' +
      '<p class="obs">A condição de preparo (A, B ou C) é a classe da NBR 12655 compatível ' +
      'com o desvio-padrão observado. Uma receita pode ter média acima do fck e ainda assim ' +
      'não atender ao critério: quem reprova é a irregularidade.</p>' +
      secaoPatamar + secaoDados +
      '</body></html>';
  }

  /* ── PAINEL: SAÚDE DOS DADOS ────────────────────────────────────────
   * Todo número desta tela se apoia na planilha, e a planilha da Usinop tem
   * defeito em cerca de um terço das linhas. Eu descartava isso em silêncio,
   * o que é a pior das opções: o resultado sai mais limpo do que a realidade e
   * ninguém fica sabendo que há o que consertar.
   *
   * Aqui o descarte fica explícito, com contagem, exemplo e o motivo de cada
   * regra. Não é para me defender — é para dar ao laboratório uma lista do que
   * arrumar, que é o trabalho que melhora todas as outras telas de uma vez.
   */
  /* O resultado fica guardado: o contador da aba e o painel pediam a mesma
   * conta, e ela varria as 4.809 linhas duas vezes a cada troca de aba. A
   * chave e' o tamanho e a aba da planilha; mudou qualquer um, recalcula. */
  let saudeCache = null;
  function saudeDosDados() {
    const sd = window.getConcrestatsData ? window.getConcrestatsData({ filtered: true }) : null;
    if (!sd || !sd.headers || !sd.headers.length) return null;
    const chave = (sd.sheet || '') + '|' + sd.data.length + '|' + sd.headers.length;
    if (saudeCache && saudeCache.chave === chave) return saudeCache.valor;
    const h = sd.headers;
    const iR = coluna(h, ['PRODUTO', 'RECEITA', 'TRAÇO', 'TRACO', 'NOME']);
    const i7 = coluna(h, ['MPA 7', 'MPA7']);
    const i28 = coluna(h, ['MPA 28', 'MPA28']);
    const iCP = coluna(h, ['CP', 'CORPO DE PROVA', 'AMOSTRA']);
    const iDt = coluna(h, ['DATA', 'DATA 28']);

    const regras = [
      { id: 'semProduto', titulo: 'Linha sem produto/receita', grave: true,
        porque: 'Sem saber de que receita é o ensaio, ele não entra em nenhuma ' +
                'estatística. É resultado de laboratório que não conta para nada.',
        vale: (l) => iR >= 0 && !String(l[iR] || '').trim() },
      { id: 'sem28', titulo: 'Sem resultado aos 28 dias', grave: false,
        porque: 'Pode ser ensaio que ainda não venceu. Só é problema se for antigo.',
        vale: (l) => i28 >= 0 && !isFinite(numBR(l[i28])) },
      { id: 'imp28', titulo: 'Resistência aos 28 dias impossível', grave: true,
        porque: 'Negativa, zero, ou acima de 120 MPa. Concreto de usina não faz ' +
                'isso — é digitação, vírgula fora do lugar ou coluna trocada.',
        vale: (l) => { const v = numBR(l[i28]); return i28 >= 0 && isFinite(v) && (v <= 0 || v > 120); } },
      { id: 'imp7', titulo: 'Resistência aos 7 dias impossível', grave: true,
        porque: 'Mesma regra do 28 dias.',
        vale: (l) => { const v = numBR(l[i7]); return i7 >= 0 && isFinite(v) && (v <= 0 || v > 120); } },
      { id: 'caiu', titulo: '28 dias muito abaixo do próprio 7 dias', grave: true,
        porque: 'Concreto não perde resistência com o tempo. Cair a menos de 70% ' +
                'do valor de 7 dias é troca de corpo de prova ou erro de anotação.',
        vale: (l) => { const a = numBR(l[i7]), b = numBR(l[i28]);
                       return isFinite(a) && isFinite(b) && a > 0 && b < a * 0.7; } },
      { id: 'saltou', titulo: '28 dias mais que quatro vezes o 7 dias', grave: true,
        porque: 'O ganho normal fica entre 1,2 e 1,7 vez. Quadruplicar indica que ' +
                'um dos dois números está errado.',
        vale: (l) => { const a = numBR(l[i7]), b = numBR(l[i28]);
                       return isFinite(a) && isFinite(b) && a > 0 && b > a * 4; } },
      { id: 'semCP', titulo: 'Sem número de corpo de prova', grave: false,
        porque: 'Sem CP não dá para ir atrás do ensaio depois.',
        vale: (l) => iCP >= 0 && !String(l[iCP] || '').trim() },
    ];

    const achados = {};
    regras.forEach(r => { achados[r.id] = []; });
    const marcadas = new Set();

    sd.data.forEach((l, i) => {
      regras.forEach(r => {
        let bate = false;
        try { bate = r.vale(l); } catch (e) { bate = false; }
        if (!bate) return;
        achados[r.id].push({ linha: i + 2, cp: iCP >= 0 ? l[iCP] : null,
                             data: iDt >= 0 ? l[iDt] : null });
        if (r.grave) marcadas.add(i);
      });
    });

    // CP repetido precisa de uma passada própria: só se sabe que repete
    // depois de ver a planilha inteira.
    if (iCP >= 0) {
      const vistos = new Map();
      sd.data.forEach((l, i) => {
        const c = String(l[iCP] || '').trim();
        if (!c) return;
        if (!vistos.has(c)) vistos.set(c, []);
        vistos.get(c).push(i);
      });
      const repetidos = [];
      vistos.forEach((idx, c) => {
        if (idx.length > 1) idx.forEach(i => repetidos.push({ linha: i + 2, cp: c, data: null }));
      });
      if (repetidos.length) {
        regras.push({ id: 'cpRepetido', titulo: 'Número de corpo de prova repetido', grave: false,
          porque: 'Dois ensaios com o mesmo CP. Pode ser reuso de numeração entre ' +
                  'meses, mas também pode ser a mesma linha lançada duas vezes — e aí ' +
                  'o resultado entra em dobro na média.' });
        achados.cpRepetido = repetidos;
      }
    }

    const valor = { total: sd.data.length, regras, achados, comProblema: marcadas.size };
    saudeCache = { chave, valor };
    return valor;
  }

  function painelDados() {
    const sa = saudeDosDados();
    if (!sa) return vazio('Abra uma planilha', 'Não há o que conferir sem dados.');

    const limpas = sa.total - sa.comProblema;
    const pct = sa.total ? Math.round(100 * limpas / sa.total) : 0;
    const tom = pct >= 90 ? 'bom' : (pct >= 70 ? '' : 'ruim');

    const itens = sa.regras.map(r => {
      const lista = sa.achados[r.id] || [];
      if (!lista.length) {
        return '<div class="prev-check ok"><div class="prev-check-topo">' +
               '<span class="prev-check-nome">' + esc(r.titulo) + '</span>' +
               '<span class="prev-check-n ok">nenhuma</span></div></div>';
      }
      const exemplos = lista.slice(0, 6).map(x =>
        'linha ' + x.linha + (x.cp ? ' (CP ' + esc(x.cp) + ')' : '')).join(' · ');
      return '<div class="prev-check' + (r.grave ? ' grave' : '') + '">' +
        '<div class="prev-check-topo">' +
          '<span class="prev-check-nome">' + esc(r.titulo) + '</span>' +
          '<span class="prev-check-n">' + lista.length + ' linha' +
            (lista.length > 1 ? 's' : '') +
            ' · ' + (Math.round(1000 * lista.length / sa.total) / 10).toString().replace('.', ',') + '%</span>' +
        '</div>' +
        '<div class="prev-check-porque">' + esc(r.porque) + '</div>' +
        '<div class="prev-check-ex">' + exemplos +
          (lista.length > 6 ? ' · e mais ' + (lista.length - 6) : '') + '</div>' +
      '</div>';
    }).join('');

    return '<div class="prev-resumo">' +
        cartao(pct + '%', 'das linhas sem defeito', tom) +
        cartao(sa.total, 'linhas na planilha') +
        cartao(sa.comProblema, 'descartadas das contas', sa.comProblema ? 'ruim' : 'bom') +
      '</div>' +
      secao('O que encontrei', itens) +
      '<p class="prev-nota">As linhas marcadas como graves ficam de fora de todas as contas ' +
      'desta tela — média, desvio, tendência e previsão. Isso protege o resultado, mas não ' +
      'conserta a planilha: cada linha aqui é um ensaio que o laboratório fez e que não está ' +
      'contando para nada.</p>' +
      '<p class="prev-nota">A numeração das linhas é a da planilha aberta, contando o ' +
      'cabeçalho — a mesma que aparece na aba Planilhas.</p>' +
      blocoColunasEmUso() +
      blocoDoisCPs();
  }

  /* De onde sai cada numero desta tela. Sem isto, uma planilha em que o
   * palpite acerta a coluna errada da' resultado com cara de certo. */
  /* ── o segundo corpo de prova ────────────────────────────────────────
   * A NBR 12655 manda usar, de cada exemplar, o MAIOR dos corpos de prova.
   * A planilha da Usinop tem dois rompimentos de 28 dias por linha (MPA 28 e
   * MPA 28.1), e a conta usava so' o primeiro.
   *
   * Por que a opcao nasce DESLIGADA: na planilha da Usinop, quando os dois
   * existem, o segundo e' o menor em 87% das linhas. Se fossem dois corpos
   * de prova da mesma amassada, cada um seria o maior mais ou menos metade das
   * vezes. Pode ser que o laboratorio ja' anote o maior primeiro (e ai' ligar
   * nao muda quase nada), ou que a coluna seja outra coisa. Mexer em
   * conformidade no escuro e' o erro que esta tela existe para nao cometer —
   * entao ela mostra o efeito medido, com e sem, e quem decide e' quem conhece
   * a coluna.
   */
  function blocoDoisCPs() {
    const c = est.colunasEmUso;
    if (!c || !(c.d28b >= 0)) return '';
    const guardado = est.colunasEmUso;          // porReceita() regrava este campo
    const medir = dois => {
      const dados = porReceita({ doisCPs: dois });
      if (!dados || dados.erro) return null;
      const lista = dados.receitas.map(analisar).filter(a => isFinite(a.folga));
      return {
        abaixo: lista.filter(a => a.folga < 0).length,
        total: lista.length,
        folga: lista.length ? media(lista.map(a => a.folga)) : NaN,
        porNome: new Map(lista.map(a => [a.nome, a.folga])),
      };
    };
    const so1 = medir(false), maior = medir(true);
    est.colunasEmUso = guardado;
    if (!so1 || !maior) return '';

    const viram = [];
    so1.porNome.forEach((f, nome) => {
      const g = maior.porNome.get(nome);
      if (isFinite(g) && (f < 0) !== (g < 0)) viram.push({ nome, de: f, para: g });
    });

    // Quantas vezes o segundo valor e' o menor, nas linhas em que os dois existem
    let ambos = 0, segundoMenor = 0;
    const sd = window.getConcrestatsData ? window.getConcrestatsData({ filtered: true }) : null;
    ((sd && sd.data) || []).forEach(l => {
      const a = numBR(l[c.d28]), b = numBR(l[c.d28b]);
      if (isFinite(a) && isFinite(b) && a > 0 && b > 0 && a <= 120 && b <= 120) {
        ambos++;
        if (b < a) segundoMenor++;
      }
    });
    const pct = ambos ? Math.round(100 * segundoMenor / ambos) : 0;
    const nome1 = esc(String(c.headers[c.d28]).trim());
    const nome2 = esc(String(c.headers[c.d28b]).trim());
    const sinal = v => (v >= 0 ? '+' : '') + br(v);

    // Em 24/09/2026 o laboratorio confirmou: a segunda coluna e' o segundo
    // corpo de prova rompido do mesmo exemplar. A medida dos 87% continua a'
    // vista — explica por que a diferenca e' pequena (o maior ja' costuma vir
    // anotado primeiro), e nao e' mais motivo para desconfiar da coluna.
    const cautela = !ambos ? '' :
      '<p class="prev-nota">Nas ' + ambos.toLocaleString('pt-BR') + ' linhas em que os dois ' +
      'existem, ' + nome2 + ' é o menor em ' + pct + '% delas' +
      (pct >= 70 ? ' — o maior costuma ser anotado primeiro, e por isso usar o maior muda pouco.'
                 : '.') + '</p>';

    return secao('Segundo corpo de prova',
      '<p class="prev-nota">Esta planilha tem dois rompimentos de 28 dias por linha: <b>' + nome1 +
      '</b> e <b>' + nome2 + '</b> — os dois corpos de prova rompidos de cada exemplar. A NBR 12655 ' +
      'manda usar o <b>maior</b> deles. ' +
      (est.doisCPs ? 'A conta está usando o maior dos dois.'
                   : 'A opção foi desligada nesta cópia: a conta está usando só ' + nome1 + '.') +
      '</p>' +
      '<div class="prev-form"><label class="prev-opcao">' +
        '<input type="checkbox" id="prev-dois-cps"' + (est.doisCPs ? ' checked' : '') + '> ' +
        'Usar o maior dos dois corpos de prova (NBR 12655)</label></div>' +
      '<div class="prev-comparacao">' +
        '<div><span>Só ' + nome1 + '</span><b>' + so1.abaixo + '</b> de ' + so1.total +
          ' abaixo do fck · folga média ' + sinal(so1.folga) + ' MPa</div>' +
        '<div><span>O maior dos dois</span><b>' + maior.abaixo + '</b> de ' + maior.total +
          ' abaixo do fck · folga média ' + sinal(maior.folga) + ' MPa</div>' +
        (viram.length
          ? '<div><span>Mudam de lado</span>' + viram.slice(0, 6).map(v =>
              esc(curtoNome(v.nome)) + ' (' + sinal(v.de) + ' → ' + sinal(v.para) + ')').join(' · ') +
            (viram.length > 6 ? ' · e mais ' + (viram.length - 6) : '') + '</div>'
          : '<div><span>Mudam de lado</span>nenhuma receita</div>') +
      '</div>' + cautela);
  }

  function curtoNome(n) {
    const t = String(n || '').trim();
    return t.length > 42 ? t.slice(0, 41) + '…' : t;
  }

  function blocoColunasEmUso() {
    const c = est.colunasEmUso;
    if (!c) return '';
    const nome = i => (i >= 0 && c.headers[i] != null
      ? String(c.headers[i]).trim() || ('coluna ' + (i + 1)) : null);
    const linha = (rot, i) => '<div class="prev-check' + (i < 0 ? '' : ' ok') + '">' +
      '<div class="prev-check-topo">' +
        '<span class="prev-check-nome">' + esc(rot) + '</span>' +
        '<span class="prev-check-n' + (i < 0 ? '' : ' ok') + '">' +
          (i < 0 ? 'não achei' : esc(nome(i))) + '</span>' +
      '</div></div>';
    return secao('De onde vieram os números',
      linha('Nome da receita', c.r) +
      linha('Rompimento aos 28 dias', c.d28) +
      linha('Rompimento aos 7 dias', c.d7) +
      linha('Corpo de prova', c.cp) +
      linha('Data', c.data) +
      linha('Volume (m³)', c.m3) +
      linha('fck pedido', c.fck) +
      linha('2º corpo de prova aos 28 dias', c.d28b) +
      '<div class="prev-form" style="margin-top:12px">' +
        '<button class="secondary-btn" id="prev-trocar-colunas">Trocar as colunas</button>' +
      '</div>' +
      '<p class="prev-nota">' +
      (c.manual ? 'Estas colunas foram escolhidas à mão para este formato de planilha. '
                : 'Estas colunas foram deduzidas pelo nome do cabeçalho. ') +
      'Volume e data só melhoram o relatório; sem elas o resto continua valendo. ' +
      'Sem o volume não dá para dizer quanto cimento a irregularidade custa.</p>');
  }

  /* ── PAINEL: RESUMO ───────────────────────────────────────────────── */
  function painelResumo(d) {
    const { analisadas, comFaixa, fora, dados } = d;
    const caindo = analisadas.filter(a => a.tend && a.tend.caiu);
    const piores = fora.slice(0, 5);

    const destaques = piores.length
      ? '<div class="prev-destaques">' + piores.map(a =>
          '<div class="prev-destaque">' +
            '<div class="prev-destaque-nome" title="' + esc(a.nome) + '">' + esc(a.nome) + '</div>' +
            '<div class="prev-destaque-linha">' +
              '<span class="prev-neg">' + br(a.folga) + ' MPa</span> abaixo do fck · ' +
              'desvio ' + br(a.desvio, 2) + ' (' + esc(a.condicao || '—') + ')' +
              (a.tend && a.tend.caiu ? ' · <span class="prev-caindo">caindo</span>' : '') +
            '</div>' +
            '<div class="prev-destaque-diag">' + esc(diagnostico(a)) + '</div>' +
          '</div>').join('') + '</div>'
      : '<p class="prev-nota">Nenhuma receita abaixo do fck. Raro e bom.</p>';

    return '<div class="prev-resumo">' +
        cartao(analisadas.length, 'receitas na planilha') +
        cartao(comFaixa.length, 'com histórico para julgar') +
        cartao(fora.length, 'abaixo do fck pedido', fora.length ? 'ruim' : 'bom') +
        cartao(caindo.length, 'caindo nos últimos 10', caindo.length ? 'ruim' : '') +
      '</div>' +
      (dados.descartados
        ? '<p class="prev-nota">Deixei de fora ' + dados.descartados + ' ensaio(s) ' +
          'fisicamente impossível(is) — resistência negativa, acima de 120 MPa, ou 28 dias ' +
          'muito abaixo do próprio 7 dias. São erros de digitação, e incluí-los distorce tudo.</p>'
        : '') +
      '<div class="prev-acoes prev-acoes-topo">' +
        '<button class="primary-btn" id="prev-relatorio">Relatório de conformidade</button>' +
        '<span class="prev-acoes-nota">Documento pronto para imprimir ou salvar em PDF — ' +
        'é o que a usina manda para o cliente dela.</span>' +
      '</div>' +
      blocoDinheiro(analisadas) +
      blocoPatamares(analisadas) +
      secao('Os piores casos', destaques);
  }

  function blocoPatamares(todas) {
    const lista = todas.filter(a => a.patamar).sort((x, y) => y.patamar.t - x.patamar.t);
    if (!lista.length) return '';
    const linhas = lista.map(a =>
      '<tr data-receita="' + esc(a.nome) + '">' +
      '<td class="prev-nome" title="' + esc(a.nome) + '">' + esc(a.nome) + '</td>' +
      '<td>' + esc(a.patamar.data ? fmtData(a.patamar.data)
                  : 'ensaio ' + a.patamar.ensaio) + '</td>' +
      '<td class="' + (a.patamar.dif < 0 ? 'prev-neg' : 'prev-pos') + '"><b>' +
        (a.patamar.dif > 0 ? '+' : '') + br(a.patamar.dif) + '</b></td>' +
      '<td>' + br(a.patamar.antes) + '</td>' +
      '<td>' + br(a.patamar.depois) + '</td>' +
      '<td>' + a.patamar.de + '</td>' +
      '</tr>').join('');
    return secao('Receitas que mudaram de patamar',
      '<div class="prev-tabela-wrap"><table class="prev-tabela">' +
      '<thead><tr><th>Receita</th><th>Quando</th><th>Mudou</th><th>Média antes</th>' +
      '<th>Média depois</th><th>Ensaios</th></tr></thead><tbody>' + linhas +
      '</tbody></table></div>' +
      '<p class="prev-nota"><b>Isto é diferente de "está caindo".</b> Cair devagar não tem ' +
      'culpado; mudar de patamar num dia tem. A busca procura o corte que mais separa a ' +
      'série em duas e mede se o salto é grande perto da variação normal daquela receita.</p>' +
      '<p class="prev-nota">A régua saiu de medição: embaralhando a ordem dos ensaios — o que ' +
      'destrói qualquer patamar real — a mesma busca encontrou <b>zero</b> casos, em todas as ' +
      'réguas testadas. Não é um alerta que aparece por acaso. Vale procurar o que mudou ' +
      'naquela data: lote de cimento, agregado novo, operador, chuva.</p>');
  }

  /* ── o desperdício em quilos e em reais ─────────────────────────────
   * Aqui a margem em MPa vira cimento, e cimento vira dinheiro — mas só
   * depois que alguém informa o fator da própria usina. Sem ele a tela mostra
   * a margem e pede o número, em vez de chutar. */
  function blocoDinheiro(todas) {
    const lista = todas.filter(a => a.desperdicio && isFinite(a.desperdicio.ganho)
                                 && a.n >= MINIMO_PARA_FAIXA && isFinite(a.alvo.valor));
    if (!lista.length) return '';

    const mpaMedio = lista.reduce((s, a) => s + a.desperdicio.ganho, 0) / lista.length;
    const m3Total = lista.reduce((s, a) => s + (a.m3 || 0), 0);

    let veredito;
    if (temFator()) {
      // kg desperdiçados = Σ (margem em MPa × kg por MPa × m³ daquela receita)
      const kg = lista.reduce((s, a) => s + a.desperdicio.ganho * est.fator.kgPorMPa * (a.m3 || 0), 0);
      const reais = isFinite(est.fator.reaisPorKg) && est.fator.reaisPorKg > 0
        ? kg * est.fator.reaisPorKg : NaN;
      veredito =
        '<div class="prev-dinheiro">' +
          '<div class="prev-dinheiro-num">' + br(kg / 1000, 1) + ' <small>toneladas de cimento</small></div>' +
          (isFinite(reais)
            ? '<div class="prev-dinheiro-reais">R$ ' +
              (Math.round(reais)).toLocaleString('pt-BR') + '</div>' : '') +
          '<div class="prev-dinheiro-nota">gastos a mais para compensar irregularidade, ' +
          'nos ' + br(m3Total, 0) + ' m³ desta planilha</div>' +
        '</div>';
    } else {
      veredito = '<p class="prev-nota"><b>' + br(mpaMedio) + ' MPa</b> de margem média ' +
        'desperdiçada em ' + lista.length + ' receitas, sobre ' + br(m3Total, 0) + ' m³. ' +
        'Informe abaixo quantos quilos de cimento valem 1 MPa no traço de vocês e eu ' +
        'converto isso em toneladas e em reais.</p>';
    }

    return secao('O que a irregularidade custa',
      veredito +
      '<div class="prev-form">' +
        '<div><label>kg de cimento por MPa</label>' +
          '<input id="prev-kg" type="text" inputmode="decimal" placeholder="ex: 8" value="' +
          (isFinite(est.fator.kgPorMPa) ? br(est.fator.kgPorMPa, 2) : '') + '"></div>' +
        '<div><label>R$ por kg de cimento</label>' +
          '<input id="prev-rs" type="text" inputmode="decimal" placeholder="ex: 0,65" value="' +
          (isFinite(est.fator.reaisPorKg) ? br(est.fator.reaisPorKg, 2) : '') + '"></div>' +
        '<button class="primary-btn" id="prev-fator-ok">Calcular</button>' +
      '</div>' +
      '<p class="prev-nota">Esse fator muda com o traço, o agregado e o cimento — não existe ' +
      'número universal, e eu não vou inventar um. O laboratório de vocês já o tem, da curva ' +
      'de dosagem. Fica guardado depois de informado.</p>' +
      '<p class="prev-nota">A conta: para o fck estimado passar, a média precisa ficar 1,65 ' +
      'desvios acima do fck. Desvio maior obriga média maior, e média maior é cimento a mais. ' +
      'Multiplico essa margem pelo volume real de cada receita nesta planilha.</p>');
  }

  function ligarFator(d) {
    const bt = $('prev-fator-ok');
    if (!bt) return;
    const aplicar = () => {
      est.fator.kgPorMPa = numBR($('prev-kg').value);
      est.fator.reaisPorKg = numBR($('prev-rs').value);
      if (!temFator()) { avisar('Informe quantos kg de cimento valem 1 MPa', 'error'); return; }
      salvarFator();
      render();
    };
    bt.addEventListener('click', aplicar);
    ['prev-kg', 'prev-rs'].forEach(id => {
      const el = $(id);
      if (el) el.addEventListener('keydown', e => { if (e.key === 'Enter') aplicar(); });
    });
  }

  /* ── marcar na planilha ────────────────────────────────────────────── */
  function ligarMarcacao(fora) {
    const bt = $('prev-marcar');
    if (bt) {
      bt.addEventListener('click', () => {
        if (typeof window.ConcrestatsMarcarReceitas !== 'function') {
          avisar('Esta versão não sabe marcar na planilha.', 'error');
          return;
        }
        const r = window.ConcrestatsMarcarReceitas(fora.map(a => a.nome), 'vermelho');
        if (!r.ok) { avisar(r.motivo, 'error'); return; }
        const sobra = r.perdidos
          ? ' (' + r.perdidos + ' com "&" no nome ficaram de fora)' : '';
        avisar(r.marcadas + ' receita(s) marcadas na coluna ' + r.coluna + sobra, 'success');
      });
    }
    const bd = $('prev-desmarcar');
    if (bd) {
      bd.addEventListener('click', () => {
        if (typeof window.ConcrestatsDesmarcarReceitas !== 'function') return;
        const r = window.ConcrestatsDesmarcarReceitas();
        avisar(r.removidas ? 'Marca retirada da planilha' : 'Não havia marca', 'success');
      });
    }
  }
  /* Exporta a tabela como .xlsx de verdade, gerado no servidor com openpyxl.
   * O caminho pelo navegador (SheetJS) falhava em algumas máquinas da usina —
   * o mesmo motivo que já levou o Painel a exportar por aqui. */
  function ligarExport(lista) {
    const bt = $('prev-exportar');
    if (!bt) return;
    bt.addEventListener('click', async () => {
      const aoa = [[
        'Receita', 'Ensaios', 'fck pedido', 'Media', 'Desvio', 'fck estimado',
        'Folga', 'Condicao (NBR 12655)', 'Ultimos 10', 'Diagnostico',
      ]];
      lista.forEach(a => {
        const t = a.tend && a.tend.caiu ? ('caiu ' + br(Math.abs(a.tend.dif))) : 'estavel';
        aoa.push([a.nome, a.n, a.alvo.valor, +a.media.toFixed(2), +a.desvio.toFixed(2),
                  +a.fckEst.toFixed(2), +a.folga.toFixed(2), a.condicao || '', t,
                  diagnostico(a)]);
      });
      try {
        let caminho = null;
        const base = 'receitas_fora_da_faixa';
        if (window.pywebview && window.pywebview.api && window.pywebview.api.save_file_dialog) {
          caminho = await window.pywebview.api.save_file_dialog(base + '.xlsx');
          if (!caminho) return;
        }
        const r = await fetch('/api/export_aoa', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ aoa, path: caminho, sheet_name: 'Fora da faixa',
                                 base_name: base }),
        });
        const ct = r.headers.get('content-type') || '';
        if (ct.indexOf('json') >= 0) {
          const j = await r.json();
          avisar(j.success ? 'Planilha salva' : ('Erro: ' + (j.error || '')),
                 j.success ? 'success' : 'error');
          return;
        }
        const blob = await r.blob();
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = base + '.xlsx';
        a.click();
        URL.revokeObjectURL(a.href);
        avisar(lista.length + ' receita(s) exportadas', 'success');
      } catch (e) {
        avisar('Falha ao exportar: ' + (e.message || e), 'error');
      }
    });
  }

  function avisar(msg, tipo) {
    if (typeof window.showToast === 'function') window.showToast(msg, tipo);
  }

  function vazio(titulo, sub) {
    return '<div class="graf-empty-state"><div class="empty-icon">◈</div>' +
           '<p>' + esc(titulo) + '</p><p class="empty-sub">' + esc(sub) + '</p></div>';
  }

  function cartao(valor, rotulo, tom) {
    return '<div class="prev-cartao ' + (tom || '') + '">' +
           '<div class="prev-cartao-num">' + valor + '</div>' +
           '<div class="prev-cartao-rot">' + esc(rotulo) + '</div></div>';
  }

  function blocoFaixa(lista) {
    if (!lista.length) {
      return secao('Receitas fora da faixa',
        '<p class="prev-nota">Nenhuma receita tem ensaios suficientes (mínimo ' +
        MINIMO_PARA_FAIXA + ') para o cálculo.</p>');
    }
    const linhas = lista.map(a => {
      const ruim = a.folga < 0;
      return '<tr class="' + (ruim ? 'prev-fora' : '') + '" data-receita="' + esc(a.nome) + '">' +
        '<td class="prev-nome" title="' + esc(diagnostico(a)) + '">' + esc(a.nome) + '</td>' +
        '<td>' + a.n + '</td>' +
        '<td>' + br(a.alvo.valor, 0) + (a.alvo.origem === 'nome' ? '<span class="prev-marca" title="lido do nome do produto; cadastre a receita para usar o valor oficial">?</span>' : '') + '</td>' +
        '<td>' + br(a.media) + '</td>' +
        '<td>' + br(a.desvio, 2) + '</td>' +
        '<td><b>' + br(a.fckEst) + '</b></td>' +
        '<td class="' + (ruim ? 'prev-neg' : 'prev-pos') + '">' +
          (a.folga >= 0 ? '+' : '') + br(a.folga) + '</td>' +
        '<td>' + (isFinite(a.ac) ? br(a.ac, 2) : '<span class="prev-sem">—</span>') + '</td>' +
        '<td>' + celulaCondicao(a) + '</td>' +
        '<td>' + celulaTendencia(a.tend) + '</td>' +
      '</tr>';
    }).join('');

    const explica =
      '<p class="prev-nota"><b>Como se lê:</b> pela NBR 12655 quem aprova a receita não é a ' +
      'média, é a resistência característica estimada — média menos 1,65 vezes o desvio. ' +
      'Repare que quase toda receita desta lista tem média ACIMA do fck pedido e mesmo assim ' +
      'fica abaixo: o que reprova é a irregularidade, não a fraqueza. Concreto irregular ' +
      'gasta cimento a mais e continua não passando.</p>' +
      '<p class="prev-nota"><b>Últimos 10:</b> compara os 10 ensaios mais recentes com os 10 ' +
      'anteriores, e só aponta queda maior que o dobro da variação normal daquela receita. ' +
      'A régua saiu de uma medição: embaralhando a ordem dos ensaios — o que destrói qualquer ' +
      'tendência real — sobra menos de um alerta falso por leitura inteira. Uma receita que ' +
      'hoje passa mas está caindo merece mais atenção do que uma que sempre foi ruim.</p>' +
      (lista.some(a => isFinite(a.ac)) ? '' :
        '<p class="prev-nota"><b>a/c vazia:</b> nenhuma destas receitas tem cimento e água ' +
        'preenchidos na aba Receitas, então a relação água/cimento não pode ser mostrada — ' +
        'e por isso ela também não entra na previsão. Seria fé, não estatística. ' +
        'Cadastre os consumos e a coluna se preenche sozinha.</p>');

    const fora = lista.filter(a => a.folga < 0);
    const botoes = fora.length
      ? '<div class="prev-acoes">' +
          '<button class="primary-btn" id="prev-marcar">Marcar na planilha as ' +
            fora.length + ' fora da faixa</button>' +
          '<button class="secondary-btn" id="prev-desmarcar">Tirar a marca</button>' +
          '<button class="secondary-btn" id="prev-exportar">Exportar a lista</button>' +
          '<span class="prev-acoes-nota">Pinta as linhas dessas receitas na aba Planilhas. ' +
            'Vira uma regra de cor, que você pode editar ou apagar por lá.</span>' +
        '</div>'
      : '<div class="prev-acoes">' +
          '<button class="secondary-btn" id="prev-exportar">Exportar a lista</button>' +
        '</div>';

    return secao('Receitas fora da faixa',
      botoes +
      '<div class="prev-tabela-wrap"><table class="prev-tabela">' +
      '<thead><tr><th>Receita</th><th>Ensaios</th><th>fck pedido</th><th>Média</th>' +
      '<th>Desvio</th><th>fck estimado</th><th>Folga</th><th>a/c</th><th>Condição</th>' +
      '<th>Últimos 10</th></tr></thead>' +
      '<tbody>' + linhas + '</tbody></table></div>' + explica);
  }

  /* Uma frase por receita, dizendo o que fazer. É o que separa um relatório
   * de um diagnóstico: o número diz que há problema, a frase diz qual. */
  function diagnostico(a) {
    const temAlvo = isFinite(a.alvo.valor);
    if (!temAlvo) return 'Sem fck no nome nem no cadastro — não dá para julgar.';
    if (!isFinite(a.fckEst)) {
      return 'Só ' + a.n + ' ensaio(s). Abaixo de ' + MINIMO_PARA_FAIXA +
             ' a conta de desvio não significa nada.';
    }
    const caindo = a.tend && a.tend.caiu;
    if (a.folga >= 0) {
      const base = 'Passa, com folga de ' + br(a.folga) + ' MPa.';
      return caindo
        ? base + ' Mas caiu ' + br(Math.abs(a.tend.dif)) +
          ' MPa nos últimos 10 ensaios — está consumindo a folga.'
        : base;
    }
    // Reprova. Por fraqueza ou por irregularidade?
    if (a.media < a.alvo.valor) {
      return 'A média (' + br(a.media) + ') já está abaixo do fck de ' +
             br(a.alvo.valor, 0) + '. Aqui o traço precisa mudar; regularidade ' +
             'sozinha não resolve.';
    }
    let txt = 'A média (' + br(a.media) + ') está ACIMA do fck de ' + br(a.alvo.valor, 0) +
              ', mas o desvio de ' + br(a.desvio, 2) + ' derruba o fck estimado para ' +
              br(a.fckEst) + '. Não é concreto fraco, é irregular.';
    if (isFinite(a.sdNecessario) && a.sdNecessario > 0) {
      txt += ' Bastaria o desvio cair para ' + br(a.sdNecessario, 2) +
             ' para passar sem mexer no traço';
      const cond = condicaoDePreparo(a.sdNecessario);
      txt += cond && cond !== 'pior que C' ? ' (condição ' + cond + ').' : '.';
    }
    if (caindo) txt += ' E ainda caiu ' + br(Math.abs(a.tend.dif)) + ' MPa nos últimos 10.';
    if (a.patamar) {
      const quando = a.patamar.data ? ' em ' + fmtData(a.patamar.data)
                                    : ' no ensaio ' + a.patamar.ensaio + ' de ' + a.patamar.de;
      txt += ' Atenção: esta receita MUDOU DE PATAMAR' + quando + ' — ' +
             (a.patamar.dif < 0 ? 'caiu ' : 'subiu ') + br(Math.abs(a.patamar.dif)) +
             ' MPa de uma vez, e ficou assim. Vale procurar o que mudou naquele dia.';
    }
    if (isFinite(a.ac)) {
      txt += ' A relação a/c cadastrada é ' + br(a.ac, 2) +
             (a.ac > 0.6 ? ' — alta; é por onde a resistência costuma escapar.' : '.');
    }
    return txt;
  }

  function celulaCondicao(a) {
    if (!a.condicao) return '<span class="prev-sem">—</span>';
    const ruim = a.condicao === 'pior que C';
    return '<span class="' + (ruim ? 'prev-cond-ruim' : 'prev-cond') + '" title="' +
           'NBR 12655: o desvio-padrão aceitável depende de como o concreto é preparado. ' +
           'A = tudo em massa com umidade corrigida; B = miúdo em massa, graúdo em volume; ' +
           'C = a mais frouxa, só até fck 20.">' + esc(a.condicao) + '</span>';
  }

  function celulaTendencia(t) {
    if (!t) return '<span class="prev-sem">—</span>';
    if (!t.caiu) return '<span class="prev-sem">estável</span>';
    return '<span class="prev-caindo" title="os 10 últimos ensaios vieram ' +
           br(Math.abs(t.dif)) + ' MPa abaixo dos 10 anteriores — mais que o dobro da ' +
           'variação normal desta receita">↓ ' + br(Math.abs(t.dif)) + '</span>';
  }

  function blocoPrevisao(todas) {
    const podem = todas.filter(a => a.reta && a.reta.n >= MINIMO_DE_ENSAIOS)
      .sort((x, y) => y.reta.n - x.reta.n);
    if (!podem.length) {
      return secao('Prever o rompimento de 28 dias',
        '<p class="prev-nota">Nenhuma receita tem ' + MINIMO_DE_ENSAIOS + ' ou mais ensaios ' +
        'com os dois rompimentos (7 e 28 dias) preenchidos. Sem esse par não há o que aprender.</p>');
    }
    const opcoes = podem.map(a =>
      '<option value="' + esc(a.nome) + '">' + esc(a.nome) + '  (' + a.reta.n + ' ensaios)</option>'
    ).join('');
    return secao('Prever o rompimento de 28 dias',
      '<div class="prev-form">' +
        '<label>Receita</label><select id="prev-receita">' + opcoes + '</select>' +
        '<label>Resistência aos 7 dias (MPa)</label>' +
        // type="text" de proposito: um campo numerico RECUSA a virgula, e aqui
        // todo mundo digita "18,5". O numBR ja' entende os dois jeitos.
        '<input id="prev-mpa7" type="text" inputmode="decimal" placeholder="ex: 18,5">' +
        '<button class="primary-btn" id="prev-calcular">Prever</button>' +
      '</div><div id="prev-saida"></div>');
  }

  /* ── carta de controle ──────────────────────────────────────────────
   * A ferramenta clássica de controle de qualidade, e a que o laboratório
   * imprime e prega na parede: os ensaios na ordem em que saíram, a linha do
   * fck pedido e a do fck estimado. Uma tabela diz QUE há problema; a carta
   * mostra QUANDO ele começou.
   *
   * Clicar na linha da receita abre a dela. Uma de cada vez, de propósito:
   * trinta e seis cartas na tela seriam trinta e seis gráficos que ninguém lê.
   */
  let cartaAberta = null;

  function ligarCarta(lista) {
    const alvo = $('prev-carta');
    if (!alvo) return;
    // A linha diz QUAL receita ela e', num data-receita.
    //
    // A primeira versao reconhecia a receita comparando o TEXTO do diagnostico
    // da linha com o de cada receita. Duas receitas com a mesma frase abriam o
    // grafico errado, calado - e frase repetida nao e' excecao: toda receita
    // com historico curto recebe exatamente "So' N ensaio(s). Abaixo de 6 a
    // conta de desvio nao significa nada."
    //
    // O seletor tambem pegava TODAS as tabelas do painel, inclusive a de
    // desperdicio, onde clicar nao deveria abrir carta nenhuma.
    document.querySelectorAll('#prev-corpo tr[data-receita]').forEach(tr => {
      tr.classList.add('prev-clicavel');
      tr.addEventListener('click', () => {
        const a = lista.find(x => x.nome === tr.dataset.receita);
        if (!a) return;
        if (cartaAberta === a.nome) { alvo.innerHTML = ''; cartaAberta = null; return; }
        cartaAberta = a.nome;
        desenharCarta(alvo, a);
        alvo.scrollIntoView({ block: 'nearest' });
      });
    });
  }

  function desenharCarta(alvo, a) {
    alvo.innerHTML =
      '<div class="prev-carta">' +
        '<div class="prev-carta-topo">' +
          '<span class="prev-carta-nome">' + esc(a.nome) + '</span>' +
          '<button class="secondary-btn prev-carta-x" id="prev-carta-fechar">fechar</button>' +
        '</div>' +
        '<div class="prev-carta-legenda">' +
          '<span class="prev-leg prev-leg-fck">fck pedido ' + br(a.alvo.valor, 0) + '</span>' +
          '<span class="prev-leg prev-leg-est">fck estimado ' + br(a.fckEst) + '</span>' +
          '<span class="prev-leg prev-leg-med">média ' + br(a.media) + '</span>' +
        '</div>' +
        '<div class="prev-carta-area"><canvas></canvas></div>' +
        '<p class="prev-nota">' + esc(diagnostico(a)) + '</p>' +
      '</div>';

    const fechar = $('prev-carta-fechar');
    if (fechar) fechar.addEventListener('click', e => {
      e.stopPropagation(); alvo.innerHTML = ''; cartaAberta = null;
    });

    const canvas = alvo.querySelector('canvas');
    if (!canvas || typeof window.Chart !== 'function') return;

    const linhas = [
      [a.alvo.valor, '#c0392b', 'fck'],
      [a.fckEst,     '#e8a030', 'fck,est'],
      [a.media,      '#2a6640', 'média'],
    ].filter(([v]) => isFinite(v));

    // As linhas de referência são o que dá sentido à nuvem de pontos: sem elas
    // o gráfico é bonito e não diz nada.
    const reguas = linhas.map(([valor, cor, rotulo]) => ({
      id: 'regua' + rotulo,
      afterDraw(chart) {
        const y = chart.scales && chart.scales.y;
        if (!y) return;
        const py = y.getPixelForValue(valor);
        if (py < chart.chartArea.top || py > chart.chartArea.bottom) return;
        const ctx = chart.ctx;
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(chart.chartArea.left, py);
        ctx.lineTo(chart.chartArea.right, py);
        ctx.lineWidth = 1.5;
        ctx.strokeStyle = cor;
        ctx.setLineDash(rotulo === 'fck' ? [] : [5, 4]);
        ctx.stroke();
        ctx.restore();
      },
    }));

    try {
      new window.Chart(canvas, {
        type: 'line',
        plugins: reguas,
        data: { datasets: [{
          label: 'MPa aos 28 dias',
          data: a.todos.map((v, i) => ({ x: i, y: v })),
          borderColor: '#2a5298',
          backgroundColor: '#2a529822',
          borderWidth: 1.5,
          pointRadius: a.todos.length > 120 ? 0 : 2,
        }] },
        options: { scales: { x: { min: 0, max: Math.max(1, a.todos.length - 1) }, y: {} } },
      });
    } catch (e) {
      alvo.querySelector('.prev-carta-area').innerHTML =
        '<p class="prev-nota">Não consegui desenhar: ' + esc(e.message) + '</p>';
    }
  }

  /* ── quando o palpite nao serve, perguntar ────────────────────────────
   * Antes esta tela so' informava a propria derrota. Quem abriu a planilha
   * sabe qual coluna e' a receita e qual e' o rompimento de 28 dias; custa
   * dois cliques dizer, e a resposta fica guardada para o formato.
   */
  function opcoes(headers, escolhido, comVazio) {
    const partes = comVazio
      ? ['<option value="-1"' + (escolhido < 0 ? ' selected' : '') +
         '>— não tenho essa coluna —</option>']
      : ['<option value="-1"' + (escolhido < 0 ? ' selected' : '') +
         '>— escolha —</option>'];
    headers.forEach((h, i) => {
      const rotulo = String(h == null ? '' : h).trim() || ('coluna ' + (i + 1));
      partes.push('<option value="' + i + '"' + (i === escolhido ? ' selected' : '') +
                  '>' + esc(rotulo) + '</option>');
    });
    return partes.join('');
  }

  function escolherColunas(d) {
    const h = d.headers || [];
    const achou = [];
    if (d.iR >= 0)  achou.push('receita em <b>' + esc(String(h[d.iR]).trim()) + '</b>');
    if (d.i28 >= 0) achou.push('28 dias em <b>' + esc(String(h[d.i28]).trim()) + '</b>');
    if (d.i7 >= 0)  achou.push('7 dias em <b>' + esc(String(h[d.i7]).trim()) + '</b>');

    // O que falta, numa frase só. Antes: "Não achei não sei qual coluna...
    // nem não sei qual..." — a frase montada por pedaços não fechava.
    const faltam = [];
    if (d.iR < 0)  faltam.push('o nome da receita');
    if (d.i28 < 0) faltam.push('o rompimento de 28 dias');
    const oQueFalta = faltam.length
      ? 'não sei qual coluna tem ' + faltam.join(' nem qual tem ')
      : '';

    // Planilha com bloco de título em cima (cliente, obra, "ENSAIO DE
    // COMPRESSÃO..."): a primeira linha vira o cabeçalho e as outras colunas
    // saem sem nome. Nenhuma escolha abaixo resolve isso — o cabeçalho de
    // verdade está mais para baixo. Melhor dizer do que deixar a pessoa
    // procurando "MPa" numa lista de "Unnamed".
    const semNome = h.filter(x => /^Unnamed:\s*\d+$/i.test(String(x || '').trim()) ||
                                   !String(x == null ? '' : x).trim()).length;
    const pareceTitulo = h.length >= 3 && semNome / h.length >= 0.5;
    const avisoTitulo = pareceTitulo
      ? '<p class="prev-nota prev-aviso-titulo"><b>A primeira linha desta planilha parece ser um ' +
        'título, e não o cabeçalho</b> — ' + semNome + ' das ' + h.length + ' colunas estão sem nome. ' +
        'Os nomes de verdade (produto, MPa…) devem estar algumas linhas abaixo. No Excel, apague as ' +
        'linhas de título acima deles, salve, e abra de novo aqui.</p>'
      : '';

    const diagnostico = d.soTrocando
      ? '<p class="prev-nota">Estou usando ' + achou.join(', ') +
        '. Se não for isso, corrija abaixo.</p>'
      : avisoTitulo + '<p class="prev-nota">' +
        (achou.length ? 'Achei ' + achou.join(' e ') + ', mas ' + oQueFalta
                      : oQueFalta.charAt(0).toUpperCase() + oQueFalta.slice(1)) +
        '. Esta planilha tem ' + h.length + ' colunas: ' +
        esc(h.map(x => String(x == null ? '' : x).trim()).filter(Boolean).join(', ')) +
        '.</p>';

    return secao('De qual coluna eu leio o quê?',
      diagnostico +
      '<div class="prev-form">' +
        '<div><label>Nome da receita / produto</label>' +
          '<select id="prev-col-r">' + opcoes(h, d.iR, false) + '</select></div>' +
        '<div><label>Rompimento aos 28 dias</label>' +
          '<select id="prev-col-28">' + opcoes(h, d.i28, false) + '</select></div>' +
        '<div><label>Rompimento aos 7 dias (opcional)</label>' +
          '<select id="prev-col-7">' + opcoes(h, d.i7, true) + '</select></div>' +
        '<button class="primary-btn" id="prev-col-ok">Usar estas colunas</button>' +
        (d.soTrocando ? '<button class="secondary-btn" id="prev-col-cancelar">Cancelar</button>' : '') +
      '</div>' +
      '<p class="prev-nota">A de 7 dias é opcional: sem ela dá para conferir conformidade ' +
      'e apontar receita fora da faixa, mas não dá para prever o 28 a partir do 7.</p>' +
      '<p class="prev-nota">Fica guardado para este formato de planilha — mesma sequência de ' +
      'cabeçalhos, mesma resposta. Planilha nova do mesmo modelo não pergunta de novo.</p>');
  }

  function ligarEscolhaDeColunas(d) {
    const cancelar = $('prev-col-cancelar');
    if (cancelar) cancelar.addEventListener('click', () => { est.trocando = false; render(); });
    const bt = $('prev-col-ok');
    if (!bt) return;
    bt.addEventListener('click', () => {
      const v = id => { const el = $(id); return el ? parseInt(el.value, 10) : -1; };
      const r = v('prev-col-r'), d28 = v('prev-col-28'), d7 = v('prev-col-7');
      if (!(r >= 0)) { avisar('Escolha a coluna com o nome da receita', 'error'); return; }
      if (!(d28 >= 0)) { avisar('Escolha a coluna do rompimento de 28 dias', 'error'); return; }
      if (d28 === r || (d7 >= 0 && (d7 === r || d7 === d28))) {
        avisar('Cada informação tem de vir de uma coluna diferente', 'error'); return;
      }
      est.colunas[formatoDaPlanilha(d.headers || [])] = { r, d28, d7 };
      salvarColunas();
      est.trocando = false;
      render();
    });
  }

  function secao(titulo, dentro) {
    return '<div class="prev-secao"><h3>' + esc(titulo) + '</h3>' + dentro + '</div>';
  }

  function ligarPrevisao(todas) {
    const bt = $('prev-calcular');
    if (!bt) return;
    const calcular = () => {
      const nome = $('prev-receita').value;
      const mpa7 = numBR($('prev-mpa7').value);
      const saida = $('prev-saida');
      if (!isFinite(mpa7) || mpa7 <= 0) {
        saida.innerHTML = '<p class="prev-nota">Digite a resistência dos 7 dias.</p>';
        return;
      }
      const a = todas.find(x => x.nome === nome);
      const r = prever(a, mpa7);
      if (!r.ok) {
        saida.innerHTML = '<div class="prev-recusa"><b>Não vou prever.</b> ' + esc(r.msg) + '</div>';
        return;
      }
      const alvo = a.alvo.valor;
      const passa = isFinite(alvo) ? (r.minimo >= alvo) : null;
      const risco = isFinite(alvo) && !passa
        ? '<div class="prev-risco">Com a margem, este corpo de prova pode ficar abaixo do fck de ' +
          br(alvo, 0) + ' MPa. Vale acompanhar.</div>'
        : '';
      saida.innerHTML =
        '<div class="prev-resultado">' +
          '<div class="prev-numero">' + br(r.valor) + ' <small>MPa aos 28 dias</small></div>' +
          '<div class="prev-margem">entre ' + br(r.minimo) + ' e ' + br(r.maximo) +
            ' — erro típico de ' + br(r.erro) + ' MPa nesta receita</div>' +
          '<div class="prev-base">calculado sobre ' + r.n + ' ensaios desta mesma receita</div>' +
        '</div>' + risco;
    };
    bt.addEventListener('click', calcular);
    $('prev-mpa7').addEventListener('keydown', e => { if (e.key === 'Enter') calcular(); });
  }

  /* ── cadastro de receitas: o fck oficial vem de lá ─────────────────── */
  function carregarCadastro() {
    try {
      const raw = localStorage.getItem('concrelab_receitas');
      if (raw) est.cadastro = JSON.parse(raw) || [];
    } catch (e) { /* segue com o nome */ }
    // Como no módulo de Gráficos, quem vai à rede aqui é a tela, e é local.
    try {
      fetch('/api/receitas')
        .then(r => (r.ok ? r.json() : null))
        .then(lista => { if (Array.isArray(lista)) est.cadastro = lista; })
        .catch(() => {});
    } catch (e) { /* idem */ }
  }

  document.addEventListener('DOMContentLoaded', function () {
    carregarCadastro();
    const b = $('prev-atualizar');
    if (b) b.addEventListener('click', render);
    window.addEventListener('concrestats:datachanged', () => {
      const el = $('module-previsao');
      if (el && el.style.display !== 'none') setTimeout(render, 50);
      setTimeout(avisarEnsaioNovoRuim, 120);
    });
  });

  /* ── aviso na hora, não no fim do mês ───────────────────────────────
   * A tabela de receitas mostra o problema do mês; isto avisa no minuto em que
   * alguém digita um resultado que a própria receita não esperava.
   *
   * O valor está no TEMPO: descobrir hoje que a carga de ontem veio 19 MPa
   * abaixo do previsto ainda permite ir atrás da betoneira, do lote e de quem
   * moldou. Descobrir no fechamento do mês não permite nada.
   *
   * Só avisa do que APARECEU desde a última conta. Na primeira vez guarda o
   * que já existia e fica calado — senão abrir uma planilha antiga despejaria
   * cento e cinquenta avisos de ensaios de meses atrás.
   */
  let suspeitosConhecidos = null;

  function chaveDoEnsaio(e) {
    return String(e.receita) + '|' + String(e.cp) + '|' + String(e.data) + '|' + e.d28;
  }

  function avisarEnsaioNovoRuim() {
    let todas;
    try {
      const d = porReceita();
      if (!d || d.erro) return;
      todas = d.receitas.map(analisar);
    } catch (e) { return; }

    const agora = new Set(ensaiosSuspeitos(todas).map(chaveDoEnsaio));
    if (suspeitosConhecidos === null) { suspeitosConhecidos = agora; return; }

    const novos = [...agora].filter(k => !suspeitosConhecidos.has(k));
    suspeitosConhecidos = agora;
    if (!novos.length) return;

    const msg = novos.length === 1
      ? 'Um ensaio veio abaixo do que a receita previa'
      : novos.length + ' ensaios vieram abaixo do que a receita previa';
    if (typeof window.showToast === 'function') {
      window.showToast(msg + ' — veja em Previsão › Ensaios', 'error');
    }
  }

  window.PrevisaoModule = {
    onModuleEnter() { carregarCadastro(); carregarFator(); carregarColunas(); render(); },
    // exposto para o Modo Teste conferir a conta sem depender da tela
    _analisar: () => (porReceita() || { receitas: [] }).receitas.map(analisar),
    _prever: prever,
    _avisar: avisarEnsaioNovoRuim,
    _relatorio: () => montarRelatorio(est.ultimo),
    _zerarAvisos: () => { suspeitosConhecidos = null; },
    // o casamento de cabecalho, exposto para o Modo Teste conferir sem
    // depender de ter a planilha certa aberta
    _coluna: coluna,
    _colunasEmUso: () => est.colunasEmUso,
    // abaixo do fck com e sem o segundo corpo de prova, sem mexer na opcao
    _comDoisCPs: dois => {
      const guardado = est.colunasEmUso;
      const d = porReceita({ doisCPs: !!dois });
      est.colunasEmUso = guardado;
      if (!d || d.erro) return null;
      const l = d.receitas.map(analisar).filter(x => isFinite(x.folga));
      return { abaixo: l.filter(x => x.folga < 0).length, total: l.length };
    },
    _doisCPsLigado: () => est.doisCPs,
  };
})();
