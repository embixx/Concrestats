/* reportar.js — o botão "Reportar problema".
 *
 * O Naor, em 24/08/2026:
 *   "Também tem uns bug que eu vejo e não falo que são de coisas que eu não
 *    tenho nem pista de o que possivelmente poderia ser."
 *
 * O que faltava não era vontade de reportar: era saber o que dizer. Este
 * arquivo guarda, desde a abertura, o que a pessoa fez (as últimas telas e
 * botões) e o que deu errado (erros da tela, pedidos ao programa que
 * falharam, avisos vermelhos). Na hora do problema, um clique monta um texto
 * pronto para colar no WhatsApp, com o que ele não tem como saber sozinho:
 * versão, edição, licença, de onde o programa está rodando, quedas.
 *
 * Nada sai daqui sozinho. O texto aparece na tela, e quem decide copiar,
 * salvar e mandar é a pessoa. Não entra o conteúdo da planilha — só o nome
 * dela e o tamanho.
 *
 * Carrega ANTES dos outros scripts: erro que acontece enquanto a tela monta
 * é justamente o que ninguém consegue descrever depois.
 */
(function () {
  'use strict';

  var MAX_PASSOS = 30;
  var MAX_ERROS = 15;
  var passos = [];
  var erros = [];
  var ofereceuReportar = false;
  var abertoEm = Date.now();

  function hora(d) {
    d = d || new Date();
    function p(n) { return (n < 10 ? '0' : '') + n; }
    return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
  }
  function curto(s, n) {
    s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
    return s.length > n ? s.slice(0, n - 1) + '…' : s;
  }
  function arquivo(url) {
    var s = String(url || '');
    var i = s.lastIndexOf('/');
    return i >= 0 ? s.slice(i + 1).split('?')[0] : s;
  }
  function passo(texto) {
    passos.push(hora() + '  ' + texto);
    if (passos.length > MAX_PASSOS) passos.shift();
  }
  // `quebrou` = erro de programa na tela (exceção que ninguém tratou). Só esse
  // oferece o "Reportar" na hora. Pedido recusado pelo programa (licença
  // inválida, versão que não é nova) já tem a sua própria mensagem na tela —
  // oferecer por cima seria dizer a mesma coisa duas vezes. Vai para o
  // relatório, mas quieto.
  function erro(texto, quebrou) {
    var linha = hora() + '  ' + texto;
    // o mesmo erro em rajada vira uma linha só, com a contagem
    var ult = erros[erros.length - 1];
    if (ult && ult.texto === texto) { ult.vezes++; return; }
    erros.push({ linha: linha, texto: texto, vezes: 1 });
    if (erros.length > MAX_ERROS) erros.shift();
    if (quebrou) oferecer();
  }

  // Erros que o Chromium dispara sem que nada esteja errado. Mostrar "algo
  // deu errado" por causa deles ensinaria a ignorar o aviso.
  function inofensivo(msg) {
    return /ResizeObserver loop/i.test(msg || '') || /^Script error\.?$/i.test(msg || '');
  }

  // ── o que deu errado ────────────────────────────────────────────────────
  window.addEventListener('error', function (ev) {
    // recurso que não carregou (script, imagem) chega aqui sem mensagem
    if (ev && ev.target && ev.target !== window && (ev.target.src || ev.target.href)) {
      erro('não carregou: ' + arquivo(ev.target.src || ev.target.href));
      return;
    }
    var msg = (ev && ev.message) || 'erro sem mensagem';
    if (inofensivo(msg)) return;
    var onde = ev && ev.filename ? ' (' + arquivo(ev.filename) + ':' + (ev.lineno || '?') + ')' : '';
    erro(curto(msg, 160) + onde, true);
  }, true);

  window.addEventListener('unhandledrejection', function (ev) {
    var r = ev && ev.reason;
    var msg = r && r.message ? r.message : String(r);
    if (inofensivo(msg)) return;
    erro('falhou sem aviso: ' + curto(msg, 160), true);
  });

  var consoleErrorOriginal = console.error;
  console.error = function () {
    try {
      var partes = Array.prototype.map.call(arguments, function (a) {
        return a && a.message ? a.message : (typeof a === 'string' ? a : '');
      }).join(' ');
      if (partes && !inofensivo(partes)) {
        var t = hora() + '  console: ' + curto(partes, 160);
        erros.push({ linha: t, texto: t, vezes: 1 });
        if (erros.length > MAX_ERROS) erros.shift();
      }
    } catch (e) { /* registrar não pode quebrar quem registra */ }
    return consoleErrorOriginal.apply(console, arguments);
  };

  // ── o que a pessoa fez ──────────────────────────────────────────────────
  document.addEventListener('click', function (ev) {
    var el = ev.target && ev.target.closest
      ? ev.target.closest('button, [data-module], [role="button"], a, .prev-aba, .ctx-item')
      : null;
    if (!el || el.classList.contains('btn-reportar') || el.closest('#rep-caixa')) return;
    if (el.dataset && el.dataset.module) {
      passo('abriu a aba ' + curto(el.textContent, 30));
      return;
    }
    var rotulo = curto(el.getAttribute('title') || el.textContent || el.getAttribute('aria-label'), 50);
    if (rotulo) passo('clicou "' + rotulo + '"');
  }, true);

  document.addEventListener('DOMContentLoaded', function () {
    // Os outros scripts já rodaram: dá para embrulhar o que eles criaram.
    if (typeof window.toast === 'function') {
      var toastOriginal = window.toast;
      window.toast = function (msg, tipo, acao) {
        if (tipo === 'error') passo('aviso vermelho: ' + curto(msg, 90));
        return toastOriginal.apply(this, arguments);
      };
      window.showToast = window.toast;
    }

    if (typeof window.fetch === 'function') {
      var fetchAnterior = window.fetch;
      window.fetch = function (entrada, opcoes) {
        var url = typeof entrada === 'string' ? entrada : (entrada && entrada.url) || '';
        var caminho = url.replace(/^https?:\/\/[^/]+/, '').split('?')[0];
        var metodo = ((opcoes && opcoes.method) || 'GET').toUpperCase();
        // a batida de coração da tela: a cada 30 s, ruído puro
        // a propria busca do relatorio tambem nao entra: no aparelho (APK)
        // essa rota nao existe, e o relatorio acusaria a si mesmo
        var ruido = caminho === '/api/sinal' || caminho === '/api/diagnostico';
        return fetchAnterior.apply(this, arguments).then(function (r) {
          if (!ruido && r && !r.ok) {
            erro('o programa respondeu ' + r.status + ' em ' + metodo + ' ' + caminho);
          }
          return r;
        }, function (e) {
          if (!ruido) erro('sem resposta em ' + metodo + ' ' + (caminho || url) + ': ' + curto(e && e.message, 80));
          throw e;
        });
      };
    }

    montarBotoes();
    passo('programa aberto');
  });

  // ── o botão, em todas as telas ──────────────────────────────────────────
  // Cada tela tem a sua barra de cima, copiada à mão — oito cópias. Pôr o
  // botão no HTML seria a nona chance de uma ficar diferente das outras (foi
  // assim que a aba Previsão apareceu duas vezes). Então ele entra por aqui,
  // em todas de uma vez.
  function montarBotoes() {
    document.querySelectorAll('.topbar-right').forEach(function (barra) {
      if (barra.querySelector('.btn-reportar')) return;
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'btn-reportar';
      b.title = 'Algo estranho? Monta um texto com o que aconteceu, pronto para mandar';
      b.textContent = 'Reportar problema';
      b.addEventListener('click', abrir);
      barra.appendChild(b);
    });
  }

  // Na hora do erro, oferecer — uma vez por abertura, e não nos primeiros
  // segundos (o que falha enquanto a tela monta costuma se resolver sozinho
  // na mesma abertura, e um aviso vermelho logo de cara assusta à toa).
  function oferecer() {
    if (ofereceuReportar) return;
    if (Date.now() - abertoEm < 4000) return;
    if (typeof window.toast !== 'function') return;
    ofereceuReportar = true;
    setTimeout(function () {
      window.toast('Algo não saiu como deveria nesta tela.', 'error',
                   { texto: 'Reportar', fn: abrir });
    }, 300);
  }

  // ── o texto ─────────────────────────────────────────────────────────────
  function telaAtual() {
    var b = document.querySelector('.nav-btn.active[data-module]');
    var vis = Array.prototype.filter.call(document.querySelectorAll('.nav-btn.active[data-module]'),
      function (x) { return x.offsetParent !== null; });
    return curto((vis[0] || b || {}).textContent || '?', 30);
  }

  function planilhaAtual() {
    try {
      if (typeof state === 'undefined' || !state.activeSheet) return 'nenhuma aberta';
      var total = (state.data || []).length;
      var vistas = state.filterActive ? (state.filteredData || []).length : total;
      var partes = [curto(state.activeSheet, 60)];
      partes.push(total.toLocaleString('pt-BR') + ' linhas');
      partes.push((state.headers || []).length + ' colunas');
      if (state.filterActive) {
        partes.push((state.filters || []).length + ' filtro(s), ' +
                    vistas.toLocaleString('pt-BR') + ' linhas visíveis');
      }
      var origem = window.__concreSourcePath ? arquivo(String(window.__concreSourcePath).replace(/\\/g, '/')) : '';
      if (origem && origem !== state.activeSheet) partes.push('arquivo ' + curto(origem, 60));
      return partes.join(' · ');
    } catch (e) { return '?'; }
  }

  function montarTexto(descricao, d) {
    d = d || {};
    var lic = d.licenca || {};
    var L = [];
    L.push('*Problema no Concrestats*');
    L.push('Quando: ' + (d.agora || new Date().toLocaleString('pt-BR')));
    L.push('O que aconteceu: ' + (descricao ? descricao : '(não descrito)'));
    L.push('');
    L.push('Tela: ' + telaAtual());
    L.push('Planilha: ' + planilhaAtual());
    if (d.versao) {
      L.push('Versão: ' + d.versao + ' · edição ' + (d.edicao || '?') + ' · canal ' + (d.canal || '?'));
      L.push('Licença: ' + (lic.texto || lic.estado || '?') +
             (lic.arquivo ? ' (' + lic.arquivo + ')' : '') + (lic.erro ? ' — ' + lic.erro : ''));
      L.push('Programa em: ' + (d.pasta || '?') + (d.pasta_temporaria ? '  ⚠ PASTA TEMPORÁRIA' : ''));
      L.push('Código: ' + (d.codigo_atualizado ? 'atualizado (codigo/)' : 'o que veio no programa') +
             ' · instalação ' + (d.instalacao || '?'));
      L.push('Windows: ' + (d.windows || '?'));
    } else {
      L.push('(não consegui falar com o programa para buscar versão e licença)');
    }
    L.push('Janela: ' + window.innerWidth + '×' + window.innerHeight +
           ' · ' + curto((navigator.userAgent.match(/Edg\/[\d.]+/) || [''])[0] || navigator.userAgent, 40));
    L.push('');
    L.push('Últimos passos:');
    if (passos.length) passos.slice(-15).forEach(function (p) { L.push('  ' + p); });
    else L.push('  (nenhum registrado)');
    L.push('');
    L.push('Erros na tela:');
    if (erros.length) {
      erros.forEach(function (e) { L.push('  ' + e.linha + (e.vezes > 1 ? '  (×' + e.vezes + ')' : '')); });
    } else L.push('  nenhum');
    if (d.quedas_total) {
      L.push('');
      L.push('Quedas registradas: ' + d.quedas_total);
      (d.quedas_ultimas || []).forEach(function (q) { L.push('  ' + q); });
    }
    return L.join('\n');
  }

  function buscarDiagnostico() {
    return fetch('/api/diagnostico')
      .then(function (r) { return r.ok ? r.json() : null; })
      .catch(function () { return null; });
  }

  // ── a caixa ─────────────────────────────────────────────────────────────
  function abrir() {
    if (typeof window.openModal !== 'function' && typeof openModal !== 'function') return;
    passo('abriu "Reportar problema"');
    var corpo =
      '<div id="rep-caixa" class="rep-caixa">' +
        '<label for="rep-descricao">O que você estava fazendo, e o que aconteceu?</label>' +
        '<textarea id="rep-descricao" rows="3" placeholder="Ex.: troquei para a aba Gráficos e o programa fechou"></textarea>' +
        '<p class="rep-ajuda">O resto eu preencho sozinho: a tela, a planilha aberta, os últimos ' +
        'passos, os erros e a versão. Nada é enviado — você copia e manda.</p>' +
        '<details class="rep-detalhes"><summary>Ver o que vai junto</summary>' +
          '<pre id="rep-previa">Montando…</pre></details>' +
        '<div class="rep-acoes">' +
          '<button type="button" class="secondary-btn" id="rep-salvar">Salvar em arquivo</button>' +
          '<span id="rep-resultado" class="rep-resultado"></span>' +
        '</div>' +
      '</div>';
    (window.openModal || openModal)('Reportar problema', corpo, copiar, 'modal-reportar');

    var confirmar = document.getElementById('modal-confirm');
    if (confirmar) confirmar.textContent = 'Copiar para mandar';

    var diag = null;
    var previa = document.getElementById('rep-previa');
    var desc = document.getElementById('rep-descricao');
    function atualizar() {
      if (previa) previa.textContent = montarTexto(desc ? desc.value.trim() : '', diag);
    }
    buscarDiagnostico().then(function (d) { diag = d; atualizar(); });
    if (desc) { desc.addEventListener('input', atualizar); setTimeout(function () { desc.focus(); }, 60); }

    function texto() { return montarTexto(desc ? desc.value.trim() : '', diag); }

    function resultado(msg, bom) {
      var el = document.getElementById('rep-resultado');
      if (el) { el.textContent = msg; el.className = 'rep-resultado ' + (bom ? 'bom' : 'ruim'); }
    }

    function copiar() {
      var t = texto();
      var feito = function () {
        resultado('Copiado. Cole no WhatsApp (Ctrl+V).', true);
        if (confirmar) confirmar.textContent = 'Copiado ✓';
      };
      var manual = function () {
        // sem área de transferência: seleciona o texto para Ctrl+C
        var det = document.querySelector('.rep-detalhes');
        if (det) det.open = true;
        if (previa) {
          previa.textContent = t;
          var sel = window.getSelection(), rng = document.createRange();
          rng.selectNodeContents(previa); sel.removeAllRanges(); sel.addRange(rng);
        }
        resultado('Não consegui copiar sozinho. O texto está selecionado: aperte Ctrl+C.', false);
      };
      // Primeiro o jeito antigo, ainda dentro do clique: funciona na janela do
      // programa mesmo quando a area de transferencia "moderna" pede permissao
      // e ninguem vai aparecer para dar. Depois o moderno. Por fim, deixar o
      // texto selecionado para o Ctrl+C.
      if (copiarDentroDoClique(t)) { feito(); return; }
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(t).then(feito, manual);
        } else manual();
      } catch (e) { manual(); }
    }

    function copiarDentroDoClique(t) {
      var ta = document.createElement('textarea');
      ta.value = t;
      ta.setAttribute('readonly', '');
      ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0;';
      document.body.appendChild(ta);
      ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      ta.remove();
      return ok;
    }

    var salvar = document.getElementById('rep-salvar');
    if (salvar) salvar.addEventListener('click', function () {
      salvar.disabled = true;
      fetch('/api/diagnostico/salvar', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ texto: texto() })
      }).then(function (r) { return r.json(); }).then(function (j) {
        salvar.disabled = false;
        if (j && j.success) resultado('Salvo em ' + j.arquivo, true);
        else resultado('Não consegui salvar: ' + ((j && j.error) || 'erro desconhecido'), false);
      }).catch(function (e) {
        salvar.disabled = false;
        resultado('Não consegui salvar: ' + (e && e.message), false);
      });
    });
  }

  window.ReportarProblema = {
    abrir: abrir,
    // para o Modo Teste conferir sem clicar
    _texto: function (descricao) { return buscarDiagnostico().then(function (d) { return montarTexto(descricao, d); }); },
    _passos: function () { return passos.slice(); },
    _erros: function () { return erros.map(function (e) { return e.linha; }); },
  };
})();
